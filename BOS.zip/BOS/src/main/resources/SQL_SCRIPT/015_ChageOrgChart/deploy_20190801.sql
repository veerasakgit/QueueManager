/*ALTER TABLE BOS2.t_timesheet_notes ADD COLUMN comment VARCHAR(1024) NULL;
ALTER TABLE BOS2.t_timesheet_notes ADD COLUMN timesheet_on DATETIME NULL;
ALTER TABLE BOS2.t_timesheet_notes ADD COLUMN issue_id INT(11) NULL;
ALTER TABLE BOS2.t_timesheet_notes ADD COLUMN hours INT(2) NULL;*/

UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 82;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 138;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 411;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 376;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 297;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 412;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 78;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 439;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 266;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 387;
UPDATE BOS2.t_users SET sub_section_id = 69, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 135;

UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 378;
UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 431;
UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 426;
UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 427;
UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 432;
UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 369;
UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 430;
UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 419;
UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 345;
UPDATE BOS2.t_users SET sub_section_id = 70, update_uid = 0, update_dt = NOW() WHERE sub_section_id IS NULL AND id = 362;

-- Division: SI Division =========================================================================
UPDATE BOS2.t_projects
SET actual_end_date = STR_TO_DATE('20190731', '%Y%m%d')
	, update_uid = 0
	, update_dt = NOW()
WHERE id = 1241
	AND DATE(actual_end_date) = STR_TO_DATE('20191231', '%Y%m%d');
    
UPDATE BOS2.t_tasks
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
    , update_uid = 0
	, update_dt = NOW()
WHERE id IN (6424, 6425, 6426, 6427);

UPDATE BOS2.t_task_assignees
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
WHERE task_id IN (6424, 6425, 6426, 6427);

-- Section: Open Source Technology =========================================================================
UPDATE BOS2.t_projects
SET project_name = '[Internal-Section] Open Source Technology'
	, update_uid = 0
	, update_dt = NOW()
WHERE id = 1230
	AND project_name = '[Internal-Department] Open Source Technology';
	
UPDATE BOS2.t_identify_key
SET unique_name = '[internal-section]opensourcetechnology'
	, name = '[Internal-Section] Open Source Technology'
WHERE id = 1230
	AND unique_name = '[internal-department]opensourcetechnology'
    AND name = '[Internal-Department] Open Source Technology';

UPDATE BOS2.t_projects
SET actual_end_date = STR_TO_DATE('20190731', '%Y%m%d')
	, update_uid = 0
	, update_dt = NOW()
WHERE id = 1248
	AND DATE(actual_end_date) = STR_TO_DATE('20191231', '%Y%m%d');
	
UPDATE BOS2.t_tasks
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
    , update_uid = 0
	, update_dt = NOW()
WHERE id IN (6452, 6453, 6454, 6455);

UPDATE BOS2.t_task_assignees
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
WHERE task_id IN (6452, 6453, 6454, 6455);

-- Section: Package Solution =========================================================================
UPDATE BOS2.t_projects
SET project_name = '[Internal-Section] Package Solution'
	, update_uid = 0
	, update_dt = NOW()
WHERE id = 1228
	AND project_name = '[Internal-Department] Package Solution';
	
UPDATE BOS2.t_identify_key
SET unique_name = '[internal-section]packagesolution'
	, name = '[Internal-Section] Package Solution'
WHERE id = 1228
	AND unique_name = '[internal-department]packagesolution'
    AND name = '[Internal-Department] Package Solution';
	
-- Staff: Kanokrat  =========================================================================
UPDATE BOS2.t_task_assignees SET end_dt = STR_TO_DATE('20190731', '%Y%m%d') WHERE id = 15372 AND user_id = 242 AND end_dt = STR_TO_DATE('20191231', '%Y%m%d');
UPDATE BOS2.t_task_assignees SET end_dt = STR_TO_DATE('20190731', '%Y%m%d') WHERE id = 15373 AND user_id = 242 AND end_dt = STR_TO_DATE('20191231', '%Y%m%d');
UPDATE BOS2.t_task_assignees SET end_dt = STR_TO_DATE('20190731', '%Y%m%d') WHERE id = 15374 AND user_id = 242 AND end_dt = STR_TO_DATE('20191231', '%Y%m%d');
UPDATE BOS2.t_task_assignees SET end_dt = STR_TO_DATE('20190731', '%Y%m%d') WHERE id = 15375 AND user_id = 242 AND end_dt = STR_TO_DATE('20191231', '%Y%m%d');

-- Section -> SubSection: Business Analyst =========================================================================
UPDATE BOS2.t_projects
SET actual_end_date = STR_TO_DATE('20190731', '%Y%m%d')
	, update_uid = 0
	, update_dt = NOW()
WHERE id = 1246
	AND DATE(actual_end_date) = STR_TO_DATE('20191231', '%Y%m%d');
    
UPDATE BOS2.t_tasks
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
    , update_uid = 0
	, update_dt = NOW()
WHERE id IN (6444, 6445, 6446, 6447);

UPDATE BOS2.t_task_assignees
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
WHERE task_id IN (6444, 6445, 6446, 6447);

-- Section -> SubSection: Tester/QA =========================================================================
UPDATE BOS2.t_projects
SET actual_end_date = STR_TO_DATE('20190731', '%Y%m%d')
	, update_uid = 0
	, update_dt = NOW()
WHERE id = 1247
	AND DATE(actual_end_date) = STR_TO_DATE('20191231', '%Y%m%d');
    
UPDATE BOS2.t_tasks
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
    , update_uid = 0
	, update_dt = NOW()
WHERE id IN (6448, 6449, 6450, 6451);

UPDATE BOS2.t_task_assignees
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
WHERE task_id IN (6448, 6449, 6450, 6451);

-- Department -> Section: Business Analyst =========================================================================
UPDATE BOS2.t_projects
SET project_name = '[Internal-Section] Business Analyst (Business Analyst and Tester/QA)'
	, update_uid = 0
	, update_dt = NOW()
WHERE id = 1229
	AND project_name = '[Internal-Department] Business Analyst';
	
UPDATE BOS2.t_identify_key
SET unique_name = '[internal-section]businessanalyst'
	, name = '[Internal-Section] Business Analyst (Business Analyst and Tester/QA)'
WHERE id = 1229
	AND unique_name = '[internal-department]businessanalyst'
    AND name = '[Internal-Department] Business Analyst';

-- Section: IT Helpdesk =========================================================================
UPDATE BOS2.t_tasks
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
    , update_uid = 0
	, update_dt = NOW()
WHERE id IN (6440, 6441, 6442, 6443);

UPDATE BOS2.t_task_assignees
SET end_dt = STR_TO_DATE('20190731', '%Y%m%d')
WHERE task_id IN (6440, 6441, 6442, 6443);

-- Division: R & D =========================================================================
UPDATE BOS2.t_identify_key
SET unique_name = '[internal-division]r&d'
	, name = '[Internal-Section] R & D'
WHERE id = 1221
	AND unique_name = '[internal-division]tft'
    AND name = '[Internal-Division] TFT';