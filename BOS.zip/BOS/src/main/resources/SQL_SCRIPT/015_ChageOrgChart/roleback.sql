USE bos2;

UPDATE t_users SET division_id = 35, main_dept_id = NULL, section_id = NULL, sub_section_id = NULL WHERE id = 258 AND login_id = 'chalermkiat' AND division_id = 82 AND main_dept_id = 35 AND section_id IS NULL AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 242 AND login_id = 'kanokrat' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 401 AND login_id = 'kanokrat_old' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 327 AND login_id = 'kanokratp' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 219 AND login_id = 'pawit' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 288 AND login_id = 'rujeewarntorn' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 188 AND login_id = 'subhawat' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 286 AND login_id = 'supakornk' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 87 AND login_id = 'tayat' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 206 AND login_id = 'touchchai' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 36, section_id = NULL, sub_section_id = NULL WHERE id = 409 AND login_id = 'walaiporn' AND division_id = 82 AND main_dept_id = 35 AND section_id = 36 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = NULL, sub_section_id = NULL WHERE id = 9 AND login_id = 'busara' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = NULL, sub_section_id = NULL WHERE id = 97 AND login_id = 'piyanuch' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 1 AND login_id = 'admin' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 82 AND login_id = 'autchrawalai' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 136 AND login_id = 'chutima' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 138 AND login_id = 'chutimad' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 411 AND login_id = 'duangporn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 81 AND login_id = 'Jackkrit' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 361 AND login_id = 'jariya' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 337 AND login_id = 'jiraporn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 376 AND login_id = 'kanokporns' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 297 AND login_id = 'Nath' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 400 AND login_id = 'Nath_old' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 412 AND login_id = 'nattamon' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 229 AND login_id = 'noppadon' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 422 AND login_id = 'panaree' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 228 AND login_id = 'pannarai' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 78 AND login_id = 'parichatp' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 405 AND login_id = 'parichatp_old' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 439 AND login_id = 'paweena' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 328 AND login_id = 'perapavee' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 398 AND login_id = 'sarocha' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 266 AND login_id = 'siriphen' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 387 AND login_id = 'thanipha' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 322 AND login_id = 'varayupat' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 69, sub_section_id = NULL WHERE id = 135 AND login_id = 'warunee' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 69;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 378 AND login_id = 'ampon' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 414 AND login_id = 'aniwatt' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 381 AND login_id = 'apicheta' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 418 AND login_id = 'arucha' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 431 AND login_id = 'chattraporn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 347 AND login_id = 'chayut' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 305 AND login_id = 'danu' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 220 AND login_id = 'ekkasit' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 388 AND login_id = 'kanyanut' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 329 AND login_id = 'Khwanchanok' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 332 AND login_id = 'nantaporn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 426 AND login_id = 'naratip' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 365 AND login_id = 'narisa' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 415 AND login_id = 'natcholakorn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 427 AND login_id = 'natnicha' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 432 AND login_id = 'nattapatj' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 379 AND login_id = 'passareeya' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 318 AND login_id = 'patthamaporn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 369 AND login_id = 'pharadee' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 373 AND login_id = 'pongsatorn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 372 AND login_id = 'poompavis' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 390 AND login_id = 'poonyamon' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 370 AND login_id = 'pritsana' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 430 AND login_id = 'saisuda' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 374 AND login_id = 'saksit' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 360 AND login_id = 'saranyoo' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 419 AND login_id = 'savitree' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 285 AND login_id = 'supachaip' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 345 AND login_id = 'supaporns' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 408 AND login_id = 'supaporns_old' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 356 AND login_id = 'supapun' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 371 AND login_id = 'supravit' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 362 AND login_id = 'teepakorn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 37, section_id = 70, sub_section_id = NULL WHERE id = 308 AND login_id = 'waraporn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 37 AND sub_section_id = 70;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = NULL, sub_section_id = NULL WHERE id = 397 AND login_id = 'admins' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = NULL, sub_section_id = NULL WHERE id = 38 AND login_id = 'denvit' AND division_id = 82 AND main_dept_id = 35 AND section_id IS NULL AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = NULL, sub_section_id = NULL WHERE id = 57 AND login_id = 'patinan' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 380 AND login_id = 'aekkalak' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 261 AND login_id = 'aneak' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 11 AND login_id = 'apichat' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 403 AND login_id = 'apichat_old' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 296 AND login_id = 'apichet' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 131 AND login_id = 'arnon' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 218 AND login_id = 'asadawoot' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 189 AND login_id = 'attasit' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 48 AND login_id = 'auttapol' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 389 AND login_id = 'bandid' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 73 AND login_id = 'chaiwat_s' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 284 AND login_id = 'chaiwaty' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 333 AND login_id = 'chatchayuth' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 417 AND login_id = 'chula' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 238 AND login_id = 'jirayus' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 335 AND login_id = 'kampon' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 264 AND login_id = 'manat' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 74 AND login_id = 'poobase' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 404 AND login_id = 'poobase_old' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 50 AND login_id = 'pornarong' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 323 AND login_id = 'pornpimol' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 351 AND login_id = 'pornpong' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 287 AND login_id = 'rawiwanw' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 277 AND login_id = 'saowanee' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 407 AND login_id = 'surachet' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 295 AND login_id = 'suriwong' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 366 AND login_id = 'tongta' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 309 AND login_id = 'veerasak' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 402 AND login_id = 'veerasak_old' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 375 AND login_id = 'wasan' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 71, sub_section_id = NULL WHERE id = 249 AND login_id = 'wirawut' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 72, sub_section_id = NULL WHERE id = 382 AND login_id = 'natthakit' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 72, sub_section_id = NULL WHERE id = 289 AND login_id = 'natthakit_old' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 72, sub_section_id = NULL WHERE id = 306 AND login_id = 'premthip' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 38, section_id = 72, sub_section_id = NULL WHERE id = 59 AND login_id = 'surachart' AND division_id = 82 AND main_dept_id = 35 AND section_id = 38 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 436 AND login_id = 'athapol' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 267 AND login_id = 'auttawut' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 108 AND login_id = 'chutiphon' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 294 AND login_id = 'marutphong' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 444 AND login_id = 'marutphong_old' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 16 AND login_id = 'nichaphat' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 346 AND login_id = 'nipun' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 163 AND login_id = 'nirut' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 317 AND login_id = 'phattareeda' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 334 AND login_id = 'pimnada' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 262 AND login_id = 'rattikarn' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 271 AND login_id = 'saowarod' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 182 AND login_id = 'somchat' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 330 AND login_id = 'sorose' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 377 AND login_id = 'theerawat' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 212 AND login_id = 'wanchai' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 35, main_dept_id = 39, section_id = NULL, sub_section_id = NULL WHERE id = 324 AND login_id = 'wannarat' AND division_id = 82 AND main_dept_id = 83 AND section_id = 39 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 437 AND login_id = 'akkarawat' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 68 AND login_id = 'chaipat' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 425 AND login_id = 'chakkrid' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 90 AND login_id = 'chalit' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 175 AND login_id = 'eksuchon' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 55 AND login_id = 'jaran' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 298 AND login_id = 'kittipong' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 64 AND login_id = 'kittisak' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 29 AND login_id = 'nuntawat' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 67 AND login_id = 'seksan' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 178 AND login_id = 'sunari' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 350 AND login_id = 'thawatchai' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 65, sub_section_id = NULL WHERE id = 364 AND login_id = 'wanlop' AND division_id = 82 AND main_dept_id = 46 AND section_id = 65 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 66, sub_section_id = NULL WHERE id = 32 AND login_id = 'arthit' AND division_id = 82 AND main_dept_id = 46 AND section_id = 66 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 66, sub_section_id = NULL WHERE id = 70 AND login_id = 'mongkol' AND division_id = 82 AND main_dept_id = 46 AND section_id = 66 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 66, sub_section_id = NULL WHERE id = 7 AND login_id = 'supamit_k' AND division_id = 82 AND main_dept_id = 46 AND section_id = 66 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 66, sub_section_id = NULL WHERE id = 71 AND login_id = 'supamitt' AND division_id = 82 AND main_dept_id = 46 AND section_id = 66 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 66, sub_section_id = NULL WHERE id = 386 AND login_id = 'surat' AND division_id = 82 AND main_dept_id = 46 AND section_id = 66 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 47, section_id = 66, sub_section_id = NULL WHERE id = 443 AND login_id = 'waruh' AND division_id = 82 AND main_dept_id = 46 AND section_id = 66 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 48, section_id = 67, sub_section_id = NULL WHERE id = 84 AND login_id = 'apichit' AND division_id = 41 AND main_dept_id = 78 AND section_id = 79 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 48, section_id = 67, sub_section_id = NULL WHERE id = 275 AND login_id = 'kittisaka' AND division_id = 41 AND main_dept_id = 78 AND section_id = 79 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 48, section_id = 67, sub_section_id = NULL WHERE id = 276 AND login_id = 'sontaya' AND division_id = 41 AND main_dept_id = 78 AND section_id = 79 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 48, section_id = 67, sub_section_id = NULL WHERE id = 280 AND login_id = 'thanakornp' AND division_id = 41 AND main_dept_id = 78 AND section_id = 79 AND sub_section_id IS NULL;
UPDATE t_users SET division_id = 46, main_dept_id = 64, section_id = NULL, sub_section_id = NULL WHERE id = 353 AND login_id = 'kobchai' AND division_id = 82 AND main_dept_id IS NULL AND section_id IS NULL AND sub_section_id IS NULL;

/*==========================================================================================================================================*/

UPDATE t_projects SET project_name = '[Internal-Division] Application & Data Services' WHERE ID = 1217;
UPDATE t_projects SET project_name = '[Internal-Division] Infrastructure Business' WHERE ID = 1219;
UPDATE t_projects SET project_name = '[Internal-Division] R&D' WHERE ID = 1221;
UPDATE t_projects SET project_name = '[Internal-Department] Development Operation ' WHERE ID = 1311;

/*==========================================================================================================================================*/

ALTER TABLE t_users DROP COLUMN sub_section_id;
/*SELECT * FROM t_users;*/

UPDATE t_departments SET parent_id = NULL WHERE id = 81 AND dept_code = '18200' AND parent_id = 1;
/*SELECT * FROM bos2.t_departments WHERE id = 81 AND dept_code = '18200' AND parent_id IS NULL;*/

UPDATE t_departments SET parent_id = NULL WHERE id = 73 AND dept_code = '17700' AND parent_id = 1;
/*SELECT * FROM bos2.t_departments WHERE id = 73 AND dept_code = '17700' AND parent_id IS NULL;*/

UPDATE t_departments SET parent_id = NULL WHERE id = 41 AND dept_code = '17600' AND parent_id = 1;
/*SELECT * FROM bos2.t_departments WHERE id = 41 AND dept_code = '17600' AND parent_id IS NULL;*/

UPDATE t_departments SET dept_type = 3 WHERE id = 70 AND dept_code = '17542' AND dept_type = 4;
/*SELECT * FROM bos2.t_departments WHERE id = 70 AND dept_code = '17542' AND dept_type = 3;*/

UPDATE t_departments SET dept_type = 3 WHERE id = 69 AND dept_code = '17541' AND dept_type = 4;
/*SELECT * FROM bos2.t_departments WHERE id = 69 AND dept_code = '17541' AND dept_type = 3;*/

UPDATE t_departments SET dept_type = 2, parent_id = 35 WHERE id = 37 AND dept_code = '17540' AND dept_type = 3 AND parent_id = 83;
/*SELECT * FROM bos2.t_departments WHERE id = 37 AND dept_code = '17540' AND dept_type = 2 AND parent_id = 35;*/

UPDATE t_departments SET dept_type = 2, parent_id = 35 WHERE id = 39 AND dept_code = '17560' AND dept_type = 3 AND parent_id = 83;
/*SELECT * FROM bos2.t_departments WHERE id = 39 AND dept_code = '17560' AND dept_type = 2 AND parent_id = 35;*/

UPDATE t_departments SET dept_type = 2 WHERE id = 38 AND dept_code = '17570' AND dept_type = 3;
/*SELECT * FROM bos2.t_departments WHERE id = 38 AND dept_code = '17570' AND dept_type = 2;*/

INSERT INTO t_departments (id, dept_code, dept_name, dept_type, parent_id, create_dt, create_uid) VALUES (71, '17571', 'System Analyst', 3, 38, now(), 0);
/*SELECT * FROM t_departments WHERE id = 71 AND dept_code = '17571';*/

INSERT INTO t_departments (id, dept_code, dept_name, dept_type, parent_id, create_dt, create_uid) VALUES (72, '17572', 'System Analyst', 3, 38, now(), 0);
/*SELECT * FROM t_departments WHERE id = 72 AND dept_code = '17572';*/

UPDATE t_departments SET dept_type = 2 WHERE id = 36 AND dept_code = '17550' AND dept_type = 3;
/*SELECT * FROM bos2.t_departments WHERE id = 36 AND dept_code = '17550' AND dept_type = 2;*/

INSERT INTO t_departments (id, dept_code, dept_name, dept_type, parent_id, create_dt, create_uid) VALUES (49, '17510', 'Application & Data Services Management', 2, 35, now(), 0);
/*SELECT * FROM t_departments WHERE id = 49 AND dept_code = '17510';*/

UPDATE t_departments SET dept_name = 'Application & Data Services', dept_type = 1, parent_id = 1 WHERE id = 35 AND dept_code = '17500' AND dept_name = 'Application Development' AND dept_type = 2 AND parent_id = 82;
/*SELECT * FROM bos2.t_departments WHERE id = 35 AND dept_code = '17500' AND dept_type = 1 AND parent_id = 1;*/

INSERT INTO t_departments (id, dept_code, dept_name, dept_type, parent_id, create_dt, create_uid) VALUES (63, '17440', 'Cloud Services', 2, 46, now(), 0);
/*SELECT * FROM t_departments WHERE id = 63 AND dept_code = '17440';*/

INSERT INTO t_departments (id, dept_code, dept_name, dept_type, parent_id, create_dt, create_uid) VALUES (48, '17430', 'IT Services', 2, 46, now(), 0);
/*SELECT * FROM t_departments WHERE id = 48 AND dept_code = '17430';*/

INSERT INTO t_departments (id, dept_code, dept_name, dept_type, parent_id, create_dt, create_uid) VALUES (67, '17431', 'IT Support', 3, 48, now(), 0);
/*SELECT * FROM t_departments WHERE id = 67 AND dept_code = '17431';*/

INSERT INTO t_departments (id, dept_code, dept_name, dept_type, parent_id, create_dt, create_uid) VALUES (68, '17432', 'IT Helpdesk', 3, 48, now(), 0);
/*SELECT * FROM t_departments WHERE id = 68 AND dept_code = '17432';*/

INSERT INTO t_departments (id, dept_code, dept_name, dept_type, parent_id, create_dt, create_uid) VALUES (47, '17420', 'System Integration', 2, 46, now(), 0);
/*SELECT * FROM bos2.t_departments WHERE id = 47 AND dept_code = '17420';*/

INSERT INTO t_departments (id, dept_code, dept_name, dept_type, parent_id, create_dt, create_uid) VALUES (64, '17410', 'Infrastructure Business Management', 2, 46, now(), 0);
/*SELECT * FROM bos2.t_departments WHERE id = 64 AND dept_code = '17410';*/

UPDATE t_departments SET parent_id = 47 WHERE id = 66 AND dept_code = '17422' AND parent_id = 46;
/*SELECT * FROM bos2.t_departments WHERE id = 66 AND dept_code = '17422';*/

UPDATE t_departments SET parent_id = 47 WHERE id = 65 AND dept_code = '17421' AND parent_id = 46;
/*SELECT * FROM bos2.t_departments WHERE id = 65 AND dept_code = '17421';*/

UPDATE t_departments SET dept_name = 'Infrastructure Business', dept_type = 1, parent_id = 1 WHERE id = 46 AND dept_code = '17400' AND dept_name = 'CC & Infrastructure Business' AND dept_type = 2 AND parent_id = 82;
/*SELECT * FROM bos2.t_departments WHERE id = 46 AND dept_code = '17400';*/

DELETE FROM t_departments WHERE id = 82 AND dept_code = '18300' AND dept_name = 'SI Division' AND dept_type = 1;
/*SELECT * FROM t_departments WHERE id = 82 AND dept_code = '18300' AND dept_name = 'SI Division' AND dept_type = 1;*/

DELETE FROM t_codebook_langs WHERE code_type = 'DEPARTMENT_TYPE' AND code_id = 4 AND code_name = 'Sub-Section';
/*SELECT * FROM t_codebook_langs WHERE code_type = 'DEPARTMENT_TYPE' AND code_id = 4, AND code_name = 'Sub-Section';*/