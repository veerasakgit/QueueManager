-- Update: Sittichai  Pumpetch ===================================================================================
/*UPDATE BOS2.t_time_entries SET time_status = 3, hours = 0 WHERE id = 159233 AND user_id = 22;

INSERT INTO BOS2.t_time_entries
(task_id, user_id, project_id, hours, time_status, spent_on, create_uid, create_dt, submitted_uid, submitted_dt, approved_uid, approved_dt) 
VALUES
(6351, 22, 1222,  8.0, 4, STR_TO_DATE('20190618', '%Y%m%d'), 1, NOW(), 1, NOW(), 1, NOW());

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1222, 6351, 8.0, 22, STR_TO_DATE('20190618', '%Y%m%d'), 'Leave record from HR', 1, NOW() );
 
UPDATE BOS2.t_leave
SET current_status = 3
	, approve_user_id = 1
	, approve_dt = NOW()
	, update_user_id = 1
	, update_date = NOW()
WHERE id = 4064
	AND user_id = 22;*/
	
-- Update: Jirabha  Navalertpreecha ===================================================================================
/*UPDATE BOS2.t_time_entries
SET time_status = 4
	, approve_user_id = 1
	, approve_dt = NOW()
WHERE id = 139775 AND user_id = 40;

UPDATE BOS2.t_leave
SET current_status = 3
	, leave_hour = 4.0
	, approve_user_id = 1
	, approve_dt = NOW()
	, update_user_id = 1
	, update_date = NOW()
WHERE id = 3615
	AND user_id = 40;*/
	
-- ===============
/*UPDATE BOS2.t_time_entries SET time_status = 4, approve_user_id = 1, approve_dt = NOW() WHERE id = 164958 AND project_id = 1214 AND task_id = 6319 AND user_id = 40;
UPDATE BOS2.t_time_entries SET time_status = 4, approve_user_id = 1, approve_dt = NOW() WHERE id = 164959 AND project_id = 1214 AND task_id = 6319 AND user_id = 40;
UPDATE BOS2.t_time_entries SET time_status = 4, approve_user_id = 1, approve_dt = NOW() WHERE id = 164960 AND project_id = 1214 AND task_id = 6319 AND user_id = 40;
UPDATE BOS2.t_time_entries SET time_status = 4, approve_user_id = 1, approve_dt = NOW() WHERE id = 164961 AND project_id = 1214 AND task_id = 6319 AND user_id = 40;
UPDATE BOS2.t_time_entries SET time_status = 4, approve_user_id = 1, approve_dt = NOW() WHERE id = 164962 AND project_id = 1214 AND task_id = 6319 AND user_id = 40;

UPDATE BOS2.t_time_entries SET time_status = 4, approve_user_id = 1, approve_dt = NOW() WHERE id = 164963 AND project_id = 1214 AND task_id = 6319 AND user_id = 40;
UPDATE BOS2.t_time_entries SET time_status = 4, approve_user_id = 1, approve_dt = NOW() WHERE id = 164964 AND project_id = 1214 AND task_id = 6319 AND user_id = 40;
UPDATE BOS2.t_time_entries SET time_status = 4, approve_user_id = 1, approve_dt = NOW() WHERE id = 164965 AND project_id = 1214 AND task_id = 6319 AND user_id = 40;
UPDATE BOS2.t_time_entries SET time_status = 4, approve_user_id = 1, approve_dt = NOW() WHERE id = 164966 AND project_id = 1214 AND task_id = 6319 AND user_id = 40;*/

UPDATE BOS2.t_leave
SET current_status = 3
	, approve_user_id = 1
	, approve_dt = NOW()
	, update_user_id = 1
	, update_date = NOW()
WHERE id = 4101
	AND user_id = 40;
	
-- Add: Priyapatt  Achamahatt ===================================================================================
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1214, 37, 6319, 8.0, STR_TO_DATE('20190121', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1214, 6319, 8.0, 37, STR_TO_DATE('20190121', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

-- =====
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1214, 37, 6319, 8.0, STR_TO_DATE('20190122', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1214, 6319, 8.0, 37, STR_TO_DATE('20190122', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

-- =====
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1214, 37, 6319, 8.0, STR_TO_DATE('20190805', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1214, 6319, 8.0, 37, STR_TO_DATE('20190805', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

-- =====
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1214, 37, 6319, 4.0, STR_TO_DATE('20190118', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1214, 6319, 4.0, 37, STR_TO_DATE('20190118', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

-- =====
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1214, 37, 6319, 8.0, STR_TO_DATE('20190304', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1214, 6319, 8.0, 37, STR_TO_DATE('20190304', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

-- =====
INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(37, STR_TO_DATE('20190121 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190122 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 16, 3, NOW(), 37, NOW(), 1, NOW(), 37);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(37, STR_TO_DATE('20190805 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190805 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 37, NOW(), 1, NOW(), 37);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(37, STR_TO_DATE('20190118 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190118 1200', '%Y%m%d %H%i'), 4, 'Leave record from HR', 4, 3, NOW(), 37, NOW(), 1, NOW(), 37);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(37, STR_TO_DATE('20190304 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190304 1730', '%Y%m%d %H%i'), 4, 'Leave record from HR', 8, 3, NOW(), 37, NOW(), 1, NOW(), 37);

-- Add/Update: Taweechon Pongsiri ===================================================================================
UPDATE BOS2.t_time_entries SET time_status = 4, update_dt = NOW(), update_uid = 0, approved_dt = NOW(), approved_uid = 1 WHERE id = 163038 AND user_id = 201 AND task_id = 6367;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1226, 6367, 8.0, 201, STR_TO_DATE('20190715', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(201, STR_TO_DATE('20190715 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190715 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 201, NOW(), 1, NOW(), 201);

-- Add: Jirabha  Navalertpreecha ===================================================================================
/*INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(40, STR_TO_DATE('20190124 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190124 1200', '%Y%m%d %H%i'), 1, 'Leave record from HR', 4, 3, NOW(), 40, NOW(), 1, NOW(), 40);*/

-- Add/Update: Pavinee Piambunchong ===================================================================================
UPDATE BOS2.t_time_entries SET time_status = 4, approved_dt = NOW(), approved_uid = 1, update_dt = NOW(), update_uid = 1 WHERE id = 149083 AND user_id = 290 AND task_id = 6359;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1224, 6359, 8.0, 290, STR_TO_DATE('20190312', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(290, STR_TO_DATE('20190312 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190312 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 290, NOW(), 1, NOW(), 290);

-- ===============
UPDATE BOS2.t_time_entries SET time_status = 4, approved_dt = NOW(), approved_uid = 1, update_dt = NOW(), update_uid = 1 WHERE id = 157695 AND user_id = 290 AND task_id = 6359;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1224, 6359, 8.0, 290, STR_TO_DATE('20190507', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

UPDATE bos2.t_time_entries SET time_status = 4, approved_dt = NOW(), approved_uid = 1, update_dt = NOW(), update_uid = 1 WHERE id = 157696 AND user_id = 290 AND task_id = 6359;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1224, 6359, 8.0, 290, STR_TO_DATE('20190508', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(290, STR_TO_DATE('20190507 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190508 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 16, 3, NOW(), 290, NOW(), 1, NOW(), 290);

-- ===============
UPDATE BOS2.t_time_entries SET time_status = 4, approved_dt = NOW(), approved_uid = 1, update_dt = NOW(), update_uid = 1 WHERE id = 164292 AND user_id = 290 AND task_id = 6359;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1224, 6359, 8.0, 290, STR_TO_DATE('20190712', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

UPDATE BOS2.t_time_entries SET time_status = 4, approved_dt = NOW(), approved_uid = 1, update_dt = NOW(), update_uid = 1 WHERE id = 164293 AND user_id = 290 AND task_id = 6359;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1224, 6359, 8.0, 290, STR_TO_DATE('20190715', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(290, STR_TO_DATE('20190712 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190712 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 290, NOW(), 1, NOW(), 290);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(290, STR_TO_DATE('20190715 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190715 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 290, NOW(), 1, NOW(), 290);

-- ===============
UPDATE BOS2.t_time_entries SET time_status = 4, approved_dt = NOW(), approved_uid = 1, update_dt = NOW(), update_uid = 1 WHERE id = 145268 AND user_id = 290 AND task_id = 6359;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1224, 6359, 2.0, 290, STR_TO_DATE('20190206', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(290, STR_TO_DATE('20190206 1530', '%Y%m%d %H%i'), STR_TO_DATE('20190206 1730', '%Y%m%d %H%i'), 4, 'Leave record from HR', 2, 3, NOW(), 290, NOW(), 1, NOW(), 290);

-- Add/Update: Sittichai  Pumpetch ===================================================================================
UPDATE BOS2.t_time_entries SET time_status = 4, approved_dt = NOW(), approved_uid = 1, update_dt = NOW(), update_uid = 1 WHERE id = 147584 AND user_id = 22 AND task_id = 6351;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1222, 6351, 8.0, 22, STR_TO_DATE('20190314', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

UPDATE BOS2.t_time_entries SET time_status = 4, approved_dt = NOW(), approved_uid = 1, update_dt = NOW(), update_uid = 1 WHERE id = 147585 AND user_id = 22 AND task_id = 6351;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1222, 6351, 8.0, 22, STR_TO_DATE('20190315', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

UPDATE BOS2.t_time_entries SET time_status = 4, approved_dt = NOW(), approved_uid = 1, update_dt = NOW(), update_uid = 1 WHERE id = 147586 AND user_id = 22 AND task_id = 6351;

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id , hour, user_id, note_date , note_detail , create_uid, create_dt  ) 
VALUES
(1, 1222, 6351, 8.0, 22, STR_TO_DATE('20190318', '%Y%m%d'), 'Leave record from HR', 1, NOW() );

-- ===============
INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(22, STR_TO_DATE('20190314 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190315 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 16, 3, NOW(), 22, NOW(), 1, NOW(), 22);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(22, STR_TO_DATE('20190318 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190318 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 22, NOW(), 1, NOW(), 22);

-- Add/Update: Pen  Nantayod ===================================================================================
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 395, 6363, 8.0, STR_TO_DATE('20190417', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 395, STR_TO_DATE('20190417', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 395, 6363, 8.0, STR_TO_DATE('20190418', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 395, STR_TO_DATE('20190418', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 395, 6363, 8.0, STR_TO_DATE('20190419', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 395, STR_TO_DATE('20190419', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(395, STR_TO_DATE('20190417 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190419 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 24, 3, NOW(), 395, NOW(), 1, NOW(), 395);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 395, 6363, 8.0, STR_TO_DATE('20190621', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 395, STR_TO_DATE('20190621', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(395, STR_TO_DATE('20190621 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190621 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 395, NOW(), 1, NOW(), 395);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 395, 6363, 8.0, STR_TO_DATE('20190715', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 395, STR_TO_DATE('20190715', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(395, STR_TO_DATE('20190715 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190715 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 395, NOW(), 1, NOW(), 395);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 395, 6363, 8.0, STR_TO_DATE('20190805', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 395, STR_TO_DATE('20190805', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(395, STR_TO_DATE('20190805 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190805 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 395, NOW(), 1, NOW(), 395);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 395, 6363, 8.0, STR_TO_DATE('20190228', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 395, STR_TO_DATE('20190228', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(395, STR_TO_DATE('20190228 1300', '%Y%m%d %H%i'), STR_TO_DATE('20190228 1730', '%Y%m%d %H%i'), 4, 'Leave record from HR', 4, 3, NOW(), 395, NOW(), 1, NOW(), 395);

-- Add/Update: Yupa  Namsom ===================================================================================
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 392, 6363, 8.0, STR_TO_DATE('20190307', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 392, STR_TO_DATE('20190307', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 392, 6363, 8.0, STR_TO_DATE('20190308', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 392, STR_TO_DATE('20190308', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(392, STR_TO_DATE('20190307 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190308 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 16, 3, NOW(), 392, NOW(), 1, NOW(), 392);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 392, 6363, 8.0, STR_TO_DATE('20190325', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 392, STR_TO_DATE('20190325', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(392, STR_TO_DATE('20190325 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190325 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 392, NOW(), 1, NOW(), 392);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 392, 6363, 8.0, STR_TO_DATE('20190509', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 392, STR_TO_DATE('20190509', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(392, STR_TO_DATE('20190509 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190509 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 392, NOW(), 1, NOW(), 392);

-- Add/Update: Sawin  Duangsa ===================================================================================
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 393, 6363, 8.0, STR_TO_DATE('20190102', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 393, STR_TO_DATE('20190102', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(393, STR_TO_DATE('20190102 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190102 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 393, NOW(), 1, NOW(), 393);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 393, 6363, 8.0, STR_TO_DATE('20190510', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 393, STR_TO_DATE('20190510', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(393, STR_TO_DATE('20190510 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190510 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 393, NOW(), 1, NOW(), 393);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 393, 6363, 8.0, STR_TO_DATE('20190513', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 393, STR_TO_DATE('20190513', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(393, STR_TO_DATE('20190513 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190513 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 393, NOW(), 1, NOW(), 393);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1225, 393, 6363, 8.0, STR_TO_DATE('20190412', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1225, 6363, 8.0, 393, STR_TO_DATE('20190412', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(393, STR_TO_DATE('20190412 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190412 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 393, NOW(), 1, NOW(), 393);

-- Add/Update: Weerapus Klankaew ===================================================================================
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1226, 394, 6367, 8.0, STR_TO_DATE('20190418', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1226, 6367, 8.0, 394, STR_TO_DATE('20190418', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1226, 394, 6367, 8.0, STR_TO_DATE('20190419', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1226, 6367, 8.0, 394, STR_TO_DATE('20190419', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(394, STR_TO_DATE('20190418 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190419 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 16, 3, NOW(), 394, NOW(), 1, NOW(), 394);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1226, 394, 6367, 8.0, STR_TO_DATE('20190523', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1226, 6367, 8.0, 394, STR_TO_DATE('20190523', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1226, 394, 6367, 8.0, STR_TO_DATE('20190524', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1226, 6367, 8.0, 394, STR_TO_DATE('20190524', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(394, STR_TO_DATE('20190523 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190524 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 16, 3, NOW(), 394, NOW(), 1, NOW(), 394);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1226, 394, 6367, 8.0, STR_TO_DATE('20190606', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1226, 6367, 8.0, 394, STR_TO_DATE('20190606', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1226, 394, 6367, 8.0, STR_TO_DATE('20190607', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1226, 6367, 8.0, 394, STR_TO_DATE('20190607', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(394, STR_TO_DATE('20190606 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190607 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 16, 3, NOW(), 394, NOW(), 1, NOW(), 394);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1226, 394, 6367, 8.0, STR_TO_DATE('20190809', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1226, 6367, 8.0, 394, STR_TO_DATE('20190809', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(394, STR_TO_DATE('20190809 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190809 1730', '%Y%m%d %H%i'), 1, 'Leave record from HR', 8, 3, NOW(), 394, NOW(), 1, NOW(), 394);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1226, 394, 6367, 8.0, STR_TO_DATE('20190225', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1226, 6367, 8.0, 394, STR_TO_DATE('20190225', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(394, STR_TO_DATE('20190225 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190225 1730', '%Y%m%d %H%i'), 4, 'Leave record from HR', 8, 3, NOW(), 394, NOW(), 1, NOW(), 394);

-- ===============
INSERT INTO BOS2.t_time_entries
(project_id, user_id, task_id, hours, spent_on, time_status, create_dt, create_uid, submitted_dt, submitted_uid, approved_dt, approved_uid)
VALUES
(1226, 394, 6367, 8.0, STR_TO_DATE('20190705', '%Y%m%d'), 4, NOW(), 1, NOW(), 1, NOW(), 1);

INSERT INTO BOS2.t_timesheet_notes
(seq, project_id, task_id, hour, user_id, note_date, note_detail, create_dt, create_uid)
VALUES
(1, 1226, 6367, 8.0, 394, STR_TO_DATE('20190705', '%Y%m%d'), 'Leave record from HR', NOW(), 1);

INSERT INTO BOS2.t_leave
(user_id, start_dt, end_dt, leave_type_id, justification, leave_hour, current_status, request_dt, request_user_id, approve_dt, approve_user_id, create_date, create_user_id)
VALUES
(394, STR_TO_DATE('20190705 0830', '%Y%m%d %H%i'), STR_TO_DATE('20190705 1730', '%Y%m%d %H%i'), 4, 'Leave record from HR', 8, 3, NOW(), 394, NOW(), 1, NOW(), 394);