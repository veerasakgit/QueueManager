package com.locus.jlo.web.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class SettingController {

	@RequestMapping(value = { "/settings" })
	public String index() {
		return "settings";
	}

	@RequestMapping(value = { "/setting_user" })
	public String setting_user() {
		return "setting_user";
	}

	@RequestMapping(value = { "/setting_department" })
	public String setting_department() {
		return "setting_department";
	}
	
	@RequestMapping(value = { "/setting_project_role" })
	public String setting_project_role() {
		return "setting_project_role";
	}
	
	@RequestMapping(value = { "/import_user" })
	public String import_user() {
		return "import_user";
	}
	
	@RequestMapping(value = { "/import_medical" })
	public String import_medical() {
		return "import_medical";
	}
 
	@RequestMapping(value = { "/setting_project_task_template" })
	public String setting_project_task_template() {
		return "setting_project_task_template";
	}
	
	@RequestMapping(value = { "/setting_privileges" })
	public String setting_privileges() {
		return "setting_privileges";
	}
	

//	@RequestMapping(value = "/testUpload", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
//	public @ResponseBody JsonResultBean testUpload(HttpServletRequest request, Locale locale) throws Exception {
//
//		Part part = request.getPart("file");
//
////		List<LinkedHashMap<String, Object>> list = PoiUtils.importExcelFileAutoMap(part.getInputStream(), 0);
////		JsonResultBean result = new JsonResultBean("success", "", list);
//
//		return null;
//	}

	@RequestMapping(value = "/testExport", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody String testExport()
			throws Exception {
				
		
		return "excel";
 
	}
	
	@RequestMapping(value = "/testExport/{file}", method = RequestMethod.GET)
	public void downloadExport(@PathVariable("file") String file, HttpServletResponse response) throws Exception {
		
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("content-disposition", "attachment; filename="+file+".xlsx");
	    
//	    OutputStream out = response.getOutputStream();
	    
//	    PoiUtils utils = new PoiUtils();
	    
//	    XSSFWorkbook workbook = PoiUtils.exportExcelFile();
//		workbook.write(out); 
//		out.flush();
//		out.close();
//		workbook.close();
	}

}