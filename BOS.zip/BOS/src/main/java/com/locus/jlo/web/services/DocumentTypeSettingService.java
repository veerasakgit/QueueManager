package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.module.DocumentTypeSettingBean;

import java.util.List;
import java.util.Map;

public interface DocumentTypeSettingService {

	ServiceResult<List<Map<String, Object>>> searchDocumentType(DocumentTypeSettingBean typeSettingBean) throws Exception;

	ServiceResult<Integer> insertDocumentType(DocumentTypeSettingBean typeSettingBean) throws Exception;
	ServiceResult<Integer> updateDocumentType(DocumentTypeSettingBean typeSettingBean) throws Exception;
	ServiceResult<Integer> removeDocumentType(Integer id) throws Exception;
}
