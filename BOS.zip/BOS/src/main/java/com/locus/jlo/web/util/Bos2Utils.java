/**
 * created-date: 2019-06-12
 * original-from: MakroAdmin project
 */

package com.locus.jlo.web.util;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public abstract class Bos2Utils {

	public static <K, V> String mapToString(Map<K, V> map) {
		StringBuilder sb = new StringBuilder();
		Iterator<Entry<K, V>> iter = map.entrySet().iterator();
		while (iter.hasNext()) {
			Entry<K, V> entry = iter.next();
			sb.append(entry.getKey());
			sb.append('=').append('"');
			sb.append(entry.getValue());
			sb.append('"');
			if (iter.hasNext()) {
				sb.append(',').append(' ');
			}
		}
		return sb.toString();

	}
	
	
	public static boolean isNullOrEmpty(String value){
		if (value != null)
		    return value.length() == 0;
		else
		    return true;
	}
	
	public static boolean isNumeric(String str)
	{
	  return str.matches("-?\\d+(\\.\\d+)?");  //match a number with optional '-' and decimal.
	}
}
