package com.locus.jlo.web.beans.assets;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AssetsBean extends StampBean {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4434821411388068367L;
	private Integer id;
	private Integer seq;
	private Integer user_id;
	private String description;
	private String asset_no;
	private String brand;
	private String serial_no;
	private Integer qty;
	private String asset_type;
	private String fullname;
	private String register_date;
	private String resign_date;
	private String first_name;
	private String last_name;
	private String dept_name;
	private String code_name;
	
	private String action;
	
//	private Integer create_uid;
//	private Date create_dt;
//	private Integer update_uid;
//	private Date update_dt;
	
}
