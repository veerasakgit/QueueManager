package com.locus.jlo.web.controller;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.util.StringUtil;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.department.DepartmentBean;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriodRes;
import com.locus.jlo.web.beans.setting.SettingChargeRateBean;
import com.locus.jlo.web.beans.setting.SettingDeptBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.SettingChargeRateService;
import com.locus.jlo.web.services.SettingDeptService;
import com.locus.jlo.web.services.impl.BaseService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class SettingChargeRateController extends CoreController {
	
	@Autowired
	private SettingChargeRateService settingChargeRateService;
	
	@RequestMapping(value = {"/setting_charge_rate"})
	public String index() {
	        return "setting_charge_rate";
	}
	
	@RequestMapping(value = {"/import_job_group"})
	public String indexImportyJobGroup() {
	        return "import_job_group";
	}
	
	@RequestMapping(value = "/searchChargeRate", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchChargeRate(HttpServletRequest request,Locale locale) throws Exception{
		
		
//		String id = request.getParameter("viewId");
		String annualYear = request.getParameter("annualYear");
		SettingChargeRateBean bean = new SettingChargeRateBean();
		bean.setAnnualYear(Integer.valueOf(annualYear));
		ServiceResult<List<SettingChargeRateBean>> listResult =  settingChargeRateService.searchSettingChargeRate(bean);
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}else {
			result = new JsonResultBean("error", "" , listResult.getResult());
		}
		return result;
	 }
	
	 @PostMapping(value = "importChargeRateFile",consumes = "multipart/form-data")
	 //@RequestMapping(value = "/", method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean importChargeRateFile( @RequestParam(value = "chargeRateFile", required = true) MultipartFile fileUpload,
             HttpServletRequest request, Locale locale) throws Exception{
	     
		 List<Object[]> list = new ArrayList<Object []>();
		 List<SettingChargeRateBean> listCr = new ArrayList<SettingChargeRateBean>();
		 JsonResultBean result = null;
		 try{
			 log.info("File path : "+fileUpload.getOriginalFilename());
			 log.info("File size : "+fileUpload.getSize());
			 list = PoiUtils.importExcelFileArr(fileUpload.getInputStream(), 2 ,7);
			 
			 
			 if(list != null) {
				 for(Object[] row : list) {
					 SettingChargeRateBean scr = new SettingChargeRateBean();
					 scr.setChargeCode(String.valueOf(row[0]));
					 scr.setJobGroup(String.valueOf(row[1]));
					 scr.setJobRank(String.valueOf(row[2]));
					 scr.setFinalCost(new BigDecimal(String.valueOf(row[3])));
					 scr.setTotalCost(new BigDecimal(String.valueOf(row[4])));
					 scr.setDirectCost(new BigDecimal(String.valueOf(row[5])));
					 scr.setSga(new BigDecimal(String.valueOf(row[6])));
					 listCr.add(scr);
				 }
			 }
			 
		 }catch(Exception e){
			 result = new JsonResultBean("error", "", list);
			 e.printStackTrace();
			 return result;
			
		 }
	
		result = new JsonResultBean("success", "", listCr);
   
		return result;
	}
	 
	 @PostMapping(value = "saveChargeRateFile",consumes = "multipart/form-data")
	 //@RequestMapping(value = "/", method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveChargeRateFile( @RequestParam(value = "chargeRateFile", required = true) MultipartFile fileUpload,
             HttpServletRequest request, Locale locale) throws Exception{
	     
		 List<Object[]> list = new ArrayList<Object []>();
		 List<SettingChargeRateBean> listCr = new ArrayList<SettingChargeRateBean>();
		 JsonResultBean result = null;
		 try{
			 log.info("File path : " + fileUpload.getOriginalFilename());
			 log.info("File size : " + fileUpload.getSize());
			 list = PoiUtils.importExcelFileArr(fileUpload.getInputStream(), 2 ,7);
			 String yearFromSheetName = PoiUtils.getSheetName(fileUpload.getInputStream(), 0);
			 Integer annualYear = null;
			 //Integer year = Calendar.getInstance().get(Calendar.YEAR);
			 try {
				 annualYear  = Integer.parseInt(yearFromSheetName);
			 } catch(Exception e) {
				 annualYear = Calendar.getInstance().get(Calendar.YEAR);
			 }
			 
			 if(list != null) {
				 SettingChargeRateBean deleteCri = new SettingChargeRateBean();
				 deleteCri.setAnnualYear(annualYear);
				 settingChargeRateService.deleteSettingChargeRate(deleteCri);
				 
				 for(Object[] row : list) {
					 SettingChargeRateBean scr = new SettingChargeRateBean();
					 scr.setChargeCode(String.valueOf(row[0]));
					 scr.setJobGroup(String.valueOf(row[1]));
					 scr.setJobRank(String.valueOf(row[2]));
					 scr.setFinalCost(new BigDecimal(String.valueOf(row[3])));
					 scr.setTotalCost(new BigDecimal(String.valueOf(row[4])));
					 scr.setDirectCost(new BigDecimal(String.valueOf(row[5])));
					 scr.setSga(new BigDecimal(String.valueOf(row[6])));
					 scr.setAnnualYear(annualYear);
					 listCr.add(scr);
				 }
				 
				 //save
				 ServiceResult<int[]> saveResult = settingChargeRateService.insertSettingChargeRate(listCr);
				 if(saveResult.isSuccess()) {
					 result = new JsonResultBean("success", String.valueOf(annualYear), saveResult.getResult());
				 }
				 
			 } else {
				 result = new JsonResultBean("error", "Cannot read Excel File Format or file is empty.",null);
			 }
			 
		 }catch(Exception e){
			 result = new JsonResultBean("error", "", e);
			 e.printStackTrace();
			 return result;
			
		 }
   
		return result;
	}
	
	 
	 @PostMapping(value = "importJobGroupFile",consumes = "multipart/form-data")
	 //@RequestMapping(value = "/", method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean importJobGroupFile( @RequestParam(value = "jobGroupFile", required = true) MultipartFile fileUpload,
             HttpServletRequest request, Locale locale) throws Exception{
		 
		 List<Object[]> list = new ArrayList<Object []>();
		 List<SettingChargeRateBean> listCr = new ArrayList<SettingChargeRateBean>();
		 JsonResultBean result = null;
		 try{
			 log.info("File path : "+fileUpload.getOriginalFilename());
			 log.info("File size : "+fileUpload.getSize());
			 list = PoiUtils.importExcelFileArr(fileUpload.getInputStream(), 1 ,19);
			 
			 
			 if(list != null) {
				 for(Object[] row : list) {
					 SettingChargeRateBean scr = new SettingChargeRateBean();
					 scr.setChargeCode(String.valueOf(row[0]));
					 scr.setJobGroup(String.valueOf(row[1]));
					 scr.setJobRank(String.valueOf(row[2]));
					 scr.setFinalCost(new BigDecimal(String.valueOf(row[3])));
					 scr.setTotalCost(new BigDecimal(String.valueOf(row[6])));
					 scr.setDirectCost(new BigDecimal(String.valueOf(row[7])));
					 scr.setSga(new BigDecimal(String.valueOf(row[8])));
					 listCr.add(scr);
				 }
			 }
			 
		 }catch(Exception e){
			 result = new JsonResultBean("error", "", list);
			 e.printStackTrace();
			 return result;
			
		 }
	
		result = new JsonResultBean("success", "", listCr);
   
		return result;
		 
	 }
	
	
	
}