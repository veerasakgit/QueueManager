package com.locus.jlo.web.services;

import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;


public interface StaffService {
	 
	ServiceResult<List<DataBean>> searchOrganize() throws Exception;

}
