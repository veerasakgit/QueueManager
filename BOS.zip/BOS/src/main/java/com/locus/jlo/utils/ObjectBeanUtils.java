package com.locus.jlo.utils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ObjectBeanUtils<T> {

	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-mm-dd"); 
	
	private Class<T> classObj;

	public ObjectBeanUtils(Class<T> tClass) {
		classObj = tClass;
	}

	public List<T> convertListMapToObject(List<Map<String, Object>> listMap) throws Exception{

		List<T> resultList = new ArrayList<>(listMap.size());

			listMap.forEach((map) -> {

				try {
					T obj = classObj.newInstance();
					
					map.forEach((key, rawVal) -> {
						
						if (rawVal != null) {
							
							Field field = null;
							
							try {
								field = obj.getClass().getDeclaredField(key);
							} catch (NoSuchFieldException | SecurityException e) {
								log.error(e+"");
							}
							if (field != null) {
								
								field.setAccessible(true);
								try {
									
									String rawStr = rawVal.toString();
									
									Object value = null;

									if (field.getType().isAssignableFrom(Integer.class)) {
										value = Integer.parseInt(rawStr);
									}
									else if (field.getType().isAssignableFrom(Long.class)) {
										value = Long.valueOf(rawStr);
									}
									else if(field.getType().isAssignableFrom(BigDecimal.class)){								
										value = new BigDecimal(rawStr);
									}

									else if(field.getType().isAssignableFrom(Date.class)) {
										
										try {
											Date date = DATE_FORMAT.parse(rawStr);
											value = date;
										} catch (ParseException e) {
											e.printStackTrace();
											value = rawVal;
										}

									}else {
										value = rawVal;
									}
																		
									field.set(obj,value);

								} catch (IllegalArgumentException | IllegalAccessException e) {
									e.printStackTrace();
								}		
								field.setAccessible(false);
								
							}

					
						}

					});
					
					resultList.add(obj);
					
				} catch (InstantiationException | IllegalAccessException e) {
					log.error(e+"");
				}
			});


		return resultList;
	}
	
	public T convertMapToObject(Map<String, Object> map) throws Exception{
		List<Map<String, Object>> listMap = new ArrayList<>(1);
		listMap.add(map);
		return convertListMapToObject(listMap).get(0);
	}
	
	public HashMap<String,Object> compareEqualMap(List<Map<String,Object>> list ,T obj,String compareField) throws Exception{
		HashMap<String,Object> eq = null;
		
		if (!CollectionUtils.isEmpty(list)) {
			
			for (Map<String, Object> map : list) {
				
				Field field = obj.getClass().getDeclaredField(compareField);
				field.setAccessible(true);
				String key = field.get(obj).toString();
				
				if (map.get(compareField).toString().equals(key)) {
					eq = new HashMap<>(map);
					break;
				}
				
				field.setAccessible(false);
			}
			
		}

		return eq;
	}
	
	public boolean compareEqualObjById(List<T> list ,T obj,String id) throws Exception{
		boolean check = false;
		
		if (!CollectionUtils.isEmpty(list)) {
			
			for (T tObj : list) {
				
				Field tField = obj.getClass().getDeclaredField(id);
				tField.setAccessible(true);
				String tKey = tField.get(obj).toString();
				
				Field field = obj.getClass().getDeclaredField(id);
				field.setAccessible(true);
				String key = field.get(obj).toString();
				
				if (tKey.equals(key)) {
					check = true;
					break;
				}
				
				
			}
			
		}

		return check;
	}
	
	public static boolean isNullOrZero(Number number) {	
		if (number == null || number.intValue() == 0) {
			return true;
		}		
		return false;
	}
	
	public static String isNullStr(String str) {	
		return StringUtils.isEmpty(str)?null:str;
	}
	
	public static String nvl(Object value, String def) {
	    if (StringUtils.isEmpty(value))
	        return def;
	    return value.toString();
	}
	
	public static Integer convertToInteger(String str) {
		try
	    {
			if (!StringUtils.isEmpty(str)) {
				return Integer.parseInt(str);
			}

	    } catch (NumberFormatException ex) {
	        return null;
	    }
		return null;
	}
	
	public static Double convertToDouble(String str) {
		try
	    {
			if (!StringUtils.isEmpty(str)) {
				return Double.parseDouble(str);
			}

	    } catch (NumberFormatException ex) {
	        return null;
	    }
		return null;
	}


}
