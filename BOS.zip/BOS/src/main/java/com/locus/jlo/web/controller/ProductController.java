package com.locus.jlo.web.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.FileUtils;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.product.ProductBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.ProductService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class ProductController extends CoreController {
	
	@Autowired
	private ProductService productService;
	
	private final static String SERV_PATH = "assets/attach_file/product/";
	
	 @RequestMapping(value = {"/product"})
	  public String index() {
	        return "product";
	    }

	 
	 @RequestMapping(value = {"/productDetail"})
	  public String productDetail() {
	        return "productDetail";
	 }
	 
	 
	 @RequestMapping(value = "/searchProduct", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchProduct(HttpServletRequest request,Locale locale) throws Exception{

		String id  = request.getParameter("id");
		 
		HashMap<String, Object> criteria = new HashMap<>();
		
		criteria.put("id", ObjectBeanUtils.isNullStr(id));
		
		ServiceResult<List<Map<String, Object>>> listResult =  productService.searchProduct(criteria );
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
	   
		return result;
	   
	 }
	 
	 @RequestMapping(value = "/saveProduct", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveProduct(HttpServletRequest request,Locale locale) throws Exception{
		
		//https://www.tutorialspoint.com/json/json_java_example.htm
		 final int USER_ID = getUid(request);
		 String data = request.getParameter("data");
		 String viewId  = request.getParameter("viewId");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		 		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
		 
		 //convert between form and bean
		 JsonBeanUtils<ProductBean> utils = new JsonBeanUtils<>(ProductBean.class);
		 
		 ProductBean bean = utils.convertFormAndBeanWithUser(json, USER_ID);
					
		 try{
			 
			 if (StringUtils.isEmpty(viewId)) {
					result =  productService.insertProduct(bean);
					
 	    			if( result.isSuccess()){
 	    			   log.info( "get long : "+result.getResult().longValue() );
 	    			   result_data   = Long.toString(result.getResult().longValue());
 	    			   result_status = "success";
					   result_msg    = "save successful";
 	    				
 	    			}else{
 	    				result_status = "fail";
						result_msg    = "save fail";
 	    			}
			}else {
				
				bean.setId(Integer.parseInt(viewId));
				
				result =  productService.updateProduct(bean);
	    		
	    			if( result.isSuccess()){
	    			   log.info( "get long : "+result.getResult().longValue() );
	    			   result_data   = Long.toString(result.getResult().longValue());
	    			   result_status = "success";
				   result_msg    = "save successful";
	    				
	    			}else{
	    				result_status = "fail";
					result_msg    = "save fail";
	    			}
			}
			 					
			}catch(Exception e){
				log.info("Error !!"+e);
			}
		  
		 /*		  
		 result_data   =  "OK";
		 result_status = "success";
		 result_msg    = "save successful";
		  */
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
	   

	 }
	 
	@RequestMapping(value = "/uploadProductImg", method = RequestMethod.POST)
	public @ResponseBody JsonResultBean uploadProductImg( @RequestParam("fileImage") MultipartFile uploadfile , HttpServletResponse response, HttpServletRequest request,Locale locale) throws Exception{
			 log.info("Start upload");
			 JsonResultBean result = null;
			 
			 String result_status = "success";
			 String result_msg = "success";

			 String path = FileUtils.uploadFile(uploadfile,SERV_PATH);

			 result = new JsonResultBean(result_status, result_msg , path );
			 
			 return result;
		
	}
	
	@RequestMapping(value = "/deleteProduct", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean deleteProduct(HttpServletRequest request,Locale locale) throws Exception{

		
		String id = request.getParameter("id");

		ServiceResult<Long> idResult =  productService.deleteProduct(id);
		JsonResultBean result = null;
		if(idResult.isSuccess()){
			result = new JsonResultBean("success", "" , idResult.getResult());
		}
		return result;
		 
	 }
	
    
}