package com.locus.jlo.web.services.impl;

import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.ReportTimesheetUtilizeBean;
import com.locus.jlo.web.services.ReportService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ReportServiceImpl extends BaseService implements ReportService{
	
	//test report
	String SQL_UTILIZE_REPORT = "REPORT.SQL_UTILIZE_TIMESHEET";
	
	
	String SQL_REPROT_SEARCH_TIMESHEET = "TIMESHEET.REPORT_SEARCH"; 
	String SQL_REPROT_SEARCH_TIMESHEET_DETAIL = "TIMESHEET.REPORT_SEARCH_DETAIL"; 
	String SQL_REPORT_SEARCH_TIMESHEET_NOTE = "TIMESHEET.REPORT_TIMESHEET_NOTE";
	String SQL_REPORT_SEARCH_TIMESHEET_OVERTIME = "TIMESHEET.REPORT_SEARCH_OVERTIME";
	
	String SQL_REPORT_GET_HOLIDAY = "TIMESHEET.REPORT_GET_HOLIDAY"; //please move to calendar
	String SQL_REPORT_GET_HOLIDAY_BETWEEN_DAY = "TIMESHEET.REPORT_GET_HOLIDAY_BETWEEN_DAY"; //please move to calendar
	
	String SQL_REPORT_TIMESHEET_UPDATE = "TIMESHEET.REPORT_TIMESHEET_UPDATE";
	String SQL_REPORT_TIMESHEET_DELETE = "TIMESHEET.REPORT_TIMESHEET_REMOVE";
	
	String SQL_STAFF_PROFILE = "USER.SQL_STAFF_PROFILE";
	
	//approval
	String SQL_APPROVAL_WORKHOUR = "APPROVAL.SQL_APPROVAL_WORKHOUR";
	String SQL_APPROVAL_OT = "APPROVAL.SQL_APPROVAL_OT";
	
	
	//report
	String SQL_TIMESHEET_APPROVAL = "REPORT.SEARCH_TIMESHEET_APPROVAL";
	String SQL_TIMESHEET_APPROVAL_STAFFDTL = "REPORT.SEARCH_TIMESHEET_APPROVAL_STAFF_DTL";
	String SEARCH_TIMESHEET_FOR_ADMIN = "TIMESHEET_ADMIN.SEARCH_TIMESHEET_FOR_ADMIN";
	
	
	@Override
	public ServiceResult<List<ReportTimesheetUtilizeBean>> searchReportTimesheetUtilize(String year, String monthId) throws Exception{
		ServiceResult<List<ReportTimesheetUtilizeBean>> serviceResult = new ServiceResult<List<ReportTimesheetUtilizeBean>>();
		List<ReportTimesheetUtilizeBean> result = null;	
		
		try{

			result = dynamicJdbcDao.findForList(SQL_UTILIZE_REPORT,
					BeanPropertyRowMapper.newInstance(ReportTimesheetUtilizeBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId));
			
			serviceResult = new ServiceResult<List<ReportTimesheetUtilizeBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<ReportTimesheetUtilizeBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetApproval(String year, String monthId , String projectId, String deptId, String staffId , String approverId ) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{

			result = dynamicJdbcDao.findForList(SQL_TIMESHEET_APPROVAL,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetApprovalStaffDetail(String year,String monthId,String staffId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{

			result = dynamicJdbcDao.findForList(SQL_TIMESHEET_APPROVAL_STAFFDTL,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId), new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimesheet(String year,String monthId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{

			result = dynamicJdbcDao.findForList(SQL_REPROT_SEARCH_TIMESHEET,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	//staff profile ( should move to staff page )
	@Override
	public ServiceResult<List<DataBean>> searchStaffDetail(String staffId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{

			result = dynamicJdbcDao.findForList(SQL_STAFF_PROFILE,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("staffId", staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimesheetDetail(String year, String monthId, String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_REPROT_SEARCH_TIMESHEET_DETAIL,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));

			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimesheetNote(String year,String monthId, String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_REPORT_SEARCH_TIMESHEET_NOTE,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));
				serviceResult = new ServiceResult<List<DataBean>>(result);
			   System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimeshhetOvertime(String year,String monthId, String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_REPORT_SEARCH_TIMESHEET_OVERTIME,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));
				serviceResult = new ServiceResult<List<DataBean>>(result);
			   System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	
	
	
	
	//UPDATE TIMESHEET ENTRY
	@Override
	public ServiceResult<Long> updateTimeSheetEntry(String udata) throws Exception{
		//trace parameter
		log.info("Get data :"+udata);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
		     //count success
			 Integer success = 0;
			
			 JSONParser parser = new JSONParser();
			 Object obj = parser.parse(udata);
			 JSONArray jarr = (JSONArray)obj;
			 int size = jarr.size();
			 log.info("update record length: "+size);
			
			 for(int i=0;i<size;i++){
				 	JSONObject data = (JSONObject)jarr.get(i);
					final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REPORT_TIMESHEET_UPDATE, new SimpleKeyValue("id",data.get("id").toString()),
																								  new SimpleKeyValue("status",data.get("sts").toString()), 
																								  new SimpleKeyValue("hour",data.get("hour").toString()));
					
					log.info("UPDATE time_entries SET status = "+data.get("sts").toString()+", hours = "+data.get("hour").toString()+"  WHERE id = "+data.get("id").toString()+";");
					
					if(cnt==1){
						success++;
					}
				 
			 }
			
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Update record Error: "+e);
			e.printStackTrace();
		}
	
		return result;
	}
	
	
	//DELETE TIMESHEET ENTRY
	@Override
	public ServiceResult<Long> removeTimeSheetEntry(String rdata) throws Exception {
		//trace parameter
		log.info("Get data :"+rdata);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
		     //count success
			 Integer success = 0;
			
			 JSONParser parser = new JSONParser();
			 Object obj = parser.parse(rdata);
			 JSONArray jarr = (JSONArray)obj;
			 int size = jarr.size();
			 log.info("update record length: "+size);
			
			 for(int i=0;i<size;i++){
				 	JSONObject data = (JSONObject)jarr.get(i);
					final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REPORT_TIMESHEET_DELETE, new SimpleKeyValue("id",data.get("id").toString()));
					log.info("DELETE FROM time_entries WHERE id = "+data.get("id").toString()+";");
					if(cnt==1){
						success++;
					}
				 
			 }
			
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Update record Error: "+e);
			e.printStackTrace();
		}
	
		return result;
	
	}
	
	
	
	@Override
	public ServiceResult<List<DataBean>> getHolidayConfig(String year, String monthId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			
			result = dynamicJdbcDao.findForList(SQL_REPORT_GET_HOLIDAY,BeanPropertyRowMapper.newInstance(DataBean.class),new SimpleKeyValue("year",year),new SimpleKeyValue("monthId",monthId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> getHolidayConfigBetweenDate(String startDate, String endDate) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			
			result = dynamicJdbcDao.findForList(SQL_REPORT_GET_HOLIDAY_BETWEEN_DAY,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("startDate", startDate),new SimpleKeyValue("endDate",endDate));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	/* approve save */
	@Override
	public ServiceResult<Long> approveWorkhour(List<DataBean> db) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			List<DataBean> arr = db;
			int dataLength = arr.size();
			Integer success = 0;
			for(int i=0;i<dataLength;i++){
				DataBean d = arr.get(i);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_APPROVAL_WORKHOUR, new SimpleKeyValue("entry_id",d.getA()) , new SimpleKeyValue("status",d.getB()) , new SimpleKeyValue("staffId",d.getC()));
				if(cnt==1){
					success++;
				}
			}
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			log.info("submitWorkhour Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> approveOvertime(List<DataBean> db) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			List<DataBean> arr = db;
			int dataLength = arr.size();
			Integer success = 0;
			for(int i=0;i<dataLength;i++){
				DataBean d = arr.get(i);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_APPROVAL_OT, new SimpleKeyValue("entry_id",d.getA()) , new SimpleKeyValue("status",d.getB()) , new SimpleKeyValue("staffId",d.getC()));
				if(cnt==1){
					success++;
				}
			}
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			log.info("submitOvertime Error: "+e);
		}
	
		return result;
	}



	@Override
	public ServiceResult<List<DataBean>> searchTimesheetForAdmin(String year, String monthId, String division,
			String departement, String section, String staffId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{

			result = dynamicJdbcDao.findForList(SEARCH_TIMESHEET_FOR_ADMIN,
					BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("year", year)
					, new SimpleKeyValue("monthId",monthId)
					, new SimpleKeyValue("division",division)
					, new SimpleKeyValue("department",departement)
					, new SimpleKeyValue("section",section)
					, new SimpleKeyValue("staffId",staffId)
					);
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	
	/*
	@Override
	public ServiceResult<List<DataBean>> searchTimesheet_beforeSubmit() throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_TEIMSHEET_BEFORE_SUBMIT,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("accountName",""));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<Long> submitTimesheet(String data_eid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control data_eid :"+data_eid);
	
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			data_eid = data_eid.replaceAll("\"", "");
			String[] arr = data_eid.split(",");
//			List<String> lst = new ArrayList<>();
			Integer success = 0;
			for(int i=0;i<arr.length;i++){
				log.info("Timesheet control data_eid :"+arr[i]);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_SUBMIT_TIMESHEET, new SimpleKeyValue("data_eid",arr[i]));
				if(cnt==1){
					success++;
				}
			}
			
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	
	
	
	
	@Override
	public ServiceResult<Long> insertLogtime(String pid,String tid,String date,String hour,String status , String uid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_LOGTIME, Boolean.TRUE, new SimpleKeyValue("pid",pid),
																							   new SimpleKeyValue("tid",tid),
																							   new SimpleKeyValue("date",date), 
																							   new SimpleKeyValue("hour",hour),
																							   new SimpleKeyValue("status",status),
																							   new SimpleKeyValue("uid",uid));
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateLogtime(String pid, String tid, String date, String hour, String status, String uid, String eid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		log.info("Timesheet control eid :"+eid);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_LOGTIME, new SimpleKeyValue("pid",pid),
																			   new SimpleKeyValue("tid",tid),
																			   new SimpleKeyValue("date",date), 
																			   new SimpleKeyValue("hour",hour),
																			   new SimpleKeyValue("status",status),
																			   new SimpleKeyValue("uid",uid),
																			   new SimpleKeyValue("eid",eid));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> removeLogtime(String eid) throws Exception {
		 
		//trace parameter
		log.info("Timesheet control eid :"+eid);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_LOGTIME, new SimpleKeyValue("eid",eid));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	/*
	@Override
	public String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception {
		//ServiceResult<String> result = null;
		
		log.info("Timesheet control"+pid);
		 
		String result = "";
		try {
			List<String> lst = dynamicJdbcDao.findForList(SQL_CHECK_LOGTIME, String.class , 
					new SimpleKeyValue("pid",pid));
			  log.info("size : "+lst.size());
			  if(lst.size()>0){
				  result = lst.get(0);
			log.info("Timesheet control"+lst.get(0));
			  }
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
		return result;
	}
  */
}
