package com.locus.jlo.web.beans.account;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AccountBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private String accountId;
	private BigInteger accountCommIdEmail;
	private BigInteger accountCommIdMainPhone;
	private BigInteger accountCommIdMobilePhone;
	private BigInteger accountOwnerId;
	private BigInteger addressId;
	private BigInteger contactId;
	private String createdBy;
	private Date createdDate;
	private int customerStatus;//
	private int customerStatusInd;//
	private int customerSubType;//
	private int customerType;//
	private String rowId;
	private String updatedBy;
	private Date updatedDate;
}