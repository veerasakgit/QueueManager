package com.locus.jlo.utils;

	
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.util.StringUtils;

import com.locus.jlo.web.beans.StampBean;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JsonBeanUtils<T extends StampBean> {
	
	private Class<T> classObj;
	
	private static final DateFormat  DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy",Locale.US); 
	
	public JsonBeanUtils(Class<T> tClass) {
		classObj = tClass;
	}
	
	
	public List<T> convertFormAndBean(JSONObject json,String idField,Integer uid) throws Exception{
		
		Map<String,Object> map =  json; 
		
		int size = 1;
		
		if (!StringUtils.isEmpty(idField)) {
			
			if (map.get(idField) instanceof JSONArray) {
				JSONArray array = (JSONArray) map.get(idField);
				size = array.size();
			}
		}
				
		List<T> list = new ArrayList<>();

		for (int i = 0; i < size; i++) {
			
			T obj = classObj.newInstance();
			int index = i;

			
			
			for (Entry<String, Object> entry : map.entrySet()) {
				
				String k = entry.getKey();
				Object v = entry.getValue();
				
				if (!StringUtils.isEmpty(v)) {

						String oField = convertJsonField(k.toString());
						
						Field field = null;
						
						try {
							field = obj.getClass().getDeclaredField(oField);
						} catch (NoSuchFieldException | SecurityException e) {
//							log.error(e+"");
						}
						if (field != null) {
							
							field.setAccessible(true);
							try {
								
								String rawVal = "";
								
								if (size > 1) {	
							
									if (v instanceof JSONArray) {
										JSONArray array = (JSONArray) v;
										
										if (array.size()-1 >= i) {
											rawVal = array.get(index).toString();
										}
										
									}else {
										if (i==0) {
											rawVal = v.toString();
										}
									}
								
								}else {
									rawVal = v.toString();
								}
								
								if (StringUtils.isEmpty(rawVal)) {
									//not set value
								}else {
									
									Object value = null;

									if (field.getType().isAssignableFrom(Integer.class)) {
										value = Integer.parseInt(rawVal);
									}
									else if (field.getType().isAssignableFrom(Long.class)) {
										value = Long.valueOf(rawVal);
									}
									else if(field.getType().isAssignableFrom(BigDecimal.class)){								
										value = new BigDecimal(rawVal);
									}

									else if(field.getType().isAssignableFrom(Date.class)) {
										
										try {
											Date date = DATE_FORMAT.parse(rawVal);
											value = date;
										} catch (ParseException e) {
											e.printStackTrace();
											value = rawVal;
										}
										
									}else {
										value = rawVal;
									}
									
									
									field.set(obj,value);
//									log.info(field.getName()+":"+value);
									
								}

							} catch (IllegalArgumentException | IllegalAccessException e) {
								e.printStackTrace();
							}		
							field.setAccessible(false);
							
						}

				}
			}
			
			if (uid != null) {
				obj.setCreate_uid(uid);
				obj.setUpdate_uid(uid);
			}

			list.add(obj);
		}
		return list;
	}
	
	public T convertFormAndBean(JSONObject json) throws Exception{
		return convertFormAndBean(json, null).get(0);
		
	}
	
	public T convertFormAndBeanWithUser(JSONObject json,Integer uid) throws Exception{
		return convertFormAndBean(json, uid).get(0);
		
	}
	
	public List<T> convertFormAndBean(JSONObject json,Integer uid) throws Exception{
		return convertFormAndBean(json,null,uid);
		
	}


	private static String convertJsonField(String jField) {
		
		String oField = "";
		
//		HashMap<Character,String> change = new HashMap();

		
		for (char cha : jField.toCharArray()) {
		
			String chaStr = cha+"";
			
			if (Character.isUpperCase(cha)) {
				char lower = Character.toLowerCase(cha);
				chaStr = "_"+lower;
			}
			
			oField += chaStr;
		}
		
//		System.out.print(oField);
		
		return oField;
	}
	
	public void testPrint(List<T> list) {
		
		list.forEach((item)->{
			
			print(item);

			System.out.println();
		});
	}


	public void print(T item) {
		
		for (Field f : item.getClass().getDeclaredFields()) {

			try {
				f.setAccessible(true);
				
				if (f.get(item) != null) {
					System.out.print(f.getName()+" : "+f.get(item)+" | ") ;
				}
				
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
	public boolean isEqualInJsonArray(String id,String[] isDeptHeadArr) {
		boolean check = false;
		if (isDeptHeadArr != null) {
			for (String arrId : isDeptHeadArr) {
				if (id.equals(arrId)) {
					check = true;
					break;
				}
			}
		}
		return check;

	}
	
	public static Map<String, Object> jsonObjToMap(JSONObject jObj) throws Exception {
		
		Map<String,Object> map = new HashMap<>();
		
		for (Object key : jObj.keySet()) {
			
			Object obj = jObj.get(key);
			
			if (!StringUtils.isEmpty(obj)) {
				map.put(key.toString(),obj);
			}

		}
		
		return map;
		
	}
	
	public static List<String> jsonToList( String jsonString ){
	  log.info("get json str: "+jsonString);
		 List<String> tmp = new ArrayList<String>();
		 if(jsonString != null){
			 try{  
				 JSONParser jParser = new JSONParser();
				 Object obj = jParser.parse(jsonString);
				 JSONArray jArray = (JSONArray)obj;
				 
				 //projectId = project.toString().replaceAll("\\[|\\]", "");  //remove [ ] 
				 if(jArray.size()>0) {
					 for(int i=0;i<jArray.size();i++){
						 tmp.add(jArray.get(i).toString());
						//log.info("project id :"+project.get(i));
					 }
				 }
				 
			 }catch(Exception e){
				/*log.info("Error !!"+e);*/
				e.printStackTrace();
			 }
		 }
		  return tmp;
   }

	
	
	

	
}
