package com.locus.jlo.web.beans.system.modeljson;


public class MenuTreeModelBean extends TreeModelBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8880505593907957985L;

}
