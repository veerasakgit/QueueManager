package com.locus.jlo.web.services.impl;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.TreeParentBean;
import com.locus.jlo.web.beans.system.modelbean.MenuDetailModelBean;
import com.locus.jlo.web.services.SettingPrivilegesService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;


@Slf4j
@Service
public class SettingPrivilegesServiceImpl extends BaseService implements SettingPrivilegesService {

    // Query
    private final String SQL_SEARCH = "PRIVILEGES.SQL_SEARCH";
    private final String SQL_SEARCH_MENU = "PRIVILEGES.SQL_SEARCH_MENU";
    private final String SQL_INIT_MENU = "PRIVILEGES.SQL_INIT_MENU";
    private final String SQL_MENU_UPDATE = "PRIVILEGES.SQL_MENU_UPDATE";
    private final String SQL_INSERT_PRIVILEGES_MENU = "PRIVILEGES.SQL_INSERT_PRIVILEGES_MENU";
 
    private final String SQL_ADMIN_MENU = "PRIVILEGS.SQL_ADMIN_MENU";    //show all menu for admin role
    
    private final String SQL_APPROVAL_MENU_AUTHORIZE = "PRIVILEGS.SQL_APPROVAL_MENU_AUTHORIZE"; //find permission for enable/disable approval menu
    private final String SQL_APPROVAL_MENU_IS_REPORT_TO_PERSON = "PRIVILEGS.SQL_APPROVAL_MENU_IS_REPORT_TO_PERSON"; //find permission for enable/disable if staff is reported to person
    private final String SQL_FIND_USER_ORGANIZE= "PRIVILEGS.SQL_FIND_USER_ORGANIZE";
    private final String SQL_SEARCH_DEPARTMENT_PRIVILEGE = "PRIVILEGES.SQL_SEARCH_DEPARTMENT_PRIVILEGE";
    
    @Override
    public ServiceResult<List<MenuDetailModelBean>> searchMenuByUserPermission(Integer uid) throws Exception {
        ServiceResult<List<MenuDetailModelBean>> serviceResult = new ServiceResult();
        try { 	
        	
        	//step1 find organize level of this user
        	ServiceResult<List<DataBean>> userOrganizeLevel =  new ServiceResult<>(dynamicJdbcDao.findForList(SQL_FIND_USER_ORGANIZE,BeanPropertyRowMapper.newInstance(DataBean.class),
        																   new SimpleKeyValue("uid", uid)) );
        	
        	//default parameter for privileges
        	String privilegesYn = "Y";
        	String useYN = "Y";
        	
        	//result will contain [ division , dept , section ]
        	if( userOrganizeLevel.isSuccess()){
        		if(userOrganizeLevel.getResult().size() != 0 ){
        			
        			List<DataBean> organizeLv = userOrganizeLevel.getResult();
        			int dataLength = organizeLv.size(); 
            		
            		for(int i=0;i<dataLength;i++){
            			DataBean data = organizeLv.get(i);
            			
            			log.info("get division id : "+data.getA());
            			log.info("get dept id : "+data.getB());
            			log.info("get section id : "+data.getB());
            			
            			//get section
            			if( !StringUtils.isEmpty(data.getC())){
            				//find menu by send section as a parameter
            				  serviceResult = new ServiceResult<>(dynamicJdbcDao.findForList(SQL_SEARCH_MENU,
														                                      BeanPropertyRowMapper.newInstance(MenuDetailModelBean.class) ,
														                                      new SimpleKeyValue("deptId",data.getC().toString()),
														                                      new SimpleKeyValue("privilegesYn",privilegesYn),
														                                      new SimpleKeyValue("useYN",useYN)));
            			
            				
            			}else if( !StringUtils.isEmpty(data.getB())){
            			//get division
            				//find menu by send dept as a parameter
            				  serviceResult = new ServiceResult<>(dynamicJdbcDao.findForList(SQL_SEARCH_MENU,
														                                      BeanPropertyRowMapper.newInstance(MenuDetailModelBean.class) ,
														                                      new SimpleKeyValue("deptId",data.getB().toString()),
														                                      new SimpleKeyValue("privilegesYn",privilegesYn),
														                                      new SimpleKeyValue("useYN",useYN)));
														            				
            			
            			}else if( !StringUtils.isEmpty(data.getA())){
            			//get section
            				//find menu by send division as a parameter
            				  serviceResult = new ServiceResult<>(dynamicJdbcDao.findForList(SQL_SEARCH_MENU,
														                                      BeanPropertyRowMapper.newInstance(MenuDetailModelBean.class) ,
														                                      new SimpleKeyValue("deptId",data.getA().toString()),
														                                      new SimpleKeyValue("privilegesYn",privilegesYn),
														                                      new SimpleKeyValue("useYN",useYN)));
            				
            			}
            		}//end for
            		
            	
            		//check is staff is a report to person ?
            		List<KeyValueBean> reportToRole = dynamicJdbcDao.findForList(SQL_APPROVAL_MENU_IS_REPORT_TO_PERSON, BeanPropertyRowMapper.newInstance(KeyValueBean.class),
							new SimpleKeyValue("uid", uid));
            		
            		
            		//check is staff is a authorize approval ? is true show approval menu on page
                	List<KeyValueBean> authorizeApproveRole = dynamicJdbcDao.findForList(SQL_APPROVAL_MENU_AUTHORIZE, BeanPropertyRowMapper.newInstance(KeyValueBean.class),
        																	new SimpleKeyValue("uid", uid));
                	
                	//if found this user is pm role will show approval menu
                	log.info("check menu reportToRole permission      : "+reportToRole.size());
                	log.info("check menu authorizeApproval permission : "+authorizeApproveRole.size());
                	if(authorizeApproveRole.size() == 0 &&  reportToRole.size() == 0){
                	 
                		List<MenuDetailModelBean> removeList = serviceResult.getResult();
                		dataLength = removeList.size();
                		int removeAtIdx = -1;
            			for(int i=0;i<dataLength;i++){
            				MenuDetailModelBean mdmb = removeList.get(i);
            				if((!StringUtils.isEmpty(mdmb.getMenuId())) && mdmb.getMenuId() == 8){
            					removeAtIdx = i;
            					log.info("menu ["+i+"] not allow ["+mdmb.getMenuId()+"]: "+mdmb.getMenuName()+"... remove done");
            				}else{
            					log.info("menu ["+i+"] allow ["+mdmb.getMenuId()+"]: "+mdmb.getMenuName());
            				} 
            			}
            			
            			//initial new menu
            			if( removeAtIdx != -1 ){
            				serviceResult.getResult().remove(removeAtIdx);
            			}
                	}
        			
        		}else{
        		//if not found organize configuration of this user !!
        		}
        	}
        	
            
        } catch (Exception e) {
            serviceResult = new ServiceResult<>(e);
            e.printStackTrace();
        }
        return serviceResult;
    }
    
   
    
    public ServiceResult<List<MenuDetailModelBean>> searchMenuByAdminRole() throws Exception {
        ServiceResult<List<MenuDetailModelBean>> serviceResult = new ServiceResult();
        try {
            serviceResult = new ServiceResult<>(dynamicJdbcDao.findForList(SQL_ADMIN_MENU,
                                                BeanPropertyRowMapper.newInstance(MenuDetailModelBean.class) ,
                                                new SimpleKeyValue("useYN","Y")));
        } catch (Exception e) {
            serviceResult = new ServiceResult<>(e);
        }
        return serviceResult;
    }





    @Override
    public ServiceResult<Integer> updatePrivileges(List<MenuDetailModelBean> menuDetailModelBeanList, Integer uid) {
        AtomicInteger row = new AtomicInteger();
        menuDetailModelBeanList.forEach(menuDetailModelBean -> {
            try {
                row.set(+dynamicJdbcDao.executeUpdate(SQL_MENU_UPDATE, menuDetailModelBean, new SimpleKeyValue("uid", uid)));
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        return new ServiceResult<Integer>(row.get());
    }

    private void checkExistsNotMenuPrivileges(Integer deptId,Integer uid) throws Exception {
        dynamicJdbcDao.executeUpdate(SQL_INIT_MENU,new SimpleKeyValue("deptId",deptId),new SimpleKeyValue("uid",uid));
    }



	@Override
	public ServiceResult<List<MenuDetailModelBean>> initialMenuByDepartment(MenuDetailModelBean menuBean) throws Exception {
		
	    ServiceResult<List<MenuDetailModelBean>> serviceResult = new ServiceResult<List<MenuDetailModelBean>>();
        try {
            serviceResult = new ServiceResult<>(dynamicJdbcDao.findForList(SQL_SEARCH_MENU,
                                                BeanPropertyRowMapper.newInstance(MenuDetailModelBean.class) ,
			                                      new SimpleKeyValue("deptId",menuBean.getDeptId())));
        } catch (Exception e) {
            serviceResult = new ServiceResult<>(e);
        }
        return serviceResult;
        
	}



	@Override
	public ServiceResult<List<TreeParentBean>> getTreeDepartmentPrivileges() throws Exception {
		ServiceResult<List<TreeParentBean>> serviceResult = new ServiceResult<List<TreeParentBean>>();
		List<TreeParentBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_DEPARTMENT_PRIVILEGE,BeanPropertyRowMapper.newInstance(TreeParentBean.class));
			
			serviceResult = new ServiceResult<List<TreeParentBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<TreeParentBean>>(e);
		}
		return serviceResult;
	}



	@Override
	public ServiceResult<Long> insertPrivileges(MenuDetailModelBean bean) {
		ServiceResult<Long> result = null;
		try {
			Long privilileges = dynamicJdbcDao.executeInsert(SQL_INSERT_PRIVILEGES_MENU, false, bean);
			result = new ServiceResult<Long>(privilileges);
			result.setSuccess(true);
			result.setResult(privilileges);
			result.setResponseDescription("success");

		} catch (Exception e) {
			result = new ServiceResult<Long>(e);
		}
		return result;
	}


}
