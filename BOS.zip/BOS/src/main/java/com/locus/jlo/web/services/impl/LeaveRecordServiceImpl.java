package com.locus.jlo.web.services.impl;

import java.util.Calendar;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.services.LeaveRecordService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LeaveRecordServiceImpl extends BaseService implements LeaveRecordService{
	
	//Query
	
	final String SQL_SEARCH_USER = "SQL_SEARCH_USER";
	
	final String SQL_SEARCH_LEAVE_RECORD = "LEAVE_RECORD.SQL_SEARCH";
	
	
	final String SQL_SUMMARY_ANNUAL_YEAR_NEXT    = "LEAVE_RECORD.ANNUAL_BALANCE_ENTITLE_YEAR_NEXT";
	final String SQL_SUMMARY_ANNUAL_YEAR_CURRENT    = "LEAVE_RECORD.ANNUAL_BALANCE_ENTITLE_YEAR_CURRENT";
	final String SQL_SUMMARY_ANNUAL_YEAR_LAST_YEAR  = "LEAVE_RECORD.ANNUAL_BALANCE_ENTITLE_YEAR-1";
	final String SQL_SUMMARY_ANNUAL_YEAR_LAST_2YEAR = "LEAVE_RECORD.ANNUAL_BALANCE_ENTITLE_YEAR-2";
	
	 final String SQL_CAL_AUUNAL_LEAVE_BALANCE = "LEAVE_RECORD.CAL_ANNAUL_LEAVE_ACCUMULATE";
	
	 final String SQL_ANNUAL_INFO_STAFF = "LEAVE_RECORD.SQL_ANNUAL_INFO_STAFF";
	 final String SQL_ANNUAL_INFO_LAST_YEAR = "LEAVE_RECORD.SQL_ANNUAL_INFO_LAST_YEAR";
	 final String SQL_ANNUAL_INFO_LAST_2YEAR = "LEAVE_RECORD.SQL_ANNUAL_INFO_LAST_2YEAR";
	 final String SQL_ANNUAL_INFO_THIS_YEAR = "LEAVE_RECORD.SQL_ANNUAL_INFO_THIS_YEAR";
	 
	 final String SQL_HOLIDAY_CALENDAR = "CALENDAR.HOLIDAY_CALENDAR";
	 final String SQL_SUM_ALL_USED_LEAVE = "LEAVE_RECORD.SUM_ALL_USED_LEAVE";
	 
	/*
	  final String SQL_CAL_WR = "UTIL.SQL_QUERY_WORKINGDAY";
	
	final String SQL_SUMMARY_ANNUAL_LEAVE_2017 = "LEAVE_RECORD.SUMMARY_ANNUAL_LEAVE_2017";
	final String SQL_SUMMARY_ANNUAL_LEAVE_2018 = "LEAVE_RECORD.SUMMARY_ANNUAL_LEAVE_2018";
	final String SQL_SUMMARY_ANNUAL_LEAVE_2019 = "LEAVE_RECORD.SUMMARY_ANNUAL_LEAVE_2019";
	final String SQL_SUMMARY_ANNUAL_LEAVE_2020 = "LEAVE_RECORD.SUMMARY_ANNUAL_LEAVE_2020";
	final String SQL_SUMMARY_ANNUAL_LEAVE_2021 = "LEAVE_RECORD.SUMMARY_ANNUAL_LEAVE_2021";
	final String SQL_SUMMARY_ANNUAL_LEAVE_2022 = "LEAVE_RECORD.SUMMARY_ANNUAL_LEAVE_2022";
	
	final String SQL_QRY_PREVIOUS_ENTITLE = "LEAVE_RECORD.LAST_YEAR_ENTITLE";
	 */

	@Override
	public ServiceResult<List<DataBean>> searchLeaveRecord(String year,String userId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		try{
			
			if (year.equalsIgnoreCase("All")) {
				year = null;
			}

			List<DataBean> result = dynamicJdbcDao.findForList(SQL_SEARCH_LEAVE_RECORD,BeanPropertyRowMapper.newInstance(DataBean.class)
								,new SimpleKeyValue("year",year),new SimpleKeyValue("userId",userId));
			
			log.info(SQL_SEARCH_LEAVE_RECORD+" size: "+result.size());
			//dataNotFound(result);
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
		
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
			
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> calAnnualLeaveAccumulate(String year,String userId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		try{
			
			if (year.equalsIgnoreCase("All")) {
				year = null;
			}

			List<DataBean> result = dynamicJdbcDao.findForList(SQL_CAL_AUUNAL_LEAVE_BALANCE,BeanPropertyRowMapper.newInstance(DataBean.class)
								,new SimpleKeyValue("year",year),new SimpleKeyValue("userId",userId));
			
			log.info(SQL_CAL_AUUNAL_LEAVE_BALANCE+" size: "+result.size());
			//dataNotFound(result);
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
		
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
			
		}
		return serviceResult;
	}
	
	
	
	
	@Override
	public ServiceResult<List<DataBean>> summaryAnnualLeave(String year,String userId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		List<DataBean> result = null;
		try{
			
			int search_year = Calendar.getInstance().get(Calendar.YEAR);
			log.info("current backend year is : "+search_year);
			log.info("get parameter year : "+year);
			search_year =  Integer.parseInt(year) - search_year;
			 log.info("year is : "+search_year);
			 
			//check search year match with backend sql [ backend support only 4 condition ]
			//if search year = +1 it mean next year
			//if search year = 0  it mean current year
			//if search year = -1 it mean previous 1 year
			//if search year = -2 it mean previous 2 year
			
		
			//remeber that annaul leave entile of current year will calculate from last year
			//if search year = 2017
			//annual leave entitle will be 2016
			  
			switch(search_year){
				case  1 : log.info("search next year ");
						 result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_YEAR_NEXT,BeanPropertyRowMapper.newInstance(DataBean.class) , new SimpleKeyValue("userId",userId));
						 break;
				case  0 : log.info("search current year");
				 		result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_YEAR_CURRENT,BeanPropertyRowMapper.newInstance(DataBean.class) , new SimpleKeyValue("userId",userId));
						break;
				case -1 : log.info("search previous year");
						result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_YEAR_LAST_YEAR,BeanPropertyRowMapper.newInstance(DataBean.class) , new SimpleKeyValue("userId",userId));
						break;
				case -2 : log.info("search previous year -2 ");
						result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_YEAR_LAST_2YEAR,BeanPropertyRowMapper.newInstance(DataBean.class) , new SimpleKeyValue("userId",userId));
						break;
				default : log.info("Front end search criteria don't match with backend ");	
				 
						/*
					case "2017":
								 break;
					case "2018": result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_LEAVE_2018,BeanPropertyRowMapper.newInstance(DataBean.class) , new SimpleKeyValue("userId",userId));
								 break;
					case "2019": result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_LEAVE_2019,BeanPropertyRowMapper.newInstance(DataBean.class) , new SimpleKeyValue("userId",userId));
								 break;
					case "2020": result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_LEAVE_2020,BeanPropertyRowMapper.newInstance(DataBean.class) , new SimpleKeyValue("userId",userId));
								 break;
					case "2021": result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_LEAVE_2021,BeanPropertyRowMapper.newInstance(DataBean.class) , new SimpleKeyValue("userId",userId));
							 	 break;
					case "2022": result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_LEAVE_2022,BeanPropertyRowMapper.newInstance(DataBean.class) , new SimpleKeyValue("userId",userId));
								 break;
								 */
			}
			
			log.info("summary annual size: "+result.size());
			serviceResult = new ServiceResult<List<DataBean>>(result);
		
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> previousYearLeaveEntitle(String userId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		List<DataBean> result = null;
		try{
			
			 
			
			result = dynamicJdbcDao.findForList(SQL_SUMMARY_ANNUAL_YEAR_CURRENT,BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("userId",userId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			
		}catch(Exception e){
			log.info("[LeaveRecordServiceImpl][calWorkingDay] Error :"+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<KeyValueBean>> searchUser() throws Exception {
		
		ServiceResult<List<KeyValueBean>> serviceResult = null;
		try{
			
		
			List<KeyValueBean> result = dynamicJdbcDao.findForList(SQL_SEARCH_USER,BeanPropertyRowMapper.newInstance(KeyValueBean.class));
			
			log.info(SQL_SEARCH_LEAVE_RECORD+" size: "+result.size());
			//dataNotFound(result);
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
		
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
			
		}
		return serviceResult;
	}
	
	
	//-- show on modal
	@Override
	public ServiceResult<List<DataBean>> leaveRecordStaffInfoService(String userId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_ANNUAL_INFO_STAFF,BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("userId",userId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			
		}catch(Exception e){
			log.info("[LeaveRecordServiceImpl][leaveRecordStaffInfoService] Error :"+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	//-- show on modal
	@Override
	public ServiceResult<List<DataBean>> leaveRecordAnnualLeaveLastYearInfoService(String userId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_ANNUAL_INFO_LAST_YEAR,BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("userId",userId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			
		}catch(Exception e){
			log.info("[LeaveRecordServiceImpl][leaveRecordAnnualLeaveLastYearInfoService] Error :"+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	//-- show on modal
	@Override
	public ServiceResult<List<DataBean>> leaveRecordAnnualLeaveLast2YearInfoService(String userId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_ANNUAL_INFO_LAST_2YEAR,BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("userId",userId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			
		}catch(Exception e){
			log.info("[LeaveRecordServiceImpl][leaveRecordAnnualLeaveLast2YearInfoService] Error :"+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	//-- show on modal
	@Override
	public ServiceResult<List<DataBean>> leaveRecordAnnualLeaveThisYearInfoService(String userId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_ANNUAL_INFO_THIS_YEAR,BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("userId",userId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			
		}catch(Exception e){
			log.info("[LeaveRecordServiceImpl][leaveRecordAnnualLeaveThisYearInfoService] Error :"+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
   //-- get calendar date show on bootstrap calendar
	@Override
	public ServiceResult<List<DataBean>> getHolidayCalendar(String year) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_HOLIDAY_CALENDAR,BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("year",year));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			
		}catch(Exception e){
			log.info("[LeaveRecordServiceImpl][leaveRecordAnnualLeaveThisYearInfoService] Error :"+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> sumAllLeaveUsed(String year,String userId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = null;
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_SUM_ALL_USED_LEAVE,BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("year",year), new SimpleKeyValue("userId",userId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			
		}catch(Exception e){
			log.info("[LeaveRecordServiceImpl][leaveRecordAnnualLeaveThisYearInfoService] Error :"+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	

}
