package com.locus.jlo.web.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.TaskService;
import com.locus.jlo.web.services.WallService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class WallController {
	
	@Autowired
	private WallService wallService;
	
	@Autowired
	private TaskService taskService;
	

	 @RequestMapping(value = {"/wall"})
	  public String index() {
	        return "wall";
	  }
	 
	 
	 @RequestMapping(value = "/searchWall", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchWall(HttpServletRequest request,Locale locale) throws Exception{
		
		ServiceResult<List<DataBean>> listResult =  wallService.searchWall(); 
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
	   
		return result;
	   
	 }
	 
	 @RequestMapping(value = "/postWall", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean postWall(HttpServletRequest request,Locale locale) throws Exception{
		
	   
		 String userid = "131";
		 
		 String act  = request.getParameter("action");
		 String msgid = "";
		 String msg = "";
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 log.info("wall control");
		 log.info("action: "+act);
		 
	
		 /*
		 //
		 JSONParser jParser = new JSONParser();
		 Object obj = jParser.parse(data);
		 
		 JSONArray jArray = (JSONArray)obj;
		  
		 log.info( ""+jArray.get(0) );
		 
		 JSONObject jObject = (JSONObject)jArray.get(0);
	
		 log.info("project : "+jObject.get("pid"));
		 log.info("task id : "+jObject.get("tid"));
		 log.info("day     : "+jObject.get("date"));
		 log.info("month   : "+jObject.get("month"));
		 log.info("hour    : "+jObject.get("hour"));
		 log.info("eid     : "+jObject.get("eid"));
		 String timesheet_status = "1";
		 
		 String day = "2017-06-";
		 if(jObject.get("date").toString().length() == 1){
			 day += "0"+jObject.get("date");
		 }else{
			 day += ""+jObject.get("date");
		 }
		 */
		 
		try{
			switch (act){
		 	    case "I" : log.info("insert wall data");
					 		
							 msg = request.getParameter("msg");
							 log.info("msg:"+msg);
							 
							
		 	    
		 	    
		 	    			result =  wallService.insertWallPost( userid , msg  );
		 	    			if( result.isSuccess()){
		 	    			   log.info( "get long : "+result.getResult().longValue() );
		 	    			   result_data   = Long.toString(result.getResult().longValue());
		 	    			   result_status = "success";
							   result_msg    = "save successful";
		 	    				
		 	    			}else{
		 	    				result_status = "fail";
								result_msg    = "save fail";
		 	    			}
		 	    	
		 	    	break;
		 	    	
			    case "U" : log.info("update wall data");
			    
			    			 msg = request.getParameter("msg");
						     msgid = request.getParameter("msgid");
						     
							 log.info("msgid: "+msgid);
							 log.info("msg:"+msg);
				 
			    			result =  wallService.updateWallPost(  userid , msgid , msg );
							if( result.isSuccess()){
							log.info( "get long : "+result.getResult().longValue() );
							result_data   = Long.toString(result.getResult().longValue());
							result_status = "success";
							result_msg    = "save successful";
							
							}else{
							result_status = "fail";
							result_msg    = "save fail";
							}

 
				break;
				
				case "R" : log.info("remove wall data");
				
							     msgid = request.getParameter("msgid");
								 log.info("msgid: "+msgid);
				 
								result =  wallService.removeWallPost( userid , msgid   );
										
								if( result.isSuccess()){
								log.info( "get long : "+result.getResult().longValue() );
								result_data   = Long.toString(result.getResult().longValue());
								result_status = "success";
								result_msg    = "save successful";
								
								}else{
								result_status = "fail";
								result_msg    = "save fail";
								}
					    break;
			
					  default : log.error("something wrong");			
					 	    			
					 	    			
					return null;
				 }
	 
		}catch(Exception e){
			log.info("Error !!"+e);
		}
			
			JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
			return res;

	 }
	 
    
	 @RequestMapping(value = "/taskQryProjectMember", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean taskQryProjectMember(HttpServletRequest request) throws Exception{
			
			 Map<String, Object> m = new HashMap<String, Object>();
			 JsonResultBean result = null;
			 
			 String projectId = request.getParameter("projectId");
			 log.info("get projectId taskQry: "+projectId);
			 
		
			 ServiceResult<List<DataBean>> projectMember =  taskService.searchProjectMember(projectId);
			 log.info("reuslt"+ projectMember.isSuccess());
			 if(projectMember.isSuccess()){
				 m.put("member", projectMember.getResult());
			 }
			 
			 return new JsonResultBean("success", "" , m);
			 
						
		}
	 
	 @RequestMapping(value = "/taskQryTaskAssignee", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean taskQryTaskAssignee(HttpServletRequest request) throws Exception{
			
			 Map<String, Object> m = new HashMap<String, Object>();
			 JsonResultBean result = null;
			 
			 String projectId = request.getParameter("projectId");
			 String taskId 	  = request.getParameter("taskId");
			 
			 log.info("get projectId taskQry: "+projectId);
			 log.info("get taskId taskQry: "+taskId);
			 
			 //search member task assigned
			 ServiceResult<List<DataBean>> memberTaskAssign =  taskService.searchMemberTaskAssigned(projectId , taskId);
			 log.info("reuslt"+ memberTaskAssign.isSuccess());
			 if(memberTaskAssign.isSuccess()){
				 m.put("assignTask", memberTaskAssign.getResult());
			 }
			 
			 //search member not assigned task
			 ServiceResult<List<DataBean>> memberTaskNotAssign =  taskService.searchMemberTaskNotAssigned(projectId, taskId);
			 log.info("reuslt"+ memberTaskNotAssign.isSuccess());
			 if(memberTaskNotAssign.isSuccess()){
				 m.put("notAssignTask", memberTaskNotAssign.getResult());
			 }
			 
			 return new JsonResultBean("success", "" , m);
			 
						
		}
	 
	 
		@RequestMapping(value = "/saveTaskAssignee", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean saveTaskAssignee(HttpServletRequest request,Locale locale) throws Exception {
			
			 ServiceResult<Long> result = new ServiceResult<>();
		     String result_status = "";
			 String result_msg    = "";
			 String result_data   = "";
				 
		
			 String UID  = request.getSession().getAttribute("UID").toString();
			 String rm  = request.getParameter("rm");
			 String ins = request.getParameter("ins");
			 String upd = request.getParameter("upd");
			 
			try{
				
					 JSONParser jParser = new JSONParser();
					 
					 //DELETE first
					 Object rmObj = jParser.parse(rm);
					 JSONArray rmArray =  (JSONArray)rmObj;
					 int j = rmArray.size();
					
					 for(int i=0;i<j;i++){
						 
						 JSONObject removeTask = (JSONObject)rmArray.get(i);
						 result =  taskService.removeTaskTaskAssign(  removeTask.get("assigneeId").toString() );
						 log.info("remove assgin task "+i); 
					 }
					 
					 if( result.isSuccess()){
							log.info( "get long : "+result.getResult().longValue() );
							result_data   = Long.toString(result.getResult().longValue());
							result_status = "success";
							result_msg    = "save successful";
					
					 }else{
						 if (rmArray.size() == 0) {
							 result_status = "success";
							 result_msg    = "save successful";
						 } else {
							 result_status = "fail";
							 result_msg    = "save fail";
						 }
							
					 }
					 
					 
					 //INSERT second
					 Object insObj = jParser.parse(ins);
					 JSONArray insArray =  (JSONArray)insObj;
					 int k = insArray.size();
					 for(int i=0;i<k;i++){
						 
							JSONObject insertTask = (JSONObject)insArray.get(i);
							
							log.info("start dt: "+insertTask.get("startDt").toString());
							log.info("end dt: "+insertTask.get("endDt").toString());
							
							
							
						    result =  taskService.inserTaskAssign(  
						    			insertTask.get("projectid").toString(),
						    			insertTask.get("taskId").toString(),
						    			insertTask.get("userId").toString(),
						    			"1",
						    			insertTask.get("startDt").toString(),
						    			insertTask.get("endDt").toString(),
						    			UID
						    		  );
							
						    log.info("insert assgin task "+i); 
					 }
					 
					 
					 if( result.isSuccess()){
							log.info( "get long : "+result.getResult().longValue() );
							result_data   = Long.toString(result.getResult().longValue());
							result_status = "success";
							result_msg    = "save successful";
					
					 }else{
						 if (insArray.size() == 0) {
							 result_status = "success";
							 result_msg    = "save successful";
						 }else {
							 result_status = "fail";
							 result_msg    = "save fail";
						 }
							
					 }
					 
					 
				 
					 //UPDATE last
					 Object updObj = jParser.parse(upd);
					 JSONArray updArray =  (JSONArray)updObj;
					 int u = updArray.size();
					 for(int i=0;i<u;i++){
						 
							JSONObject updateTask = (JSONObject)updArray.get(i);
							
							log.info("assigneeId: "+updateTask.get("assigneeId").toString());
							log.info("start dt: "+updateTask.get("startDt").toString());
							log.info("end dt: "+updateTask.get("endDt").toString());
							
							
							
							result =  taskService.updateTaskAssign(  
						    			updateTask.get("assigneeId").toString(),
						    			updateTask.get("startDt").toString(),
						    			updateTask.get("endDt").toString()
						    		  );
							
						    log.info("update assgin task "+i); 
					 }
					 
					 
					 if( result.isSuccess()){
							log.info( "get long : "+result.getResult() );
							result_data   = Long.toString(result.getResult().longValue());
							result_status = "success";
							result_msg    = "save successful";
					
					 }else{
						 if (updArray.size() == 0) {
							 result_status = "success";
							 result_msg    = "save successful";
						 } else {
							 result_status = "fail";
							 result_msg    = "save fail";
						 }
							
					 }
					 
			 }catch(Exception e){
				 log.info("Error !!"+e);
					e.printStackTrace();
			 }
			
			JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
			return res;
			 
		}
	 
}