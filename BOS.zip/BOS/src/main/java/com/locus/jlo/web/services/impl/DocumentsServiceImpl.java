package com.locus.jlo.web.services.impl;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.module.DocumentsBean;
import com.locus.jlo.web.services.DocumentsService;
import lombok.extern.slf4j.Slf4j;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class DocumentsServiceImpl extends BaseService implements DocumentsService{
	
	String SQL_SEARCH = "DOCUMENTS.SQL_SEARCH";
	String SQL_SEARCH_DEAL_PROJECT = "DOCUMENTS.SQL_SEARCH_DEAL_PROJECT";
	
	String SQL_INSERT = "DOCUMENTS.SQL_INSERT";
	String SQL_UPDATE = "DOCUMENTS.SQL_UPDATE";
	String SQL_DELETE = "DOCUMENTS.SQL_DELETE";

	@Override
	public ServiceResult<List<DataBean>> searchDocuments(DocumentsBean documentsBean) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<>();
		try {
			
			List<DataBean> result = dynamicJdbcDao.findForList(SQL_SEARCH
					, BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("project_id", documentsBean.getProject_id())
					, new SimpleKeyValue("id", documentsBean.getId()));
			
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}
	
   
	@Override
	public ServiceResult<List<DataBean>> searchDealInProjectDocuments(DocumentsBean documentsBean) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<>();
		try {
			
			List<DataBean> result = dynamicJdbcDao.findForList(SQL_SEARCH_DEAL_PROJECT
					, BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("project_id", documentsBean.getProject_id()) );
			
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}

	
	@Override
	public ServiceResult<Integer> insertDocuments(DocumentsBean documentsBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, documentsBean ).intValue();
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> updateDocuments(DocumentsBean documentsBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, documentsBean);
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> removeDocuments(Integer doc_id) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",doc_id));
			result.setResult(res);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}
}
