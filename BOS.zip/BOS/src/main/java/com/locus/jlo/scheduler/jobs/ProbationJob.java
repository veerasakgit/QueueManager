package com.locus.jlo.scheduler.jobs;

import java.util.Calendar;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.quartz.UnableToInterruptJobException;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.services.BashService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@PersistJobDataAfterExecution
@DisallowConcurrentExecution
@Component
public class ProbationJob extends BaseQuartzJob implements InterruptableJob
{
	private BashService bashService;
	
	@Override
	public void interrupt() throws UnableToInterruptJobException {log.info("INTERRUPTING");}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
	{
		log.info("APPLICATION NAME: [{}]", applicationContext.getApplicationName());
		bashService = applicationContext.getBean(BashService.class);
	}

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException
	{
		log.info("==>>> JOBS: ProbationJob ========================== " + Calendar.getInstance().getTime());
		log.info("************************************************");
		try
		{
			//Date startDate = (Date)context.getJobDetail().getJobDataMap().get(SchedulerConstant.SCHEDULE_START_DATE);
			//Date endDate = (Date)context.getJobDetail().getJobDataMap().get(SchedulerConstant.SCHEDULE_END_DATE);
			
			ServiceResult<Long> listResult =  bashService.autoUpdatePassProbation();
			
			if (listResult != null && listResult.isSuccess())
				log.info(">>>>> Success: [{}] <<<<<", listResult.getResult());
			else
				log.info(">>>>> Fail <<<<<");
			
        } catch (Exception ex)
		{
            log.error(ex.getMessage(), ex);
            JobExecutionException jee = new JobExecutionException(ex);
            throw jee;
        } finally
		{
        	log.info("======================== JOBS: ProbationJob ==>>> " + Calendar.getInstance().getTime());
        }
	}
}
