/**
 * created-date: 2019-06-12
 * original-from: MakroAdmin project
 */

package com.locus.jlo.web.controller;

import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.constant.JLOWebConstant;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.util.Bos2Utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletRequest;

@Component
public class BaseController
{
	@Autowired protected MessageSource messageSource;
	
	protected static final String PAGEABLE_ATTRIBUTE = "pageable";
	protected static final String SESS_CRITERIA_ALREADY_SEARCH = "alreadySearch";
	
	protected void setMenuId(HttpServletRequest request)
	{
		String menuId = request.getParameter(JLOWebConstant.SESSION_MENU_ID);
		if (menuId != null && !"".equals(menuId))
		{
			//log.debug("MENU ID [ " + menuId + " ]");
			removeSessionAttr(request, JLOWebConstant.SESSION_MENU_ID);
			setSessionAttr(request, JLOWebConstant.SESSION_MENU_ID, menuId);
		}
	}
	
	protected Object getSessionMenuId(HttpServletRequest request) { return getSessionAttr(request, JLOWebConstant.SESSION_MENU_ID); }

	protected void showWebMessage(HttpServletRequest request, String code, String desc)
	{
		if (code == null)
			code = JLOWebConstant.FAIL_CODE;
		if (desc == null)
			desc = JLOWebConstant.FAIL_DESC;
		
		setSessionAttr(request,BOSConstant.STRING_RESULT_TITLE, code);
		setSessionAttr(request,BOSConstant.STRING_RESULT_DESC, desc);
	}
	
	protected void showWebMessage(HttpServletRequest request, String code, String desc, String title)
	{
		if (code == null)
			code = JLOWebConstant.FAIL_CODE;
		if (desc == null)
			desc = JLOWebConstant.FAIL_DESC;
		if (title == null)
			title = "";
		
		setSessionAttr(request,BOSConstant.STRING_RESULT_CODE, code);
		setSessionAttr(request,BOSConstant.STRING_RESULT_DESC, desc);
		setSessionAttr(request,BOSConstant.STRING_RESULT_TITLE, title);
	}
	
	protected Object getSessionAttr(HttpServletRequest request, String code) { return request.getSession().getAttribute(code); }
	protected void setSessionAttr(HttpServletRequest request, String code, Object obj) { request.getSession().setAttribute(code, obj); }
	protected void removeSessionAttr(HttpServletRequest request, String code) { request.getSession().removeAttribute(code); }
	
	protected Pageable getPagableFromRequest(HttpServletRequest request)
	{
		String iDisplayStartTxt = request.getParameter("iDisplayStart");
		String iDisplayLengthTxt = request.getParameter("iDisplayLength");
		
		Integer iDisplayStart = (!Bos2Utils.isNullOrEmpty(iDisplayStartTxt)) ? Integer.valueOf(iDisplayStartTxt) : 0;
		Integer iDisplayLength = (!Bos2Utils.isNullOrEmpty(iDisplayLengthTxt)) ? Integer.valueOf(iDisplayLengthTxt) : 0;
		Integer cPage = 0;
		
		if (iDisplayStart != 0)
			cPage = (iDisplayStart / iDisplayLength) ;

		return new PageRequest(cPage, iDisplayLength);
	}
	
	protected Integer getSecho(HttpServletRequest request)
	{
		String sEchoTxt = request.getParameter("sEcho");
		Integer sEcho = (!Bos2Utils.isNullOrEmpty(sEchoTxt)) ? Integer.valueOf(sEchoTxt) : 0;
		
		return sEcho;
	}
	
	protected UserInfoDTO getUserInfo(HttpServletRequest request) { return (UserInfoDTO) request.getSession().getAttribute(BOSConstant.USER_PROFILE); }
	protected String getUserId(HttpServletRequest request)
	{
		try
		{
			return getUserInfo(request).getUid();
		} catch (Exception e)
		{
			return "";
		}
	}
	
	protected String getDataTableOrderBy(HttpServletRequest request)
	{
		String iSortCol_0 = request.getParameter("iSortCol_0");
		String sSortDir_0 = request.getParameter("sSortDir_0");
		if(iSortCol_0==null)
		{
			return "";
		}
		if(sSortDir_0==null)
		{
			sSortDir_0 = "asc";
		}
		String mDataProp = request.getParameter("mDataProp_"+iSortCol_0);
		if(mDataProp==null)
		{
			return "";
		}
		return mDataProp+" "+sSortDir_0;
	}
}
