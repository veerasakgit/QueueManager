package com.locus.jlo.web.beans;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TreeParentBean {
	
	private String id;
	private String name;
	private String level;
	private String parentId;

}
