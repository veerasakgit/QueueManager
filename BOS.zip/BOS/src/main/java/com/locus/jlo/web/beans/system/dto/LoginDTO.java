package com.locus.jlo.web.beans.system.dto;

import com.locus.jlo.web.beans.system.modelbean.MenuDetailModelBean;
import java.util.List;
import org.springframework.security.core.GrantedAuthority;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.security.core.userdetails.User;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper = false, doNotUseGetters = true, of = "userId")
public class LoginDTO extends User {

    private static final long serialVersionUID = -7155518853403064085L;

    private String userId;
    private String login;
    private String password;
    private String authenMode;
    private List<GrantedAuthority> authorityInfo;
    private UserInfoDTO userInfo;
    private List<MenuDetailModelBean> menuInfo;

    public LoginDTO(String userName, String password, List<GrantedAuthority> authorities, String authenMode) {
        super(userName, password, authorities);

        this.login = userName;
        this.password = password;
        this.authorityInfo = authorities;
        this.authenMode = authenMode;
      
    }
}
