package com.locus.jlo.web.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.department.DepartmentBean;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriodRes;
import com.locus.jlo.web.beans.setting.SettingDeptBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.SettingDeptService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class SettingDeptController extends CoreController {
	
	@Autowired
	private SettingDeptService settingDeptService;
	
	@RequestMapping(value = "/searchSettingDept", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchSettingDept(HttpServletRequest request,Locale locale) throws Exception{
		
		
		String id = request.getParameter("viewId");
		
		ServiceResult<List<Map<String, Object>>> listResult =  settingDeptService.searchSettingDept(id);
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
		return result;
	 }
	
	@RequestMapping(value = "/searchSettingDeptViewDetail", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.GET)
	public @ResponseBody ModelAndView searchSettingDeptViewDetail(HttpServletRequest request,Locale locale) throws Exception{
		String id = request.getParameter("id");
		return new ModelAndView("departmentDetail", "departmentId", id);
	 }
	
	@RequestMapping(value = "/searchSettingDeptViewDetailById", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchSettingDeptViewDetailById(HttpServletRequest request,Locale locale) throws Exception{
		JsonResultBean result = null;
		Map<String, Object> mapObject = new HashMap<String, Object>();
		String result_status = "success";
		String result_msg    = "search success";
		
		String id = request.getParameter("id");
		mapObject.put("departmentId", id); 
		
		ServiceResult<DepartmentBean> departResult =  settingDeptService.searchSettingDeptDetailById(id);
		if(departResult.isSuccess()){
			mapObject.put("departDetailById", departResult.getResult());
			
			DepartmentBean bean = departResult.getResult();
			if(bean != null){
				String projectId = bean.getDeptProjectId();
				
				if(projectId == null){
					projectId = "";
				}
				
				ServiceResult<DepartmentBean> departProjectResult =  settingDeptService.searchSettingDeptProjectDetailById(projectId);
				if(departProjectResult.isSuccess()){
					mapObject.put("departProjectDetailById", departProjectResult.getResult());
				}
			}
		}
		
		result = new JsonResultBean(result_status, result_msg , mapObject);
		return result;
	 }
	
	@RequestMapping(value = "/searchSettingDeptMember", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchSettingDeptMember(HttpServletRequest request,Locale locale) throws Exception{
		
		String id = request.getParameter("viewId");
		
		ServiceResult<List<Map<String, Object>>> listResult =  settingDeptService.searchSettingDeptMember(id);
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
		return result;
	}
	
	@RequestMapping(value = "/saveSettingDept", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveSettingDept(HttpServletRequest request,Locale locale) throws Exception{
			
		 final Integer USER_ID = getUid(request);
		 String data = request.getParameter("data");
		 String id = request.getParameter("viewId");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		 		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 log.info("saveSettingDept");
		 log.info("data: "+data);
		 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
			 
		 log.info( ""+json );
			 
		 JsonBeanUtils<SettingDeptBean> utils = new JsonBeanUtils<SettingDeptBean>(SettingDeptBean.class);
		 
		 //convert between form and bean
		 SettingDeptBean dept = utils.convertFormAndBean(json);
		 dept.setCreate_uid(USER_ID);
		 dept.setUpdate_uid(USER_ID);
				
		 try{
			try {
				Integer.parseInt(dept.getParent_id());
			} catch (Exception e) {
				dept.setParent_id(null);
			}
			
			String act =  StringUtils.isEmpty(id) ? "I":"U";
			 
			switch (act){
		 	    case "I" : log.info("insert data");
	 	    			result =  settingDeptService.insertSettingDept(dept);
	 	    			
	 	    			if( result.isSuccess()){
	 	    			   log.info( "get long : "+result.getResult().longValue() );
	 	    			   result_data   = Long.toString(result.getResult().longValue());
	 	    			   result_status = "success";
						   result_msg    = "save successful";
	 	    				
	 	    			}else{
	 	    				result_status = "fail";
							result_msg    = "save fail";
	 	    			}
						break;
					
		 	    case "U" : log.info("update data");
 	    				dept.setId(Integer.parseInt(id));
 	    				
 	    				
 						result =  settingDeptService.updateSettingDept(dept);
 						
						if( result.isSuccess()){
							log.info( "get long : "+result.getResult().longValue() );
							result_data   = Long.toString(result.getResult().longValue());
							result_status = "success";
							result_msg    = "save successful";		
						}else{
							result_status = "fail";
							result_msg    = "save fail";
						}
		 	   			break;
		 	   default : log.error("No action");
			}
			
		}catch(Exception e){
			log.info("Error !!"+e);
		}
		 
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
	}
		 
	 @RequestMapping(value = "/saveSettingDeptMember", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveSettingDeptMember(HttpServletRequest request,Locale locale) throws Exception{

			
			//https://www.tutorialspoint.com/json/json_java_example.htm
			final Integer USER_ID = getUid(request);
			String data = request.getParameter("data");
			String viewId = request.getParameter("viewId");
			 
			ServiceResult<Long> result = new ServiceResult<>();

			String result_status = "";
			String result_msg    = "";
			String result_data   = "";
			 
			List<SettingUserBean> beans = null;
			 
			 if (!data.equals("{}")) {
				JSONParser jParser = new JSONParser();
				JSONObject json = (JSONObject)jParser.parse(data);
				JsonBeanUtils<SettingUserBean> utils = new JsonBeanUtils<>(SettingUserBean.class);
				beans = utils.convertFormAndBean(json, "id", USER_ID);
				

				 try{
					 
						if (!CollectionUtils.isEmpty(beans)) {
//							
	    	   				String[] isDeptHeadArr = beans.get(0).getIs_dept_head_arr()==null?null:beans.get(0).getIs_dept_head_arr().split(",");
 	    					String[] isDeptAppr = beans.get(0).getIs_dept_appr_arr()==null?null:beans.get(0).getIs_dept_appr_arr().split(",");
 	    					
 	    					for (SettingUserBean bean : beans) {
 	    						
 	    						bean.setIs_dept_head("N");
 	    						bean.setIs_dept_appr("N");
 	    						
 	    						bean.setMain_dept_id(Integer.parseInt(viewId));
								if (utils.isEqualInJsonArray(bean.getId().toString(),isDeptHeadArr)) {
									bean.setIs_dept_head("Y");
								}
								if (utils.isEqualInJsonArray(bean.getId().toString(),isDeptAppr)) {
									bean.setIs_dept_appr("Y");
								}
							}
 	    					
 	    					utils.testPrint(beans);
 	    					
 	    					result =  settingDeptService.saveSettingDeptMember(beans);
	 						
							if( result.isSuccess()){
								log.info( "get long : "+result.getResult().longValue() );
								result_data   = Long.toString(result.getResult().longValue());
								result_status = "success";
								result_msg    = "save successful";		
							}else{
								result_status = "fail";
								result_msg    = "save fail";
							}

						}	
						}catch(Exception e){
							log.info("Error !!"+e);
						}
			 }
			 
			JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
			return res;
		   

		
	 }
	 
	 
		@RequestMapping(value = "/removeSettingDept", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean removeSettingDept(HttpServletRequest request,Locale locale) throws Exception{
			
			String id  = request.getParameter("id");
			log.info("id: "+id);
			ServiceResult<Long> idResult =  settingDeptService.removeSettingDept(id);
			JsonResultBean result = null;
			if(idResult.isSuccess()){
				result = new JsonResultBean("success", "" , idResult.getResult());
			}
			return result;
		 }

		
		
		@RequestMapping(value = "/initialDivision", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean initialDivision(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
	 
		//Map<String, Object> m = new HashMap<String, Object>();
		//JsonResultBean res = null;
		
		ServiceResult<List<KeyValueBean>> listResult = new ServiceResult<List<KeyValueBean>>();
		listResult =  settingDeptService.searchSettingDevision();

		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}

		return result;
		
	}
		@RequestMapping(value = "/initialDivisionNew", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean initialDepartmentNew(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
	 
			String cri = request.getParameter("cri");
			JSONParser jParser = new JSONParser();
			JSONObject json = (JSONObject)jParser.parse(cri);
			
			 String division = json.get("divisionddd").toString();
		log.info("divisionddd : "+division);
		ServiceResult<List<KeyValueBean>> listResult = new ServiceResult<List<KeyValueBean>>();
		listResult =  settingDeptService.searchSettingDepartment(division);

		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}

		return result;
		
	}
		
	@RequestMapping(value = "/initialDepartment", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean initialDepartment(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
	 
		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(cri);
			
		String division = json.get("division").toString();
		log.info("division : "+division);
		ServiceResult<List<KeyValueBean>> listResult = new ServiceResult<List<KeyValueBean>>();
		listResult =  settingDeptService.searchSettingDepartment(division);

		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}

		return result;
		
	}
	
	@RequestMapping(value = "/searchDivisionByDepartmentId", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchDivisionByDepartmentId(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
			
		String department = null;
		ServiceResult<List<KeyValueBean>> listResult = new ServiceResult<List<KeyValueBean>>();
		listResult =  settingDeptService.searchDivisionByDepartmentId(department);

		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}

		return result;
		
	}
	
	@RequestMapping(value = "/searchDepartmentBySectionId", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchDepartmentBySectionId(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
	 
		String division = null;
		ServiceResult<List<KeyValueBean>> listResult = new ServiceResult<List<KeyValueBean>>();
		listResult =  settingDeptService.searchDepartmentBySectionId(division);

		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}

		return result;
		
	}
		
		@RequestMapping(value = "/initialSection", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean initialSection(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
	 
			String cri = request.getParameter("cri");
			JSONParser jParser = new JSONParser();
			JSONObject json = (JSONObject)jParser.parse(cri);
			
			 String department = json.get("department").toString();
		log.info("department : "+department);
		ServiceResult<List<KeyValueBean>> listResult = new ServiceResult<List<KeyValueBean>>();
		listResult =  settingDeptService.searchSettingSection(department);

		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}

		return result;
		
	}
		
		@RequestMapping(value = "/initialSectionFrist", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean initialSectionFrist(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
	 
			String department = request.getParameter("id");
			/*JSONParser jParser = new JSONParser();
			JSONObject json = (JSONObject)jParser.parse(cri);
			
			 String department = json.get("department").toString();*/
			log.info("departmentOOO! : "+department);
			 
		ServiceResult<List<KeyValueBean>> listResult = new ServiceResult<List<KeyValueBean>>();
		listResult =  settingDeptService.searchSettingSection(department);

		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}

		return result;
		
	}
		
		@RequestMapping(value = "/initialDepartmentFrist", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean initialDepartmentFrist(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
			String division = request.getParameter("id");
			/*JSONParser jParser = new JSONParser();
			JSONObject json = (JSONObject)jParser.parse(cri);
			
			 String department = json.get("department").toString();*/
			log.info("divisionOOO! : "+division);
		ServiceResult<List<KeyValueBean>> listResult = new ServiceResult<List<KeyValueBean>>();
		listResult =  settingDeptService.searchSettingDepartment(division);

		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}

		return result;
		
	}
		
	@RequestMapping(value = "/saveSettingDeptAndProject", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveSettingDeptAndProject(HttpServletRequest request,Locale locale) throws Exception{
			
		 final Integer USER_ID = getUid(request);
		 String data = request.getParameter("data");
		 String departmentId = request.getParameter("departmentId");
		 String departmentProjectId = request.getParameter("departmentProjectId");
		 String deptProjectName = request.getParameter("deptProjectName");
		 String deptProjectPlanStartDate = request.getParameter("deptProjectPlanStartDate");
		 String deptProjectPlanEndDate = request.getParameter("deptProjectPlanEndDate");
		 String deptProjectStatus = request.getParameter("deptProjectStatus");
		 String deptProjectUniName = request.getParameter("deptProjectUniName");
		 String deptParentId = request.getParameter("deptParentId");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		 ServiceResult<Long> resultProject = new ServiceResult<>();
		 ServiceResult<Long> resultProjectIndentify = new ServiceResult<>();
		 ServiceResult<Long> resultTaskTemplate = new ServiceResult<>();
		 		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 log.info("saveSettingDept");
		 log.info("data: "+data);
		 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
			 
		 JsonBeanUtils<SettingDeptBean> utils = new JsonBeanUtils<SettingDeptBean>(SettingDeptBean.class);
		 
		 //convert between form and bean
		 SettingDeptBean dept = utils.convertFormAndBean(json);
		 dept.setCreate_uid(USER_ID);
		 dept.setUpdate_uid(USER_ID);
		 
		 DepartmentBean deptProject = new DepartmentBean();
		 deptProject.setDeptProjectId(departmentProjectId);
		 deptProject.setDeptProjectName(deptProjectName);
		 deptProject.setDeptProjectUniName(deptProjectUniName);
		 deptProject.setDeptProjectPlanStartDate(deptProjectPlanStartDate);
		 deptProject.setDeptProjectPlanEndDate(deptProjectPlanEndDate);
		 deptProject.setDeptProjectStatus(deptProjectStatus);
		 deptProject.setDeptCreateBy(String.valueOf(USER_ID));
		 deptProject.setDeptUpdateBy(String.valueOf(USER_ID));
		 deptProject.setDeptProjectType("0");
		 deptProject.setDeptProjectActualStartDate(deptProjectPlanStartDate);
		 deptProject.setDeptProjectActualEndDate(deptProjectPlanEndDate);
		 deptProject.setDeptProjectTypePd("P");
		 deptProject.setDeptProjectStatusIndentity("1");
		 deptProject.setDeptParentId(deptParentId);
				
		 try{
			try {
				Integer.parseInt(dept.getParent_id());
			} catch (Exception e) {
				dept.setParent_id(null);
			}
			
			//Department save
			String act =  StringUtils.isEmpty(departmentId) ? "I":"U";
			 
			switch (act){
		 	    case "I" : log.info("insert data");
	 	    			result =  settingDeptService.insertSettingDept(dept);
	 	    			
	 	    			if( result.isSuccess()){
	 	    			   log.info( "get long : "+result.getResult().longValue() );
	 	    			   result_data   = Long.toString(result.getResult().longValue());
	 	    			   result_status = "success";
						   result_msg    = "save successful";
	 	    				
	 	    			}else{
	 	    				result_status = "fail";
							result_msg    = "save fail";
	 	    			}
						break;
					
		 	    case "U" : log.info("update data");
 	    				dept.setId(Integer.parseInt(departmentId));
 	    				
 	    				
 						result =  settingDeptService.updateSettingDept(dept);
 						
						if( result.isSuccess()){
							log.info( "get long : "+result.getResult().longValue() );
							result_data   = Long.toString(result.getResult().longValue());
							result_status = "success";
							result_msg    = "save successful";		
						}else{
							result_status = "fail";
							result_msg    = "save fail";
						}
		 	   			break;
		 	   default : log.error("No action");
			}
			
			//Department Project save
			String actProject =  StringUtils.isEmpty(departmentProjectId) ? "I":"U";
			 
			switch (actProject){
		 	    case "I" : log.info("insert data");
		 	    		//Insert Project table
		 	    		resultProjectIndentify =  settingDeptService.insertSettingDeptProjectIndentifyKey(deptProject);
		 	    		
	 	    			
		 	    		//Insert identify key table
	 	    			if( resultProjectIndentify.isSuccess()){
	 	    				
	 	    				deptProject.setDeptProjectId(String.valueOf(resultProjectIndentify.getResult()));
	 	    				resultProject  =  settingDeptService.insertSettingDeptProject(deptProject);
		 	    			
		 	    			if( resultProject.isSuccess()){
		 	    				
		 	    				//Update project_id in department table
		 	    				if(act.equals("U")){
		 	    					dept.setId(Integer.valueOf(departmentId));
		 	    				}else{
		 	    					dept.setId(result.getResult().intValue());
		 	    				}
		 	    				
		 	    				dept.setProject_id(String.valueOf(resultProjectIndentify.getResult())); //Set project Id
		 	    				result =  settingDeptService.updateProjectSettingDept(dept);
		 						
								if( result.isSuccess()){
									
									//Insert Task Template
									resultTaskTemplate = settingDeptService.insertTaskTemplateDepartmentProject(deptProject);
									if(resultTaskTemplate.isSuccess()){
										result_status = "success";
										result_msg    = "save successful";
										
									}else{
										result_status = "fail";
										result_msg    = "save fail";
									}
									
								}else{
									result_status = "fail";
									result_msg    = "save fail";
								}
		 	    			}
	 	    				
	 	    			}else{
	 	    				result_status = "fail";
							result_msg    = "save fail";
	 	    			}
						break;
					
		 	    case "U" : log.info("update data");
		 	    		deptProject.setDeptProjectId(departmentProjectId);
 	    				
 	    				resultProject =  settingDeptService.updateSettingDeptProject(deptProject);
 						
						if( resultProject.isSuccess()){
							log.info( "get long : "+resultProject.getResult().longValue() );
							result_data   = Long.toString(resultProject.getResult().longValue());
							result_status = "success";
							result_msg    = "save successful";		
						}else{
							result_status = "fail";
							result_msg    = "save fail";
						}
		 	   			break;
		 	   default : log.error("No action");
			}
			
		}catch(Exception e){
			log.info("Error !!"+e);
		}
		 
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
	}
}