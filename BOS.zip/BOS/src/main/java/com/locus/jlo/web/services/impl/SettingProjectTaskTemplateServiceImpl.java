package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.setting.SettingProjectTaskTemplateBean;
import com.locus.jlo.web.services.SettingProjectTaskTemplateService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SettingProjectTaskTemplateServiceImpl extends BaseService implements SettingProjectTaskTemplateService {

	// Query
	private final String SQL_SEARCH = "SETTING_PROJECT_TASK_TEMPLATE.SQL_SEARCH";

	// Excute
	private final String SQL_INSERT = "SETTING_PROJECT_TASK_TEMPLATE.SQL_INSERT";
	private final String SQL_UPDATE = "SETTING_PROJECT_TASK_TEMPLATE.SQL_UPDATE";
	private final String SQL_DELETE = "SETTING_PROJECT_TASK_TEMPLATE.SQL_DELETE";

	@Override
	public ServiceResult<List<Map<String, Object>>> searchProjectTaskTemplate(String id) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();

		try {
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH,new SimpleKeyValue("id",ObjectBeanUtils.isNullStr(id)));
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());

		} catch (Exception e) {
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> insertProjectTaskTemplate(SettingProjectTaskTemplateBean bean) throws Exception {

		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	
	}

	@Override
	public ServiceResult<Long> updateProjectTaskTemplate(SettingProjectTaskTemplateBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer delId = dynamicJdbcDao.executeUpdate(SQL_UPDATE,bean);
				result.setResult(Long.valueOf(delId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
		
	
	}

	@Override
	public ServiceResult<Long> deleteProjectTaskTemplate(String id) throws Exception {
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer delId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(delId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
		
	}

}
