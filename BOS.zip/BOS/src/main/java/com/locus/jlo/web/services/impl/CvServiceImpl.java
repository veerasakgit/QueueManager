package com.locus.jlo.web.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.cv.CvBean;
import com.locus.jlo.web.beans.trainingRecord.TrainingRecordBean;
import com.locus.jlo.web.services.CvService;
import com.locus.jlo.web.services.TrainingRecordService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class CvServiceImpl extends BaseService implements CvService{

	//Query
	final String SQL_SEARCH = "CV.SQL_SEARCH";
	
	//Excute
	final String SQL_INSERT = "CV.SQL_INSERT";
	final String SQL_DELETE = "CV.SQL_DELETE";
	
	@Override
	public ServiceResult<List<Map<String, Object>>> searchCv(String userId) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();

		try{

			Map<String, Object> param = new HashMap<>(1);

			param.put("userId", ObjectBeanUtils.isNullStr(userId));
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH, param);

			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<Long> insertCv(CvBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}
	
	@Override
	public ServiceResult<Long> deleteCv(String id) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
			
				final int returnId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(returnId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}
}
