package com.locus.jlo.web.services.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.common.mapper.PrimitiveSafeBeanPropertyRowMapper;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.medicalAllowance.MedicalAllowanceBean;
import com.locus.jlo.web.services.MedicalAllowanceService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class MedicalAllowanceServiceImpl extends BaseService implements MedicalAllowanceService{
	
	String SQL_STAFF_PROBATION_CHECK = "MEDICAL_ALLOWANCE.FIND_STAFF_PROBATION";
	
	String SQL_SEARCH = "MEDICALL_ALLOWANCE.SQL_SEARCH";
	String SQL_SEARCH_DETAIL = "MEDICAL_ALLOWANCE.SQL_SEARCH_DETAIL";
	
	
	String SQL_DELETE = "MEDICALL_ALLOWANCE.SQL_DELETE";
//	String SQL_SEARCH_MEDICALL_ALLOWANCE_DETAIL = "MEDICALL_ALLOWANCE.SQL_SEARCH_MEDICALL_ALLOWANCE_DETAIL";
	
	String SQL_INSERT = "MEDICALL_ALLOWANCE.SQL_INSERT";
	String SQL_UPDATE = "MEDICALL_ALLOWANCE.SQL_UPDATE";
	
	String SQL_IMPORT_INSERT = "MEDICALL_ALLOWANCE.SQL_IMPORT_INSERT";
	
	String SQL_USER_SEARCH = "SETTING_USER.SQL_SEARCH";
	
	String SQL_USER_SEARCH_DETAIL = "SETTING_USER.SQL_SEARCH_DETAIL";
	
	
	//Nonn
	String SQL_FIND_USER_BY_LOCUS_EMPID = "MEDICAL_ALLOWANCE_IMPORT.SQL_FIND_USER_BY_LOCUS_EMPID";

	@Override
	public ServiceResult<List<DataBean>> searcStaffProbationCheck(String year,String userId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
		
			//change year parameter
			String end_year   = year+"-12-31";
			String start_year = year+"-01-01";
			
			
			result = dynamicJdbcDao.findForList(SQL_STAFF_PROBATION_CHECK,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("endYear",end_year)
					,new SimpleKeyValue("startYear",start_year)
					,new SimpleKeyValue("userId",userId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
		
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchMedicalAllowance(String year,String userId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
		
			result = dynamicJdbcDao.findForList(SQL_SEARCH,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("year",year)
					,new SimpleKeyValue("userId",userId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
		
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	//search detail
	@Override
	public ServiceResult<List<DataBean>> searchMedicalAllowanceDetail(String medicalId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
		
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_DETAIL,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("medicalId",medicalId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
		
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	/*
	public ServiceResult<List<Map<String, Object>>> searchMedicalAllowance(String year,String id,String userId) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();
			
		
		try{
		
			HashMap<String, Object> param = new HashMap<>();
			param.put("year",ObjectBeanUtils.isNullStr(year));
			param.put("id",ObjectBeanUtils.isNullStr(id));
			param.put("userId",ObjectBeanUtils.isNullStr(userId));
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH,param);
			
//			dataNotFound(result);
			
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}
*/

	@Override
	public ServiceResult<Long> insertMedicalAllowance(MedicalAllowanceBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}


	@Override
	public ServiceResult<Long> updateMedicalAllowance(MedicalAllowanceBean bean) throws Exception {

		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, bean);
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	
	}


	@Override
	public ServiceResult<Integer> saveImportMedicalAllowance(MedicalAllowanceBean bean) throws Exception {
		

		final ServiceResult<Integer> result = new ServiceResult<>();
	
		try{
				
			    Integer caseVal = validate(bean);

				if (caseVal == 0) {
					final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
		            result.setSuccess(Boolean.TRUE); 
				}
				
				result.setResult(caseVal);
				
				
		}catch(Exception e){ 
			   log.error(e.getMessage(),e);
	           setErrorResult(result, e);
		}
		
		

		return result;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> findUserByLocusEmpId(String empId) throws Exception {
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<>();
		try{
			List<DataBean> result = dynamicJdbcDao.findForList(SQL_FIND_USER_BY_LOCUS_EMPID, PrimitiveSafeBeanPropertyRowMapper.newInstance(DataBean.class)
											,new SimpleKeyValue("empId",empId));
			
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		
		return serviceResult;
	}
	
	
	@Override
	@Transactional
	public ServiceResult<Long> importMedicalAllowance(List<DataBean> db) throws Exception{
		
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			List<DataBean> arr = db;
			int dataLength = arr.size();
			Integer success = 0;
			for(int i=0;i<dataLength;i++){
				DataBean d = arr.get(i);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_IMPORT_INSERT, 
						new SimpleKeyValue("empId",d.getA()) , 
						new SimpleKeyValue("receiptDate",d.getB()) , 
						new SimpleKeyValue("receiptAmount",d.getC()),
						new SimpleKeyValue("paymentDate",d.getD()),
						new SimpleKeyValue("hospital",d.getE()),
						new SimpleKeyValue("disease",d.getF()),
						new SimpleKeyValue("staffMedical",d.getG()),
						new SimpleKeyValue("staffDental",d.getH()),
						new SimpleKeyValue("staffEyes",d.getI()),
						new SimpleKeyValue("familyMedical",d.getJ()),
						new SimpleKeyValue("familyDental",d.getK()),
						new SimpleKeyValue("familyEyes",d.getL()),
						new SimpleKeyValue("comment",d.getM()), //note -> comment
						new SimpleKeyValue("medicalAllowance",d.getN()), //medical allowance
						new SimpleKeyValue("createUid",d.getS()),
						new SimpleKeyValue("userId",d.getT())
				 );
				
				if(cnt==1){
					success++;
				}
			}
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			log.info("submitWorkhour Error: "+e);
			throw e;
		}
	
		return result;
		
	}
	 
	/*
	@Override
	private ServiceResult<DataBean> findUserIdByLocusEmpId(String empId) throws Exception{
		
		ServiceResult<DataBean> serviceResult = new ServiceResult<>();
		try{
			DataBean result = dynamicJdbcDao.findForObject(SQL_FIND_LOCUS_EMPID,
					PrimitiveSafeBeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("empId",empId));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		
		
		return serviceResult;
		
		
	}
	
	
	@Override
	private ServiceResult<DataBean>  saveMedicalAllowanceImport(DataBean db) throws Exception{
		//step1 check employee_id is 
		//SELECT id FROM t_users WHERE emp_id = AND status = 
		
		List<DataBean> db = dynamicJdbcDao.findForList("SQL_FIND_EMPLOYE_ID", new SimpleKeyValue("employee_id", db.getA());
		
		
		//setp2 check insert 
		
		
		return 
	}
	*/

	private int validate(MedicalAllowanceBean bean) throws Exception {
		
		Integer caseVal = 1;
		
		
		
		List<Map<String,Object>> userList = dynamicJdbcDao.findForList(SQL_USER_SEARCH, new SimpleKeyValue("employee_id",bean.getEmployee_id()));
		//fixed
		BigDecimal total = new BigDecimal(1.5);
		/*
		BigDecimal total = bean.getStaff_medical_amount().add(bean.getFamily_medical_amount()
							.add(bean.getStaff_dental_amount().add(bean.getFamily_dental_amount()
							.add(bean.getStaff_eyes_amount().add(bean.getFamily_eyes_amount())))));
		*/
		if (StringUtils.isEmpty(bean.getEmployee_id())||StringUtils.isEmpty(bean.getReceipt_date())
				||ObjectBeanUtils.isNullOrZero(bean.getReceipt_amount())||StringUtils.isEmpty(bean.getHospital())
				||StringUtils.isEmpty(bean.getDisease())) {
			caseVal = 2;
		}else if (total.compareTo(BigDecimal.ZERO) <= 0) {
			caseVal = 3;
		}
		else if (CollectionUtils.isEmpty(userList)) {
			caseVal = 1;
		}
		else if(!CollectionUtils.isEmpty(userList)){

			
			Integer userId = Integer.parseInt(userList.get(0).get("id").toString());
			List<Map<String,Object>> userDetail = dynamicJdbcDao.findForList(SQL_USER_SEARCH_DETAIL, new SimpleKeyValue("id",userId));
			
			Map<String,Object> user = userDetail.get(0);
			
			
			
			//addCondition
			BigDecimal totalMed = BigDecimal.ZERO;

			
			List<Map<String,Object>> medicalList = dynamicJdbcDao.findForList(SQL_SEARCH, new SimpleKeyValue("userId",userId));
			
			
			if (!CollectionUtils.isEmpty(medicalList)) {
				
				for (Map<String, Object> medical : medicalList) {
					
					BigDecimal smed = objectToBigDecimal(medical.get("staffMedicalAmount"));
					BigDecimal fmed = objectToBigDecimal(medical.get("familyMedicalAmount"));
					
					BigDecimal sden = objectToBigDecimal(medical.get("staffDentalAmount"));
					BigDecimal fden = objectToBigDecimal(medical.get("familyDentalAmount"));
					
					BigDecimal seye = objectToBigDecimal(medical.get("staffMedicalAmount"));
					BigDecimal feye = objectToBigDecimal(medical.get("familyMedicalAmount"));
					
					BigDecimal totalMedical = smed.add(fmed.add(sden).add(fden).add(seye).add(feye));
					
					totalMed = totalMed.add(totalMedical);
					
						
				}
				
				if (totalMed.compareTo(BigDecimal.ZERO) > 0) {
					
					BigDecimal entitle = BigDecimal.ZERO;

					if (user.get("enInYear") != null) {
						entitle = objectToBigDecimal(user.get("enInYear"));
					}else if (user.get("enResign") != null) {
						entitle = objectToBigDecimal(user.get("enResign"));
					}else {
						entitle = objectToBigDecimal(user.get("enAppearance"));
					}
					
					if (entitle.compareTo(totalMed.add(total)) >= 0) {
						bean.setUser_id(userId);
						caseVal = 0;
					}else {
						caseVal = 4;
					}
					
				}
			}
			
			
			
			
		}
		
		return caseVal;
	}


	@Override
	public ServiceResult<Long> deleteMedical(String id) {
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer delId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(delId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	
	}
	
	private BigDecimal objectToBigDecimal(Object num) {
		
		BigDecimal bigD = BigDecimal.ZERO; 
		
		if (num != null) {
			bigD = new BigDecimal(num.toString());
		}
		
		return bigD;
		
	}

	
	
	
 
}
