package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.project.ProjectMembersBean;

public interface ProjectMembersService {
	
	
	ServiceResult<List<Map<String, Object>>> searchProjectMembers(String projectId, String manager) throws Exception;
	
	ServiceResult<List<Long>> saveProjectMembers(List<ProjectMembersBean> beans)throws Exception;;

	ServiceResult<List<Map<String, Object>>> searchProjectMembersByProject(String project_id,String roleId);

	ServiceResult<List<Map<String, Object>>> searchRoleProjectMembersByProject(String project_id);
	
	ServiceResult<List<Long>> updateByProjectProgress(List<ProjectMembersBean> beans)throws Exception;;
}
