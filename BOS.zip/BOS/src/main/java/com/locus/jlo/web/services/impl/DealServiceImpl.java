package com.locus.jlo.web.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.locus.common.mapper.PrimitiveSafeBeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.deals.DealBean;
import com.locus.jlo.web.services.DealService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DealServiceImpl extends BaseService implements DealService{

	// Query
	private final String SQL_SEARCH = "DEAL.SQL_SEARCH";	
	// Excute
	private final String SQL_INSERT = "DEAL.SQL_INSERT";
	private final String SQL_UPDATE = "DEAL.SQL_UPDATE";
	private final String SQL_DELETE = "DEAL.SQL_DELETE";

	private final String SQL_SEARCH_DEAL_DETAIL_BY_ID = "DEAL.SQL_SEARCH_DEAL_DETAIL_BY_ID";
	
	@Override
	public ServiceResult<List<Map<String, Object>>> searchDeal(String id, String filter_status) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = null;
		try {
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH
					,new SimpleKeyValue("id",id)
					,new SimpleKeyValue("status",filter_status));
			serviceResult = new ServiceResult<>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());
		} catch (Exception e) {
			serviceResult = new ServiceResult<>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> insertDeal(DealBean bean) throws Exception {

		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.FALSE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	
	}

	@Override
	public ServiceResult<Long> updateDeal(DealBean bean) throws Exception {
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer id = dynamicJdbcDao.executeUpdate(SQL_UPDATE,bean);
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	
	}

	@Override
	public ServiceResult<Long> deleteDeal(String id) throws Exception {
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer delId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(delId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	}

	@Override
	public ServiceResult<DealBean> searchDealDetailById(String id) {
		ServiceResult<DealBean> serviceResult = new ServiceResult<>();
		try{
			DealBean result = dynamicJdbcDao.findForObject(SQL_SEARCH_DEAL_DETAIL_BY_ID,
					PrimitiveSafeBeanPropertyRowMapper.newInstance(DealBean.class)
					,new SimpleKeyValue("id",id));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}

}
