package com.locus.jlo.web.beans.system.dto;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TokenDTO implements Serializable {

    private static final long serialVersionUID = -3582225134766461835L;

    private Integer tokenId;
    private String sessionId;
    private String tokenCode;
    private Integer createdBy;
    private String createdDate;
    private String createdTime;
    private String expiredDate;
    private String expiredTime;
    private String userName;
    private String password;
    private String deviceId;
    private String passcode;
}
