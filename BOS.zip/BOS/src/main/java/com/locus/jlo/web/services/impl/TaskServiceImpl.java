package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.project.ProjectMembersBean;
import com.locus.jlo.web.beans.task.TaskAssigneeBean;
import com.locus.jlo.web.beans.task.TaskBean;
import com.locus.jlo.web.services.ProjectMembersService;
import com.locus.jlo.web.services.TaskService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TaskServiceImpl extends BaseService implements TaskService{
	
	String SQL_SEARCH_TASK = "TASK.SQL_SEARCH_TASK";
	String SQL_SEARCH_BY_PROJECT = "TASK.SQL_SEARCH_BY_PROJECT";
	
	String SQL_INSERT_TASK = "TASK.SQL_INSERT_TASK";
	String SQL_UPDATE_TASK = "TASK.SQL_UPDATE_TASK";
	String SQL_DELETE_TASK = "TASK.SQL_DELETE_TASK";
	
	String SQL_SUM_TIME_ENTRIES_BY_TASK_PARENT = "TASK.SQL_SUM_TIME_ENTRIES_BY_TASK_PARENT";
	String SQL_SUM_TIME_ENTRIES_BY_TASK_CHILD  = "TASK.SQL_SUM_TIME_ENTRIES_BY_TASK_CHILD";
	String SQL_DELETE_TASK_BY_PARENT = "TASK.SQL_DELETE_TASK_BY_PARENT";
	String SQL_DELETE_TASK_BY_CHILD  = "TASK.SQL_DELETE_TASK_BY_CHILD";
	String SQL_DELETE_TASK_ASSIGNED_BY_TASK_PARENT = "TASK.SQL_DELETE_TASK_ASSIGNED_BY_TASK_PARENT";
	String SQL_DELETE_TASK_ASSIGNED_BY_TASK_CHILD  = "TASK.SQL_DELETE_TASK_ASSIGNED_BY_TASK_CHILD";
	
	
	String SQL_INSERT_TASK_ASSIGNEE = "TASK_ASSIGNEE.SQL_INSERT_TASK_ASSIGNEE";
	String SQL_INSERT_TASK_ASSIGNEE_MEMBER = "TASK_ASSIGNEE.SQL_INSERT_TASK_ASSIGNEE_MEMBER";
	String SQL_UPDATE_TASK_ASSIGNEE = "TASK_ASSIGNEE.SQL_UPDATE_TASK_ASSIGNEE";
	String SQL_REMOVE_TASK_ASSIGNEE = "TASK_ASSIGNEE.SQL_DELETE_TASK_ASSIGNEE";
	String SQL_REMOVE_TASK_ASSIGNEE_MEMBER = "TASK_ASSIGNEE.SQL_DELETE_TASK_ASSIGNEE_MEMBER";
	String SQL_REMOVE_TASK_ASSIGNEE_MEMBER_ROLE = "TASK_ASSIGNEE.SQL_REMOVE_TASK_ASSIGNEE_MEMBER_ROLE";
	
	String SQL_SEARCH_PROJECT_MEMBER = "TASK_ASSIGNEE.SQL_SEARCH_PROJECT_MEMBER";
	String SQL_SERACH_MEMBER_ASSIGNED = "TASK_ASSIGNEE.SQL_SEARCH_MEMBER_TASK_ASSIGNED";
	String SQL_SEARCH_MEMBER_TASK_NOT_ASSIGNED = "TASK_ASSIGNEE.SQL_SEARCH_MEMBER_TASK_NOT_ASSIGNED"; 
	
	String SQL_INSERT_TASK_ASSIGNED = "TASK_ASSIGNEE.SQL_INSERT_TASK_ASSIGNED";
	String SQL_DELETE_TASK_ASSIGNED = "TASK_ASSIGNEE.SQL_DELETE_TASK_ASSIGNED";
	String SQL_UPDATE_TASK_ASSIGNED = "TASK_ASSIGNEE.SQL_UPDATE_TASK_ASSIGNED";
	
	
	@Autowired
	private  ProjectMembersService projectMembersService;

	@Override
	public ServiceResult<List<Map<String, Object>>> searchTaskByProject(String projectId) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
		try{
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH_BY_PROJECT
					,new SimpleKeyValue("projectId",projectId));
			serviceResult.setResult(result);
		}catch(Exception e){
			e.printStackTrace();
			serviceResult = new ServiceResult<>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchTaskTreeByProject(String projectId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_BY_PROJECT,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Integer> insertTask(TaskBean taskBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
				final Integer id = dynamicJdbcDao.executeInsert(SQL_INSERT_TASK, Boolean.TRUE, taskBean ).intValue();
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
	           throw e;
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Integer> updateTask(TaskBean taskBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
				final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE_TASK, taskBean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}
	
	
	@Override
	public ServiceResult<Integer> removeTask(String task_id) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer id = dynamicJdbcDao.executeUpdate(SQL_DELETE_TASK,new SimpleKeyValue("task_id",task_id));
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			   log.error(e.getMessage(), e);
			   setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> insertTaskAssignee(TaskAssigneeBean taskAssigneeBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			result.setResult( dynamicJdbcDao.executeInsert(SQL_INSERT_TASK_ASSIGNEE, Boolean.TRUE, taskAssigneeBean ).intValue());
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}


	@Override
	public ServiceResult<Integer> removeTaskAssigneeByTask(String task_id) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			result.setResult(dynamicJdbcDao.executeUpdate(SQL_REMOVE_TASK_ASSIGNEE,new SimpleKeyValue("task_id",task_id)));
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	@Transactional
	public ServiceResult<Integer> saveTask(List<TaskBean> tasks) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		result.setResult(0);
		log.info("save :"+ tasks.size() +"item");
		int parentId = 0;
		boolean foundParentChildNode = tasks.size() > 1 ? true : false;
		int rec = 0;
		for (TaskBean taskBean:tasks) {
			rec ++;
			if ("I".equals(taskBean.getAct())){
				try {
					if (rec > 1 && foundParentChildNode) {
						taskBean.setParent_id(String.valueOf(parentId));
					}
					int id = insertTask(taskBean).getResult();
					parentId = id;
					result.setResult(result.getResult()+1);
					taskBean.setTask_id(String.valueOf(id));
					//assigneeByTask(taskBean,false);
				} catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
			}else if("U".equals(taskBean.getAct())){
				try {
					updateTask(taskBean);
					//assigneeByTask(taskBean,true);
					result.setResult(result.getResult()+1);
				} catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
			}/*else{
				try {
					removeTask(taskBean.getTask_id());
					removeTaskAssigneeByTask(taskBean.getTask_id());
					result.setResult(result.getResult()+1);
				} catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
			}*/
		}
		log.info("save success: "+ result.getResult() +"item");
		result.setSuccess(true);
		return result;
	}

	@Override
	public ServiceResult<Integer> assigneeByTask(TaskBean taskBean,boolean clearOld) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		List<Map<String, Object>> mapMembers =  projectMembersService.searchProjectMembersByProject(taskBean.getProject_id(),String.valueOf(taskBean.getTask_assign_role_id())).getResult();
		if(clearOld){
			removeTaskAssigneeByTask(taskBean.getTask_id());
		}
		for (Map<String, Object> m:mapMembers) {
			TaskAssigneeBean assigneeBean = new TaskAssigneeBean();
			assigneeBean.setProject_id(taskBean.getProject_id());
			assigneeBean.setTask_id(taskBean.getTask_id());
			assigneeBean.setTask_assignee_id(String.valueOf(m.get("userId")));
			assigneeBean.setStatus(1);
			assigneeBean.setStart_dt(taskBean.getStart_dt());
			assigneeBean.setEnd_dt(taskBean.getEnd_dt());
			assigneeBean.setCreate_user_id(taskBean.getCreate_user_id());
			insertTaskAssignee(assigneeBean);
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> assigneeByMembers(ProjectMembersBean bean) throws Exception{
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			result.setResult(dynamicJdbcDao.executeUpdate(SQL_INSERT_TASK_ASSIGNEE_MEMBER,bean));
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> removeTaskAssigneeByMember(ProjectMembersBean bean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			if(StringUtils.isEmpty(bean.getRole_id()))
				result.setResult(dynamicJdbcDao.executeUpdate(SQL_REMOVE_TASK_ASSIGNEE_MEMBER,bean));
			else
				result.setResult(dynamicJdbcDao.executeUpdate(SQL_REMOVE_TASK_ASSIGNEE_MEMBER_ROLE,bean));
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}
	
	@Override
	public ServiceResult<Integer> removeTask(String taskId, String projectId, boolean isParent) throws Exception {
		
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{	
				// Check time entries before delete
				if (isParent) {
					Double sum = dynamicJdbcDao.findForObject(SQL_SUM_TIME_ENTRIES_BY_TASK_PARENT, new DoubleResultMapper()
							, new SimpleKeyValue("projectId", projectId)
							, new SimpleKeyValue("taskId",taskId));
					if (sum > 0) {
						result.setResponseCode("Data Already Used");
						result.setResponseDescription("Cannot delete task with sub task already used in clock timesheets");
						result.setSuccess(Boolean.FALSE);
						return result;
					}
				} else {
					Double sum = dynamicJdbcDao.findForObject(SQL_SUM_TIME_ENTRIES_BY_TASK_CHILD, new DoubleResultMapper()
							, new SimpleKeyValue("projectId", projectId)
							, new SimpleKeyValue("taskId",taskId));
					if (sum > 0) {
						result.setResponseCode("Data Already Used");
						result.setResponseDescription("Cannot delete task with already used in clock timesheets");
						result.setSuccess(Boolean.FALSE);
						return result;
					}
				}
				
						
				Integer cnt;
				if (isParent) {
					// delete task_assigned
					cnt  = dynamicJdbcDao.executeUpdate(SQL_DELETE_TASK_ASSIGNED_BY_TASK_PARENT, new SimpleKeyValue("taskId",taskId) );
					result.setResult(cnt);
		            result.setSuccess(Boolean.TRUE);
		            // delete task
		            if (result.isSuccess()) {
		            	cnt  = dynamicJdbcDao.executeUpdate(SQL_DELETE_TASK_BY_PARENT, new SimpleKeyValue("taskId",taskId));
						result.setResult(cnt);
			            result.setSuccess(Boolean.TRUE);
		            }
		            
		            
				} else {
					
					// delete task_assigned
					cnt  = dynamicJdbcDao.executeUpdate(SQL_DELETE_TASK_ASSIGNED_BY_TASK_CHILD, new SimpleKeyValue("taskId",taskId) );
					result.setResult(cnt);
		            result.setSuccess(Boolean.TRUE);
		            // delete task
		            if (result.isSuccess()) {
						cnt  = dynamicJdbcDao.executeUpdate(SQL_DELETE_TASK_BY_CHILD, new SimpleKeyValue("taskId",taskId) );	
						result.setResult(cnt);
			            result.setSuccess(Boolean.TRUE);
		            }

				}				
	            
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           setErrorResult(result, e);
		}
		return result;
		
	}
	
	
	
	
	/* ArnonW*/
	@Override
	public ServiceResult<List<DataBean>> searchProjectMember(String projectId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = null;
		try{
		
			List<DataBean> result = dynamicJdbcDao.findForList(SQL_SEARCH_PROJECT_MEMBER, BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	

	@Override
	public ServiceResult<List<DataBean>> searchMemberTaskAssigned(String projectId, String taskId)  throws Exception {
		ServiceResult<List<DataBean>> serviceResult = null;
		try{
		
			List<DataBean> result = dynamicJdbcDao.findForList(SQL_SERACH_MEMBER_ASSIGNED, BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("projectId",projectId),new SimpleKeyValue("taskId",taskId) );
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchMemberTaskNotAssigned(String projectId, String taskId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = null;
		try{
		
			List<DataBean> result = dynamicJdbcDao.findForList(SQL_SEARCH_MEMBER_TASK_NOT_ASSIGNED, BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("projectId",projectId),new SimpleKeyValue("taskId",taskId) );
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	@Override
	public ServiceResult<Long> removeTaskTaskAssign(String taskAssigneeId) throws Exception {
		
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
				final Integer cnt  = dynamicJdbcDao.executeUpdate(SQL_DELETE_TASK_ASSIGNED, Boolean.TRUE, new SimpleKeyValue("taskAssigneeId",taskAssigneeId) );
				result.setResult(cnt.longValue());
	            result.setSuccess(Boolean.TRUE);
	            
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           setErrorResult(result, e);
		}
		return result;
		
	}
	
	@Override
	public ServiceResult<Long> inserTaskAssign(  String projectId, 
													String taskId , 
													String userId, 
													String status, 
													String StartDt, 
													String endDt, 
													String createUid )throws Exception {
		
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
			
			final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_TASK_ASSIGNED, Boolean.TRUE  
													, new SimpleKeyValue("projectId",projectId)
													, new SimpleKeyValue("taskId",taskId)
													, new SimpleKeyValue("userId",userId)
													, new SimpleKeyValue("status",status)
													, new SimpleKeyValue("startDt",StartDt)
													, new SimpleKeyValue("endDt",endDt)
													, new SimpleKeyValue("createUid",createUid));
				
			result.setResult(id);
            result.setSuccess(Boolean.TRUE);
            
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           setErrorResult(result, e);
		}
		return result;
		
	}
	
	@Override
	public ServiceResult<Long> updateTaskAssign(  String taskAssigneeId ,  
													String StartDt, 
													String endDt )throws Exception {
		
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
			
			final Integer id = dynamicJdbcDao.executeUpdate(SQL_UPDATE_TASK_ASSIGNED, Boolean.TRUE  
													, new SimpleKeyValue("taskAssigneeId",taskAssigneeId)
													, new SimpleKeyValue("startDt",StartDt)
													, new SimpleKeyValue("endDt",endDt));
				
			result.setResult(id.longValue());
            result.setSuccess(Boolean.TRUE);
            
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           setErrorResult(result, e);
		}
		return result;
		
	}
	
	
	
	
	

}
