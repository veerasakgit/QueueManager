package com.locus.jlo.web.beans.medical.report;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class MedicalReportByPeriodRes {
	private String receiptDate;
	private String sectionCode;
	private String departmentCode;
	private String divisionCode;
	private String deptCode;
	private String empCode;
	private String fullname;
	private String hospital;
	private String disease;
	private String staffMedical;
	private String staffDental;
	private String staffEye;
	private String familyMedical;
	private String familyDental;
	private String familyEye;
	private String total;
}
