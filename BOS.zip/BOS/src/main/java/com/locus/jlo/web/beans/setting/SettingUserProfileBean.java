package com.locus.jlo.web.beans.setting;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SettingUserProfileBean {
    private Integer uid;
    private String ufirstName;
    private String ulastName;
    private String umiddleName;
    private String unickname;
    private String umobile;
    private String emergencyName;
    private String emergencyMobile;
    private String emergencyRelation;
    private String ufilepath;
    private String emailNotifyTimesheet;
    private String emailNotifyLeaveRequest;

}
