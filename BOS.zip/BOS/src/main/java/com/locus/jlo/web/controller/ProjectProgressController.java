package com.locus.jlo.web.controller;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.NumberUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.project.CalendarBean;
import com.locus.jlo.web.beans.project.MemberTimeEntriesBean;
import com.locus.jlo.web.beans.project.ProjectBean;
import com.locus.jlo.web.beans.project.ProjectMembersBean;
import com.locus.jlo.web.beans.project.ProjectProgressBean;
import com.locus.jlo.web.beans.project.ProjectProgressResultBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.ProjectMembersService;
import com.locus.jlo.web.services.ProjectProgressService;
import com.locus.jlo.web.services.ReportService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
@RequestMapping("progress")
public class ProjectProgressController extends CoreController {

    @Autowired
    private ProjectProgressService projectProgressService;
    @Autowired
    private ReportService reportService;
	@Autowired
	private ProjectMembersService projectMembersService;

    @GetMapping("/searchProgressByProject/{id}")
    public @ResponseBody
    JsonResultBean searchProjectProgressByProject(@PathVariable("id") Integer project_id,
                                                  HttpServletRequest request, Locale locale) throws Exception {
        ProjectProgressBean bean = new ProjectProgressBean();
        bean.setProject_id(project_id);
        ServiceResult<List<Map<String, Object>>> obj = projectProgressService.searchProjectProgress(bean);
        JsonResultBean result = null;
        if (obj.isSuccess()) {
            result = new JsonResultBean("success", "", obj.getResult());
        }
        return result;
    }
    
    @GetMapping("/searchProgressResultByProject/{id}")
    public @ResponseBody
    JsonResultBean searchProjectProgressResutlByProject(@PathVariable("id") String projectId,
                                                  HttpServletRequest request, Locale locale) throws Exception {
        ServiceResult<List<ProjectProgressResultBean>> obj = projectProgressService.searchProjectProgressResult(projectId);
        ServiceResult<List<MemberTimeEntriesBean>> timeEntries = projectProgressService.searchProjectMemberTimeEntries(projectId);
        
        Map<String, Object> m = new HashMap<String, Object>();
        
        String startDate = "", endDate = "";
        JsonResultBean result = null;
        List<MemberTimeEntriesBean> allTimeEntries = new ArrayList<MemberTimeEntriesBean>();
        List<MemberTimeEntriesBean> displayTimeEntries = new ArrayList<MemberTimeEntriesBean>();
        if (obj.isSuccess()) {
        	
        	if (!obj.getResult().isEmpty()) {
        		startDate = obj.getResult().get(0).getPlanStartDate();
        		endDate = obj.getResult().get(0).getPlanEndDate();
        		
        		if (StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate)) {
        			m.put("result", "");
        			result = new JsonResultBean("success", "" , m) ;
        	        return result;
        		}
        		
        		ServiceResult<List<DataBean>> hConf = reportService.getHolidayConfigBetweenDate(startDate,endDate);
        		
        	
        		DateFormat sdf = new SimpleDateFormat("EEE,d-MMM-yy");
        		DateFormat f_EEE = new SimpleDateFormat("EEE");
        		DateFormat f_d = new SimpleDateFormat("d");
        		DateFormat f_MMM_yy = new SimpleDateFormat("MMM yy");
        		Calendar startDateCal = Calendar.getInstance();
        		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        		startDateCal.setTime(df.parse(startDate));
        		
        		Calendar endDateCal = Calendar.getInstance();
        		endDateCal.setTime(df.parse(endDate));
        		long difference = (endDateCal.getTime()).getTime()- (startDateCal.getTime()).getTime();
        		long projectDay =  TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);
        		
        		Map<String, CalendarBean> thisCalendar = new TreeMap<String, CalendarBean>(new Comparator<String>() {

					@Override
					public int compare(String o1, String o2) {
						return o1.compareTo(o2);
					}
				});
				

        		
        		 
				String[] dayOfWeek = {"wk","wd","wd","wd","wd","wd","wk"};
				String chkMMYY = "";
				
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate from = LocalDate.parse(startDate, dtf);
				LocalDate to = LocalDate.parse(endDate, dtf);
				Period diff = Period.between(from, to);
				int monthCnt = ((Math.abs(diff.getYears())*12) + Math.abs(diff.getMonths())) + 1 ;
				int dayOfMonth = 0;

			    
				

				for (int i = 0 ; i <= projectDay; i++) {
					CalendarBean cb = new CalendarBean();
					MemberTimeEntriesBean tb =new MemberTimeEntriesBean();
					if (i > 0 ) {
						startDateCal.add(Calendar.DATE, 1);
					}
					cb.setDate(df.format(startDateCal.getTime()));
					cb.setDayType(dayOfWeek[startDateCal.get(Calendar.DAY_OF_WEEK)-1]);
					cb.setDayNameInWeek(f_EEE.format(startDateCal.getTime()));
					cb.setDd(f_d.format(startDateCal.getTime()));
					cb.setMmyy(f_MMM_yy.format(startDateCal.getTime()));
					cb.setMonthCnt(monthCnt);
					
					
					thisCalendar.put(df.format(startDateCal.getTime()), cb);
					
					tb.setDayType(dayOfWeek[startDateCal.get(Calendar.DAY_OF_WEEK)-1]);
					tb.setSpentOn(df.format(startDateCal.getTime()));
					allTimeEntries.add(tb);
				
					
					if (i == 0) {
						chkMMYY = cb.getMmyy();
						
						Calendar endOfMonth = Calendar.getInstance();
						endOfMonth.setTime(startDateCal.getTime());
						endOfMonth.add(Calendar.MONTH, 1);
						endOfMonth.set(Calendar.DAY_OF_MONTH, 1);  
						endOfMonth.add(Calendar.DATE, -1);  
						

//						System.out.println(endOfMonth.get(Calendar.DATE));
//						System.out.println(endOfMonth.get(Calendar.DAY_OF_MONTH));
//						System.out.println(endOfMonth.get(Calendar.MONTH));
//						System.out.println(endOfMonth.get(Calendar.YEAR));
//						System.out.println(endOfMonth.getActualMaximum(Calendar.DATE));
						dayOfMonth = calDayOfMonth(startDateCal, endOfMonth, endDateCal);
					}
					
					if (!cb.getMmyy().equals(chkMMYY)) {
						
						chkMMYY = cb.getMmyy();
						
						Calendar endOfMonth = Calendar.getInstance();
						endOfMonth.setTime(startDateCal.getTime());
						endOfMonth.add(Calendar.MONTH, 1);
						endOfMonth.set(Calendar.DAY_OF_MONTH, 1);  
						endOfMonth.add(Calendar.DATE, -1);  
						
						dayOfMonth = calDayOfMonth(startDateCal, endOfMonth, endDateCal);
						
					}
					
					cb.setDayOfMonth(dayOfMonth);
					
				}
        		 
				List<DataBean> holidays = new ArrayList<DataBean>();
				if(hConf.isSuccess()){
					holidays = hConf.getResult();
				 
					for(DataBean holiday : holidays ){
						String hdDate = holiday.getA();
						thisCalendar.get(hdDate).setDayType("hd");
						
						MemberTimeEntriesBean x = (MemberTimeEntriesBean)CollectionUtils.find(allTimeEntries, new Predicate() {
							
							@Override
							public boolean evaluate(Object object) {
								return hdDate.equals(((MemberTimeEntriesBean) object).getSpentOn());
							}
						});
						x.setDayType("hd");
					} 
					
					
				}
        		 
        		 m.put("cal", thisCalendar);
        		 
//    			for (Map.Entry<String, CalendarBean> entry : thisCalendar.entrySet()) {
//    				CalendarBean b = entry.getValue();
//    				System.out.println("Key : " + entry.getKey() + " Value : " + b.getDate() + " , " + b.getDayType() + " , " + b.getDayNameInWeek() + " , " + b.getDd() + " , " + b.getMmyy()
//    				+ ", DayofMonth :" + b.getDayOfMonth() + ", " + b.getMonthCnt());
//    				
//    			}


        	}
        	
        	
        	// set member_time_entries
        	
            if (timeEntries.isSuccess()) {
            	
            	if (!timeEntries.getResult().isEmpty()) {
            		List<ProjectProgressResultBean> listResult = obj.getResult();
            		for (ProjectProgressResultBean pp : listResult) {
            			displayTimeEntries = new ArrayList<MemberTimeEntriesBean>();
            			String userId = pp.getUserId();
            			Double sumActualHour = 0.0;
            			
            			@SuppressWarnings("unchecked")
						Collection<MemberTimeEntriesBean> userTimeEntries = CollectionUtils.select(timeEntries.getResult(), new Predicate(){
							
							@Override
							public boolean evaluate(Object object) {
								
								return ((MemberTimeEntriesBean) object).getUserId().equals(userId);
							}

						});
            			
            			for (MemberTimeEntriesBean all : allTimeEntries) {
            				String spentOn = all.getSpentOn();
            				String dayType = all.getDayType();
            				
            				MemberTimeEntriesBean mte = (MemberTimeEntriesBean) CollectionUtils.find(userTimeEntries, new Predicate() {
								
								@Override
								public boolean evaluate(Object object) {
									return ((MemberTimeEntriesBean) object).getSpentOn().equals(spentOn);
								}
							});
            				
            				if (mte == null) {
            					mte = new MemberTimeEntriesBean();
            					mte.setDayType(dayType);
            					mte.setHours("");
            					mte.setSpentOn(spentOn);
            					mte.setUserId(userId);
            				} else {
            					mte.setDayType(dayType);
            					sumActualHour += Double.parseDouble(mte.getHours());
            				}
            				
            				displayTimeEntries.add(mte);
            				
            			}
            			DecimalFormat twoDigits = new DecimalFormat("#,##0.00");
            			pp.setActualHour(sumActualHour);
            			pp.setActualHourDisp(twoDigits.format(sumActualHour));
            			pp.setTimeEntries(new ArrayList<MemberTimeEntriesBean>());
            			pp.getTimeEntries().addAll(displayTimeEntries);
            			if (!StringUtils.isEmpty(pp.getManday())) {
            				int mh = Integer.parseInt(pp.getManday()) * 8;
            				pp.setManHour(twoDigits.format(mh));
            				Double cs = (sumActualHour * 100) / mh;
            				pp.setConsumed(twoDigits.format(cs));
            			} else {
            				pp.setManHour("");
            				pp.setConsumed("");
            			}
            			
            		}
            		
            		
            	}
            }
        	
        	System.out.println(obj.getResult().size());
//        	for (ProjectProgressResultBean beans : obj.getResult()) {
//        		log.info("User : "+ beans.getUserFullname() + "," + beans.getUserId());
//        		for(MemberTimeEntriesBean t : beans.getTimeEntries()) {
//        			log.info("times: " + t.getHours() + " : " + t.getSpentOn() + "  user_id :" + t.getUserId());
//        		}
//        		
//        	}
            m.put("result", obj.getResult());
        }
        result = new JsonResultBean("success", "" , m);
        return result;
    }
    
    private int calDayOfMonth(Calendar startDate, Calendar endDate, Calendar endProject) {
    	long dayOfMonth = 0;
    	if (endDate.before(endProject)) {

			long end = endDate.getTimeInMillis();
			long start = startDate.getTimeInMillis();
			dayOfMonth = TimeUnit.MILLISECONDS.toDays(Math.abs(end - start)) + 1;
			//long daysBetween = Math.abs(ChronoUnit.DAYS.between(endDate.toInstant(), startDate.toInstant())) + 1;
    		
    	} else {
    		long end = endProject.getTimeInMillis();
			long start = startDate.getTimeInMillis();
			dayOfMonth = TimeUnit.MILLISECONDS.toDays(Math.abs(end - start)) + 1;
    	}
    	return Integer.parseInt(Long.toString((dayOfMonth)));
    }
    
    
    

    @PostMapping("/searchProjectProgress")
    public @ResponseBody
    JsonResultBean searchProjectProgressByProject(@RequestBody ProjectProgressBean bean, HttpServletRequest request, Locale locale) throws Exception {
        ServiceResult<List<Map<String, Object>>> obj = projectProgressService.searchProjectProgress(bean);
        JsonResultBean result = null;
        if (obj.isSuccess()) {
            result = new JsonResultBean("success", "", obj.getResult());
        }
        return result;
    }

    @PostMapping("/saveProjectProgress")
    @Transactional
    public @ResponseBody
    JsonResultBean saveProjectProgress(@RequestBody List<ProjectProgressBean> beans, HttpServletRequest request, Locale locale) throws Exception {

        final Integer USER_ID = getUid(request);

        ServiceResult<Integer> result = new ServiceResult<>();
        result.setResult(0);

        String result_status = "";
        String result_msg = "";
        String result_data = "";

        projectProgressService.removeProjectProgressByProject(beans.get(0).getProject_id());

        log.info("save :"+ beans.size() +" item"); 
        for(ProjectProgressBean p : beans){
            String act = p.getAction();

            p.setCreate_uid(USER_ID);
            p.setUpdate_uid(USER_ID);

            if (BOSConstant.DBAction.INSERT.equals(act)) {
                log.info("insert progress...");
                projectProgressService.insertProjectProgress(p);
                result.setResult(result.getResult()+1);
            }else if (BOSConstant.DBAction.UPDATE.equals(act)) {
                log.info("update progress...");
                projectProgressService.updateProjectProgress(p);
                result.setResult(result.getResult()+1);
            } else if (BOSConstant.DBAction.DELETE.equals(act)) {
                log.info("delete progress...");
                projectProgressService.removeProjectProgress(p.getId());
                result.setResult(result.getResult()+1);
            } else {
                log.info("No action");
            }
            result.setSuccess(Boolean.TRUE);
            if (result.isSuccess()) {
                log.info("get long : " + result.getResult());
                result_data = Long.toString(result.getResult());
                result_status = "success";
                result_msg = "save successful";
            } else {
                result_status = "fail";
                result_msg = "save fail";
            }
        }
        JsonResultBean res = new JsonResultBean(result_status, result_msg, result_data);
        return res;
    }
    
    @PostMapping("/saveProjectMember")
    @Transactional
    public @ResponseBody
    JsonResultBean saveProjectMember(@RequestBody List<ProjectMembersBean> beans, HttpServletRequest request, Locale locale) throws Exception {

        final Integer USER_ID = getUid(request);

        ServiceResult<List<Long>>  result = new ServiceResult<>();
        String result_status = "";
        String result_msg = "";

        log.info("save :"+ beans.size() +" item"); 
             
        try{
        	
        	for(ProjectMembersBean p : beans){

                p.setCreate_uid(USER_ID);
                p.setUpdate_uid(USER_ID);
                
            }
        	result = projectMembersService.updateByProjectProgress(beans);
            

			if(result.isSuccess()){
				result_status = "success";
				result_msg    = "save successful";
			}else{
                result_status = "fail";
                result_msg    = "save fail";
			}

		 } catch(Exception e) {
				log.info("Error !!"+e);
				 result_status = "fail";
				 result_msg    = "save fail";
		 }
		 JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult() );

        return res;
    }
    
    
    @GetMapping("/getLastUpdProgress/{projectId}")
    public @ResponseBody
    JsonResultBean getLastUpdProgress(@PathVariable("projectId") String projectId, HttpServletRequest request, Locale locale) throws Exception {

        ServiceResult<ProjectProgressResultBean> resultObj = projectProgressService.getLastUpdProgress(projectId);
        JsonResultBean result = null;
        if (resultObj.isSuccess()) {
            result = new JsonResultBean("success", "", resultObj.getResult());
        }
        return result;
    }
    

    
    
    
}