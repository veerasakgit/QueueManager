package com.locus.jlo.web.controller;

import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URLDecoder;
import java.security.Principal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.TimeZone;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import org.springframework.security.core.Authentication;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.account.search.AccountSearchBean;
import com.locus.jlo.web.beans.system.dto.LoginDTO;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modeljson.DatatableModelBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.beans.timesheet.OvertimeBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetIncompleteBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetIncompleteDetailBean;
import com.locus.jlo.web.beans.timesheet.TimesheetNoteBean;
import com.locus.jlo.web.services.AccountSearchService;
import com.locus.jlo.web.services.ApprovalService;
import com.locus.jlo.web.services.EmailNotifyService;
import com.locus.jlo.web.services.EmailService;
import com.locus.jlo.web.services.ReportService;
import com.locus.jlo.web.services.SettingUserService;
import com.locus.jlo.web.services.TimeSheetIncompleteService;
import com.locus.jlo.web.services.TimesheetService;
import com.locus.jlo.web.services.TimesheetSummaryService;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;

@Slf4j
@Controller
public class TimeSheetController {
	
	@Autowired
	ServletContext context;
	
	@Autowired
	private TimesheetService timesheetService;
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private EmailNotifyService emailNotifyService;
	
	@Autowired
	private ApprovalService approvalService;
	
	@Autowired
	private TimeSheetIncompleteService timeSheetIncompleteService;
	
	@Autowired
	private SettingUserService settingUserService;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private TimesheetSummaryService timesheetSummaryService;
	
	@RequestMapping(value = {"/timesheet"})
	public String index() {
	        return "timesheet";
	}
	
	@RequestMapping(value = "/staffTimesheetInitial", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean staffTimesheetInitial(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
		
		JsonResultBean result = null;
		Map<String, Object> m = new HashMap<String, Object>();
		
		String result_status = "success";
		String result_msg    = "search success";
		String result_data   = "";
		
		try{
			
			//get session user
			UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
			
			//check staff is dept head  
			if( uinfo.getIsDeptHeadYN().equals("Y")){
				//show  members
				 ServiceResult<List<DataBean>> staffMember = timesheetSummaryService.searchMemberInDept(uinfo.getUid()); 
				 if(staffMember.isSuccess()){
					 m.put("staffMember", staffMember.getResult() );
				 }
			}
			
			
		}catch(Exception e){
			//res = new JsonResultBean(result_status, result_msg , result_data );
			log.info("Error !!"+e);
			e.printStackTrace();
			
		}
	
		result = new JsonResultBean(result_status, result_msg , m);
		return result;
		
	}
  	 
	 @RequestMapping(value = "/searchTimesheet", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean searchTimesheet(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
		 Map<String, Object> m = new HashMap<String, Object>();
		 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
		 JsonResultBean result = null;
		 
		 int year   =  Integer.parseInt(request.getParameter("filter_year"));
		 int month  = Integer.parseInt(request.getParameter("filter_month"));
		 String uid = request.getSession().getAttribute("UID").toString();
		 String staffId = request.getParameter("filter_staff");
		 
		 if (!StringUtils.isEmpty(staffId) && !staffId.equals("me")) {
			 uid = staffId;
		 }
		 
		 log.info("Locale  : "+Locale.getDefault());
		 log.info("year : "+year);
		 log.info("month: "+month);
		 //find month first day of month & last day of month for draw calendar
		 Calendar endOfMonth = Calendar.getInstance(Locale.US);  
		 int calendar_month = month -1 ;   //Calendar.MONTH start from 0 = JAN
		 endOfMonth.set(Calendar.YEAR, year);
		 endOfMonth.set(Calendar.MONTH, calendar_month );
		 endOfMonth.set(Calendar.DAY_OF_MONTH, 1);// This is necessary to get proper results
		 endOfMonth.set(Calendar.DATE, endOfMonth.getActualMaximum(Calendar.DATE));
		 
		 log.info("end of month: "+endOfMonth.getTime());
		 log.info("end day of month : "+endOfMonth.get(Calendar.DATE));
		 
		 Calendar startOfMonth = Calendar.getInstance(Locale.US);
		 startOfMonth.set(Calendar.YEAR, year);
		 startOfMonth.set(Calendar.MONTH, calendar_month );
		 startOfMonth.set(Calendar.DATE, 1 );
		 //find holiday
		 
		 log.info("start of month: "+startOfMonth.getTime());
		 log.info("start day of month : "+startOfMonth.get(Calendar.DATE));
		 
		 
		 //holiday
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
		 ServiceResult<List<DataBean>> hConf = reportService.getHolidayConfigBetweenDate(dateFormat.format(startOfMonth.getTime()),dateFormat.format(endOfMonth.getTime()));
	
		 String[] thisMonthCalendar = new String[endOfMonth.get(Calendar.DATE)];
		 log.info("calendar length : "+thisMonthCalendar.length);
		 
		 String[] dayOfWeek = {"wk","wd","wd","wd","wd","wd","wk"};
		 //Calendar.DAY_OF_WEEK will return 1-7 MONDAY is 1
		 for(int i=1;i<=endOfMonth.get(Calendar.DATE);i++){
			 startOfMonth.set(Calendar.DATE, i );
			 log.info(i+" | "+startOfMonth.getTime()+" > "+startOfMonth.get(Calendar.DAY_OF_WEEK)+" "+dayOfWeek[startOfMonth.get(Calendar.DAY_OF_WEEK)-1]);
			 thisMonthCalendar[i-1] = dayOfWeek[startOfMonth.get(Calendar.DAY_OF_WEEK)-1];
		 }
		 
		
		 log.info("find holiday between "+dateFormat.format(startOfMonth.getTime())+" and "+dateFormat.format(endOfMonth.getTime()));
		 
		 List<DataBean> holidays = new ArrayList<DataBean>();
		 if(hConf.isSuccess()){
			 holidays = hConf.getResult();
			 log.info("holiday : "+holidays.size());
			 
			 for(DataBean holiday : holidays ){
				 Date d = sdf.parse(holiday.getA());
				 Calendar cal = Calendar.getInstance(Locale.US);
				 cal.setTime(d);
				 
				 thisMonthCalendar[cal.get(Calendar.DATE)-1] = "hd";
				 
				 log.info("holiday day : "+ cal.get(Calendar.DATE));
			 } 
		 }
		 
		 m.put("cal",thisMonthCalendar);
		 String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
		 
		 m.put("month", monthName[endOfMonth.get(Calendar.MONTH)]);
		 m.put("year", year);
		 
		 //find assign task & clocking hour
		 log.info("find timesheet month_id:"+month+"|year :"+year+"|uid :"+uid);
		 ServiceResult<List<DataBean>> timesheet =  timesheetService.searchTimesheet( month , year , uid);
		 log.info("reuslt"+ timesheet.isSuccess());
		 if(timesheet.isSuccess()){
			
			 m.put("time", timesheet.getResult());
		 }
		 
		 //find note
		 ServiceResult<List<DataBean>> note =  timesheetService.searchTimesheetNote( month , year , uid);
		 log.info("reuslt note: "+ note.isSuccess());
		 if(note.isSuccess()){
			 m.put("note", note.getResult());
		 }
		 
		 //find ot hour
		 ServiceResult<List<DataBean>> overtime =  timesheetService.searchTimesheetOvertime( month , year , uid);
		 log.info("reuslt ot: "+ overtime.isSuccess());
		 if(overtime.isSuccess()){
			 m.put("ot", overtime.getResult());
		 }
		 
		 //search project lookup
		 ServiceResult<List<DataBean>> avaProjectTask =  timesheetService.searchAvailableProjectTask( month , year , uid );
		 log.info("reuslt"+ avaProjectTask.isSuccess());
		 if(avaProjectTask.isSuccess()){
			 m.put("avaProjectTask", avaProjectTask.getResult());
		 }
		 
		 //search progress
		 ServiceResult<List<DataBean>> monthlyPercentApprove =  timesheetService.searchMonthlyPercentApprove( year , uid );
		 log.info("reuslt"+ monthlyPercentApprove.isSuccess());
		 if(monthlyPercentApprove.isSuccess()){
			 m.put("mPercent", monthlyPercentApprove.getResult());
		 }
		  
		 
		 //find timesheet note
		 /*
		 List<String> overtimeThisMonth = new ArrayList<String>();
		 ServiceResult<List<DataBean>> overtime =  timesheetService.searchTimesheetOvertime( month , year , uid);
		 List<DataBean> ots = new ArrayList<DataBean>();
		 log.info("reuslt"+ overtime.isSuccess());
		 if(overtime.isSuccess()){
			 //loop for footer
			 ots = overtime.getResult();
			 log.info("holiday : "+ots.size());
			 for(DataBean ot : ots ){
				 overtimeThisMonth.add(ot.getM());
			 }
			 m.put("ot", overtimeThisMonth );
		 }
		 */ 
		 
		    result = new JsonResultBean("success", "" , m);
			return result;
		}
	 
	//deprecate
	@RequestMapping(value = "/getTimesheet", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean getTimesheet(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
		
		ServiceResult<List<DataBean>> listResult = null;
		//timesheetService.searchTimesheet(); 
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
		
		Authentication auth  = SecurityContextHolder.getContext().getAuthentication();
		log.info("auth: "+auth.getPrincipal());
		log.info("name: "+auth.getName());
		log.info("principal: "+ principal);
	
		 
		return result;
	}
	
	
	@RequestMapping(value = "/saveLogtime", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveLogtime(HttpServletRequest request,Locale locale) throws Exception {
		
		 Map<String, Object> m = new HashMap<String, Object>();
	
		 String UID  = request.getSession().getAttribute("UID").toString();
		 String data = request.getParameter("data");
		 String act  = request.getParameter("action");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 log.info("save Logtime");
		 log.info("data :"+data);
		 log.info(act);
		 
		 //
		 JSONParser jParser = new JSONParser();
		 Object obj = jParser.parse(data);
		 
		 JSONArray jArray = (JSONArray)obj;
		  
		 log.info( ""+jArray.get(0) );
		 
		 JSONObject jObject = (JSONObject)jArray.get(0);
	
		 log.info("project : "+jObject.get("pid"));
		 log.info("task id : "+jObject.get("tid"));
		 log.info("day     : "+jObject.get("date"));
		 log.info("month   : "+jObject.get("month"));
		 log.info("year    : "+jObject.get("year"));
		 log.info("hour    : "+jObject.get("hour"));
		 log.info("id      : "+jObject.get("id"));
		 log.info("uid     : "+UID);
		 
		 String timesheet_status = "1";
		 if(jObject.get("sts") != null && jObject.get("sts").toString().equals("draft")){
			 timesheet_status = "1";
		 }
		 if(jObject.get("sts") != null && jObject.get("sts").toString().equals("submitted")){
			  timesheet_status = "2";
		 }
		 
		 
		 Calendar spentOn = Calendar.getInstance(Locale.US);
		 spentOn.set(Calendar.DATE, Integer.parseInt(jObject.get("date").toString()));
		 spentOn.set(Calendar.MONTH, Integer.parseInt(jObject.get("month").toString())-1);  //Calendar.MONTH start from 0 = JAN
		 spentOn.set(Calendar.YEAR, Integer.parseInt(jObject.get("year").toString()));
	
//		 DateFormat  DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd",Locale.US); 
//		 String dateText = jObject.get("year").toString()+"-"+(Integer.parseInt(jObject.get("month").toString())-1)+"-"+jObject.get("date").toString();
//		 Date spentOn = DATE_FORMAT.parse(dateText);
		 
		try{
	
			switch (act){
		 	    case "I" : log.info("insert data");
		 	    			result =  timesheetService.insertLogtime(  jObject.get("pid").toString() , 
	 	    				   										   jObject.get("tid").toString() , 
	 	    				   										spentOn.getTime(), 
	 	    				   										   jObject.get("hour").toString() , 
	 	    				   										   timesheet_status ,
	 	    				   										   UID );
		 	    			
		 	    			if( result.isSuccess()){
		 	    			   log.info( "get long : "+result.getResult().longValue() );
		 	    			   result_data   = Long.toString(result.getResult().longValue());
		 	    			   result_status = "success";
							   result_msg    = "save successful";
		 	    				
		 	    			}else{
		 	    				result_status = "fail";
								result_msg    = "save fail";
		 	    			}
		 	    		
						break;
						
		 	    case "U" : log.info("update data");
		 	    
		 						result =  timesheetService.updateLogtime(  jObject.get("pid").toString() , 
																		   jObject.get("tid").toString() , 
																		   spentOn.getTime(), 
																		   jObject.get("hour").toString() , 
																		   timesheet_status ,
																		   UID,
																		   jObject.get("id").toString() );
		 					

								if( result.isSuccess()){
									log.info( "get long : "+result.getResult().longValue() );
									result_data   = jObject.get("id").toString();
									result_status = "success";
									result_msg    = "save successful";
								
								}else{
									result_status = "fail";
									result_msg    = "save fail";
								}

		 	    
		 	   			break;
 	   			case "R" : log.info("remove data");
 	   							result =  timesheetService.removeLogtime( jObject.get("id").toString());
 	   									
   								if( result.isSuccess()){
	   								log.info( "get long : "+result.getResult().longValue() );
	   								result_data   = Long.toString(result.getResult().longValue());
	   								result_status = "success";
	   								result_msg    = "save successful";
   								
   								}else{
	   								result_status = "fail";
	   								result_msg    = "save fail";
   								}
		 	   		    break;
		 	   		 
		 	   default : log.error("something wrong");
				
			}
			
			//qry current record and return to front end
			//timesheetService.searchTimesheet(entry_id);
			if(!act.equals("R")){
				 ServiceResult<List<DataBean>> timeEntry =  timesheetService.searchTimesheetById( result_data );
				 log.info("timeEntry"+ timeEntry.isSuccess());
				 if(timeEntry.isSuccess()){
					 m.put("timeEntry", timeEntry.getResult());
				 }
			}
			
			
		}catch(Exception e){
			log.info("Error !!"+e);
			e.printStackTrace();
		}
		
		JsonResultBean res = new JsonResultBean(result_status, result_msg , m );
		return res;
	}
	 
	@RequestMapping(value = "/searchTimesheetNoteDetail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchTimesheetNote(HttpServletRequest request,Locale locale) throws Exception {
		
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
		 
		 Map<String, Object> m = new HashMap<String, Object>();
		 
		 int year  =  Integer.parseInt(request.getParameter("year"));
		 int monthId = Integer.parseInt(request.getParameter("monthId"));
		 int day   = Integer.parseInt(request.getParameter("day"));
		 String staffId = request.getSession().getAttribute("UID").toString();
		
		 String result_status = "";
		 String result_msg    = "";
		 try{
			
				 Calendar noteDate = Calendar.getInstance(Locale.US);
				 noteDate.set(Calendar.DATE, day );
				 noteDate.set(Calendar.MONTH, monthId-1);  //Calendar.MONTH start from 0 = JAN
				 noteDate.set(Calendar.YEAR, year );
				 
				 log.info("noteDate : "+noteDate);
				 //Date d = ;
			
				  
				 ServiceResult<List<DataBean>> noteDtl =  timesheetService.searchTimesheetNoteDetail( sdf.format(noteDate.getTime())  , staffId );
				 log.info("reuslt"+ noteDtl.isSuccess());
				 if(noteDtl.isSuccess()){
					 m.put("noteDtl", noteDtl.getResult());
					 result_status = "success";
				 }
				
				 
			}catch(Exception e){
				log.info("Error !!"+e);
				e.printStackTrace();
			}
		
			JsonResultBean res = new JsonResultBean(result_status, result_msg , m );
			return res;
		 
		
	}
	

	@RequestMapping(value = "/saveTimesheetNote", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveTimesheetNote(HttpServletRequest request,Locale locale) throws Exception {
		
		 Map<String, Object> m = new HashMap<String, Object>();
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
			
	     String staffId = request.getSession().getAttribute("UID").toString();
	     String data = request.getParameter("data");
	     
	     String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
	     ServiceResult<Long> result = new ServiceResult<>();
	     
		try{
		 JSONParser jParser = new JSONParser();
		 Object obj = jParser.parse(data);
		 JSONArray jArray =  (JSONArray)obj;
		 Calendar noteDate = Calendar.getInstance(Locale.US);
		 
		 int j = jArray.size();
		 for(int i=0;i<j;i++){
			 JSONObject jObject = (JSONObject)jArray.get(i);
			 
			 //convert date
			 noteDate.set(Calendar.DATE, Integer.parseInt(jObject.get("noteDate").toString()));
			 noteDate.set(Calendar.MONTH, Integer.parseInt(jObject.get("noteMonth").toString())-1);  //Calendar.MONTH start from 0 = JAN
			 noteDate.set(Calendar.YEAR, Integer.parseInt(jObject.get("noteYear").toString()));
			 
			 String act = jObject.get("act").toString();
			 TimesheetNoteBean tnb = new TimesheetNoteBean();
			 
			 if(!StringUtils.isEmpty(jObject.get("noteId").toString())){
				 tnb.setId(jObject.get("noteId").toString());
			 } 
			 tnb.setSeq(jObject.get("noteSeq").toString());
			 tnb.setProject_id(jObject.get("noteProjectId").toString());
			 tnb.setTask_id(jObject.get("noteTaskId").toString());
			 tnb.setHour(jObject.get("noteHour").toString());
			 tnb.setNote_date(noteDate.getTime());
			 tnb.setNote_detail(jObject.get("noteDtl").toString());
			 tnb.setUser_id(staffId);
			 tnb.setCreate_uid(staffId);
			 tnb.setUpdate_uid(staffId);
			 
			 switch(act){
		 	    case "I" : log.info("insert data");
		 	    			result =  timesheetService.insertTimesheetNote(tnb);
		 	    			
		 	    			if( result.isSuccess()){
		 	    			   log.info( "get long : "+result.getResult().longValue() );
		 	    			   result_data   = Long.toString(result.getResult().longValue());
		 	    			   result_status = "success";
							   result_msg    = "save successful";
		 	    				
		 	    			}else{
		 	    				result_status = "fail";
								result_msg    = "save fail";
		 	    			}
		 	    		
						break;
						
		 	    case "U" : log.info("update data");
		 	    				
		 						result =  timesheetService.updateTimesheetNote(tnb);
								if( result.isSuccess()){
									log.info( "get long : "+result.getResult().longValue() );
									result_data   = Long.toString(result.getResult().longValue());
									result_status = "success";
									result_msg    = "save successful";
								
								}else{
									result_status = "fail";
									result_msg    = "save fail";
								}

		 	    
		 	   			break;
	   			case "R" : log.info("remove data");
	   							result =  timesheetService.removeTimesheetNote(jObject.get("noteId").toString() );
	   									
								if( result.isSuccess()){
	   								log.info( "get long : "+result.getResult().longValue() );
	   								result_data   = Long.toString(result.getResult().longValue());
	   								result_status = "success";
	   								result_msg    = "save successful";
								
								}else{
	   								result_status = "fail";
	   								result_msg    = "save fail";
								}
		 	   		    break;
		 	   default : log.error("something wrong");
			}	 
		 }//end for
	
		 if( result_status.equals("success")){
			 ServiceResult<List<DataBean>> noteDtl =  timesheetService.searchTimesheetNoteDetail( sdf.format(noteDate.getTime())  , staffId );
			 log.info("reuslt"+ noteDtl.isSuccess());
			 if(noteDtl.isSuccess()){
				 m.put("noteDtl", noteDtl.getResult());
			 }
		 }
		
		 
		}catch(Exception e){
			log.info("Error !!"+e);
			e.printStackTrace();
		} 
	
		JsonResultBean res = new JsonResultBean(result_status, result_msg , m );
	
		return res;
	}
	
	@RequestMapping(value = "/searchOvertime", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchOvertime(HttpServletRequest request,Locale locale) throws Exception {
	
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
		 
		 Map<String, Object> m = new HashMap<String, Object>();
		 
		 int year  =  Integer.parseInt(request.getParameter("year"));
		 int monthId = Integer.parseInt(request.getParameter("monthId"));
		 int day   = Integer.parseInt(request.getParameter("day"));
		 String staffId = request.getSession().getAttribute("UID").toString();
		
		 String result_status = "";
		 String result_msg    = "";
		 try{
			
				 Calendar otDate = Calendar.getInstance(Locale.US);
				 otDate.set(Calendar.DATE, day );
				 otDate.set(Calendar.MONTH, monthId-1);  //Calendar.MONTH start from 0 = JAN
				 otDate.set(Calendar.YEAR, year );
				 
				 log.info("noteDate : "+otDate);
				
				 //search overtime
				 ServiceResult<List<DataBean>> otDtl =  timesheetService.searchTimesheetOvertimeDetail( sdf.format(otDate.getTime()), staffId );
				 log.info("reuslt"+ otDtl.isSuccess());
				 if(otDtl.isSuccess()){
					 m.put("otDtl", otDtl.getResult());
					 result_status = "success";
				 }
				 
				
			
				 
			}catch(Exception e){
				log.info("Error !!"+e);
				e.printStackTrace();
			}
		
			JsonResultBean res = new JsonResultBean(result_status, result_msg , m );
			return res;
		 
	
	}
	
	
	@RequestMapping(value = "/saveOvertime", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveOvertime(HttpServletRequest request,Locale locale) throws Exception {
		
		log.info("start save overtime ");
		
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
		 SimpleDateFormat tformat = new SimpleDateFormat("hh:mm:ss",Locale.US);
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		 
	     String staffId = request.getSession().getAttribute("UID").toString();
	     String data = request.getParameter("data");
		 String act = request.getParameter("action");
		 
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 log.info("act: "+act);
		 log.info("data: "+data);
	
		 try{
			 
		 JSONParser jParser = new JSONParser();
		 Object obj = jParser.parse(data);
		 JSONArray jArray =  (JSONArray)obj;
	

		 JSONObject jObject = (JSONObject)jArray.get(0);
		 
		
		 Calendar spentOn = Calendar.getInstance(Locale.US);
		 spentOn.set(Calendar.DATE, Integer.parseInt(jObject.get("day").toString()));
		 spentOn.set(Calendar.MONTH, Integer.parseInt(jObject.get("monthId").toString())-1);  //Calendar.MONTH start from 0 = JAN
		 spentOn.set(Calendar.YEAR, Integer.parseInt(jObject.get("year").toString()));
		 
		 log.info("spentOn : "+spentOn);
		 Date otSpentOn =  spentOn.getTime();
		 //set default ot_status to draft
		 String ot_status = "1";
		
		 String dateType = "";
		 switch( jObject.get("dayType").toString() ){
			 case "wk" : dateType = "Weekend";  break;
			 case "wd" : dateType = "Weekday"; break;
			 case "hd" : dateType = "Holiday"; break;
		 }
		 
		 log.info("dateType: "+dateType);
		 
		 Calendar startTime = Calendar.getInstance(Locale.US);
		 startTime.set(Calendar.HOUR_OF_DAY,Integer.parseInt(jObject.get("otStartHH").toString()));
		 startTime.set(Calendar.MINUTE,Integer.parseInt(jObject.get("otStartMM").toString()));
		 startTime.set(Calendar.SECOND,0);
		 
		 String endTime_hh = jObject.get("otEndHH").toString();
		 String endTime_mm = jObject.get("otEndMM").toString();
		 
		 log.info("end hh:  "+endTime_hh);
		 log.info("end min: "+endTime_mm);
		 
		 if( endTime_hh.equals("24") && endTime_mm.equals("0")){
			 endTime_hh = "23";
			 endTime_mm = "59";
		 }
		 
		 
		 Calendar endTime = Calendar.getInstance(Locale.US);
		 endTime.set(Calendar.HOUR_OF_DAY,Integer.parseInt(endTime_hh));
		 endTime.set(Calendar.MINUTE,Integer.parseInt(endTime_mm));
		 endTime.set(Calendar.SECOND,0);
		 
		 Date otStartTime = startTime.getTime();
		 Date otEndTime = endTime.getTime();
		 
		 OvertimeBean ot = new OvertimeBean();
		 if(!StringUtils.isEmpty(jObject.get("otId").toString())){
			 ot.setId(jObject.get("otId").toString());
		 }
			 ot.setProject_id(jObject.get("otProjectId").toString());
			 ot.setTask_id(jObject.get("otProjectTaskId").toString());
			 ot.setUser_id(staffId);
			 ot.setOt_date(otSpentOn);
			 ot.setOt_status(ot_status);
			 ot.setStart_time(otStartTime);
			 ot.setEnd_time(otEndTime);
			 ot.setDate_type(dateType);
		 
		 if(!StringUtils.isEmpty(jObject.get("otReq").toString())){
			 ot.setOt_requested(jObject.get("otReq").toString());
		 }
		 if(!StringUtils.isEmpty(jObject.get("mobileService").toString())){
			 ot.setMobile_service(jObject.get("mobileService").toString());
		 }
		 if(!StringUtils.isEmpty(jObject.get("carAllowance").toString())){
			 ot.setCar_allowance(jObject.get("carAllowance").toString());
		 }
		 if(!StringUtils.isEmpty(jObject.get("taxiAllowance").toString())){
			 ot.setTaxi_requested(jObject.get("taxiAllowance").toString());
		 }
		 if(!StringUtils.isEmpty(jObject.get("taxiFare").toString())){
			 ot.setTaxi_fare(jObject.get("taxiFare").toString());
		 }
		 if(!StringUtils.isEmpty(jObject.get("otNote").toString())){
			 ot.setOt_note(jObject.get("otNote").toString());
		 }
		 
		 ot.setCreate_uid(staffId);
		 ot.setUpdate_uid(staffId);
		 
		
			 switch(act){
		 	    case "I" : log.info("insert data");
		 	    			result =  timesheetService.insertOvertime(ot);
		 	    			
		 	    			if( result.isSuccess()){
		 	    			   log.info( "get long : "+result.getResult().longValue() );
		 	    			   result_data   = Long.toString(result.getResult().longValue());
		 	    			   result_status = "success";
							   result_msg    = "save successful";
		 	    				
		 	    			}else{
		 	    				result_status = "fail";
								result_msg    = "save fail";
		 	    			}
		 	    		
						break;
						
		 	    case "U" : log.info("update data");
		 	    
		 						result =  timesheetService.updateOvertime(ot );
		 					 
								if( result.isSuccess()){
									log.info( "get long : "+result.getResult().longValue() );
									result_data   = ot.getId(); //Long.toString(result.getResult().longValue());
									result_status = "success";
									result_msg    = "save successful";
								
								}else{
									result_status = "fail";
									result_msg    = "save fail";
								}

		 	    
		 	   			break;
		 	    /*
	   			case "R" : log.info("remove data");
	   							result =  timesheetService.removeOvertime( jObject.get("id").toString());
	   									
								if( result.isSuccess()){
	   								log.info( "get long : "+result.getResult().longValue() );
	   								result_data   = Long.toString(result.getResult().longValue());
	   								result_status = "success";
	   								result_msg    = "save successful";
								
								}else{
	   								result_status = "fail";
	   								result_msg    = "save fail";
								}
		 	   		    break;
		 	   	 */
		 	   		 
		 	   default : log.error("something wrong");
				
			}
	
			
		}catch(Exception e){
			log.info("Error !!"+e);
			e.printStackTrace();
		}
	
			
		 
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
	}
	
	@RequestMapping(value = "/removeOvertime", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean removeOvertime(HttpServletRequest request,Locale locale) throws Exception {
		
		 ServiceResult<Long> result = new ServiceResult<>();
		 
		 String result_status = "";
		 String result_msg = "";
		 String result_data = "";
		 
		 try{
			 String staffId = request.getSession().getAttribute("UID").toString();
		     String id = request.getParameter("id");
			 String act = request.getParameter("action");
			 
			 result =  timesheetService.removeOvertime( id );
				
				if( result.isSuccess()){
					log.info( "get long : "+result.getResult().longValue() );
					result_data   = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg    = "save successful";
				
				}else{
					result_status = "fail";
					result_msg    = "save fail";
				}
				
		 }catch(Exception e){
				log.info("Error !!"+e);
				e.printStackTrace();
			}
		
			 
			JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
			return res;
	}

	 
	@RequestMapping(value = "/searchTimesheetSummary", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchTimesheetSummary(HttpServletRequest request,Locale locale) throws Exception {
		log.info("into searchTimesheetSummary");
		Map<String, Object> m = new HashMap<String, Object>();
		JsonResultBean result = null;
		 
		String staffId = request.getSession().getAttribute("UID").toString();
		String monthId = request.getParameter("monthId");
		String year    = request.getParameter("year");
		
		ServiceResult<List<DataBean>> workhour =  timesheetService.searchTimesheetSummary(year, monthId, staffId); 
		if(workhour.isSuccess()){
			log.info("wokhour summary ");
			m.put("whour",workhour.getResult());
		}
		
		ServiceResult<List<DataBean>> ohour =  timesheetService.searchOvertimeSummary(year, monthId, staffId); 
		if(ohour.isSuccess()){
			log.info("overtime summary ");
			m.put("ohour",ohour.getResult());
		}
		
		ServiceResult<List<DataBean>> monthUtilize =  timesheetService.searchMonthUtilize(year, monthId); 
		if(monthUtilize.isSuccess()){
			
			 String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
			 int x = Integer.parseInt(monthId) -1;
			 m.put("monthName", monthName[x]);
			 
			 List<DataBean> db  =  monthUtilize.getResult();
			 m.put("mutilize", db.get(0).getA());
		}
		
		 
		result = new JsonResultBean("success", "" ,  m);
		
		return result;
	}
		
	@RequestMapping(value = "/submitTimesheet", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean submitTimesheet(HttpServletRequest request,Locale locale) throws Exception {
		log.info("into searchTimesheet_beforeSubmit");
		
		 String overtime = request.getParameter("ot");
		 String workhour = request.getParameter("workhour");
		 String act      = request.getParameter("action");
		 //String staffId  = request.getParameter("staffId");
		 
		 //use for send data email notify
		 String monthId  = request.getParameter("monthId");
		 String year     = request.getParameter("year");
				 
	 	 //find approval & is pass probation
		 UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
	 	 String UID       = uinfo.getUid();
		 String staffName = uinfo.getFirstName()+" "+uinfo.getLastName();	
		 String organize  = uinfo.getOrganizeUnitName();
		 
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		 
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 JSONParser jParser = new JSONParser();
		 Object wobj = jParser.parse(workhour);
		 JSONArray wjArray = (JSONArray)wobj;
		 
		//log.info("START WORKHOUR !!!!!!!!!!!!!!!!!!!!!!!!!");
		 if( act.equals("workhour_save")){
			 
			     //This arrayList keep unique project_id for send notify to each PM,Approval 
			 	 List<String> t = new ArrayList<String>();
			 
			 	 
				 //1) loop workhour
				 List<DataBean> wh = new ArrayList<DataBean>();
				 for( int i=0;i<wjArray.size();i++){
					 
					 JSONObject jObject = (JSONObject)wjArray.get(i);
		
					 DataBean db = new DataBean();
					 db.setA(jObject.get("tid").toString());
					 db.setB(jObject.get("sts").toString());
					 db.setC( UID );
					 db.setD(jObject.get("pid").toString());
					 db.setE(jObject.get("hour").toString());
					 wh.add(db);
					  
					 //send submit mail notify do only submitted status
					 if( jObject.get("sts").toString().equalsIgnoreCase("2")){
						 if(t.contains(jObject.get("pid").toString())){
							 //do nothing
							 //log.info("FOund submit "+jObject.get("pid").toString());
						 }else{
							 //log.info("NOt found submit in list do insert list");
							 //insert new data to array
							 t.add(jObject.get("pid").toString());
						 }
					 }
				 }
				 //end loop workhour
				 
				 //save workhour
				 result =  timesheetService.submitWorkhour( wh );
				 if( result.isSuccess()){
						log.info( "get long : "+result.getResult().longValue() );
						result_data   = Long.toString(result.getResult().longValue());
						result_status = "success";
						result_msg    = "save successful";
						
				 }else{
					result_status = "fail";
					result_msg    = "save fail";
				 }
				
				 log.info("Check send submitted email notify : "+t.size());
				 //send email to approval if workhour status == 2(submitted);
				 if( t.size() > 0 ){
					 String sendTo = "";
					 String template = "";
					 String totalUtilizeHour = "";
					 String emailSubjectProjectName = "";
					  
					  //loop project
					  for(int j=0;j<t.size();j++){
						  
						  sendTo = ""; //clear current email address
						  ServiceResult<List<DataBean>> mail  = emailNotifyService.findApprovalEmailByProjectId(t.get(j) , UID);
						  log.info("get email:"+mail.getResult().size()); 
						  if(mail.isSuccess()){
							  if( mail.getResult().size() > 1){
								  List<DataBean> lists =  mail.getResult();
								  for(int k=0;k<lists.size();k++){
									 sendTo += lists.get(k).getA()+",";
								  }
							  
								  //replace last comma with empty string
								  sendTo = removeLastChar(sendTo);
							  }else{
								  sendTo = mail.getResult().get(0).getA();
							  }
						  }
						  
						
						  log.info("sendEmailTo"+sendTo);
						  						  
						  //query email data
						  StringBuilder tmp = new StringBuilder();
						  ServiceResult<List<DataBean>> utilizeHour = emailNotifyService.qryUtilizeHourSummary(monthId, year);
						  List<DataBean> utilize = utilizeHour.getResult();
						  totalUtilizeHour = utilize.get(0).getA();
						  
						  //query utilize hour
						  ServiceResult<List<DataBean>> data = emailNotifyService.qryTimesheetWorkhourData(t.get(j),UID ,monthId, year); 
						  Double sumHour = 0d;
						  
						  if(data.isSuccess()){
							 List<DataBean> lists =  data.getResult();
							 
							 if(lists != null && lists.size() != 0) {
								 for(int a=0;a<lists.size();a++){
									 //Timsheet data
									 tmp.append("<tr>");
									 tmp.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:10px; margin:0; padding:0\">"+lists.get(a).getF()+"</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;margin:0; padding:0\">"+lists.get(a).getG()+"</p></td>");
									 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+lists.get(a).getB()+"</td>");
									 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+lists.get(a).getD()+"</td>");
									 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+lists.get(a).getE()+"</td>");
									 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\"> SUBMITTED </td>");
									 tmp.append("</tr>");
									 
									 staffName = lists.get(a).getH();
								 
									 try{
										   
									    sumHour += Double.parseDouble(lists.get(a).getE());
										 
									 }catch(Exception e){
										 
									 }
								 }
								 emailSubjectProjectName = lists.get(0).getB();
								 
								 //prepare data
								  DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US);
								  Date date = new Date();
									
								  int month  = Integer.parseInt(monthId) -1;
								  String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
								  
								  //get default template
								  template = mailTemplate("workhour_submitted");
								  //replace template with dynamic data
								  template = template.replaceAll("#createdon",dateFormat.format(date));
								  template = template.replaceAll("#staffName",staffName);
								  template = template.replaceAll("#staffDept",organize);
								  template = template.replaceAll("#timesheet",tmp.toString());
								  template = template.replaceAll("#month_year",monthName[month]+" "+year);
								  template = template.replaceAll("#totalHour",sumHour.toString());
								  template = template.replaceAll("#utilizeHour",totalUtilizeHour);
								   
								  String mailSubject = "*** SUBMITTED **** "+staffName+" has submitted timesheet workhour on project "+emailSubjectProjectName;
							      //String mailTo = "arnon@locus.co.th"; //test
								   
								  //send submit mail notify
								  //sendTo = "arnon@locus.co.th"; //test
								  sendMailNotify(mailSubject,sendTo,template);
							 }
							 
						  }
					  }
					 
				 }//end send mail 
		 }//end workhour
		 
		 
		//2) loop ot
		Object oobj = jParser.parse(overtime);
		JSONArray ojArray = (JSONArray)oobj;
		
		
		//log.info("START OT !!!!!!!!!!!!!!!!!!!!!!!!!");
		 if( act.equals("ot_save")){
			//This arrayList keep unique project_id for send notify to each PM,Approval 
		 	List<String> t = new ArrayList<String>();
			
			List<DataBean> ot = new ArrayList<DataBean>();
			for( int i=0;i<ojArray.size();i++){
				 JSONObject jObject = (JSONObject)ojArray.get(i);
				 
				 DataBean db = new DataBean();
				 db.setA(jObject.get("oid").toString());
				 db.setB(jObject.get("sts").toString());
				 db.setC( UID );
				 ot.add(db);
				 				 
				//send submit mail notify do only submitted status
				 if( jObject.get("sts").toString().equalsIgnoreCase("2")){
					 log.info("get project id :"+jObject.get("pid").toString());
					 if(t.contains(jObject.get("pid").toString())){
						 //do nothing
						 //log.info("FOund submit "+jObject.get("pid").toString());
					 }else{
						 //log.info("NOt found submit in list do insert list");
						 //insert new data to array
						 t.add(jObject.get("pid").toString());
					 }
				 }
				 
			 }
			  
			result =  timesheetService.submitOvertime( ot );
			if( result.isSuccess()){
					log.info( "get long : "+result.getResult().longValue() );
					result_data   = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg    = "save successful";
					
			}else{
				result_status = "fail";
				result_msg    = "save fail";
			}
			
			
			 log.info("Check send submitted email notify : "+t.size());
			 //send email to approval if workhour status == 2(submitted);
			 if( t.size() > 0 ){
				 String sendTo = "";
				 String template = "";
				 String emailSubjectProjectName = "";
				 
				 log.info("SEND OT EMAIL NOTIFY : !!!!!!!!");
				  
				 //loop project
				  for(int j=0;j<t.size();j++){
					  
					 sendTo = ""; //clear current email address
					  
					 ServiceResult<List<DataBean>> mail  = emailNotifyService.findApprovalEmailByProjectId(t.get(j),UID);
					  if(mail.isSuccess()){
						  if( mail.getResult().size() > 1){
							  List<DataBean> lists =  mail.getResult();
							  for(int k=0;k<lists.size();k++){
								 sendTo += lists.get(k).getA()+",";
							  }
							  //replace last comma with empty string
							  sendTo = removeLastChar(sendTo);
						  }else{
							  sendTo = mail.getResult().get(0).getA();
						  }
					  }
					
					  log.info("sendEmailTo"+sendTo);
					  						  
					  //query email data
					  StringBuilder tmp = new StringBuilder();
					  
					  //query utilize hour
					  ServiceResult<List<DataBean>> data = emailNotifyService.qryTimesheetOTData(t.get(j),UID ,monthId, year); 
					  
					  if(data.isSuccess()){
						 List<DataBean> lists =  data.getResult();
						 
						 if(lists != null && lists.size() != 0) {
							 for(int a=0;a<lists.size();a++){
								//OT DATA
								 tmp.append("<tr>");
								 tmp.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:11px; margin:0; padding:0\">"+lists.get(a).getD()+"</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;margin:0; padding:0\">"+lists.get(a).getE()+"</p></td>");
								 tmp.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; margin:0; padding:0\">"+lists.get(a).getC()+"</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:11px; font-weight: 400; line-height: 1.4;margin:0; padding:0\">"+lists.get(a).getB()+"</p></td>");
								 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:center\">"+lists.get(a).getF()+"</td>");
								 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:center\">"+lists.get(a).getG()+"</td>");
								 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:center\">"+lists.get(a).getH()+"</td>");
								 
								 tmp.append("<td style=\"text-align:center\">"+lists.get(a).getI()+"</td>");
								 tmp.append("<td style=\"text-align:center\">"+lists.get(a).getJ()+"</td>");
								 tmp.append("<td style=\"text-align:center\">"+lists.get(a).getK()+"</td>");
								 tmp.append("<td style=\"text-align:center\"><p style=\"margin:0; padding:0\">"+lists.get(a).getL()+"</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:11px; font-weight: 400; line-height: 1.4; text-align:center\">"+lists.get(a).getM()+"</p></td>");
								 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:center\"> SUBMITTED </td>");
							 
								 tmp.append("</tr>");
								 
								 staffName = lists.get(a).getP();
							
							 }
							 emailSubjectProjectName = lists.get(0).getC();
							 
							//prepare data
							  DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US);
							  Date date = new Date();
								
							  int month  = Integer.parseInt(monthId) -1;
							  String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
							  
							  //get default template
							  template = mailTemplate("ot_submitted");
							  //replace template with dynamic data
							  template = template.replaceAll("#createdon",dateFormat.format(date));
							  template = template.replaceAll("#staffName",staffName);
							  template = template.replaceAll("#staffDept",organize);
							  template = template.replaceAll("#ot",tmp.toString());
							  template = template.replaceAll("#month_year",monthName[month]+" "+year);
							  template = template.replaceAll("#checkbox","<img src=\"https://workspace.locus.co.th/bos/assets/img/checkbox.png\">");
							  					  
							  //template = template.replaceAll("#totalHour",sumHour.toString());
							  //template = template.replaceAll("#utilizeHour",totalUtilizeHour);
							   
							  String mailSubject = "*** SUBMITTED *** "+staffName+" has submitted overtime on project "+emailSubjectProjectName;
						      //String mailTo = "arnon@locus.co.th"; //test
							  
							  //send submit mail notify
							  //sendTo = "arnon@locus.co.th"; //test
							  sendMailNotify(mailSubject,sendTo,template);
						 }
						 
					  }
					  
				  }//end loop
			 }
		 }//end ot
		 JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		 return res;
	}
	
	//send mail notify to user
	//mailTo is String and format is "user1@email.com,user2@email.com";
	//template = email body data
	 private void sendMailNotify(String mailSubject , String mailTo , String template){
			 try{
				 
				    log.info("-----start send email");
				  	Properties props = new Properties();
			        props.put("mail.smtp.host", "smtp.office365.com");
			        props.put("mail.smtp.socketFactory.port", "587");
			        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			        props.put("mail.smtp.auth", "true");
			        props.put("mail.smtp.port", "587");
			        props.put("mail.smtp.starttls.enable", "true");
				 
				    Session session = Session.getDefaultInstance(props,
				        	new javax.mail.Authenticator() {
		                 protected PasswordAuthentication getPasswordAuthentication() {
		                     return new PasswordAuthentication("locus_smtp@locus.co.th","locus@123+");
		                 }
		             });
				     
		             Message message = new MimeMessage(session);
		             message.setFrom(new InternetAddress("no-reply@locus.co.th")); 
		             message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(mailTo));
		  
		             
		             message.setSubject(mailSubject);
		             message.setContent(template, "text/html; charset=utf-8");
		             Transport.send(message);
						
		             log.info("-----email successfully sent..");
				
				 
			 }catch(Exception e){
				 log.info("Error !!"+e);
				 e.printStackTrace();
			 }
			 
	 }
			
	 //util
	 //get template path
	 //template type request will have approve and reject link
	 //tempate notify will have only information
	 private String mailTemplate( String template_type ){
		 
		 String relativeWebPath = "/WEB-INF";
		 String filePath = context.getRealPath(relativeWebPath);
		 
		 log.info("relativeWebPath: "+relativeWebPath);

		 switch( template_type ){
			 case "workhour_submitted" : 
								 filePath +=  "/view/emailTemplate/timesheetSubmitNotify.html";
								 break;
			 case "ot_submitted" : 
								 filePath +=  "/view/emailTemplate/otSubmitNotify.html";
								 break;
			 case "workhour_approved"  :
				 				filePath += "";
				 				break;
		 
		 }
			
		 File file = new File(filePath);
		 String msg = "";
		 if (file.exists() && !file.isDirectory()) {
			log.info("filePath: file exist");
			 msg = readContentFromFile(filePath);
		 } else {
			log.info("[filePath] file doesn't exist");
		 }
		 
		 file = new File(file.getAbsolutePath());
		 
		 log.info("getAbsolutePath: "+file);
		 msg = "";
		 if (file.exists() && !file.isDirectory()) {
			log.info("file absolute path: file exist");
			 msg = readContentFromFile(filePath);
		 } else {
			log.info("[file absolute path] file doesn't exist");
		 }
		 
		 return msg;
	 }
	 
	  
 	  //util
	 //read file template 
	 private String readContentFromFile(String fileName){
	     StringBuffer contents = new StringBuffer();
	     
	     try {
	       //use buffering, reading one line at a time
	       BufferedReader reader =  new BufferedReader(new FileReader(fileName));
	       try {
	         String line = null; 
	         while (( line = reader.readLine()) != null){
	           contents.append(line);
	           contents.append(System.getProperty("line.separator"));
	         }
	       }
	       finally {
	           reader.close();
	       }
	     }
	     catch(IOException ex){
	       ex.printStackTrace();
	     }
	     return contents.toString();
	 }
	 //util
	 //remove last character from string
	 private static String removeLastChar(String s) {
		    return (s == null || s.length() == 0)
		      ? null
		      : (s.substring(0, s.length() - 1));
		}
	
	 
	 //initial time sheet admin
	 @RequestMapping(value = "/initialTimesheetAdmin", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean initialTimesheetAdmin(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
	 
		Map<String, Object> m = new HashMap<String, Object>();
		JsonResultBean res = null;
		
		String result_status = "success";
		String result_msg    = "success";
		String result_data   = "";
		
		String year    = request.getParameter("searchYear");
		String monthId = request.getParameter("searchMonth");
		
		
		UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
		String approverId = uinfo.getUid();
		String isAdmin    = uinfo.getIsAdminYN();
	
		
		//String projectId  = "";
		List<String> deptId = new ArrayList<String>();
		List<String> staffId = new ArrayList<String>();

		try{
		
	
			
			//add search filter by staff
			ServiceResult<List<DataBean>> staff =  approvalService.initFilterTimesheetStaff(year,monthId,null,isAdmin,approverId); 
			if( staff.isSuccess()){
				m.put("filterStaff",staff.getResult());
			}
			 
			//add search filter by department 
			ServiceResult<List<KeyValueBean>> department =  approvalService.initFilterTimesheetDepartment(year,monthId,null,isAdmin); 
			if( department.isSuccess()){
				m.put("filterDept",department.getResult());
			}
			
		}catch(Exception e){
			 result_status = "fail";
			 result_msg    = "fail";
			
			res = new JsonResultBean(result_status, result_msg , result_data );
			log.info("Error !!"+e);
			e.printStackTrace();
			
		}
		
		res = new JsonResultBean(result_status, result_msg , m );
		return res;
		
	}
	 
	@RequestMapping(value = "/searchTimesheetSummaryForAdmin", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchTimesheetSummaryForAdmin(HttpServletRequest request,Locale locale) throws Exception {
		log.info("into searchTimesheetSummary");
		Map<String, Object> m = new HashMap<String, Object>();
		JsonResultBean result = null;
		 
		String staffId = request.getParameter("staffId");
		String monthId = request.getParameter("monthId");
		String year    = request.getParameter("year");
		
		if(staffId == null){
			staffId = "";
		}
		
		ServiceResult<List<DataBean>> workhour =  timesheetService.searchTimesheetSummary(year, monthId, staffId); 
		if(workhour.isSuccess()){
			log.info("wokhour summary ");
			m.put("whour",workhour.getResult());
		}
		
		ServiceResult<List<DataBean>> ohour =  timesheetService.searchOvertimeSummary(year, monthId, staffId); 
		if(ohour.isSuccess()){
			log.info("overtime summary ");
			m.put("ohour",ohour.getResult());
		}
		
		ServiceResult<List<DataBean>> monthUtilize =  timesheetService.searchMonthUtilize(year, monthId); 
		if(monthUtilize.isSuccess()){
			
			 String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
			 int x = Integer.parseInt(monthId) -1;
			 m.put("monthName", monthName[x]);
			 
			 List<DataBean> db  =  monthUtilize.getResult();
			 m.put("mutilize", db.get(0).getA());
		}
		
		m.put("staffIdTemp",staffId);
		result = new JsonResultBean("success", "" ,  m);
		
		return result;
	}
	 
	@RequestMapping(value = "/sendEmailTaskAssignee", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean sendEmailTaskAssignee(HttpServletRequest request,Locale locale) throws Exception {
		log.info("into sendEmailTaskAssignee");
		String result_status = "success";
		String result_msg    = "success";
	
		String monthId = request.getParameter("monthId");
		String year = request.getParameter("year");
		String staffId = request.getParameter("staffList");
		String staffListArr[] = staffId.split(",");
		
		if(staffListArr != null && staffListArr.length != 0){
			
			for (int i = 0; i < staffListArr.length; i++) {
				String userId = staffListArr[i].toString();
				
				TimeSheetIncompleteBean timeSheetBean = new TimeSheetIncompleteBean();
				timeSheetBean.setYear(year);
				timeSheetBean.setMonthId(monthId);
				timeSheetBean.setUid(userId);
				ServiceResult<TimeSheetIncompleteBean> userDetailResult = timeSheetIncompleteService.findTimeSheetIncompleteByUserId(timeSheetBean);
				
				TimeSheetIncompleteBean userDetail = new TimeSheetIncompleteBean();
				if(userDetailResult.isSuccess()){
					userDetail = userDetailResult.getResult();
				}
						
				log.info("Email  : "+userDetail.getEmail());
				//1. Get Send mail to 
				String sendTo = userDetail.getEmail(); 
				//String sendTo = "kanokporn@locus.co.th";
				String template = "";
				String totalUtilizeHour = userDetail.getMonthUtilize();
				String emailSubjectProjectName = "";
				StringBuilder tmp = new StringBuilder();
				Double sumHour = 0d;
				Double sumHourDraft = 0d;
				Double sumHourSubmitted = 0d;
				Double sumHourRejected = 0d;
				Double sumHourApproved = 0d;
				log.info("staffId : "+staffListArr[i].toString());
				
				TimeSheetIncompleteBean timesheetDetail = new TimeSheetIncompleteBean();
				timesheetDetail.setUid(userId);
				timesheetDetail.setMonthId(monthId);
				timesheetDetail.setYear(year);
				
				//Get date Time sheet by user id
				ServiceResult<List<TimeSheetIncompleteDetailBean>> listTimesheetDetailResult = timeSheetIncompleteService.findTimeSheetIncompleteDetailByUserId(timesheetDetail);
				
				if(listTimesheetDetailResult.isSuccess()){
					List<TimeSheetIncompleteDetailBean> listTimesheetDetail = listTimesheetDetailResult.getResult();
					
					StringBuilder tmpSummary = new StringBuilder();
					
					if(listTimesheetDetail != null && listTimesheetDetail.size() != 0){
						
						// Draw tbody in table time sheet
						for (TimeSheetIncompleteDetailBean bean : listTimesheetDetail) {
							//Timsheet data
							 tmp.append("<tr>");
							 tmp.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:10px; margin:0; padding:0\">"+bean.getDays()+"</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;margin:0; padding:0\">"+bean.getDates()+"</p></td>");
							 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+bean.getProjectName()+"</td>");
							 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+bean.getTaskName()+"</td>");
							 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+bean.getHours()+"</td>");
							 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+bean.getStatus()+"</td>");
							 tmp.append("</tr>");
						 
							 try{
							    sumHour += Double.parseDouble(bean.getHours());
							    
							    if(bean.getStatus().equals("DRAFT")){
							    	sumHourDraft += Double.parseDouble(bean.getHours());
							    	
							    }else if(bean.getStatus().equals("SUBMITTED")){
							    	sumHourSubmitted += Double.parseDouble(bean.getHours());
							    	
							    }else if(bean.getStatus().equals("REJECTED")){
							    	sumHourRejected += Double.parseDouble(bean.getHours());
							    	
							    }else if(bean.getStatus().equals("APPROVED")){
							    	sumHourApproved += Double.parseDouble(bean.getHours());
							    }
								 
							 }catch(Exception e){
								 
							 }
						}
						emailSubjectProjectName = listTimesheetDetail.get(0).getProjectName();
					}
					
					//Time sheet summary
					tmpSummary.append("<tr>");
					tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Utilize</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+totalUtilizeHour+"</p></td>");
					tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Total</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHour.toString()+"</p></td>");
					tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Draft</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHourDraft+"</p></td>");
					tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Submitted</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHourSubmitted+"</p></td>");
					tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Rejected</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHourRejected+"</p></td>");
					tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Approved</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHourApproved+"</p></td>");
					tmpSummary.append("</tr>");
					
					//prepare data
					DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US);
					Date date = new Date();
					
					int month  = Integer.parseInt(monthId) -1;
					String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
					
					//2. Get Template
					template = emailService.mailTemplate("get_time_sheet_incomplete");
					template = template.replaceAll("#createdon",dateFormat.format(date));
					template = template.replaceAll("#staffName",userDetail.getStaff());
					template = template.replaceAll("#staffDept",userDetail.getDept());
					template = template.replaceAll("#timesheet",tmp.toString());
					template = template.replaceAll("#month_year",monthName[month]+" "+year);
					template = template.replaceAll("#totalHour",sumHour.toString());
					template = template.replaceAll("#utilizeHour",totalUtilizeHour);
					template = template.replaceAll("#summary",tmpSummary.toString());
					
					String mailSubject = "*** SUBMITTED **** "+userDetail.getStaff()+" has submitted timesheet workhour on project "+emailSubjectProjectName;
				   
					//send submit mail notify
					emailService.sendMailNotify(mailSubject,sendTo,template);
				}
				log.info("sendEmailTo : "+sendTo);
			}
		}
		 
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_status );
		return res;
	}
	
	@RequestMapping(value = "/deleteTaskAssigneeByUserId", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean deleteTaskAssigneeByUserId(HttpServletRequest request,Locale locale) throws Exception {
		log.info("into sendEmailTaskAssignee");
		String result_status = "";
		String result_msg    = "success";
	
		String taskList = request.getParameter("taskList");
		String staffId = request.getParameter("staffId");
		String taskListArr[] = taskList.split(",");
		
		if(taskListArr != null && taskListArr.length != 0){
			
			for (int i = 0; i < taskListArr.length; i++) {
				String taskId = taskListArr[i].toString();
				ServiceResult<Long> idResult =  settingUserService.deleteTimesheetTaskAssigneeByUserId(staffId, taskId);
				if(idResult.isSuccess()){
					result_status = "success";
				}
			}
		}
		 
		JsonResultBean res = new JsonResultBean(result_status, result_msg , staffId);
		return res;
	}
	
	 @RequestMapping(value = "/searchTimesheetSummaryForPmAndTeamLead", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchTimesheetSummaryForPmAndTeamLead(HttpServletRequest request,Locale locale) throws Exception {
		log.info("into searchTimesheetSummary");
		Map<String, Object> m = new HashMap<String, Object>();
		JsonResultBean result = null;
		 
		String staffId = request.getParameter("staffId");
		String monthId = request.getParameter("monthId");
		String year    = request.getParameter("year");
		String projectId    = request.getParameter("projectId");
		
		if(staffId == null){
			staffId = "";
		}
		
		ServiceResult<List<DataBean>> workhour =  timesheetService.searchTimesheetSummaryForPm(year, monthId, staffId,projectId); 
		if(workhour.isSuccess()){
			log.info("wokhour summary ");
			m.put("whour",workhour.getResult());
		}
		
		ServiceResult<List<DataBean>> ohour =  timesheetService.searchOvertimeSummaryForPm(year, monthId, staffId,projectId); 
		if(ohour.isSuccess()){
			log.info("overtime summary ");
			m.put("ohour",ohour.getResult());
		}
		
		ServiceResult<List<DataBean>> monthUtilize =  timesheetService.searchMonthUtilize(year, monthId); 
		if(monthUtilize.isSuccess()){
			
			 String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
			 int x = Integer.parseInt(monthId) -1;
			 m.put("monthName", monthName[x]);
			 
			 List<DataBean> db  =  monthUtilize.getResult();
			 m.put("mutilize", db.get(0).getA());
		}
		
		m.put("staffIdTemp",staffId);
		result = new JsonResultBean("success", "" ,  m);
		
		return result;
	}
    
}