package com.locus.jlo.web.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.beans.setting.SettingUserProfileBean;
import com.locus.jlo.web.beans.task.TaskAssigneeBean;
import com.locus.jlo.web.beans.task.TaskBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.SettingUserService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class SettingUserServiceImpl extends BaseService implements SettingUserService{
	
	private final static String SQL_SEARCH = "SETTING_USER.SQL_SEARCH";
	private final static String SQL_SEARCH_LOCK = "SETTING_USER.SQL_SEARCH_LOCK";
	private final static String SQL_UPDATE_STATUS = "SETTING_USER.SQL_UPDATE_STATUS";
	private final static String SQL_DELETE = "SETTING_USER.SQL_DELETE";
	
	private final static String SQL_INSERT = "SETTING_USER.SQL_INSERT";
	private final static String SQL_SEARCH_DETAIL = "SETTING_USER.SQL_SEARCH_DETAIL";
	private final static String SQL_SEARCH_DETAIL_NEW = "SETTING_USER.SQL_SEARCH_DETAIL_NEW";
	private final static String SQL_UPDATE = "SETTING_USER.SQL_UPDATE";
	
	private final static String SQL_UPDATE_NEW = "SETTING_USER.SQL_UPDATE_NEW";
	private final static String SQL_INSERT_NEW = "SETTING_USER.SQL_INSERT_NEW";
	
	private final static String SQL_UPDATE_SETTING_PROFILE = "SETTING_USER.SQL_UPDATE_SETTING_PROFILE";
	private final static String USER_DETAIL_BY_ID = "SETTING_USER.USER_DETAIL_BY_ID";
	private final static String TASK_LIST_BY_ID = "SETTING_USER.TASK_LIST_BY_ID";
	private final static String INSERT_TASK_ASSIGNEE = "SETTING_USER.INSERT_TASK_ASSIGNEE";
	private final static String FIND_TIME_SHEET_TASK_ASSIGNEE_BY_USERID = "SETTING_USER.FIND_TIME_SHEET_TASK_ASSIGNEE_BY_USERID";
	private final static String DELETE_TIME_SHEET_TASK_ASSIGNEE_BY_USERID = "SETTING_USER.DELETE_TIME_SHEET_TASK_ASSIGNEE_BY_USERID";
	
	private final static String SQL_FIND_CUR_DEPT_PROJECT_ID = "SETTING_USER.FIND_CURRENT_DEPT_PROJECT_ID";
	private final static String SQL_DELETE_OLD_TASK_ASSIGNEE = "SETTING_USER.DELETE_OLD_TASK_ASSIGNEE";
	
	
	//private final static String SQL_SUBMIT_TIMESHEET = "TIMESHEET.SQL_SUBMIT_TIMESHEET";
	
//	private final static String SQL_CHECK_SETTING_USER = "SETTING.CHECK_SETTING_USER";
//	
//
//	private final static String SQL_REMOVE_SETTING_USER = "SETTING.DELETE_SETTING_USER";
	
	@Override
	public ServiceResult<List<Map<String, Object>>> searchSettingUserList(String userStatus) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
		List<Map<String, Object>> result = null;
		
		try{
			
			HashMap<String, Object> criteria = new HashMap<>(3);
			String id =null;
			String deptId = null;
			criteria.put("id", ObjectBeanUtils.isNullStr(id));
			criteria.put("userStatus", ObjectBeanUtils.isNullStr(userStatus));
			criteria.put("deptId", ObjectBeanUtils.isNullStr(deptId));
			
			log.info("get parameter user status : "+userStatus);
			if("0".equals(userStatus)) {
				result = dynamicJdbcDao.findForList(SQL_SEARCH_LOCK,criteria);
			}else
				result = dynamicJdbcDao.findForList(SQL_SEARCH,criteria);
			
			dataNotFound(result);
			
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}
	

	@Override
	public ServiceResult<List<Map<String, Object>>> searchSettingUser(String id,String userStatus, String deptId) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
		List<Map<String, Object>> result = null;
		
		try{
			
			HashMap<String, Object> criteria = new HashMap<>(3);
			
			criteria.put("id", ObjectBeanUtils.isNullStr(id));
			criteria.put("userStatus", ObjectBeanUtils.isNullStr(userStatus));
			criteria.put("deptId", ObjectBeanUtils.isNullStr(deptId));
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH,criteria);
			
			dataNotFound(result);
			
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<Map<String, Object>> > searchSettingUserDetail(String id) throws Exception {
		
	
		ServiceResult<List<Map<String, Object>> > serviceResult = new ServiceResult<List<Map<String, Object>>>();
			
		try{
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH_DETAIL_NEW,new SimpleKeyValue("id",id));
			
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.error(e+"");
			serviceResult = new ServiceResult<List<Map<String, Object>> >(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<Long> insertSettingUser(SettingUserBean bean) throws Exception {
	
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_NEW, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateSettingUser(SettingUserBean bean) throws Exception {

		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				/*final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, bean);*/
			
			//update New query for devision ,section 24072018
			final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE_NEW, bean);
				
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	
	}
	
	
	@Override
	public ServiceResult<Long> removeSettingUser(String id) throws Exception {

		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final int resId = dynamicJdbcDao.executeUpdate(SQL_DELETE, new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(resId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	
	}

	@Override
	public ServiceResult<Long> userStatusUpdate(String id, int user_status) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final int resId = dynamicJdbcDao.executeUpdate(SQL_UPDATE_STATUS,new SimpleKeyValue("id",id),new SimpleKeyValue("user_status",user_status) );
				result.setResult(Long.valueOf(resId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}
	
	@Override
	public ServiceResult<Integer> saveImportSettingUser(SettingUserBean bean) throws Exception {
	
		log.info("Import Userser");
		final ServiceResult<Integer> result = new ServiceResult<>();
		
		/*if(null != bean.getDivision()) {
			log.info("getDivision : "+bean.getDivision().toString());
		}
		if(null != bean.getMain_dept_id()) {
			log.info("getMain_dept_id : "+bean.getMain_dept_id().toString());
		}
		if(null != bean.getDepartment()) {
			log.info("getDepartment : "+bean.getDepartment().toString());
		}
		if(null != bean.getSection()) {
			log.info("getSection : "+bean.getSection().toString());
		}*/
		try{
			
			if (StringUtils.isEmpty(bean.getIs_admin())) {
				bean.setIs_admin("N");
			}				
			if (StringUtils.isEmpty(bean.getProbation())
						||bean.getProbation()=="N"
						||bean.getProbation_date()==null) {					
				bean.setProbation("N");
				bean.setProbation_date(null);
			}				
			if (!bean.getEmail().endsWith(BOSConstant.Suffix.EMAIL)) {
				bean.setEmail(null);
			}
			
			int caseVal = validateUser(bean);
			if (caseVal == 0) {
				
				switch (bean.getAction()) {
	    		
				case BOSConstant.DBAction.INSERT:
					dynamicJdbcDao.executeInsert(SQL_INSERT_NEW, Boolean.TRUE, bean );
					break;
					
				case BOSConstant.DBAction.UPDATE:
					dynamicJdbcDao.executeUpdate(SQL_UPDATE_NEW,bean);
					break;
				}
				
			}
			
			result.setResult(caseVal);
			
			result.setSuccess(Boolean.TRUE);
			

		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}

	@Override
	public ServiceResult<Integer> saveImportSettingUserProfile(SettingUserProfileBean bean) throws Exception {
		return new ServiceResult<Integer>(dynamicJdbcDao.executeUpdate(SQL_UPDATE_SETTING_PROFILE,bean)) ;
	}

	private int validateUser(SettingUserBean bean) {
		
		if (StringUtils.isEmpty(bean.getLogin_id())||
			StringUtils.isEmpty(bean.getFirst_name())||
			StringUtils.isEmpty(bean.getMiddle_name())||
			StringUtils.isEmpty(bean.getLast_name())||
			StringUtils.isEmpty(bean.getEmail())||
			StringUtils.isEmpty(bean.getAuthentication_type_id())||
			StringUtils.isEmpty(bean.getAppearance_date())||
			StringUtils.isEmpty(bean.getEmployee_type())||
			StringUtils.isEmpty(bean.getMain_dept_id())) {
							
			return 1;//Required field is Empty
			
		}
		
    	if (bean.getAction().equals(BOSConstant.DBAction.UPDATE)&&ObjectBeanUtils.isNullOrZero(bean.getId())) {
			return 2;//"User not found";
		}
		
		try {
			List<Map<String, Object>> userList = dynamicJdbcDao.findForList(SQL_SEARCH,new SimpleKeyValue("", ""));
	    	
			for (Map<String, Object> map : userList) {
					
					if (bean.getAction().equals(BOSConstant.DBAction.UPDATE)) {
						if (bean.getId().equals(map.get("id"))) {
							continue;
						}
					}
				
					if (bean.getLogin_id().equalsIgnoreCase(map.get("login_id").toString())) {
						return 3;//"Duplicate Login ID"
					} 
					else if (bean.getLast_name().equalsIgnoreCase(map.get("last_name").toString())){
							if( bean.getMiddle_name().equalsIgnoreCase(map.get("middle_name").toString())){
								if (bean.getFirst_name().equalsIgnoreCase(map.get("first_name").toString())) {
									return 4;//"Duplicate User"
								}
							}
					}
					else if (bean.getEmail().equalsIgnoreCase(map.get("Email").toString())) {
						return 5;//"Duplicate Email";
					} 
					else if (map.get("employee_id") != null && bean.getEmployee_id().equalsIgnoreCase(map.get("employee_id").toString())) {
						return 6;//"Duplicate Employee ID";
						
					}


			}

		} catch (Exception e) {
			e.printStackTrace();
			return 2;
		}
		
		return 0;
	}


	@Override
	public ServiceResult<SettingUserBean> searchUserDetailById(String id) throws Exception {
		ServiceResult<SettingUserBean> serviceResult = new ServiceResult<SettingUserBean>();
		
		try{
			
			SettingUserBean result  = dynamicJdbcDao.findForObject(USER_DETAIL_BY_ID,
                    BeanPropertyRowMapper.newInstance(SettingUserBean.class), new SimpleKeyValue("id", id));
			serviceResult = new ServiceResult<SettingUserBean>(result);
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
            setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}


	@Override
	public ServiceResult<List<TaskBean>> searchTaskListByProjectId(String projectId,String userId) throws Exception {
		ServiceResult<List<TaskBean>> serviceResult = new ServiceResult<List<TaskBean>>();   
		try{
			List<TaskBean> result  = dynamicJdbcDao.findForList(TASK_LIST_BY_ID,BeanPropertyRowMapper.newInstance(TaskBean.class)
					,new SimpleKeyValue("id",projectId)
					,new SimpleKeyValue("userId",userId));
			
			serviceResult = new ServiceResult<List<TaskBean>>(result);
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<TaskBean>>(e);
		}
		return serviceResult;
	}


	@Override
	public ServiceResult<int[]> insertInsertTaskAssignee(List<TaskAssigneeBean> taskAssigneeList) {
		ServiceResult<int[]> result = null;
		try {
			// Mapping
			Map<String, Object>[] arrMap = mappingDataBatchInsertTaskAssignee(taskAssigneeList);

			// insert
			int[] id = dynamicJdbcDao.batchInsert(INSERT_TASK_ASSIGNEE, arrMap);
			result = new ServiceResult<int[]>(id);
			result.setSuccess(true);
			result.setResponseDescription("success");

		} catch (Exception e) {
			log.info("error "+e);
			e.printStackTrace();
		}
		return result;
	}
	
	private Map<String, Object>[] mappingDataBatchInsertTaskAssignee(List<TaskAssigneeBean> list) {
		List<Map<String, Object>> txnValueMap = new ArrayList<>();

		for (TaskAssigneeBean bean : list) {
			TaskAssigneeBean taskAssignee = new TaskAssigneeBean();
			taskAssignee.setTaskId(bean.getTaskId());
			taskAssignee.setProjectId(bean.getProjectId());
			taskAssignee.setUserId(bean.getUserId());
			taskAssignee.setCreateBy(bean.getCreateBy());
			taskAssignee.setStartDate(bean.getStartDate());
			taskAssignee.setEndDate(bean.getEndDate());
			taskAssignee.setStatus(bean.getStatus());

			ObjectMapper objectMapper = new ObjectMapper();
			@SuppressWarnings("unchecked")
			Map<String, Object> objectTxnBean = objectMapper.convertValue(taskAssignee, Map.class);
			txnValueMap.add(objectTxnBean);
		}

		@SuppressWarnings("unchecked")
		Map<String, Object>[] arrMap = new HashMap[txnValueMap.size()];
		txnValueMap.toArray(arrMap);
		return arrMap;
	}


	@Override
	public ServiceResult<TaskAssigneeBean> searchTimesheetTaskAssigneeByUserId(String userId, String projectId)throws Exception {
		ServiceResult<TaskAssigneeBean> serviceResult = new ServiceResult<TaskAssigneeBean>();
		
		try{
			
			TaskAssigneeBean result  = dynamicJdbcDao.findForObject(USER_DETAIL_BY_ID,
                    BeanPropertyRowMapper.newInstance(TaskAssigneeBean.class)
                    , new SimpleKeyValue("userId", userId)
                    , new SimpleKeyValue("projectId", projectId));
			serviceResult = new ServiceResult<TaskAssigneeBean>(result);
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
            setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}


	@Override
	public ServiceResult<Long> deleteTimesheetTaskAssigneeByUserId(String userId,String projectId) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		
		try{
				final int resId = dynamicJdbcDao.executeUpdate(DELETE_TIME_SHEET_TASK_ASSIGNEE_BY_USERID
						, new SimpleKeyValue("userId", userId)
	                    , new SimpleKeyValue("taskAssignId", projectId));
				result.setResult(Long.valueOf(resId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	}
	
	/*
	@Override
	public String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception {
		//ServiceResult<String> result = null;
		
		log.info("Timesheet control"+pid);
		 
		String result = "";
		try {
			List<String> lst = dynamicJdbcDao.findForList(SQL_CHECK_LOGTIME, String.class , 
					new SimpleKeyValue("pid",pid));
			  log.info("size : "+lst.size());
			  if(lst.size()>0){
				  result = lst.get(0);
			log.info("Timesheet control"+lst.get(0));
			  }
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
		return result;
	}
  */
	
	@Override
	public ServiceResult<List<DataBean>> findCurrentDeptProjectId(List<String> deptId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = null;
		try{
		
			List<DataBean> result = dynamicJdbcDao.findForList(SQL_FIND_CUR_DEPT_PROJECT_ID, BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("deptId",deptId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<Long> deleteOldTaskAssignee(String userId,List<String> projectId) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		
		try{
				final int resId = dynamicJdbcDao.executeUpdate(SQL_DELETE_OLD_TASK_ASSIGNEE
						, new SimpleKeyValue("userId", userId)
	                    , new SimpleKeyValue("projectId", projectId));
				result.setResult(Long.valueOf(resId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	}
}
