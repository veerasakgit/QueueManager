package com.locus.jlo.web.beans.module;

import com.locus.jlo.web.beans.StampBean;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class DocumentsBean extends StampBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer project_id;
	private Integer document_type_setting_id;
	private String document_name;
	private String description;
	private String disk_path;
	private String file_name;
	private String file_size;
	private String file_type;
	private Integer documents_version_id;
	private String disk_directory;

	//Ui
	private String action;

}
