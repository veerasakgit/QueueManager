package com.locus.jlo.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.web.beans.assets.AssetCriteria;
import com.locus.jlo.web.beans.assets.AssetsBean;
import com.locus.jlo.web.beans.assets.AssetsCustomBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.AssetsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class AssetsController extends CoreController{

	
	 @Autowired
	 private AssetsService assetsService;
	 
	 @RequestMapping(value = {"/setting_asset"})
	 public String index() {
	        return "setting_asset";
	}
	 
	
	@RequestMapping(value = "/searchAssets", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchAssets(HttpServletRequest request,Locale locale) throws Exception{

		String data = request.getParameter("data");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(data);
		
		HashMap<String, String> jsonMap = json;
		HashMap<String, String> criteria = new HashMap<>(3);
		
		jsonMap.forEach((key,value)->{
			if (!StringUtils.isEmpty(jsonMap.get(key)) && !key.equals("userId")) {
				criteria.put(key, "%"+jsonMap.get(key)+"%");
			}
		});
		
		
		ServiceResult<AssetsCustomBean> listResult =  assetsService.searchAssets(criteria); 
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
		return result;
	 }
	
	 @RequestMapping(value = "/saveAssets", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveAssets(HttpServletRequest request,Locale locale) throws Exception{
			
			//https://www.tutorialspoint.com/json/json_java_example.htm
			 final int USER_ID = getUid(request);
			 String data = request.getParameter("data");
			 String userId = request.getParameter("userId");
			 
			 log.info("Setting User control");
			 log.info("data: "+data);
			 
			 List<AssetsBean> beans = new ArrayList<>();
			 
			 if (!(data.equals("{}"))) {
				 JSONParser jParser = new JSONParser();
				 JSONObject json = (JSONObject) jParser.parse(data);
				 
				 JsonBeanUtils<AssetsBean> utils = new JsonBeanUtils<>(AssetsBean.class);	 		 
				 beans = utils.convertFormAndBean(json,"action",USER_ID);
				 
				 log.info("data");
				 utils.testPrint(beans);
			}

			 String result_status = "";
			 String result_msg    = "";
			 ServiceResult<List<Long>> result = new ServiceResult<>();
			 
			 try{

				 result =  assetsService.saveAssets(beans, Integer.parseInt(userId));
	 	    			
	 	    	if(result.isSuccess()){
	 	    		log.info( "get long : "+result.getResult());
	 	    		result_status = "success";
	 	    		result_msg    = "save successful";
	 	    				
	 	    	}else{
	 	    			result_status = "fail";
	 	    			result_msg    = "save fail";
	 	    	}
		
				}catch(Exception e){
					log.info("Error !!"+e);
				}

			JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult());
			return res;
		   

		 }
	 
		@RequestMapping(value = "/deleteAssets", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean deleteAssets(HttpServletRequest request,Locale locale) throws Exception{
			
			String id  = request.getParameter("id");
			log.info("id: "+id);
			ServiceResult<Long> idResult =  assetsService.deleteAssets(Long.valueOf(id));
			JsonResultBean result = null;
			if(idResult.isSuccess()){
				result = new JsonResultBean("success", "" , idResult.getResult());
			}
			return result;
		 }
		
		
		@RequestMapping(value = "/searchAssetAll", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean searchAssetAll(HttpServletRequest request,Locale locale) throws Exception{

			String cri = request.getParameter("cri");	
			JSONParser jParser = new JSONParser();
			JSONObject json = (JSONObject)jParser.parse(cri);

			AssetCriteria criteria = new AssetCriteria();
			
			String id = "";
			String userId = "";
			String status = "";
			String assetNo = "";
			String brand = "";
			String serialNo = "";
			String division = "";
			String department = "";
			String section = "";
			
			if (json.get("userId") != null ) {
				userId = json.get("userId").toString();
			} else {
				userId = json.get("staff").toString();
				status = json.get("status").toString();
				assetNo = json.get("assetNo").toString();
				brand = json.get("brand").toString();
				serialNo = json.get("serialNo").toString();
				division = json.get("division").toString();
				department = json.get("department").toString();
				section = json.get("section").toString();
			}
			
			if (!StringUtils.isEmpty(id))
				criteria.setId(id);
			if (!StringUtils.isEmpty(userId))
				criteria.setUserId(userId);
			if (!StringUtils.isEmpty(status))
				criteria.setStatus(status);
			if (!StringUtils.isEmpty(assetNo))
				criteria.setAssetNo(assetNo);
			if (!StringUtils.isEmpty(brand))
				criteria.setBrand(brand);
			if (!StringUtils.isEmpty(serialNo))
				criteria.setSerialNo(serialNo);
			if (!StringUtils.isEmpty(division))
				criteria.setDivision(division);
			if (!StringUtils.isEmpty(department))
				criteria.setDepartment(department);
			if (!StringUtils.isEmpty(section))
				criteria.setSection(section);
			
			 
			 JsonResultBean result = null;
			 ServiceResult<List<AssetsBean>> listResult = assetsService.searchAssetAll(criteria); 
			 
			 if (listResult.isSuccess()) {
				 result = new JsonResultBean("success", "" , listResult.getResult());

				 log.info("successRespones : "+result.toString());
				 log.info(" total : " + listResult.getResult().size());
			 } else {
				 
				 result = new JsonResultBean("fail", "" , "");
				 log.info("fail_Respones : ");
			 }
			 return result;
		
		}
		
		@RequestMapping(value = "/searchAssetUser", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean searchAssetUser(HttpServletRequest request,Locale locale) throws Exception{

			String userId = request.getParameter("userId");

			AssetCriteria criteria = new AssetCriteria();
			criteria.setUserId(userId);
			ServiceResult<List<AssetsBean>> listResult =  assetsService.searchAssetUser(criteria); 
			JsonResultBean result = null;
			
			if (listResult.isSuccess()) {
				 result = new JsonResultBean("success", "" , listResult.getResult());

				 log.info("successRespones : "+result.toString());
				 log.info(" total : " + listResult.getResult().size());
			 } else {
				 result = new JsonResultBean("fail", "" , "");
				 log.info("fail_Respones : ");
			 }
			
			return result;
		 }
	
}
