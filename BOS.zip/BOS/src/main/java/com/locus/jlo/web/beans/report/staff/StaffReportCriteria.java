package com.locus.jlo.web.beans.report.staff;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StaffReportCriteria {

	private String startDate;
	private String endDate;
	private String division;
	private String department;
	private String section;
	private List<String> project;
	private List<String> employeeName;
	private String searchMode;
}
