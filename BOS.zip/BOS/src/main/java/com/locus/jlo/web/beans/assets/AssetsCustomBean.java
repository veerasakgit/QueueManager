package com.locus.jlo.web.beans.assets;

import java.io.Serializable;
import java.util.List;

import com.locus.jlo.web.beans.setting.SettingDeptBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.sun.org.apache.bcel.internal.generic.LUSHR;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AssetsCustomBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3007751875465863340L;
	private SettingUserBean settingUserBean;
	private SettingDeptBean settingDeptBean;
	private List<AssetsBean> assetsBeans;

	
	public AssetsCustomBean(SettingUserBean settingUserBean,SettingDeptBean settingDeptBean) {
		this.settingUserBean = settingUserBean;
		this.settingDeptBean = settingDeptBean;		
	}
}
