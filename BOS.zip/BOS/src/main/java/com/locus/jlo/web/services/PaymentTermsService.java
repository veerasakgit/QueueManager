package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.paymentTerms.PaymentTermsBean;
import com.locus.jlo.web.beans.project.ProjectBean;

import java.util.List;
import java.util.Map;


public interface PaymentTermsService {

	ServiceResult<List<Map<String, Object>>> searchProjectPayTerm(PaymentTermsBean projectBean) throws Exception;

	ServiceResult<Integer> insertProjectPayTerm(PaymentTermsBean projectBean) throws Exception;
	ServiceResult<Integer> updateProjectPayTerm(PaymentTermsBean projectBean) throws Exception;
	ServiceResult<Integer> removeProjectPayTerm(Integer id) throws Exception;

	ServiceResult<Integer> removeProjectPayTermByDeal(Integer deal_id) throws Exception;
	ServiceResult<Integer> removeProjectPayTermById(Integer paymentTermId) throws Exception;

	ServiceResult<Integer> savePaymentTerms(List<PaymentTermsBean> beans, Integer USER_ID) throws Exception;
	
	ServiceResult<ProjectBean> searchPaymentTermsProjectDetail(String project_id) throws Exception;
}
