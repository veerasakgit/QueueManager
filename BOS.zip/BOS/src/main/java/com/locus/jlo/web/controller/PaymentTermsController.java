package com.locus.jlo.web.controller;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.paymentTerms.PaymentTermsBean;
import com.locus.jlo.web.beans.project.ProjectBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.PaymentTermsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.List;
import java.util.Locale;
import java.util.Map;


@Slf4j
@Controller
@RequestMapping("paymentterms")
public class PaymentTermsController extends CoreController {

    @Autowired
    private PaymentTermsService paymentTermsService;

    @GetMapping("/searchPaymentTermsById/{id}")
    public @ResponseBody
    JsonResultBean searchPaymentTermsById(@PathVariable("id") Integer deal_id, HttpServletRequest request, Locale locale) throws Exception {

        PaymentTermsBean bean = new PaymentTermsBean();
        bean.setDeal_id(deal_id);

        ServiceResult<List<Map<String, Object>>> obj = paymentTermsService.searchProjectPayTerm(bean);
        JsonResultBean result = null;
        if (obj.isSuccess()) {
            result = new JsonResultBean("success", "", obj.getResult());
        }
        return result;
    }
    
    @RequestMapping(value = "/searchPaymentTermsProjectDetailById/{id}", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.GET)
    public @ResponseBody
    JsonResultBean searchPaymentTermsProjectDetailById(@PathVariable("id") String id, HttpServletRequest request, Locale locale) throws Exception {
        log.info("id: " + id);
        ServiceResult<ProjectBean> resultObj = paymentTermsService.searchPaymentTermsProjectDetail(id);
        JsonResultBean result = null;
        if (resultObj.isSuccess()) {
            result = new JsonResultBean("success", "", resultObj.getResult());
        }
        return result;
    }

    @PostMapping("/searchPaymentTerms")
    public @ResponseBody
    JsonResultBean searchPaymentTerms(@RequestBody PaymentTermsBean bean, HttpServletRequest request, Locale locale) throws Exception {
        ServiceResult<List<Map<String, Object>>> obj = paymentTermsService.searchProjectPayTerm(bean);
        JsonResultBean result = null;
        if (obj.isSuccess()) {
            result = new JsonResultBean("success", "", obj.getResult());
        }
        return result;
    }

    @PostMapping("/savePaymentTerms")
    @Transactional
    public @ResponseBody
    JsonResultBean savePaymentTerms(@RequestBody List<PaymentTermsBean> beans, HttpServletRequest request, Locale locale) throws Exception {

        final Integer USER_ID = getUid(request);

        String result_status = "";
        String result_msg = "";
        String result_data = "";

        ServiceResult<Integer> result = paymentTermsService.savePaymentTerms(beans, USER_ID);

        if (result.isSuccess()) {
            log.info("get long : " + result.getResult());
            result_data = Long.toString(result.getResult());
            result_status = "success";
            result_msg = "save successful";
        } else {
            result_status = "fail";
            result_msg = "save fail";
        }

        JsonResultBean res = new JsonResultBean(result_status, result_msg, result_data);
        return res;
    }
    
    
    @RequestMapping(value = "/deletePaymentTerms", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
    @Transactional
	public @ResponseBody JsonResultBean deletePaymentTerms(@RequestParam(required = false) String paymentsListArr,Model model, HttpServletRequest request, HttpServletResponse response, Locale local) throws Exception {
    	String result_msg = "";
        String result_data = "";
        String result_status = "";
        
//		String payments = request.getParameter("paymentsList");
		String[] paymentsList = paymentsListArr.split(",");
		
		if(paymentsList != null && paymentsList.length != 0){
			
			for (int i = 0; i < paymentsList.length; i++) {
				String paymentTermId = paymentsList[i].toString();
				
				ServiceResult<Integer> delResult = paymentTermsService.removeProjectPayTermById(Integer.parseInt(paymentTermId));
		        if(delResult.isSuccess()){
		        	log.info("get long : " + delResult.getResult());
		            result_status = "success";
		        }else{
		        	 result_status = "fail";
		        }
			}
		}
		
		JsonResultBean res = new JsonResultBean(result_status, result_msg, result_data);
        return res;
	}

}