package com.locus.jlo.web.services.impl;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.project.ProjectMembersBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.ProjectMembersService;
import com.locus.jlo.web.services.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class ProjectMembersServiceImpl extends BaseService implements ProjectMembersService{
	
	String SQL_SEARCH = "PROJECT_MEMBERS.SQL_SEARCH";
	String SQL_SEARCH_LIST_BY_PROJECT = "PROJECT_MEMBERS.SQL_SEARCH_LIST_BY_PROJECT";
	String SQL_SELECT_ROLE_BY_PROJECT = "PROJECT_MEMBERS.SQL_SELECT_ROLE_BY_PROJECT";
	String SQL_INSERT = "PROJECT_MEMBERS.SQL_INSERT";
	String SQL_UPDATE = "PROJECT_MEMBERS.SQL_UPDATE";
	String SQL_DELETE = "PROJECT_MEMBERS.SQL_DELETE";
	String SQL_DELETE_ID = "PROJECT_MEMBERS.SQL_DELETE_ID";
	String SQL_UPDATE_BY_PROGRESS = "PROJECT_MEMBERS.SQL_UPDATE_BY_PROJECT_PROGRESS";
	@Autowired
	private TaskService taskService;
	
	@Override
	public ServiceResult<List<Map<String, Object>>> searchProjectMembers(String projectId, String roleId) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();
		try {
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH
					, new SimpleKeyValue("projectId", projectId)
					, new SimpleKeyValue("roleId", roleId));
			serviceResult = new ServiceResult<>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());

		} catch (Exception e) {
			serviceResult = new ServiceResult<>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	@Transactional
	public ServiceResult<List<Long>> saveProjectMembers(List<ProjectMembersBean> beans) throws Exception {
		ServiceResult<List<Long>> serviceResult = null;
		try{
			List<Long> ids = new ArrayList<>();

			if (!CollectionUtils.isEmpty(beans)) {
	
				for (ProjectMembersBean bean : beans) {
						Long id = 0L;
						switch (bean.getAction()) {
							case BOSConstant.DBAction.INSERT :
								id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean);
								taskService.assigneeByMembers(bean);
								break;
							case BOSConstant.DBAction.UPDATE :
								id = Long.valueOf(dynamicJdbcDao.executeUpdate(SQL_UPDATE,bean));
								break;
							case BOSConstant.DBAction.DELETE :
								if(StringUtils.isEmpty(bean.getId()))
									id = Long.valueOf(dynamicJdbcDao.executeUpdate(SQL_DELETE,bean));
								else
									id = Long.valueOf(dynamicJdbcDao.executeUpdate(SQL_DELETE_ID,bean));
								taskService.removeTaskAssigneeByMember(bean);
								break;
							default:
								log.error("Not an action");
								break;
							}
						if (id != null && id != 0L) {
							ids .add(id);
						}

				}

			}
			
			serviceResult = new ServiceResult<>(ids);
			return serviceResult;
		}catch(Exception e){
			throw e;
		}

	}

	@Override
	public ServiceResult<List<Map<String, Object>>> searchProjectMembersByProject(String project_id,String roleId) {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();
		try {
			HashMap<String, Object> map = new HashMap<>();
			map.put("projectId", StringUtils.isEmpty(project_id) ? null : project_id);
			map.put("roleId", StringUtils.isEmpty(roleId) ? null : roleId);
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH_LIST_BY_PROJECT, map);
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());
		} catch (Exception e) {
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<Map<String, Object>>> searchRoleProjectMembersByProject(String project_id) {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();
		try {
			HashMap<String, Object> map = new HashMap<>();
			map.put("projectId", StringUtils.isEmpty(project_id) ? null : project_id);
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SELECT_ROLE_BY_PROJECT, map);
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());
		} catch (Exception e) {
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	@Override
	@Transactional
	public ServiceResult<List<Long>> updateByProjectProgress(List<ProjectMembersBean> beans) throws Exception {
		ServiceResult<List<Long>> serviceResult = null;
		try{
			List<Long> ids = new ArrayList<>();

			if (!CollectionUtils.isEmpty(beans)) {
	
				for (ProjectMembersBean bean : beans) {
						Long id = 0L;
						id = Long.valueOf(dynamicJdbcDao.executeUpdate(SQL_UPDATE_BY_PROGRESS,bean));
						if (id != null && id != 0L) {
							ids .add(id);
						}

				}

			}
			
			serviceResult = new ServiceResult<>(ids);
			return serviceResult;
		}catch(Exception e){
			throw e;
		}

	}


}
