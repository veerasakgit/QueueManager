package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.project.ProjectBean;
import com.locus.jlo.web.beans.project.ProjectMembersBean;

import java.util.List;
import java.util.Map;


public interface ProjectService {
	
	ServiceResult<List<DataBean>> searchProject(String filter_my_project,String filter_project_type,String filter_project_status, String filter_active_project) throws Exception;
	ServiceResult<ProjectBean> searchProjectDetail(String project_id) throws Exception;
	
	//deprecate
	ServiceResult<Long> insertProject(ProjectBean projectBean, List<ProjectMembersBean> subBeans) throws Exception;
	
	
	ServiceResult<Long> insertNewProject(ProjectBean projectBean) throws Exception;
	
	ServiceResult<Long> updateProject(ProjectBean projectBean ) throws Exception;
	ServiceResult<Long> removeProject(String project_id) throws Exception;
	
	
	
	//String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception;
	/*
	ServiceResult<Long> insertLogtime(String pid, String tid, String date, String hour, String status, String uid) throws Exception;
	ServiceResult<Long> updateLogtime(String pid, String tid, String date, String hour, String status, String uid, String eid ) throws Exception;
	ServiceResult<Long> removeLogtime(String eid) throws Exception;
	
	
	ServiceResult<Long> submitTimesheet(String data_eid) throws Exception;

	
	ServiceResult<Integer> insertLogtime(String id) throws Exception;
	ServiceResult<Integer> updateLogtime(String id) throws Exception;
	ServiceResult<Integer> deleteLogtime(String id) throws Exception;
	*/
}
