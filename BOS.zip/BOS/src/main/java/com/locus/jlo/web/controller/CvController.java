package com.locus.jlo.web.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.locus.jlo.utils.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.cv.CvBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.CvService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class CvController extends CoreController{
	
	
	private String userId;
	
	@Autowired
	private CvService cvService;

	@Value("${jlo.cv.path}")
	private String cvPath;
	
	@RequestMapping(value = {"/cv"})
	  public String index() {
	        return "cv";
	}
	
	
	@RequestMapping(value = "/searchCv", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchCv(HttpServletRequest request, Locale locale)
			throws Exception {
		
		this.userId = null;
		String userId = request.getParameter("userId");
		if (StringUtils.isEmpty(userId)) {
			userId = getUid(request).toString();
		}
		
		ServiceResult<List<Map<String, Object>>> listResult = cvService.searchCv(userId);
		JsonResultBean result = null;
		if (listResult.isSuccess()) {
			result = new JsonResultBean("success", "", listResult.getResult());
			this.userId = userId;
		}

		return result;
	}
	
	 @RequestMapping(value = "/uploadAndInsertCv", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean uploadAndInsertCv( @RequestParam("cvFile") MultipartFile uploadfile,HttpServletRequest request,Locale locale) throws Exception{
		 
		 log.info("Start upload");
		 JsonResultBean res = null;
		 
		 String result_status = "success";
		 String result_msg = "success";
		 String result_data = "";
		 
		 final String directory = BOSConstant.Path.DIRECTORY;
		 
		 try {
		      // Get the filename and build the local file path
			 
			  long mstime = System.currentTimeMillis();
		      String filename = uploadfile.getOriginalFilename();
		      String filenameInTime = mstime+"-"+filename;
		      //Temp
		      String servPath = "assets/attach_file/cv/"+userId;
		      
		      String filepath = Paths.get(directory+servPath, filenameInTime).toString();
		      
		      // Save the file locally
		      File file = new File(filepath);
		      
		      file.getParentFile().mkdirs();
		      
		      FileOutputStream output = new FileOutputStream(file);

		      BufferedOutputStream stream =  new BufferedOutputStream(output);
		      stream.write(uploadfile.getBytes());
		      stream.close();
		      
		      //insert
		      {
		    	  
		    	  	String downloadPath = servPath+"/"+filenameInTime;
		    	  
		    		CvBean bean = new CvBean();
		    		bean.setFile_name(filename);
		    		bean.setFile_path(downloadPath);
		    		bean.setUser_id(Integer.parseInt(userId));
		    		bean.setCreate_uid(getUid(request));

					ServiceResult<Long> result =  cvService.insertCv(bean);
	 	    			
		    		 if(result.isSuccess()){
				 	   		log.info( "get long : "+result.getResult());
				 	   		result_status = "success";
				 	   		result_msg    = "save successful";
				 	    				
				 	 }else{
				     		result_status = "fail";
				    		result_msg    = "save fail";
			 	    }
		      }
		      
		      
		      
	    }catch(Exception e){
	    	e.printStackTrace();
	    }

		res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
	
	 }
	
	@RequestMapping(value = "/deleteCv", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean deleteCv(HttpServletRequest request,Locale locale) throws Exception{
			
			String id  = request.getParameter("id");
			log.info("id: "+id);
			ServiceResult<Long> idResult =  cvService.deleteCv(id);
			JsonResultBean result = null;
			if(idResult.isSuccess()){
				result = new JsonResultBean("success", "" , idResult.getResult());
			}
			return result;
	 }

	@RequestMapping(value = "/downloadCv/{fileName:.+}", method = RequestMethod.GET)
	public @ResponseBody void downloadDocumentById(@PathVariable String fileName,
												   HttpServletRequest request, HttpServletResponse response, Locale locale) throws Exception {
		if(!StringUtils.isEmpty(fileName)){
			FileUtils.downloadFile(request, response, cvPath + "/" + fileName);
		}
	}

}