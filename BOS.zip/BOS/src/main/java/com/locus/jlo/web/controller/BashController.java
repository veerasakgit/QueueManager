package com.locus.jlo.web.controller;

import java.util.Locale;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.BashService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class BashController extends CoreController{

	
	@Value("#{servletContext.contextPath}")
	private String servletContextPath;
	
	 @Autowired
	 private BashService bashService;
	
	 
	 @RequestMapping(value = "/reCalLeaveHour", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.GET)
		public @ResponseBody JsonResultBean reCalLeaveHour(HttpServletRequest request,Locale locale) throws Exception{
		 
		 
		 String userId = request.getParameter("staffid");
		 
		 log.info("userId : "+userId);

		//update pass probation
		ServiceResult<Long> listResult =  bashService.reCalLeaveHour(userId); 
		
		
		
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
			
		
		 
		 log.info("bash run done");
		 return result;
	 }
	 
	@RequestMapping(value = "/bashTask", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.GET)
	public @ResponseBody JsonResultBean bashProbationPass(HttpServletRequest request,Locale locale) throws Exception{
 
		//every date
		//update pass probation
		ServiceResult<Long> listResult =  bashService.autoUpdatePassProbation(); 
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
		
		log.info("bash run done");
		
		return result;
		
		
	 }
	
	
	@RequestMapping(value = "/bashNotifyTimesheetUnsuccess", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.GET)
	public @ResponseBody JsonResultBean searchAssets(HttpServletRequest request,Locale locale) throws Exception{
 
		//update pass probation
		ServiceResult<Long> listResult =  bashService.autoUpdatePassProbation(); 
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
		
		return result;
		
		
	 }
}
