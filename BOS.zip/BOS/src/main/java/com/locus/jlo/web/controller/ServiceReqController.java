package com.locus.jlo.web.controller;

import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;
import java.util.Date;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.account.search.AccountSearchBean;
import com.locus.jlo.web.beans.leaveForm.LeaveFormDetailBean;
import com.locus.jlo.web.beans.system.modeljson.DatatableModelBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.LeaveFormService;


import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;

@Slf4j
@Controller
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceReqController {
	 
	final static private SimpleDateFormat yyyyMMddHHmm = new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US);
	final static private SimpleDateFormat yyyyMMddHHmmss = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US);
	
	final static private SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US); 
	
	
	@Autowired
	private LeaveFormService leaveFormService;
	
	
 
	 /*
	 @RequestMapping(value = "/emailLeaveRej", method = RequestMethod.GET)
	 public @ResponseBody String rejectByEmail(HttpServletRequest request,Locale locale) throws Exception{
		 
		 String id = request.getParameter("id");
		 String verify = request.getParameter("verify");
		 String token = request.getParameter("token");
		 
		 log.info("get reject: "+id+"|"+verify+"|"+token);
		 return "leave";
	 }
	 
	 
	 @RequestMapping(value = "/emailLeaveAppr", method = RequestMethod.GET)
	 public @ResponseBody String approveByEmail(HttpServletRequest request,Locale locale) throws Exception{
		 
		 //test by 
		 
		 String id = request.getParameter("id");
		 String verify = request.getParameter("verify");
		 String token = request.getParameter("token");
		 
		 log.info("approve by email: "+id+"|"+verify+"|"+token);
		 
		 return "leave";
	 }
	 
	  
	 //if from email channel error will be response to notify
	 //Can't approve leave arnon request by email channel because status is already approve
	 @RequestMapping(value = "/sendMail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean sendMail(HttpServletRequest request,Locale locale) throws Exception{
		 
		 
		 	String result_status = "";
			String result_msg = "";
			String result_data = "";
					
			try{
					String template = mailTemplate();
					//log.info(template);
				
				  	Properties props = new Properties();
			        props.put("mail.smtp.host", "smtp.office365.com");
			        props.put("mail.smtp.socketFactory.port", "587");
			        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			        props.put("mail.smtp.auth", "true");
			        props.put("mail.smtp.port", "587");
			        props.put("mail.smtp.starttls.enable", "true");
			        
			        Session session = Session.getDefaultInstance(props,
			        	new javax.mail.Authenticator() {
	                    protected PasswordAuthentication getPasswordAuthentication() {
	                        return new PasswordAuthentication("arnon@locus.co.th","locus123");
	                    }
	                });

	                Message message = new MimeMessage(session);
	                message.setFrom(new InternetAddress("arnon@locus.co.th"));
	                message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("arnon@locus.co.th"));
	                message.setSubject("This is testing message");
	               // message.setText("Hi this is testing email....not spam");
	               // message.setContent("<h1><img src='http://www.locus.co.th/assets/main/img/logo@2x.png'> Hello</h1>", "text/html");
	                message.setContent(template, "text/html; charset=utf-8");
	                //message.setContent(someHtmlMessage, "text/html; charset=utf-8");
	                Transport.send(message);
	                System.out.println("email successfully sent..");
			
				
			}catch(Exception e){
				throw new RuntimeException(e);
			}
			
		
			JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
			return res;
			
	}
	 
	 private String readContentFromFile(String fileName){
	     StringBuffer contents = new StringBuffer();
	     
	     try {
	       //use buffering, reading one line at a time
	       BufferedReader reader =  new BufferedReader(new FileReader(fileName));
	       try {
	         String line = null; 
	         while (( line = reader.readLine()) != null){
	           contents.append(line);
	           contents.append(System.getProperty("line.separator"));
	         }
	       }
	       finally {
	           reader.close();
	       }
	     }
	     catch(IOException ex){
	       ex.printStackTrace();
	     }
	     return contents.toString();
	
	 }


	 private String mailTemplate(){
		 
		 String filePath = "D:\\JLO_WORKSPACE\\BOS2\\BOS\\src\\main\\webapp\\WEB-INF\\view\\mailTemplate2.html";
		 File file = new File(filePath);
		 log.info(file.getAbsolutePath());
		 String msg = readContentFromFile(filePath);
		// log.info(msg);

		 
		 return msg;
		 
	 }
	 
	 @RequestMapping(value = "/searchLeaveRequest", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchLeaveRequest(HttpServletRequest request,Locale locale) throws Exception{
		
		String userId  = "131"; //request.getParameter("id");
		String year    = "2018"; //request.getParameter("year");
		 
		ServiceResult<List<DataBean>> listResult =  leaveFormService.searchLeaveReq(year , userId); 
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
	   
		return result;
	   
	 }
	 
	 @RequestMapping(value = "/searchLeaveRequestDetail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchLeaveRequestDetail(HttpServletRequest request,Locale locale) throws Exception{
		 
		 String id  = request.getParameter("id");
		 log.info("id: "+id);
		 ServiceResult<List<DataBean>> listResult =  leaveFormService.searchLeaveReqDetail(id); 
		 JsonResultBean result = null;
		 if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		 }
		 
		return result;
	 }
	 
	 @RequestMapping(value = "/saveLeaveRequest", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveLeaveRequestDetail(HttpServletRequest request,Locale locale) throws Exception{
		
		 
		 //send mail
		 //create task
		 //insert into notification
		 
		//https://www.tutorialspoint.com/json/json_java_example.htm
		 String USER_ID = "131";
		 String data = request.getParameter("data");
		 String act  = request.getParameter("action");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 log.info("Timesheet control");
		 log.info("data: "+data);
		 log.info("action : "+act);
		 
		 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
		 
		 log.info( ""+json );
		 log.info(""+json.get("leave_type_id"));
		 
		 //convert between form and bean
		 LeaveFormDetailBean leaveForm = new LeaveFormDetailBean();
		 leaveForm.setLeave_id(json.get("leave_id").toString());
		 leaveForm.setUser_id(USER_ID);
		 leaveForm.setLeave_type_id(json.get("leave_type_id").toString());
		 leaveForm.setJustification(json.get("justification").toString());
		
		 log.info("start date: "+json.get("start_date").toString()+" "+json.get("start_time_hh").toString()+":"+json.get("start_time_mm").toString());
		 log.info("end date: "+json.get("end_date").toString()+" "+json.get("end_time_hh").toString()+":"+json.get("end_time_mm").toString());
		 
		 Date startdt = yyyyMMddHHmm.parse(json.get("start_date").toString()+" "+json.get("start_time_hh").toString()+":"+json.get("start_time_mm").toString());
		 Date enddt = yyyyMMddHHmm.parse(json.get("end_date").toString()+" "+json.get("end_time_hh").toString()+":"+json.get("end_time_mm").toString());
		 Date cur_date = yyyyMMddHHmmss.parse(yyyyMMddHHmmss.format(new Date()));
		  
		 leaveForm.setStart_dt(startdt);
		 leaveForm.setEnd_dt(enddt);
		  	
		 //get status
		 switch(json.get("leave_status").toString()){
		 	 case "draft" : leaveForm.setLeave_status("1");
		 		 			break;
		 	 case "request" : leaveForm.setLeave_status("2");
		 	 				leaveForm.setRequest_dt(cur_date);
		 	 				leaveForm.setRequest_user_id(USER_ID);
		 	 				break;
			 case "approve" : leaveForm.setLeave_status("3"); 
			 				leaveForm.setApprove_dt(cur_date);
			 				leaveForm.setApprove_user_id(USER_ID);
			 				break;
			 case "cancel": leaveForm.setLeave_status("0"); 
			 				leaveForm.setCancel_dt(cur_date);
			 				leaveForm.setCancel_user_id(USER_ID);
			 				break;
			 case "reject" : leaveForm.setLeave_status("4"); 
			 				leaveForm.setReject_dt(cur_date);
			 				leaveForm.setReject_user_id(USER_ID);
			 				leaveForm.setReject_reason("");
			 				break;
			 case "approve_wh_pay" : leaveForm.setLeave_status("5"); 
			 				leaveForm.setApprove_wh_pay_dt(cur_date);
			 				leaveForm.setApprove_wh_pay_user_id(USER_ID);
			 				break;
		 }
		 
		
	
			
		 try{
			 
				switch (act){
			 	    case "I" : log.info("insert data");
			 	    			result =  leaveFormService.insertLeaveForm( leaveForm );
			 	    			
			 	    			if( result.isSuccess()){
			 	    			   log.info( "get long : "+result.getResult().longValue() );
			 	    			   result_data   = Long.toString(result.getResult().longValue());
			 	    			   result_status = "success";
								   result_msg    = "save successful";
			 	    				
			 	    			}else{
			 	    				result_status = "fail";
									result_msg    = "save fail";
			 	    			}
			 	    		
							break;
						
			 	    case "U" : log.info("update data");
			 	    
			 						result =  leaveFormService.updateLeaveForm( leaveForm );
									if( result.isSuccess()){
									log.info( "get long : "+result.getResult().longValue() );
									result_data   = Long.toString(result.getResult().longValue());
									result_status = "success";
									result_msg    = "save successful";
									
									}else{
									result_status = "fail";
									result_msg    = "save fail";
									}

			 	   			break;
	 	   			case "R" : log.info("remove data"); 
	 	   							result =  leaveFormService.removeLeaveForm( json.get("leave_id").toString() );
	 	   									
	   								if( result.isSuccess()){
	   								log.info( "get long : "+result.getResult().longValue() );
	   								result_data   = Long.toString(result.getResult().longValue());
	   								result_status = "success";
	   								result_msg    = "save successful";
	   								
	   								}else{
	   								result_status = "fail";
	   								result_msg    = "save fail";
	   								}
			 	   		    break;
			 	   		 
			 	   default : log.error("something wrong");
					
				}
					
			}catch(Exception e){
				log.info("Error !!"+e);
			}
		  
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
	   

	 }
	 
	 @RequestMapping(value = "/removeLeaveRequest", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean removeLeaveRequest(HttpServletRequest request,Locale locale) throws Exception{
		
	   
		return null;
	 }
	 
	 */
	
	 

}