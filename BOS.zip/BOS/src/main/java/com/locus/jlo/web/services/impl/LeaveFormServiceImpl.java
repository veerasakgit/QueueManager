package com.locus.jlo.web.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.common.mapper.PrimitiveSafeBeanPropertyRowMapper;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.deals.DealBean;
import com.locus.jlo.web.beans.leaveForm.LeaveFormDetailBean;
import com.locus.jlo.web.services.LeaveFormService;


import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class LeaveFormServiceImpl extends BaseService implements LeaveFormService{
	
	String SQL_SEARCH_LEAVE_REQ = "LEAVE_FORM.SQL_SEARCH_LEAVE_REQ";
	String SQL_SEARCH_LEAVE_FORM = "LEAVE_FORM.SQL_SEARCH_LEAVE_FORM";
	String SQL_INSERT_LEAVE_FORM = "LEAVE_FORM.SQL_INSERT_LEAVE_FORM"; 
	String SQL_UPDATE_LEAVE_FORM = "LEAVE_FORM.SQL_UPDATE_LEAVE_FORM"; 
	String SQL_REMOVE_LEAVE_FORM = "LEAVE_FORM.SQL_REMOVE_LEAVE_FORM"; 
	String SQL_SEARCH_APPROVAL = "LEAVE_FORM.SQL_SEARCH_APPROVAL";
	String SQL_SEARCH_ALLOW_LEAVE_ON_PROBATION = "LEAVE_FORM.SQL_ALLOW_LEAVE_ON_PROBATION";
	
	//update flag
	String SQL_RECHECK_USER_ALLOW_LEVE_ON_PROBATION = "LEAVE_FORM.SQL_RECHECK_USER_ALLOW_LEVE_ON_PROBATION";
			
	//String SQL_SEARCH_LEAVE_ON_SAMEDAY = "LEAVE_FORM.SQL_SEARCH_LEAVE_ON_SAMEDAY";

	
	String SQL_UPDATE_LEAVE_APPROVE = "LEAVE_FORM.SQL_UPDATE_LEAVE_APPROVE";
	String SQL_UPDATE_LEAVE_REJECT = "LEAVE_FORM.SQL_UPDATE_LEAVE_REJECT";
	String SQL_UPDATE_LEAVE_CANCEL= "LEAVE_FORM.SQL_UPDATE_LEAVE_CANCEL";
	
	
	@Override
	public ServiceResult<List<DataBean>> searchLeaveReq(String year,String request_from_me, String request_to_me, String leaveStatus , String leaveType ) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		log.info("getYear: "+year);
		log.info("request_from_me: "+request_from_me);
		log.info("request_to_me: "+request_to_me);
		log.info("leaveStatus: "+leaveStatus);
		log.info("leaveType: "+leaveType);
	
		/*
		if(request_from_me == null){ request_from_me = null;}
		if(request_to_me == null){ request_to_me = null;}
		if(leaveStatus == null){ leaveStatus = null; }
		if(leaveType == null){ leaveType = null;}
		*/
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_LEAVE_REQ,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("year",year)
					,new SimpleKeyValue("request_from_me",request_from_me)
					,new SimpleKeyValue("request_to_me",request_to_me)
					,new SimpleKeyValue("leaveStatus",leaveStatus)
					,new SimpleKeyValue("leaveType",leaveType));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> searchLeaveReqDetail(String leave_id) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_LEAVE_FORM,BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("leave_id",leave_id));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("search leave form :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> findApproval(String user_id) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_APPROVAL,BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("user_id",user_id));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("findApproval :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> findAllowLeaveOnProbation(String user_id) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_ALLOW_LEAVE_ON_PROBATION,BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("user_id",user_id));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("findApproval :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	@Override
	public ServiceResult<DataBean> findLeaveOnSameDay(String user_id, String start_date , String end_date) throws Exception {
	//	ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
	//	List<DealBean> result = null;	
		
		ServiceResult<DataBean> result = null;
		try{
		
			/*
			DealBean dd  = dynamicJdbcDao.findForObject("sp_example1",BeanPropertyRowMapper.newInstance(DealBean.class)
					, new SimpleKeyValue("user_id",user_id) 
					, new SimpleKeyValue("start_date",start_date)
					, new SimpleKeyValue("end_date",end_date));
					*/
			
			//serviceResult.setResult(result);
			//serviceResult.setSuccess(Boolean.TRUE);
			
			//serviceResult = new ServiceResult<List<DataBean>>(result);
			//System.out.println("findApproval :: "+serviceResult.getResult().size());
			 
			
			log.info("call store sp_example1");
			log.info("user_id: "+user_id);
			log.info("start_date: "+start_date);
			log.info("end_date: "+end_date);
			
		
			Map<String,Object> map = dynamicJdbcDao.executeCall("sp_leave_overlap" , new SimpleKeyValue("uid",user_id) 
					, new SimpleKeyValue("v_st",start_date)
					, new SimpleKeyValue("v_et",end_date));
			
			//if sp return 0 is ok else not ok (overlap)
			String check = "";
			Set<String> set = map.keySet();
			for (String key : set) {
				log.info("key = "+map.get(key));
				log.info("size: "+map.size());
			}
			
			for (Object key : map.keySet()) {
			    String lKey = (String) key;
			    log.info("key: "+lKey);
			}

			log.info("check "+map.get("chk")); 	
			DataBean db = new DataBean();
			if(map.containsKey("chk")){
			//new Integer(map.get("chk").toString())
				db.setA(map.get("chk").toString());
				log.info("check is:"+ map.get("chk").toString());
				result = new ServiceResult<DataBean>(db);
			}else{
				log.info("check is not found");
				result = new ServiceResult<DataBean>(db);
				result.setSuccess(false);
			}
	
		}catch(Exception e){
			log.info("Error: "+e);
	
		}
		return result;
	}
	


	@Override
	public ServiceResult<Long> insertLeaveForm( LeaveFormDetailBean leaveForm ) throws Exception {
		
		//trace parameter
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_LEAVE_FORM, Boolean.TRUE, leaveForm );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateLeaveForm(LeaveFormDetailBean leaveForm) throws Exception {
		
		//trace parameter
		/*
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		log.info("Timesheet control eid :"+eid);
		*/
		
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_LEAVE_FORM, leaveForm );
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> updateLeaveApprove(LeaveFormDetailBean leaveForm) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_LEAVE_APPROVE, leaveForm );
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	@Override
	public ServiceResult<Long> updateLeaveReject(LeaveFormDetailBean leaveForm) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_LEAVE_REJECT, leaveForm );
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	@Override
	public ServiceResult<Long> updateLeaveCancel(LeaveFormDetailBean leaveForm) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_LEAVE_CANCEL, leaveForm );
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	
	@Override
	public ServiceResult<Long> removeLeaveForm(String leave_id) throws Exception {
		 
		//trace parameter
		log.info("Timesheet control eid :"+leave_id);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_LEAVE_FORM, new SimpleKeyValue("leave_id",leave_id));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> recheckAllowLeaveOnProbation(LeaveFormDetailBean leaveForm) throws Exception {
		 
		//trace parameter
		log.info("Timesheet control eid :"+leaveForm.getLeave_id());
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_RECHECK_USER_ALLOW_LEVE_ON_PROBATION, new SimpleKeyValue("leave_id",leaveForm.getLeave_id()));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	
	
	
 
}
