package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.services.CodeBookLangService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CodeBookLangServiceImpl extends BaseService implements CodeBookLangService{

	final String SQL_SEARCH = "CODE_BOOK_LANGS.SQL_SEARCH";
	
	@Override
	public ServiceResult<List<Map<String, Object>>> searchCodeBookLangByType(String codeType) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>> ();
		
		try{
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH,new SimpleKeyValue("codeType",StringUtils.isEmpty(codeType)?null:codeType));
			dataNotFound(result);
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}
	
	
	
}
