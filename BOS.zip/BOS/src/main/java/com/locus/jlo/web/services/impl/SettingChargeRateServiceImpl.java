package com.locus.jlo.web.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.scheduler.bean.SchedulerBean;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.department.DepartmentBean;
import com.locus.jlo.web.beans.setting.SettingChargeRateBean;
import com.locus.jlo.web.beans.setting.SettingDeptBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.beans.task.TaskAssigneeBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.SettingChargeRateService;
import com.locus.jlo.web.services.SettingDeptService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class SettingChargeRateServiceImpl extends BaseService implements SettingChargeRateService{
	
	private static final String SQL_SEARCH = "SETTING_CHARGE_RATE.SQL_SEARCH";	
	private static final  String SQL_INSERT = "SETTING_CHARGE_RATE.SQL_INSERT";
	private static final String SQL_DELETE = "SETTING_CHARGE_RATE.SQL_DELETE";

	@Override 
	public ServiceResult<List<SettingChargeRateBean>> searchSettingChargeRate(SettingChargeRateBean criteria) throws Exception {
		ServiceResult<List<SettingChargeRateBean>> serviceResult = new ServiceResult<List<SettingChargeRateBean>>();
		
		try{
			
			List<SettingChargeRateBean> result  = dynamicJdbcDao.findForList(SQL_SEARCH, BeanPropertyRowMapper.newInstance(SettingChargeRateBean.class),criteria); 
			serviceResult = new ServiceResult<List<SettingChargeRateBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<SettingChargeRateBean>>(e);
		}
		return serviceResult;
	}
	
//	@Override
//	public ServiceResult<List<DataBean>> searchSettingDeptDetail(String dept_id) throws Exception {
//		
//	
//		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
//		List<DataBean> result = null;	
//		
//		try{
//			
////			result = dynamicJdbcDao.findForList(SQL_SEARCH_DETAIL,BeanPropertyRowMapper.newInstance(DataBean.class)
////					,new SimpleKeyValue("accountName",""));
//			
//			serviceResult = new ServiceResult<List<DataBean>>(result);
//			System.out.println("Element result :: "+serviceResult.getResult().size());
//			
//		}catch(Exception e){
//			serviceResult = new ServiceResult<List<DataBean>>(e);
//		}
//		return serviceResult;
//	}
	
	@Override
	public ServiceResult<int[]> insertSettingChargeRate(List<SettingChargeRateBean> bean) throws Exception {

		
		final ServiceResult<int[]> result = new ServiceResult<>();
	
		try{
			Map<String, Object>[] arrMap = mappingDataBatchInsertChargeRate(bean);
			
			//final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
			int[] resArr = dynamicJdbcDao.batchInsert(SQL_INSERT, arrMap);
			result.setResult(resArr);
            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
		   log.error(e.getMessage(), e);
           setErrorResult(result, e);
		}
		return result;
	 
	}
	
	
	@Override
	public ServiceResult<Integer> deleteSettingChargeRate(SettingChargeRateBean criteria) throws Exception {

		
		final ServiceResult<Integer> result = new ServiceResult<>();
	
		try{
			
			Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE, criteria);
			result.setResult(res);
            result.setSuccess(Boolean.TRUE);
            
		}catch(Exception e){ 
		   log.error(e.getMessage(), e);
           setErrorResult(result, e);
		}
		return result;
	 
	}
	
	
	private Map<String, Object>[] mappingDataBatchInsertChargeRate(List<SettingChargeRateBean> list) {
		List<Map<String, Object>> txnValueMap = new ArrayList<>();

		for (SettingChargeRateBean bean : list) {
			SettingChargeRateBean scrb = new SettingChargeRateBean();
			scrb.setChargeCode(bean.getChargeCode());
			scrb.setJobGroup(bean.getJobGroup());
			scrb.setJobRank(bean.getJobRank());
			scrb.setFinalCost(bean.getFinalCost());
			scrb.setTotalCost(bean.getTotalCost());
			scrb.setDirectCost(bean.getDirectCost());
			scrb.setSga(bean.getSga());
			scrb.setAnnualYear(bean.getAnnualYear());

			ObjectMapper objectMapper = new ObjectMapper();
			@SuppressWarnings("unchecked")
			Map<String, Object> objectTxnBean = objectMapper.convertValue(scrb, Map.class);
			txnValueMap.add(objectTxnBean);
		}

		@SuppressWarnings("unchecked")
		Map<String, Object>[] arrMap = new HashMap[txnValueMap.size()];
		txnValueMap.toArray(arrMap);
		return arrMap;
	}


}
