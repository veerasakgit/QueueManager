package com.locus.jlo.web.beans.report.hr;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OTReportRes {
	
	private String userId;
	private String employeeId;
	private String employeeName;
	private String position;
	private String divisionId;
	private String divisionName;
	private String departmentId;
	private String departmentName;
	private String sectionId;
	private String sectionName;
	private String employeeType;
	private String ot1Value;
	private String ot15Value;
	private String ot3Value;
	private String otTotal;
	private String totalAllowance;
	private String mobileService;
	private String carAllowance;
	private String taxiFee;
	
}
