package com.locus.jlo.web.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.project.TicketsBean;
import com.locus.jlo.web.services.TicketsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TicketsServiceImpl extends BaseService implements TicketsService {

	private static final String SQL_SEARCH = "TICKETS.SQL_SEARCH";
	
	private static final String SQL_INSERT = "TICKETS.SQL_INSERT";
	private static final String SQL_UPDATE = "TICKETS.SQL_UPDATE";

	@Override
	public ServiceResult<List<Map<String, Object>>> searchTickets(HashMap<String, Object> criteria) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
		
		try {
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH,criteria);
//			dataNotFound(result);
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
		
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
			e.printStackTrace();
		}
		
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> insertTickets(TicketsBean bean) throws Exception {
	
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}

	@Override
	public ServiceResult<Long> updateTickets(TicketsBean bean) throws Exception {
	
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, bean );
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}

}
