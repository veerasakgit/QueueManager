package com.locus.jlo.web.controller;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.project.ProjectMembersBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ProjectMembersService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Slf4j
@Controller
public class ProjectMembersController extends CoreController {
	
	 @Autowired
	 private ProjectMembersService projectMembersService;

	 @GetMapping("projectMembers/roles/{projectId}")
	 public @ResponseBody JsonResultBean searchRoleProjectMembersByProject(@PathVariable String projectId)throws Exception{
		 ServiceResult<List<Map<String, Object>>> listResult =  projectMembersService.searchRoleProjectMembersByProject(projectId);
		 JsonResultBean result = null;
		 if(listResult.isSuccess()){
			 result = new JsonResultBean("success", "" , listResult.getResult());
		 }
		 return result;
	 }

	@RequestMapping(value = "searchProjectMembers", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody JsonResultBean searchProjectMembers(@RequestParam(required = false) String roleId,
															 @RequestParam(required = false) String projectId,
															 HttpServletRequest request, Locale locale) throws Exception{
			ServiceResult<List<Map<String, Object>>> listResult =  projectMembersService.searchProjectMembers(projectId,roleId);
			JsonResultBean result = null;
			if(listResult.isSuccess()){
				result = new JsonResultBean("success", "" , listResult.getResult());
			}
			return result;
	}

	 @PostMapping(value = "/saveProjectMembers")
	 public @ResponseBody JsonResultBean saveProjectMembers(@RequestBody List<ProjectMembersBean> membersBeans, HttpServletRequest request,Locale locale) throws Exception{

			 final int USER_ID = getUid(request);

			 String result_status = "";
			 String result_msg    = "";
			 ServiceResult<List<Long>> result = new ServiceResult<>();

			 try{
                membersBeans.forEach(projectMembersBean -> { projectMembersBean.setCreate_uid(USER_ID);projectMembersBean.setUpdate_uid(USER_ID);});
				result =  projectMembersService.saveProjectMembers(membersBeans);

				if(result.isSuccess()){
					result_status = "success";
					result_msg    = "save successful";
				}else{
                    result_status = "fail";
                    result_msg    = "save fail";
				}

			 }catch(Exception e){
					log.info("Error !!"+e);
					 result_status = "fail";
					 result_msg    = "save fail";
			 }
			 JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult() );
			return res;


		 }
}
