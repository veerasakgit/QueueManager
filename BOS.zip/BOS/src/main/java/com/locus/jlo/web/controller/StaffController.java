package com.locus.jlo.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.StaffService;

import lombok.Getter;
import lombok.Setter;



@Controller

public class StaffController {
	
	 @Autowired
     private StaffService staffService;
	
	 @RequestMapping(value = {"/allstaff"})
	  public String index() {
	        return "allstaff";
	  }
	 
	 @Setter
	 @Getter
	 public class DataTree{
		 String title;
		 String key;
		 boolean folder;
		 String level;
		 List<DataTree>children;	 
		 
	 }
	 
	 @SuppressWarnings("unchecked")
	 @PostMapping("/getTreeData")
	    public @ResponseBody  JsonResultBean getTreeData(HttpServletRequest request, Locale locale) throws Exception {
	    	
	    	JsonResultBean res = null;
	    	Map<String, Object> m = new HashMap<String, Object>();
	    	
	    	String result_status = "success";
			String result_msg    = "success";
			String result_data   = ""; 
	    	
	    	try{
	    		
	    		ServiceResult<List<DataBean>> listResult =  staffService.searchOrganize();
	    		List<DataTree>  organize = new ArrayList<DataTree>();
	            if (listResult.isSuccess()) {
	            	List<DataBean> listOrg = listResult.getResult();
	            	
	            	
					List<DataBean> listDivision = (List<DataBean>) CollectionUtils.select(listOrg, new Predicate() {
						
						@Override
						public boolean evaluate(Object object) {
							DataBean b = (DataBean)object;
							return b.getC().equals("1") || b.getC().equals("0");
						}
					});
	            	
	            	
	            	for (DataBean en: listDivision) {
	            		List<DataTree> lch1 = new ArrayList<DataTree>();
		            	
		            	
	            		DataTree parent = new DataTree();
	            		parent.setTitle(en.getB());
	            		if (en.getC().equals("0")) {
	            			parent.setKey("all");
	            		} else {
	            			parent.setKey(en.getA());
		            		
	            		}
	            		parent.setFolder(true);
	            		String parent_id = en.getA();
	            		if (!en.getC().equals("0")) {
	            			List<DataBean> listDept = (List<DataBean>) CollectionUtils.select(listOrg, new Predicate() {
								
								@Override
								public boolean evaluate(Object object) {
									DataBean b = (DataBean)object;
									return b.getD().equals(parent_id);
								}
							});
		            		
		            		for (DataBean en1 : listDept) {
		            			List<DataTree> lch2 = new ArrayList<DataTree>();
		            			DataTree child1 = new DataTree();
		            			child1.setTitle(en1.getB());
		            			child1.setKey(en1.getA());
		            			child1.setFolder(true);
		            			child1.setLevel("2");
		            			String parent_id1 = en1.getA();
		            			lch1.add(child1);

		            			List<DataBean> listSec = (List<DataBean>) CollectionUtils.select(listOrg, new Predicate() {
									
									@Override
									public boolean evaluate(Object object) {
										DataBean b = (DataBean)object;
										return b.getD().equals(parent_id1);
									}
								});
		            			
		            			for (DataBean en2 : listSec) {
			            			DataTree child2 = new DataTree();
			            			child2.setTitle(en2.getB());
			            			child2.setKey(en2.getA());
			            			child2.setFolder(false);
			            			lch2.add(child2);
			            			
			            		}
		            			child1.setChildren(lch2);
		            		}
		            		parent.setChildren(lch1);
	            		}
	            		
	            		organize.add(parent);
	            	}
	            }


	  			m.put("tree", organize);
	  		
	    		
	    	}catch( Exception e){
	    		
	    		 result_status = "fail";
				 result_msg    = "fail";
				
				res = new JsonResultBean(result_status, result_msg , result_data );
				//log.info("Error !!"+e);
				e.printStackTrace();
	    		
	    	}
	    	
	    	res = new JsonResultBean(result_status, result_msg , m );
			return res;
	      
	       
	    }
	 
    
}