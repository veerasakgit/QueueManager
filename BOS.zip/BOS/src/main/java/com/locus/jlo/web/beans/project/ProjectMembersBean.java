package com.locus.jlo.web.beans.project;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ProjectMembersBean extends StampBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2339923562467923490L;
	private Integer id;
	private Integer project_id;
	private Integer user_id;
	private Integer role_id;
	private Integer manday;
	private String plan;
	
	//UI
	private String action;
	private String role_arr;
	private String id_arr;
}
