package com.locus.jlo.web.beans.account;

import java.io.Serializable;
import java.math.BigInteger;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ContactCommunicationBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String contactCommId;
	private String commType;
	private BigInteger contactId;
	private String email;
	private String mainPhoneCode;
	private String mainPhoneNo;
	private String mobilePhoneCode;
	private String mobilePhoneNo;
	private String partyRowId;
	private String rowId;
}
