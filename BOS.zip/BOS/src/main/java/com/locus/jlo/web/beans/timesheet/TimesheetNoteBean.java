package com.locus.jlo.web.beans.timesheet;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
public class TimesheetNoteBean {

    private String id;
    private String seq;
    private String project_id;
    private String task_id;
    private String user_id;
    private String note_detail;
    private String hour;
    private Date note_date;
    private String create_uid;
    private String create_date;
    private String update_uid;
    private String update_date;
    
}
