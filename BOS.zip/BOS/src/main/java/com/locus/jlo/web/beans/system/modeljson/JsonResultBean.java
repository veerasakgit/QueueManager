package com.locus.jlo.web.beans.system.modeljson;

import java.io.Serializable;

import lombok.Data;

@Data
public class JsonResultBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8905061577893321731L;
	
	public JsonResultBean() {
		
	}
	
	public JsonResultBean(String resStatus, String resMsg, Object data) {
		this.status = resStatus;
		this.msg = resMsg;
		this.data = data;
	}
	
	private String status;
	private String msg;
	private Object data;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
	
}
