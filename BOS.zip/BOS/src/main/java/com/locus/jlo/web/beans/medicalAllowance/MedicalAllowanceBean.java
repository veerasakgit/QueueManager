package com.locus.jlo.web.beans.medicalAllowance;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MedicalAllowanceBean extends StampBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;       //record id
	private Integer user_id;  
	private Date receipt_date;
	private Double receipt_amount;
	private Double allow_claim_amount;
	private Date payment_date;
	private String staff_medical;
	private String staff_dental;
	private String staff_eyes;
	private String family_medical;
	private String family_dental;
	private String family_eyes;
	private String comment;
	private String status;
	private String hospital;
	private String disease;
	private Double staff_medical_amount;
	private Double staff_dental_amount;
	private Double staff_eyes_amount;
	private Double family_medical_amount;
	private Double family_dental_amount;
	private Double family_eyes_amount;
	private String note;
	private Date created_on;
	private Integer created_user_id;
	private Date updated_on;
	private Integer updated_user_id;
	private String result_save_status;
	private String result_save_status_dtl;
	
	//joinByUserId
	private String employee_id;

}
