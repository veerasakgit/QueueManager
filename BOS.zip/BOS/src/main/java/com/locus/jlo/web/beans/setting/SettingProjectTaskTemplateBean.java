package com.locus.jlo.web.beans.setting;

import java.io.Serializable;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SettingProjectTaskTemplateBean extends StampBean implements Serializable{
	private static final long serialVersionUID = 1L;

	private Integer id;
	private String role_id;
	private String type;
	private String template_task_name;	
		
}
