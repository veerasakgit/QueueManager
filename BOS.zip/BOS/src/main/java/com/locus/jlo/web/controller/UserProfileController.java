package com.locus.jlo.web.controller;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.setting.SettingUserProfileBean;
import com.locus.jlo.web.beans.system.dto.LoginDTO;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.SettingUserService;
import com.locus.jlo.web.services.UserManagementService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.activation.MimetypesFileTypeMap;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;


@Slf4j
@Controller
public class UserProfileController extends CoreController {

	@Value("${jlo.profile.path}")
	private String pathUserImage;

	private final static String SERV_PATH = "avatar/";
	@Autowired
	private SettingUserService settingUserService;
	@Autowired
	private UserManagementService userManagementService;

	@RequestMapping(value = "/saveMyProfile", method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchLeaveRequest(@ModelAttribute SettingUserProfileBean settingUserProfileBean,
														@RequestParam(value = "myAvatarUpload", required = false) MultipartFile uploadfile,
														HttpServletRequest request,
														Authentication authentication   ) throws Exception{
	 log.info("Start saveMyProfile");
	 log.info("attrib [{}]",settingUserProfileBean);
	 String result_status = "success";
	 String result_msg = "";
	 String result_data = "";
	 Integer uid = getUid(request);
	 LoginDTO login = (LoginDTO)authentication.getPrincipal();
	 try {
		//todo upload
		String pathAvatar = uploadAvater(uploadfile,uid);
		log.info("URI Avater : {}",pathAvatar);
		settingUserProfileBean.setUid(getUid(request));
		if(!StringUtils.isEmpty(pathAvatar)){
			settingUserProfileBean.setUfilepath(pathAvatar);
		}
		
		settingUserService.saveImportSettingUserProfile(settingUserProfileBean);
		ServiceResult<UserInfoDTO> user =  userManagementService.getUserInfo(login.getLogin());
		request.getSession().setAttribute(BOSConstant.User.USER,user.getResult());

	}catch(Exception e){
		result_status = "fail";
		e.printStackTrace();
	}
	return new JsonResultBean(result_status, result_msg , result_data );

	}

	public String uploadAvater(MultipartFile uploadfile ,Integer empId) throws Exception{
		if(null!=uploadfile){
			String filename = uploadfile.getOriginalFilename();
			String extension = (filename.lastIndexOf(".") != -1 && filename.lastIndexOf(".") != 0)?filename.substring(filename.lastIndexOf(".")+1):"png";
			String avartarfilename = getRandomHexString(30);
			Path directory = Paths.get(pathUserImage +"/"+SERV_PATH+ "/" +empId +"/");

			log.info("OriginalFilename:{}",filename);
			log.info("AvaterFilename:{}",avartarfilename);
			log.info("extension:{}",extension);
			log.info("directory:{}",directory.toString());

			//todo clear old.
			File dir = new File(directory.toString());
			if(dir.exists())FileUtils.cleanDirectory(dir);
			else dir.mkdirs();

			//todo save image.
			byte[] bytes = uploadfile.getBytes();
			Path path = Paths.get(directory.toString(),avartarfilename + "." +extension);
			Files.write(path, bytes);
			log.info("filepath:{}",path.toString());
			return "assets/img/avatar/"+empId +"/"+avartarfilename+"/"+extension;
		}else{
			return null;
		}
	}

	private String getRandomHexString(int numchars){
	Random r = new Random();
	StringBuffer sb = new StringBuffer();
	while(sb.length() < numchars){
		sb.append(Integer.toHexString(r.nextInt()));
	}
	return sb.toString().substring(0, numchars);
	}

	@GetMapping(value = "assets/img/avatar/{empId}/{fileName}/{fileType}")
	public void getImg(
		@PathVariable("empId") String empId,
		@PathVariable("fileName") String fileName,
		@PathVariable("fileType") String fileType,
		HttpServletRequest request,
		HttpServletResponse response) {
	try {
		File f = null;
		if (!StringUtils.isEmpty(empId)&&!StringUtils.isEmpty(fileName)&&!StringUtils.isEmpty(fileType)) {
			f = new File(Paths.get(pathUserImage + File.separator + SERV_PATH + File.separator + empId + File.separator + fileName + "." + fileType).toString());
			if (!(f.exists() && f.isFile())) {
				log.info("Image not exist !!");
				f = new File(request.getServletContext().getRealPath(File.separator) + "/assets/img/default-user.png");
				fileType = "png";
			}
		} else {
			log.info("src not exist !!");
			f = new File(request.getServletContext().getRealPath(File.separator) + "/assets/img/default-user.png");
			fileType = "png";
		}

		response.setContentType(new MimetypesFileTypeMap().getContentType(f));
		BufferedImage bi = ImageIO.read(f);
		OutputStream out = response.getOutputStream();
		ImageIO.write(bi, StringUtils.isEmpty(fileType)?"png":fileType, out);
		out.close();
	} catch (Exception e) {
		log.error(e.getMessage(), e);
	}
}
	 

    
}