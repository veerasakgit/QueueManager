package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.contacts.ContactBean;


public interface ContactService {
		
	public ServiceResult<List<Map<String, Object>>> searchContact() throws Exception;
	public ServiceResult<List<Map<String, Object>>> searchContactDetail(String id,String is_company,String company_id) throws Exception;

	public ServiceResult<Long> insertContact(ContactBean bean) throws Exception;
	public ServiceResult<Long> updateContact(ContactBean bean) throws Exception;
	public ServiceResult<Long> deleteContact(String id) throws Exception;
	
	public ServiceResult<List<Map<String, Object>>> searchIndustries() throws Exception;
}
