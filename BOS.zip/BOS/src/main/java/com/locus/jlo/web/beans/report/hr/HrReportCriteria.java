package com.locus.jlo.web.beans.report.hr;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class HrReportCriteria {

	private String spentFrom;
	private String spentTo;
	private String division;
	private String department;
	private String section;
	private List<String> employeeId;
	private String employeeType;
	private String projectId;
	
}
