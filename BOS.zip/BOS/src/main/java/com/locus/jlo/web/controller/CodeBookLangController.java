package com.locus.jlo.web.controller;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.CodeBookLangService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class CodeBookLangController {
	

	@Autowired
	private CodeBookLangService codeBookLangService;

	 
	@RequestMapping(value = "/searchCodeBookLangByType", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchSettingCalendar(HttpServletRequest request,Locale locale) throws Exception{
		
		String codeType = request.getParameter("codeType");
		
		ServiceResult<List<Map<String, Object>>> listResult =  codeBookLangService.searchCodeBookLangByType(codeType);
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
		return result;
	}
	    
}