package com.locus.jlo.web.services.impl;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.common.mapper.PrimitiveSafeBeanPropertyRowMapper;
import com.locus.jlo.web.beans.paymentTerms.PaymentTermsBean;
import com.locus.jlo.web.beans.project.ProjectBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.PaymentTermsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class PaymentTermsServiceImpl extends BaseService implements PaymentTermsService {
	
	String SQL_SEARCH = "PAYMENT_TERMS.SQL_SEARCH";
	
	String SQL_INSERT = "PAYMENT_TERMS.SQL_INSERT";
	String SQL_UPDATE = "PAYMENT_TERMS.SQL_UPDATE";
	String SQL_DELETE = "PAYMENT_TERMS.SQL_DELETE";

	String SQL_DELETE_BY_DEAL_ID = "PAYMENT_TERMS.SQL_DELETE_BY_DEAL_ID";
	String SQL_DELETE_BY_ID = "PAYMENT_TERMS.SQL_DELETE_BY_ID";
	
	String  SQL_SEARCH_PAYMENT_TERMS_PROJECT_DETAIL_BY_ID = "PROJECT.SQL_SEARCH_PAYMENT_TERMS_PROJECT_DETAIL_BY_ID";

	@Override
	public ServiceResult<List<Map<String, Object>>> searchProjectPayTerm(PaymentTermsBean paymentTermsBean) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
		try{
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH
					, new SimpleKeyValue("deal_id", paymentTermsBean.getDeal_id())
					, new SimpleKeyValue("id", paymentTermsBean.getId()));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Integer> insertProjectPayTerm(PaymentTermsBean paymentTermsBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, paymentTermsBean ).intValue();
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> updateProjectPayTerm(PaymentTermsBean paymentTermsBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, paymentTermsBean);
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> removeProjectPayTerm(Integer payment_id) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",payment_id));
			result.setResult(res);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> removeProjectPayTermByDeal(Integer deal_id) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE_BY_DEAL_ID,new SimpleKeyValue("deal_id",deal_id));
			result.setResult(res);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> savePaymentTerms(List<PaymentTermsBean> beans, Integer USER_ID) throws Exception {
		ServiceResult<Integer> result = new ServiceResult<>();
		result.setResult(0);

		log.info("save :"+ beans.size() +" item");
		for(PaymentTermsBean p : beans){
			String act = p.getAction();

			p.setCreate_uid(USER_ID);
			p.setUpdate_uid(USER_ID);

			if (BOSConstant.DBAction.INSERT.equals(act)) {
				log.info("insert payment terms...");
				insertProjectPayTerm(p);
				result.setResult(result.getResult()+1);
			}else if (BOSConstant.DBAction.UPDATE.equals(act)) {
				log.info("update payment terms...");
				updateProjectPayTerm(p);
				result.setResult(result.getResult()+1);
			} else if (BOSConstant.DBAction.DELETE.equals(act)) {
				log.info("delete payment terms...");
				removeProjectPayTerm(p.getId());
				result.setResult(result.getResult()+1);
			} else {
				log.info("No action");
			}
			result.setSuccess(Boolean.TRUE);
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> removeProjectPayTermById(Integer paymentTermId) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE_BY_ID,new SimpleKeyValue("paymentTermId",paymentTermId));
			result.setResult(res);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}
	
	@Override
	public ServiceResult<ProjectBean> searchPaymentTermsProjectDetail(String dealId) throws Exception {
		ServiceResult<ProjectBean> serviceResult = new ServiceResult<>();
		try{
			ProjectBean result = dynamicJdbcDao.findForObject(SQL_SEARCH_PAYMENT_TERMS_PROJECT_DETAIL_BY_ID
					,PrimitiveSafeBeanPropertyRowMapper.newInstance(ProjectBean.class)
					,new SimpleKeyValue("deal_id",dealId));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}

}
