package com.locus.jlo.web.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.SearchBean;
import com.locus.jlo.web.beans.medicalAllowance.MedicalAllowanceBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.MedicalAllowanceService;
import com.locus.jlo.web.services.SettingUserService;

import lombok.extern.slf4j.Slf4j;



@Slf4j
@Controller
public class MedicalAllowanceController extends CoreController {

	@Autowired
	private MedicalAllowanceService medicalAllowanceService;
	@Autowired
	private SettingUserService settingUserService;
	
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy"); 
	
	@RequestMapping(value = {"/medicalAllowances"})
	  public String index() {
	        return "medicalAllowances";
	}
	
	 //from home>medical allowance
	 @RequestMapping(value = "/searchMedicalAllowance", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchMedicalAllowance(HttpServletRequest request,Locale locale) throws Exception{
		  
		 JsonResultBean result = null;
		 Map<String, Object> m = new HashMap<String, Object>();
		 
		 String result_status = "";
		 String result_msg = "";
	
		 try{
			 
			String year = request.getParameter("year");
			String staffId = request.getParameter("staffId");
			String userId = "";
			if(StringUtils.isEmpty(staffId)){
				userId = request.getSession().getAttribute("UID").toString();
			}else{
				 userId = staffId; 
			}
			
			 ServiceResult<List<DataBean>> staffmedical = new ServiceResult<>();
			 staffmedical = medicalAllowanceService.searchMedicalAllowance(year,userId); 
			 if(staffmedical.isSuccess()){
				 m.put("staffmedical",  staffmedical.getResult());
				 result_status = "success";
				 result_msg = "success";
			 }
			 
			 ServiceResult<List<DataBean>> staffProbation = new ServiceResult<>();
			 staffProbation = medicalAllowanceService.searcStaffProbationCheck(year,userId); 
			 if(staffProbation.isSuccess()){
				 m.put("staffProbation",  staffProbation.getResult());
				 result_status = "success";
				 result_msg = "success";
			 }
			 
			 ServiceResult<List<Map<String, Object>>> listResult =  settingUserService.searchSettingUserDetail(userId); 
			 if(listResult.isSuccess()){
				m.put("userDetail", listResult.getResult());
				result_status = "success";
				result_msg = "success";

			 }
			 
			 
		
		}catch(Exception e){
			log.info("Error !!"+e);
		}
		
		
		result = new JsonResultBean(result_status, result_msg , m);
		return result;
	 }
	 
	
	 @RequestMapping(value = "/searchMedicalAllowanceDetail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchMedicalAllowanceDetail(HttpServletRequest request,Locale locale) throws Exception{
		
		 String id  = request.getParameter("id");
		  
		 log.info("id: "+id);
		 ServiceResult<List<DataBean>> listResult =  medicalAllowanceService.searchMedicalAllowanceDetail(id);
		 JsonResultBean result = null;
		 if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		 }
		 
		return result;
	 }
	
	 @RequestMapping(value = "/saveMedicalAllowance", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveMedicalAllowance(HttpServletRequest request,Locale locale) throws Exception{
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		 
		 String result_status = "";
		 String result_msg = "";
		 String result_data = "";
		 
		 String data = request.getParameter("data");
		 String userId = request.getSession().getAttribute("UID").toString();
		 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
		 
		 log.info( ""+json );
		 log.info(" test "+json.get("receiptDate"));
		 
		 //covert form and bean
		 Double allowClaimAmount = 0d;
		 MedicalAllowanceBean medicalBean = new MedicalAllowanceBean();
		 
		 medicalBean.setUser_id(Integer.parseInt(json.get("medicalUserId").toString()));
		 
		 
		 //covert  format date
		 Date recp_date = DATE_FORMAT.parse(json.get("receiptDate").toString());
		 medicalBean.setReceipt_date(recp_date);
		 
		 Date pay_date = DATE_FORMAT.parse(json.get("paymentDate").toString());
		 medicalBean.setPayment_date(pay_date);
		 
		 medicalBean.setReceipt_amount(Double.parseDouble(json.get("receiptAmount").toString()));
		 
		 medicalBean.setHospital(json.get("hospital").toString());
		 medicalBean.setDisease(json.get("disease").toString());
		 
		 if(json.get("staffMedical") != null){
			 medicalBean.setStaff_medical("1");
			 medicalBean.setStaff_medical_amount(Double.parseDouble(json.get("staffMedicalAmount").toString()));
			 allowClaimAmount = allowClaimAmount + Double.parseDouble(json.get("staffMedicalAmount").toString());
		 }
		 
		 if( json.get("staffDental") != null ){
			 medicalBean.setStaff_dental("1");
			 medicalBean.setStaff_dental_amount(Double.parseDouble(json.get("staffDentalAmount").toString()));
			 allowClaimAmount = allowClaimAmount + Double.parseDouble(json.get("staffDentalAmount").toString());
		 }
		 
		
		 if( json.get("staffEyes") != null ){
			 medicalBean.setStaff_eyes("1");
			 medicalBean.setStaff_eyes_amount(Double.parseDouble(json.get("staffEyesAmount").toString()));
			 allowClaimAmount = allowClaimAmount + Double.parseDouble(json.get("staffEyesAmount").toString());
		 }
		 
		 if( json.get("familyMedical") != null ){
			 medicalBean.setFamily_medical("1");
			 medicalBean.setFamily_medical_amount(Double.parseDouble(json.get("familyMedicalAmount").toString()));
			 allowClaimAmount = allowClaimAmount + Double.parseDouble(json.get("familyMedicalAmount").toString());
		 }
		 
		 if( json.get("familyDental") != null ){
			 medicalBean.setFamily_dental("1");
			 medicalBean.setFamily_dental_amount(Double.parseDouble(json.get("familyDentalAmount").toString()));
			 allowClaimAmount = allowClaimAmount + Double.parseDouble(json.get("familyDentalAmount").toString());
		 }
		 
		 if( json.get("familyEyes") != null ){
			 medicalBean.setFamily_eyes("1");
			 medicalBean.setFamily_eyes_amount(Double.parseDouble(json.get("familyEyesAmount").toString()));
			 allowClaimAmount = allowClaimAmount + Double.parseDouble(json.get("familyEyesAmount").toString());
		 }
		 
		 medicalBean.setAllow_claim_amount(Double.parseDouble(json.get("totalClaimAmount").toString()));
		 medicalBean.setComment(json.get("comment").toString());
		 medicalBean.setStatus("1");
		 
		 
		 try {
				
				if (StringUtils.isEmpty(json.get("medicalId").toString())) {
					log.info("insert");
					
						//set create user
					    medicalBean.setCreate_uid(Integer.parseInt(userId));
					
					 
					 	result =  medicalAllowanceService.insertMedicalAllowance(medicalBean);
						if( result.isSuccess()){
							log.info( "get long : "+result.getResult().longValue() );
							result_data   = Long.toString(result.getResult().longValue());
							result_status = "success";
							result_msg    = "save successful";
			    				
			    		}else{
			    			result_status = "fail";
							result_msg    = "save fail";
			    		}
						
				}else{
					
					log.info("update");
					
					medicalBean.setId(Integer.parseInt(json.get("medicalId").toString()));
					medicalBean.setUpdate_uid(Integer.parseInt(userId));
					
					result =  medicalAllowanceService.updateMedicalAllowance(medicalBean);
					if( result.isSuccess()){
						log.info( "get long : "+result.getResult().longValue() );
						result_data   = Long.toString(result.getResult().longValue());
						result_status = "success";
						result_msg    = "save successful";
		    				
		    		}else{
		    			result_status = "fail";
						result_msg    = "save fail";
		    		}
					
				}
					
					
		 }catch (Exception e) {
				log.error("Error !!"+e);
				
				result_status = "fail";
				result_msg    = "save fail";
		 }
			 
		 JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		 return res;	
		 
	 }
	 

	 
	 @RequestMapping(value = "/saveMedicalAllowanceMAxxx", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveMedicalAllowanceMAxxx(HttpServletRequest request,Locale locale) throws Exception{
		
		 Integer USER_ID = getUid(request);
		 String data = request.getParameter("data");
		 String id = request.getParameter("viewId");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		 		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
		 
		 log.info( ""+json );
		 
		 JsonBeanUtils<MedicalAllowanceBean> utils = new JsonBeanUtils<MedicalAllowanceBean>(MedicalAllowanceBean.class);
		 
		 //convert between form and bean
		 MedicalAllowanceBean beanData = utils.convertFormAndBeanWithUser(json, USER_ID);
 
		 try {
			
			if (StringUtils.isEmpty(id)) {
				log.info("insert data");
				result =  medicalAllowanceService.insertMedicalAllowance(beanData);
				if( result.isSuccess()){
					log.info( "get long : "+result.getResult().longValue() );
					result_data   = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg    = "save successful";
	    				
	    		}else{
	    			result_status = "fail";
					result_msg    = "save fail";
	    		}
				
			}else {
				
				log.info("update data");
				beanData.setId(Integer.parseInt(id));
				
				result =  medicalAllowanceService.updateMedicalAllowance(beanData);
				if( result.isSuccess()){
					log.info( "get long : "+result.getResult().longValue() );
					result_data   = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg    = "save successful";
	    				
	    		}else{
	    			result_status = "fail";
					result_msg    = "save fail";
	    		}
				
			}
			 
		 } catch (Exception e) {
			log.error("Error !!"+e);
		 }
		 
		 JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		 return res;	 
	 }
	   
	 @RequestMapping(value = "/importMedical", method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean importMedical(HttpServletRequest request,Locale locale) throws Exception{
		
		Part part = request.getPart("medicalFile");
		
		List<Object[]> list = PoiUtils.importExcelFileArr(part.getInputStream(), 1 ,13);
		JsonResultBean result = new JsonResultBean("success", "", list);

		return result;
	}
	 
	 //not used
	 @RequestMapping(value = "/saveImportMedicalAllowance", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveImportMedicalAllowance(HttpServletRequest request,Locale locale) throws Exception{

		final Integer USER_ID = getUid(request);
		String data = request.getParameter("data");

		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(data);
		 
		log.info( ""+json );

		JsonBeanUtils<MedicalAllowanceBean> utils = new JsonBeanUtils<MedicalAllowanceBean>(MedicalAllowanceBean.class);
		
		MedicalAllowanceBean bean = utils.convertFormAndBeanWithUser(json, USER_ID);
		
		utils.print(bean);

		ServiceResult<Integer> result =  medicalAllowanceService.saveImportMedicalAllowance(bean);
		
		String result_status = "";
		String result_msg    = "";

		
		if( result.isSuccess()){
			log.info( "get long : "+result.getResult());
			result_status = "success";
			result_msg    = "save successful";
				
		}else{
			result_status = "fail";
			result_msg    = "save fail";
		}
		
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult());

		return res;
	}
	 
	@RequestMapping(value = "/deleteMedical", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean deleteMedical(HttpServletRequest request,Locale locale) throws Exception{
			
			String id  = request.getParameter("id");
			log.info("id: "+id);
			ServiceResult<Long> idResult =  medicalAllowanceService.deleteMedical(id);
			JsonResultBean result = null;
			if(idResult.isSuccess()){
				result = new JsonResultBean("success", "" , idResult.getResult());
			}
			return result;
	 }

}