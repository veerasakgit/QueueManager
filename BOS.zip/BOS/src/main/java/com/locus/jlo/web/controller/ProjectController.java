package com.locus.jlo.web.controller;

import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.IdentifyKeyBean;
import com.locus.jlo.web.beans.project.ProjectBean;
import com.locus.jlo.web.beans.project.ProjectMembersBean;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.report.staff.StaffReportCriteria;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.IdentifyKeyService;
import com.locus.jlo.web.services.ProjectService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
public class ProjectController extends CoreController {

    @Autowired
    private ProjectService projectService;

    @Autowired
    private IdentifyKeyService identifyKeyService;

    @RequestMapping(value = {"/project"})
    public String index() {
        return "project";
    }

    @RequestMapping(value = {"/project_new"})
    public String new_project() {
        return "project_new";
    }
    
    ServiceResult<List<DataBean>> listResult;


    @RequestMapping(value = "/searchProject", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
    public @ResponseBody  JsonResultBean searchProject(HttpServletRequest request, Locale locale) throws Exception {

    	
//    	String filter_type = request.getParameter("filter_type");
//		String keyword = request.getParameter("keyword");
		String filterArr = request.getParameter("filterArr");
		
		JSONParser jParser = new JSONParser();
		Object obj = jParser.parse(filterArr);
		 
		JSONArray jArray = (JSONArray)obj;
		System.out.println(jArray);
	
		
		String filter_my_project = null;
		String filter_project_type  = null;
		String filter_project_status  = null;
		String filter_active_project = null;
		
		
		UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
	 	String userId  = uinfo.getUid();
	 	
	 	for (int i = 0 ;i < jArray.size() ; i++) {
			JSONObject jObject = (JSONObject)jArray.get(i);
			String filter_type = (String)jObject.get("filter_type");
			String keyword = (String)jObject.get("keyword");
			if (filter_type.equals("filter_my_project")) {
				
				if( keyword.equals("my-project")){
					filter_my_project = userId;
					filter_active_project = "Y";
				}else{
					//all
					filter_my_project = null;
					filter_active_project = "Y";	
				}

				
			}
			
			if (filter_type.equals("filter_project_type")) {
				
				if( keyword.equals("all")){
					filter_project_type = null;
					filter_active_project = "Y";
				}else{
					filter_project_type = keyword;
					filter_active_project = "Y";
				}
				
			}
			
			if (filter_type.equals("filter_project_status")) {
				
				log.info("filter status ");
				if( keyword.equals("all")){
					filter_project_status = null;
					filter_active_project = null;
					log.info("filter status all");
				} else if (keyword.equals("active")) {
					filter_project_status = null;
					filter_active_project = "Y";
					log.info("filter active project ");
				} else {
					filter_project_status = keyword;
					filter_active_project = null;
					log.info("filter status : "+filter_project_status);
				}
				
			}
		}
		
	 	
	 	
		log.info("filter_my_project : "+filter_my_project);
		log.info("filter_project_type : "+filter_project_type);
		log.info("filter_project_status : "+filter_project_status);
		
	
	 	
//		if(!StringUtils.isEmpty(filter_type) && filter_type.equals("filter_my_project")){
//			if( keyword.equals("my-project")){
//				filter_my_project = userId;
//				filter_active_project = "Y";
//			}else{
//				//all
//				filter_my_project = null;
//				filter_active_project = "Y";
//				//set fillter all project = null if want to search with all project else
//				
//			}
//		}
//		if(!StringUtils.isEmpty(filter_type) && filter_type.equals("filter_project_type")){
//			if( keyword.equals("all")){
//				filter_project_type = null;
//			}else{
//				filter_project_type = keyword;
//			}
//			
//		}  
//		
//		if(!StringUtils.isEmpty(filter_type) && filter_type.equals("filter_project_status")){
//			log.info("filter status ");
//			if( keyword.equals("all")){
//				filter_project_status = null;
//				filter_active_project = null;
//				log.info("filter status all");
//			} else if (keyword.equals("active")) {
//				filter_project_status = null;
//				filter_active_project = "Y";
//				log.info("filter active project ");
//			} else {
//				filter_project_status = keyword;
//				filter_active_project = null;
//				log.info("filter status : "+filter_project_status);
//			}
//		}
		
    	listResult =  projectService.searchProject(filter_my_project,filter_project_type,filter_project_status , filter_active_project);
        JsonResultBean result = null;
        if (listResult.isSuccess()) {
            result = new JsonResultBean("success", "", listResult.getResult());
        }
        return result;
    }

    @RequestMapping(value = "/projectDetail", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.GET)
    public @ResponseBody
    ModelAndView searchProjectDetail(HttpServletRequest request, Locale locale) throws Exception {

        String id = request.getParameter("id");
        log.info("id: " + id);
        return new ModelAndView("projectDetail", "projectId", id);
    }

    @RequestMapping(value = "/searchProjectDetailById/{id}", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.GET)
    public @ResponseBody
    JsonResultBean searchProjectDetailById(@PathVariable("id") String id, HttpServletRequest request, Locale locale) throws Exception {
        log.info("id: " + id);
        ServiceResult<ProjectBean> resultObj = projectService.searchProjectDetail(id);
        JsonResultBean result = null;
        if (resultObj.isSuccess()) {
            result = new JsonResultBean("success", "", resultObj.getResult());
        }
        return result;
    }

    //update project
    @RequestMapping(value = "/saveProjectDetail", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
    public @ResponseBody
    JsonResultBean saveProjectDetail(HttpServletRequest request, Locale locale) throws Exception {

        final Integer USER_ID = getUid(request);
        String data = request.getParameter("data");
        String act = request.getParameter("action");

        ServiceResult<Long> result = new ServiceResult<>();

        String result_status = "";
        String result_msg = "";
        String result_data = "";

        JSONParser jParser = new JSONParser();
        JSONObject json = (JSONObject) jParser.parse(data);

        //convert between form and bean
        JsonBeanUtils<ProjectBean> utils = new JsonBeanUtils<>(ProjectBean.class);
        ProjectBean bean = utils.convertFormAndBeanWithUser(json, USER_ID);

        utils.print(bean);

        bean.setUpdate_uid(USER_ID);
        bean.setPlan_start_date(parseStrToDate(json.get("plan_start_date").toString()));
        bean.setPlan_end_date(parseStrToDate(json.get("plan_end_date").toString()));
        bean.setKick_off_date(parseStrToDate(json.get("kick_off_date").toString()));
        bean.setActual_start_date(parseStrToDate(json.get("actual_start_date").toString()));
        bean.setActual_end_date(parseStrToDate(json.get("actual_end_date").toString()));

        if (BOSConstant.DBAction.INSERT.equals(act)) {
        	log.info("insert identifyKey");
            ServiceResult<Integer> identifyKey = identifyKeyService.insertIdentifyKey("P", bean.getProject_name().trim(), bean.getProject_name().trim(),  USER_ID);
            bean.setId(identifyKey.getResult());

            log.info("insert data");
            
            utils.print(bean);
             
            result = projectService.insertNewProject(bean);
            if (result.isSuccess()) {
                log.info("get long : " + result.getResult().longValue());
                result_data = Integer.toString(bean.getId());
                result_status = "success";
                result_msg = "save successful";
            } else {
                result_status = "fail";
                result_msg = "save fail";
            }
        
        } else if (BOSConstant.DBAction.UPDATE.equals(act)) {
            log.info("update project detail...");
            result = projectService.updateProject(bean);
            if (result.isSuccess()) {
                log.info("get long : " + result.getResult().longValue());
                result_data = Integer.toString(bean.getId());
                result_status = "success";
                result_msg = "save successful";
            } else {
                result_status = "fail";
                result_msg = "save fail";
            }
            
            //castcase update to t_identify_key
            IdentifyKeyBean identifyKeyBean = new IdentifyKeyBean();
            identifyKeyBean.setType_PD("P");
            identifyKeyBean.setUnique_name(bean.getProject_name().trim());
            identifyKeyBean.setCreate_uid(USER_ID);
            identifyKeyBean.setName(bean.getProject_name().trim());
            identifyKeyBean.setId(bean.getId());
            identifyKeyBean.setStatus(bean.getProject_status().toString());
           
            log.info("try to update identifyKey");
            ServiceResult<Integer> identifyKey = identifyKeyService.updateIdentifyKeyBean(identifyKeyBean);
            if(identifyKey.isSuccess()){
            	 log.info("update identifyKey success");
            }
            

        } else if (BOSConstant.DBAction.DELETE.equals(act)) {
            log.info("update project detail...");

        } else {
            log.info("No action");
        }
        JsonResultBean res = new JsonResultBean(result_status, result_msg, result_data);
        return res;
    }

    //insert project
    @RequestMapping(value = "/saveProject", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
    public @ResponseBody
    JsonResultBean saveProject(HttpServletRequest request, Locale locale) throws Exception {

        final Integer USER_ID = getUid(request);
        String data = request.getParameter("data");
        String act = request.getParameter("action");

        ServiceResult<Long> result = new ServiceResult<>();

        String result_status = "";
        String result_msg = "";
        String result_data = "";

        JSONParser jParser = new JSONParser();
        JSONObject json = (JSONObject) jParser.parse(data);

        //convert between form and bean
        JsonBeanUtils<ProjectBean> utils = new JsonBeanUtils<>(ProjectBean.class);
        ProjectBean bean = utils.convertFormAndBeanWithUser(json, USER_ID);

        utils.print(bean);

        //subData
        String subData = request.getParameter("subData");
        List<ProjectMembersBean> subBeans = new ArrayList<>();

        if (!StringUtils.isEmpty(subData) && !(subData.equals("{}"))) {

            JSONObject subJson = (JSONObject) jParser.parse(subData);
            JsonBeanUtils<ProjectMembersBean> subUtils = new JsonBeanUtils<>(ProjectMembersBean.class);
            List<ProjectMembersBean> rawBeans = subUtils.convertFormAndBean(subJson, "userId", USER_ID);

            rawBeans.forEach((raw) -> {

                String[] roleArr = raw.getRole_arr().split(",");
                String[] idArr = null;

                //findSize Array
                int size = roleArr.length;
                if (!StringUtils.isEmpty(raw.getId_arr())) {
                    idArr = raw.getId_arr().split(",");
                    if (idArr.length > roleArr.length) {
                        size = idArr.length;
                    }
                }

                for (int i = 0; i < size; i++) {

                    ProjectMembersBean subBean = new ProjectMembersBean();
                    BeanUtils.copyProperties(raw, subBean);

                    switch (subBean.getAction()) {
                        case BOSConstant.DBAction.INSERT:
                            subBean.setRole_id(Integer.parseInt(roleArr[i]));
                            subBeans.add(subBean);
                            break;
                        default:
                            break;
                    }
                }
            });
            subUtils.testPrint(subBeans);
        }

        try {

            switch (act) {
                case "I":
                    log.info("insert identifyKey");
                    ServiceResult<Integer> identifyKey = identifyKeyService.insertIdentifyKey("P", bean.getProject_name().trim(), bean.getProject_name().trim(),  USER_ID);
                    bean.setId(identifyKey.getResult());

                    log.info("insert data");
                    
                    utils.print(bean);
                     
                    result = projectService.insertNewProject(bean);
                    
                   // result = projectService.insertProject(bean, subBeans);

                    if (result.isSuccess()) {
                        log.info("get long : " + result.getResult().longValue());
                        result_data = Long.toString(result.getResult().longValue());
                        result_status = "success";
                        result_msg = "save successful";

                    } else {
                        result_status = "fail";
                        result_msg = "save fail";
                    }
                    break;
                default:
                    log.error("No action");

            }
        } catch (Exception e) {
            log.info("Error !!" + e);
        }

        JsonResultBean res = new JsonResultBean(result_status, result_msg, result_data);
        return res;
    }
    
    
    @RequestMapping(value = "/exportRes", method = RequestMethod.POST)
	public @ResponseBody void exportHrTimeSheetReport(HttpServletRequest request, HttpServletResponse response, StaffReportCriteria cr) throws Exception {

		OutputStream outputStream = null;
		ByteArrayOutputStream outByteStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();
      
		try {
			
			int rowCount = 0;
			int columnCount = 0;
          	List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
          	DecimalFormat df = new DecimalFormat("#,##0.00");
          	//create Header styles
          	XSSFCellStyle cellStyleHeader = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
			
			//create Cells styles
			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
            
			//create header
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Seq", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Value", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Customer Company", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Status", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Start Date", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "End Date", cellStyleHeader));

			
			//create row data

			for (DataBean rec : listResult.getResult()) {
				rowCount++;
				columnCount = 0;
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rowCount, cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getB(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, df.format(Double.parseDouble(ObjectBeanUtils.nvl(rec.getG(),"0"))) ,cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getF(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getH(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getC(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getD(), cellStyleCenter));

				
			}
            
			PoiUtils.createSheet(wb, "Project", lstExObj, null, false);

			log.info("start export...");
			outByteStream = new ByteArrayOutputStream();
            wb.write(outByteStream);
            byte[] outArray = outByteStream.toByteArray();
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setContentLength(outArray.length);
            response.setHeader("Content-Disposition", "attachment; filename=\"Project.xlsx\"");
            outputStream = response.getOutputStream();
            outputStream.write(outArray);
            log.info("end export");
            
          
      } catch (Exception e) {
          e.printStackTrace();
      } finally {
      	outputStream.flush();
      	outputStream.close();
      	outByteStream.close();
      	wb.close();
      }
      
	}

	 
	@RequestMapping(value = "/searchProjectActive", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchProjectActive(HttpServletRequest request,Locale locale) throws Exception{
		String filter_active_project  = request.getParameter("filter_active_project");
		listResult =  projectService.searchProject(null, null, null , filter_active_project);
		JsonResultBean result = null;
		if (listResult.isSuccess()) {
			result = new JsonResultBean("success", "", listResult.getResult());
	    }
		return result;
	}

}