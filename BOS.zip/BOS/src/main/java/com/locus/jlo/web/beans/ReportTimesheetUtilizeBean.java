package com.locus.jlo.web.beans;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReportTimesheetUtilizeBean  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7590883002468348017L;
	
	private String test;
	
}
