package com.locus.jlo.web.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.product.ProductBean;
import com.locus.jlo.web.beans.project.TicketsBean;
import com.locus.jlo.web.services.ProductService;
import com.locus.jlo.web.services.TicketsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProductServiceImpl extends BaseService implements ProductService {

	private static final String SQL_SEARCH = "PRODUCT.SQL_SEARCH";
	
	private static final String SQL_INSERT = "PRODUCT.SQL_INSERT";
	private static final String SQL_UPDATE = "PRODUCT.SQL_UPDATE";
	private static final String SQL_DELETE = "PRODUCT.SQL_DELETE";
	
	@Override
	public ServiceResult<List<Map<String, Object>>> searchProduct(HashMap<String, Object> criteria) throws Exception {

		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
		
		try {
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH,criteria);
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		
		return serviceResult;
	
	}

	@Override
	public ServiceResult<Long> insertProduct(ProductBean bean) throws Exception {
	
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}

	@Override
	public ServiceResult<Long> updateProduct(ProductBean bean) throws Exception {
	
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, bean );
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}

	@Override
	public ServiceResult<Long> deleteProduct(String id) throws Exception {
	
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer resId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id) );
				result.setResult(Long.valueOf(resId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}




}
