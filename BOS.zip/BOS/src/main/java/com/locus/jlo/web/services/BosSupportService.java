package com.locus.jlo.web.services;

import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.BosServiceReqBean.BosServiceReqBean;

public interface BosSupportService {
	 
	ServiceResult<List<DataBean>> qrySupportSR() throws Exception;
	ServiceResult<List<DataBean>> qrySupportSRDetail(String id) throws Exception;
	
	ServiceResult<Long> insertSupportSR(BosServiceReqBean bosSRBean) throws Exception;
	ServiceResult<Long> updateSupportSR(BosServiceReqBean bosSRBean) throws Exception;
	ServiceResult<Long> removeSupportSR(String id) throws Exception;

}
