package com.locus.jlo.web.beans.report.leave;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LeaveReportWithFillterRes {
	private String userId;
	private String empId;
	private String fullName;
	private String empType;
	private String employmentDate;
	private String probationDate;
	private String previousYearBal;
	private String resignDate;
	private String resignFlag;
	private String carryPrevious;
	private String newEntitle;
	private String additionalDay;
	private String additionalDate;
	private String annualTotal;
	
	private String usedLeave;
	private String balance;
	
	private String usedJan;
	private String usedFeb;
	private String usedMar;
	private String usedApr;
	private String usedMay;
	private String usedJun;
	private String usedJul;
	private String usedAug;
	private String usedSep;
	private String usedOct;
	private String usedNov;
	private String usedDec;
	
	


}
