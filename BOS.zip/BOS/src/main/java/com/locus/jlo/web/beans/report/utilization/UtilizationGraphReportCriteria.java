package com.locus.jlo.web.beans.report.utilization;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UtilizationGraphReportCriteria {

	private List<String> employeeName;
	private String yearSpentOn;
	private String monthSpentOn;
	private List<String> employeeNameTe;
	private String yearOt;
	private String monthOt;
	private List<String> employeeNameOt;
	private String utilizeYear;
	private String utilizeMonth;
	private String division;
	private String department;
	private String section;
	
}
