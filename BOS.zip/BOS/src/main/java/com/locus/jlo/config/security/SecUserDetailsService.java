package com.locus.jlo.config.security;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.system.dto.LoginDTO;
import com.locus.jlo.web.beans.system.dto.UserAuthenDTO;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.services.SettingPrivilegesService;
import com.locus.jlo.web.services.UserManagementService;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.jar.Attributes;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Slf4j
@Service()
public class SecUserDetailsService
        extends AbstractUserDetailsAuthenticationProvider
        implements UserDetailsService {
	
	//@Value("#{jlo.profile.path}")
	//private String defaultServerProfilePath;
	
    @Autowired
    private MessageSource messageSource;

    @Autowired
    private UserManagementService userManagementService;

	@Autowired
	private SettingPrivilegesService settingPrivilegesService;
    //private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    LoginDTO userInfo;
    
    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {

    }

    @Override
    protected UserDetails retrieveUser(String userId, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
    	logger.info("SecUserDetailsService - retrieveUser : ");
    	logger.info("************************************************************");
    	logger.info("Login : "+userId);
    	
    	//if found @locus.co.th remove it
		userId = userId.replace("@locus.co.th","");
			
    	try{
    		 
    		final UserDetails loadedUser;
    		 ServiceResult<UserAuthenDTO> loginServiceResult = userManagementService.getAuthentication(userId);
    		 
    		 if(loginServiceResult.isSuccess()){
    			 	 logger.info("login service : "+loginServiceResult.getResult().getAuthenMode());
    				//check authentication mode
		 	    		//1 is local storage 
		 	    		//2 is LDAP
		 	    		if( loginServiceResult.getResult().getAuthenMode().equals("1")){
		 	    			//Local
		 	    			logger.info("User login mode 1 : Local Storage");
		 	    			logger.info("Local Storage Authentication");
		 		          //  logger.info("authentication.getCredentials() : "+authentication.getCredentials().toString());
		 		          //  logger.info("authentication.getPassword() : "+userInfo.getPassword());
		 	    			
		 		             //check authentication
		 		             if(!loginServiceResult.getResult().getPassword().equalsIgnoreCase(authentication.getCredentials().toString())){
		 		             	throw new AuthenticationServiceException(messageSource.getMessage("LOGIN_0902", new Object[]{userId}, Locale.getDefault()));
		 		             }
		 		             
		 		             logger.info("Authentication pass with [success]");
		 		            //get user information
		 		    		 loadedUser  = this.loadUserByUsername(userId);
		 		    	
		 		       
		 	    		}else
		 	    		if( loginServiceResult.getResult().getAuthenMode().equals("2")){
		 	    			//LDAP
		 	    			logger.info("User login mode 2 : LDAP Authentication");
		 	    			logger.info("authentication.getCredentials() : "+userId+"@locus.co.th");
		 	   	            //logger.info("authentication.getPassword() : "+authentication.getCredentials().toString());
		 	   	            
		 	   	            //LDAP
		 	   	            final String ldapServer = "ldap://192.168.200.101:389";
		 		   	 		final String ldapUser = userId; 
		 		   			final String ldapPasswd = authentication.getCredentials().toString();
		 		   			final String ldapDomain = "@locus.co.th";
		 		   			 
		 		   			Hashtable<String, Object> env = new Hashtable<String, Object>();
		 		   			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		 		   			env.put("java.naming.ldap.attributes.binary", "objectSID");
		 		   		    env.put(Context.PROVIDER_URL, ldapServer);
		 		   		    env.put(Context.SECURITY_AUTHENTICATION, "simple");
		 		   			 
		 		   		    //check user or password must not empty
		 		   		    logger.info("LDAP Authentication Start");
		 		   		    if (StringUtils.isEmpty(ldapUser)||StringUtils.isEmpty(ldapPasswd)) {
		 		   		    	throw new AuthenticationServiceException(messageSource.getMessage("LOGIN_0910", new Object[]{userId}, Locale.getDefault()));
							}else {
		  		   	            env.put(Context.SECURITY_PRINCIPAL, ldapUser + ldapDomain);
		  		   	            env.put(Context.SECURITY_CREDENTIALS, ldapPasswd);
							}
		 		   		  
		 		   			try {
		 		   				DirContext ctx = new InitialDirContext(env);
		 		   				ctx.close();
		 		   				
		 		   			}catch(NamingException e){
		 		   				
		 		   			    throw new AuthenticationServiceException(getAuthenticatedExceptionDetail(e.getExplanation()));
		 		   			   
		 		   				
		 		   			}catch(Exception e){
			 		   			e.printStackTrace();
		 		   				logger.info("LDAP Authentication Fail :"+e);
		 		   				//if can't connect or anything else throw error
		 		   				throw new AuthenticationServiceException(messageSource.getMessage("LOGIN_0902", new Object[]{userId}, Locale.getDefault()));
		 		   			}
		 	   	          
		 		   			logger.info("LDAP Authentication Success");
		 		   			//get user information 
		 		    		loadedUser  = this.loadUserByUsername(userId); 
		 		    		 
		 	    		}else{
		 	    			
		 	    			logger.info("Error: No authentication mode found");
		 	    			throw new AuthenticationServiceException(messageSource.getMessage("LOGIN_0902", new Object[]{userId}, Locale.getDefault()));
		 	    		}
 	    	
    		 }else{
    				throw new AuthenticationServiceException(messageSource.getMessage("LOGIN_0913", new Object[]{userId}, Locale.getDefault()));
    		 }
    	   
            return loadedUser;
            
        } catch (UsernameNotFoundException e) {
        	logger.info("Error : "+e);
            throw e;
            
        } catch (Exception e) {
        	logger.info("Error : "+e);
        	e.printStackTrace();
            throw new AuthenticationServiceException(e.getMessage(), e);
           
        }
    }
    
    @Override
    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException{
   
        //TODO implements load role
        final List<GrantedAuthority> auth = new ArrayList<>();
        auth.add((GrantedAuthority) new SimpleGrantedAuthority("ROLE_USER"));
        
        ServiceResult<LoginDTO> userServiceResult = userManagementService.getLoginInfo(userId);
        if (userServiceResult.isSuccess()) {
            userInfo = userServiceResult.getResult();
            userInfo.setUserId(userId);
            userInfo.setAuthorityInfo(auth);
            userInfo.setAuthenMode(userServiceResult.getResult().getAuthenMode());
			try {
				log.info("check is admin : "+userInfo.getUserInfo().getIsAdminYN());
				if(userInfo.getUserInfo().getIsAdminYN().equals("Y")){
					userInfo.setMenuInfo(settingPrivilegesService.searchMenuByAdminRole().getResult());
				}else{ 
					//int deptId = Integer.parseInt(userInfo.getUserInfo().getDeptId());
					 Integer uid = Integer.parseInt(userInfo.getUserInfo().getUid());
					 
					
					//get user menu
					userInfo.setMenuInfo(settingPrivilegesService.searchMenuByUserPermission(uid).getResult());
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
            throw new AuthenticationServiceException(messageSource.getMessage("LOGIN_0913", new Object[]{userId}, Locale.getDefault()));
        }
        
        log.info("info : "+userInfo.toString());
        return userInfo;
    }
    
    
     private String getAuthenticatedExceptionDetail(String errorCode){
    	  
    	  if(errorCode.indexOf("data 525")!=-1){
	    	   return "The specified account does not exist.";
	    	  }else if(errorCode.indexOf("data 52e")!=-1){
	    	   return "Unknown user name or bad password.";
	    	  }else if(errorCode.indexOf("data 530")!=-1){
	    	   return "Account logon time restriction violation.";
	    	  }else if(errorCode.indexOf("data 531")!=-1){
	    	   return "User not allowed to log on to this system.";
	    	  }else if(errorCode.indexOf("data 532")!=-1){
	    	   return "Password expired.";
	    	  }else if(errorCode.indexOf("data 533")!=-1){
	    	   return "Account currently disabled.";
	    	  }else if(errorCode.indexOf("data 701")!=-1){
	    	   return "Account expired.";
	    	  }else if(errorCode.indexOf("data 773")!=-1){
	    	   return "User must reset password.";
	    	  }else if(errorCode.indexOf("data 775")!=-1){
	    	   return "Account locked out.";
	    	  }else{
	    	   return "Unexpected error from active directory : "+errorCode;
	    	  }
    	 }
   

}
