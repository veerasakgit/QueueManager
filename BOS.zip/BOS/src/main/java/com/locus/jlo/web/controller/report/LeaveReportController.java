package com.locus.jlo.web.controller.report;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.report.leave.LeaveReportCriteria;
import com.locus.jlo.web.beans.report.leave.LeaveReportRes;
import com.locus.jlo.web.beans.report.leave.LeaveReportWithFillterRes;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
public class LeaveReportController {
	
	@Autowired
	private ExcelReportService excelReportService;
	
		
	@RequestMapping(value = "/searchLeaveReport", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchLeaveReport(HttpServletRequest request,Locale locale) throws Exception{

		String cri = request.getParameter("cri");	
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(cri);
		
		JsonResultBean validResult = validateCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		LeaveReportCriteria leaveReportCriteria = getCriteria(json);
		 Map<String, Object> m = new HashMap<String, Object>();
		 m.put("curYear", leaveReportCriteria.getYear());
		 m.put("prvYear", Integer.parseInt(leaveReportCriteria.getYear()) - 1);
		 
		 JsonResultBean result = null;
		 if (!StringUtils.isEmpty(leaveReportCriteria.getLeaveType())) {
			 ServiceResult<List<LeaveReportWithFillterRes>> listResult = excelReportService.searchLeaveReportFillter(leaveReportCriteria); 
			 
			 if (listResult.isSuccess()) {
				 m.put("result", listResult.getResult());
				 result = new JsonResultBean("success", "" , m);
				 log.info("successRespones : "+result.toString());
				 log.info(" total : " + listResult.getResult().size());
			 } else {
				 log.info("fail_Respones : ");
			 }
		 } else {
			 ServiceResult<List<LeaveReportRes>> listResult = excelReportService.searchLeaveReport(leaveReportCriteria);
			 
			 if (listResult.isSuccess()) {
				 m.put("result", listResult.getResult());
				 result = new JsonResultBean("success", "" , m);
				 log.info("successRespones : "+result.toString());
				 log.info(" total : " + listResult.getResult().size());
			 } else {
				 log.info("fail_Respones : ");
			 }
		 }
		 
		 return result;
	
	}
	 
    @RequestMapping(value = "/validateCriteria", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateCriteria(HttpServletRequest request,Locale locale) throws Exception{
    	String cri = request.getParameter("cri");
    	JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(cri);
		return validateCriteria(json);
    }
    
    @SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportLeaveReport", method = RequestMethod.POST)
	public @ResponseBody void exportLeaveReport(HttpServletRequest request, HttpServletResponse response, LeaveReportCriteria cr) throws Exception {

		OutputStream outputStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();
      
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("startDate", cr.getStartDate());
			jsonObj.put("endDate", cr.getEndDate());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());
			jsonObj.put("employeeName", cr.getEmployeeName());
			jsonObj.put("employeeType", cr.getEmployeeType());
			jsonObj.put("leaveType", cr.getLeaveType());

			boolean isFillter = false;
			LeaveReportCriteria leaveReportCriteria  = getCriteria(jsonObj);
			String reportFrom = cr.getStartDate() + " - " + cr.getEndDate();
			String year = leaveReportCriteria.getYear();

			ServiceResult<List<LeaveReportWithFillterRes>> listFillterResult = null;
			ServiceResult<List<LeaveReportRes>> listResult = null;
			if (!StringUtils.isEmpty(leaveReportCriteria.getLeaveType())) {
				listFillterResult = excelReportService.searchLeaveReportFillter(leaveReportCriteria); 
				isFillter = true;
			} else {
				listResult = excelReportService.searchLeaveReport(leaveReportCriteria); 
			}
		
			// end search
			
			int rowCount = 0;
			int columnCount = 0;
          	List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
          	List<Integer[]> mergeList = new ArrayList<Integer[]>();
          	
			XSSFCellStyle cellStyleR1 = PoiUtils.creatCellStyle(wb, "Angsana New", true, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleG1 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
	        XSSFCellStyle cellStyleG2 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.ORANGE.index);
			XSSFCellStyle cellStyleG3 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.RED.index);
			XSSFCellStyle cellStyleG4 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.DARK_YELLOW.index);
			XSSFCellStyle cellStyleG5 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.SEA_GREEN.index);
            
			String [] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sep", "Oct", "Nov", "Dec"};
            if (!isFillter) {

            	//row1 
                columnCount = 0;
                lstExObj.add(new ExcelObject(rowCount, columnCount, "Leave Report", cellStyleR1));
                mergeList.add(new Integer[]{ 0, 0, 0, 6}); 
                lstExObj.add(new ExcelObject(rowCount, 7, "Report From : " + reportFrom, cellStyleR1));
                mergeList.add(new Integer[]{ 0, 0, 7, 109});

            	//row2
                rowCount++;
                columnCount = 0;
                
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp ID", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Name", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp Type", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employment Date", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Probation \n completion \n Date", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, Integer.toString(Integer.parseInt(year)-1), cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Resigned \n Date", cellStyleG2));
                lstExObj.add(new ExcelObject(rowCount, columnCount++,  year + " Entitlement", cellStyleG3));
                
                columnCount +=4;
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Used", cellStyleG4));
                
                columnCount +=6;
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Balance", cellStyleG5));
                
                columnCount +=6;
                lstExObj.add(new ExcelObject(rowCount, columnCount++, year + " Used (Detail)", cellStyleG5));

                //row3
                rowCount++;
                columnCount = 5;
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Balance", cellStyleG1));
                
                columnCount +=1;
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Carry \n from \n previous \n year", cellStyleG3));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "New \n entitlement \n as of 1 Jan", cellStyleG3));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Additional 1 day \n (1 year completion)", cellStyleG3));
                
                columnCount ++;
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total", cellStyleG3));

                for (String month : months) {
                	if (month.equals("Jan")) {
                		columnCount +=14;
    	                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Jan", cellStyleG5));
                	} else {
                		columnCount +=6;
		                lstExObj.add(new ExcelObject(rowCount, columnCount++, month, cellStyleG5));
                	}
                }
                 
                //row4
                rowCount++;
                columnCount = 9;
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Days", cellStyleG3));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Start from", cellStyleG3));
                
                columnCount +=1;
                for (int i = 1 ; i<=14 ; i++) {
                	XSSFCellStyle cs = cellStyleG5;
                	if (i == 1) {
                		cs = cellStyleG4;
                	}
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, "Sick", cs));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, "Business", cs));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, "Annual", cs));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, "Maternity", cs));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, "Ordination", cs));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, "Leave w/o pay", cs));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, "Others", cs));
                }
                
                
                // set merge cell
                mergeList.add(new Integer[]{ 1, 3, 0, 0});//Emp ID
                mergeList.add(new Integer[]{ 1, 3, 1, 1});//Name
                mergeList.add(new Integer[]{ 1, 3, 2, 2});
                mergeList.add(new Integer[]{ 1, 3, 3, 3});
                mergeList.add(new Integer[]{ 1, 3, 4, 4});//Probation completion Date
                mergeList.add(new Integer[]{ 2, 3, 5, 5});//Balance
                mergeList.add(new Integer[]{ 1, 3, 6, 6});//Resigned 
                mergeList.add(new Integer[]{ 1, 1, 7, (7+4)});//2018 Entitlement
                mergeList.add(new Integer[]{ 2, 3, 7, 7});//Carry from previous year
                mergeList.add(new Integer[]{ 2, 3, 8, 8});//New entitlement as of 1 Jan
                mergeList.add(new Integer[]{  2, 2, 9, 10});//Additional 1 day
                mergeList.add(new Integer[]{ 2, 3, 11, 11});//Total
                mergeList.add(new Integer[]{ 1, 2, 12, (12+6)});//Used
                mergeList.add(new Integer[]{ 1, 2, 19, (19+6)});//Balance
                mergeList.add(new Integer[]{  1, 1, 26, (26+83)});//2018 Used (Detail)
                
                int colSt = 26;
                int colNext = 6;
                for (int i=1 ; i<=12 ; i++) {
                	mergeList.add(new Integer[]{  2, 2, colSt, (colSt+colNext)});//Jan-Dec
                    colSt += colNext +1;
                }
                
            } else {
            	
            	//row1
                columnCount = 0;
                
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Leave Report", cellStyleR1));
                mergeList.add(new Integer[]{ 0, 0, 0, 6});
                
                int mergeCol = 0;
                if (leaveReportCriteria.getLeaveType().equals("1")) {//annual leave
                	mergeCol = 18;
                } else {
                	mergeCol = 13;
                }
               
                lstExObj.add(new ExcelObject(rowCount, 7, "Report From : " + reportFrom, cellStyleR1));
                mergeList.add(new Integer[]{ 0, 0, 7, 7+mergeCol});
                 
            	//row2
                rowCount++;
                columnCount = 0;
                
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp ID", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Name", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp Type", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employment Date", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Probation \n completion \n Date", cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, Integer.toString(Integer.parseInt(year)-1), cellStyleG1));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Resigned \n Date", cellStyleG2));
                
                if (leaveReportCriteria.getLeaveType().equals("1")) {//annual leave
                	lstExObj.add(new ExcelObject(rowCount, columnCount++,  year + " Entitlement", cellStyleG3));
                    columnCount +=4;
                }
                
                lstExObj.add(new ExcelObject(rowCount, columnCount++,  "Used", cellStyleG4));
                lstExObj.add(new ExcelObject(rowCount, columnCount++,  "Balance", cellStyleG5));
                lstExObj.add(new ExcelObject(rowCount, columnCount++,  year + " Used (Detail)", cellStyleG5));
                

                //row3
                rowCount++;
                columnCount = 5;
                lstExObj.add(new ExcelObject(rowCount, columnCount++,  "Balance", cellStyleG1));
                
                columnCount +=1;
                if (leaveReportCriteria.getLeaveType().equals("1")) {//annual leave
	                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Carry \n from \n previous \n year", cellStyleG3));
	                
	                lstExObj.add(new ExcelObject(rowCount, columnCount++, "New \n entitlement \n as of 1 Jan", cellStyleG3));
	                
	                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Additional 1 day \n (1 year completion)", cellStyleG3));
	                
	                columnCount ++;
	                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total", cellStyleG3));
                }
                
                columnCount +=2;
                for (String month : months) {
                	lstExObj.add(new ExcelObject(rowCount, columnCount++, month, cellStyleG5));
                }
                
                //row4
                rowCount++;
                columnCount = 9;
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Days", cellStyleG3));
                
                lstExObj.add(new ExcelObject(rowCount, columnCount++, "Start from", cellStyleG3));
                
                
                // set merge cell
                mergeList.add(new Integer[]{ 1, 3, 0, 0});//Emp ID
                mergeList.add(new Integer[]{ 1, 3, 1, 1});//Name
                mergeList.add(new Integer[]{ 1, 3, 2, 2});
                mergeList.add(new Integer[]{ 1, 3, 3, 3});
                mergeList.add(new Integer[]{1, 3, 4, 4});
                mergeList.add(new Integer[]{2, 3, 5, 5});//Balance
                mergeList.add(new Integer[]{ 1, 3, 6, 6});//Resigned 
                
                int annStart = 12;
                int colStMonth = 14;
                if (leaveReportCriteria.getLeaveType().equals("1")) {
                    mergeList.add(new Integer[]{ 1, 1, 7, (7+4)});//2018 Entitlement
                    mergeList.add(new Integer[]{ 2, 3, 7, 7});//Carry from previous year
                    mergeList.add(new Integer[]{ 2, 3, 8, 8});//New entitlement as of 1 Jan
                    mergeList.add(new Integer[]{ 2, 2, 9, 10});//Additional 1 day
                    mergeList.add(new Integer[]{ 2, 3, 11, 11});//Total
                    
                } else {
                	annStart -= 5;
                	colStMonth -= 5;
                }
                
                mergeList.add(new Integer[]{ 1, 3, annStart, annStart});//Used
                mergeList.add(new Integer[]{ 1, 3, annStart+1, annStart+1});//Balance
                mergeList.add(new Integer[]{ 1, 1, annStart+2, ((annStart+2)+11)});//2018 Used (Detail)
                
                for (int i=1 ; i<=12 ; i++) {
                	mergeList.add(new Integer[]{  2, 3, colStMonth, colStMonth++});//Jan-Dec
                }
            	
            }
            
            //create row data
            
			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
            
            if (!isFillter) {
            	// Create Other rows and cells 
                for (LeaveReportRes rec: listResult.getResult()) {
                    rowCount++;
                    columnCount = 0;

                	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpId(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFullName(), cellStyleLeft));
                    
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpType(), cellStyleCenter));
                    
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmploymentDate(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProbationDate(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getPreviousYearBal(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getResignDate(), cellStyleCenter));
                    
                    //no fillter
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getCarryPrevious(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNewEntitle(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAdditionalDay(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAdditionalDate(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAnnualTotal(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedSi(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedBu(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedAn(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedMa(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedOr(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedWp(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedOthers(), cellStyleCenter));
	                                        
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getBalSi(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getBalBu(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getBalAn(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getBalMa(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getBalOr(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getBalWp(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getBalOthers(), cellStyleCenter));
	                    
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanSi(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanBu(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanAn(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanMa(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanOr(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanWp(), cellStyleCenter));
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanOthers(), cellStyleCenter));
	                    
	                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebSi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarSi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprSi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMaySi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunSi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulySi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulyBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulyAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulyMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulyOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulyWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulyOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugSi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepSi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctSi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovSi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovOthers(), cellStyleCenter));
						
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecSi(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecBu(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecAn(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecMa(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecOr(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecWp(), cellStyleCenter));
						lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecOthers(), cellStyleCenter));
  
	                }
	            } else {
	            	          	
	            	// Create Other rows and cells with 
                
                for (LeaveReportWithFillterRes rec: listFillterResult.getResult()) {
                    rowCount++;
                    columnCount = 0;
                    
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpId(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFullName(), cellStyleLeft));
                    
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpType(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmploymentDate(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProbationDate(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getPreviousYearBal(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getResignDate(), cellStyleCenter));
                                       
                    if (leaveReportCriteria.getLeaveType().equals("1")) {//annual leave                    	
                        lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getCarryPrevious(), cellStyleCenter));
                        lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNewEntitle(), cellStyleCenter));
                        lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAdditionalDay(), cellStyleCenter));
                        lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAdditionalDate(), cellStyleCenter));
                        lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAnnualTotal(), cellStyleCenter));
    				} 

                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedLeave(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getBalance(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedJan(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedFeb(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedMar(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedApr(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedMay(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedJun(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedJul(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedAug(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedSep(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedOct(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedNov(), cellStyleCenter));
                    lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUsedDec(), cellStyleCenter));   
                    
                }
             
            }
            
			PoiUtils.createSheet(wb, "Leave", lstExObj, mergeList, true);
			wb.getSheet("Leave").autoSizeColumn((short) 0);
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.addHeader("Content-Disposition", "attachment; filename=\"LeaveReport.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream); 
          
      } catch (Exception e) {
          e.printStackTrace();
      } finally {
      	outputStream.flush();
      	outputStream.close();
      	wb.close();
      }
      
	}
    
    private JsonResultBean validateCriteria(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg    = "";
		String result_data   = "";

		if (StringUtils.isEmpty(json.get("startDate"))) {
			result_data   = "";
			result_status = "error";
			result_msg    = "Please Fill StartDate";
			return new JsonResultBean(result_status, result_msg , result_data );
		}
		 
		if (StringUtils.isEmpty(json.get("endDate"))) {
			result_data   = "";
			result_status = "error";
			result_msg    = "Please Fill EndDate";
			return new JsonResultBean(result_status, result_msg , result_data );
		}
		
		
		String startDate = json.get("startDate").toString();
		String endDate = json.get("endDate").toString();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date stDate = sdf.parse(startDate); 
		Date edDate = sdf.parse(endDate);

		long difference = edDate.getTime() - stDate.getTime();
		float daysBetween =  TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);
		
		if (daysBetween < 0) {
			 result_data   = "";
			 result_status = "error";
			 result_msg    = "EndDate more than equal StartDate";
			 return new JsonResultBean(result_status, result_msg , result_data );
		}
		
		if ( daysBetween > 366 ) {
			
			 result_data   = "";
			 result_status = "error";
			 result_msg    = "StartDate-EndDate not over 1 Year";
			 return new JsonResultBean(result_status, result_msg , result_data );
			 
		}
		
		Calendar calSt = Calendar.getInstance();
		calSt.setTime(stDate);

		Calendar calEd = Calendar.getInstance();
		calEd.setTime(edDate);
		if (calSt.get(Calendar.YEAR) != calEd.get(Calendar.YEAR)) {
			 result_data   = "";
			 result_status = "error";
			 result_msg    = "StartDate-EndDate must be the same year";
			 return new JsonResultBean(result_status, result_msg , result_data );
		}
		return new JsonResultBean("success", "" , "" );
    }
    
    
    private LeaveReportCriteria getCriteria(JSONObject json) throws Exception {
    	String year = "";
		String startDate = json.get("startDate").toString();
		String endDate = json.get("endDate").toString();
		String division = json.get("division").toString();
		String department = json.get("department").toString();
		String section = json.get("section").toString();
		String employeeName = null;
		if (json.get("employeeName") != null) {
			employeeName = json.get("employeeName").toString();
		}
		String employeeType = json.get("employeeType").toString();
		String leaveType = json.get("leaveType").toString();
		 
		 
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd");
		Date stDate = sdf.parse(startDate);
		String startDateFmt = output.format(stDate);
		Date edDate = sdf.parse(endDate);
		String endDateFmt = output.format(edDate);
		

		Calendar calSt = Calendar.getInstance();
		calSt.setTime(stDate);

		year = Integer.toString(calSt.get(Calendar.YEAR));
		 
		 LeaveReportCriteria leaveReportCriteria = new LeaveReportCriteria();
		
		 if (!StringUtils.isEmpty(year))
			 leaveReportCriteria.setYear(year);
		 if (!StringUtils.isEmpty(startDateFmt)) {
			 leaveReportCriteria.setStartDate_1(startDateFmt);
			 leaveReportCriteria.setStartDate(startDateFmt);
		 }
			 
		 if (!StringUtils.isEmpty(endDateFmt))
			 leaveReportCriteria.setEndDate(endDateFmt);
		 if (!StringUtils.isEmpty(division))	
			 leaveReportCriteria.setDivision(division);
		 if (!StringUtils.isEmpty(department))
			 leaveReportCriteria.setDepartment(department);
		 if (!StringUtils.isEmpty(section))
			 leaveReportCriteria.setSection(section);
		 if (!StringUtils.isEmpty(employeeName)) { 
			 String ids = employeeName.replaceAll("\\[|\\]", ""); 
			 List<String> listId = Arrays.asList(ids.split(","));
			 if (listId.size() > 1) {
				 listId = JsonBeanUtils.jsonToList(employeeName); 
			 }
			 leaveReportCriteria.setEmployeeName_1(listId);
			 leaveReportCriteria.setEmployeeName(listId);
		 }
		 if (!StringUtils.isEmpty(employeeType))
			 leaveReportCriteria.setEmployeeType(employeeType);
		 if (!StringUtils.isEmpty(leaveType)) {
			 leaveReportCriteria.setLeaveType(leaveType);
			 leaveReportCriteria.setLeaveType_lq(leaveType);
		 }
		 return leaveReportCriteria;
    }
		

}
