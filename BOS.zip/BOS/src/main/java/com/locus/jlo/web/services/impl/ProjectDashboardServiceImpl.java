package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Set;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.services.ProjectDashboardService;
import com.locus.jlo.web.services.WallService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ProjectDashboardServiceImpl extends BaseService implements ProjectDashboardService{
	
	String SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_DETAIL = "PROJECT_DASHBOARD.SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_DETAIL";
	String SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_MEMBER = "PROJECT_DASHBOARD.SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_MEMBER";
	String SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_WORKHOUR = "PROJECT_DASHBOARD.SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_WORKHOUR";
	String SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_OVERTIME = "PROJECT_DASHBOARD.SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_OVERTIME";
	//String SQL_PROJECT_DASHBOARD_SEARCH_SUMMARY_TABLE = "PROJECT_DASHBOARD.SQL_PROJECT_DASHBOARD_SEARCH_SUMMARY_TABLE";
	String SQL_PROJECT_DASHBOARD_BAR_GRAPH_SUMMARY_LOGTIME = "PROJECT_DASHBOARD.SQL_PROJECT_DASHBOARD_BAR_GRAPH_SUMMARY_LOGTIME";
	
	
	@Override
	public ServiceResult<List<DataBean>> searchProjectDashboardDetail(String projectId)  throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_DETAIL,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchProjectDashboardMember(String projectId)  throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_MEMBER,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchProjectWorkhourLogtime(String projectId)  throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_WORKHOUR,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchProjectOvertimeLogtime(String projectId)  throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_PROJECT_DASHBOARD_SEARCH_PROJECT_OVERTIME,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	/*
	@Override
	public ServiceResult<List<DataBean>> searchProjectSummaryTable(String projectId)  throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_PROJECT_DASHBOARD_SEARCH_SUMMARY_TABLE,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	*/
	
	
	@Override
	public ServiceResult<List<DataBean>> searchProjectBarGraphLogtime(String projectId)  throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_PROJECT_DASHBOARD_BAR_GRAPH_SUMMARY_LOGTIME,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
 
}
