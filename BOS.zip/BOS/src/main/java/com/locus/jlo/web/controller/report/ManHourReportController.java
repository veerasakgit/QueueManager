package com.locus.jlo.web.controller.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.report.hr.ManHourReportCriteria;
import com.locus.jlo.web.beans.report.hr.ManHourReportRes;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
public class ManHourReportController {
	
	@Autowired
	private ExcelReportService excelReportService;
	
		
	@RequestMapping(value = "/searchManHourReport", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchManHourReport(HttpServletRequest request,Locale locale) throws Exception{

		String cri = request.getParameter("cri");	
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(cri);
		
		JsonResultBean validResult = validateCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		 ManHourReportCriteria criteria = getCriteria(json);
		 
		 JsonResultBean result = null;
		 
		 ServiceResult<List<ManHourReportRes>> listResult = excelReportService.searchManHourTimeSheetReport(criteria);
		 
		 if (listResult.isSuccess()) {
			 result = new JsonResultBean("success", "" , listResult.getResult());
			 log.info("successRespones : "+result.toString());
			 log.info(" total : " + listResult.getResult().size());
		 }  else {
			 log.info("fail_Respones : ");
		 }
			 

		 
		 return result;
	
	}
	 
    @RequestMapping(value = "/validateManHourCriteria", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateManHourCriteria(HttpServletRequest request,Locale locale) throws Exception{
    	String cri = request.getParameter("cri");
    	JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(cri);
		return validateCriteria(json);
    	
    }
    
    
    @SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportManHourReport", method = RequestMethod.POST)
	public @ResponseBody void exportManHourReport(HttpServletRequest request, HttpServletResponse response, ManHourReportCriteria cr) throws Exception {

    	String excelFilePath = "D:\\Manhour_report.xlsx";
        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));

        XSSFWorkbook wb = new XSSFWorkbook(inputStream);
    	
		OutputStream outputStream = null;
		ByteArrayOutputStream outByteStream = null;
//		XSSFWorkbook wb = new XSSFWorkbook();
      
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("startDate", cr.getStartDate());
			jsonObj.put("endDate", cr.getEndDate());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());
			jsonObj.put("employeeId", cr.getEmployeeId());
			jsonObj.put("employeeType", cr.getEmployeeType());
			jsonObj.put("projectId", cr.getProjectId());

			ManHourReportCriteria criteria  = getCriteria(jsonObj);

			ServiceResult<List<ManHourReportRes>> manHourTimeSheetList = excelReportService.searchManHourTimeSheetReport(criteria);
			ServiceResult<List<ManHourReportRes>> manHourOverTimeList = excelReportService.searchManHourOverTimeReport(criteria);
			int rowCount = 1;
			int columnCount = 0;
          	List<ExcelObject> internalList = new ArrayList<ExcelObject>();
          	List<ExcelObject> outsouceList = new ArrayList<ExcelObject>();
          	
			//create Cells styles
			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
            
			//create row data
			for (ManHourReportRes rec : manHourTimeSheetList.getResult()) {
				if(!"3".equals(rec.getEmployeeType())) {
					rowCount++;
					columnCount = 0;
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTyear()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTmonth()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getSpentOn(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeId(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getPosition(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDeptCode().concat(rec.getRankId())), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getJobGroup().concat(rec.getRankId()), cellStyleCenter));;
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDivisionId()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDeptCode()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getDeptName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getSectionCode()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRankId()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRoleId()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getJobGroup(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,7,0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,8,0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,9,0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",P"+(rowCount+1)+",0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",Q"+(rowCount+1)+",0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",R"+(rowCount+1)+",0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectCode(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getTaskName(), cellStyleLeft));
					String formula = "IF(AC"+(rowCount+1)+"=\"Chargable\",IF(AA"+(rowCount+1)+"=1,\"MA\",\"Project\"),IF(AC"+(rowCount+1)+"=\"Non Chargable\",IF(X"+(rowCount+1)+"=\"Company Meeting\",\"Company Meeting\",IF(X"+(rowCount+1)+"=\"Company Training\",\"Company Training\",IF(X"+(rowCount+1)+"=\"Internal Project\",\"Internal Project\",IF(X"+(rowCount+1)+"=\"Leave\",\"Leave\",IF(LEFT(X"+(rowCount+1)+",3)=\"Pre\",\"Presale\",\"Admin\")))))))";
					internalList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getInternalProject()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getMaProject()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDealProject()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectType(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getOrcStatusName(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getDealStatusName(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getSalesName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getCustomerName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeStatus(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeApproveBy(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getNoteComment(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getOfficeHour()), cellStyleCenter));
					columnCount++;
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(AK"+(rowCount+1)+":AL"+(rowCount+1)+")", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "+(AS"+(rowCount+1)+"*1)+(AT"+(rowCount+1)+"*1.5)+(AU"+(rowCount+1)+"*3)", cellStyleCenter));
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(S"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(S"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(S"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(S"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					internalList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BA"+(rowCount+1)+":BB"+(rowCount+1)+")", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(T"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(T"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(T"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(T"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					internalList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BD"+(rowCount+1)+":BE"+(rowCount+1)+")", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(U"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(U"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(U"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(U"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					internalList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BG"+(rowCount+1)+":BH"+(rowCount+1)+")", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AV"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",350,0),0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AW"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",150,0),0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AY"+(rowCount+1)+"=\"APPROVED\",AX"+(rowCount+1)+",0)", cellStyleCenter));
				}
			}

			for (ManHourReportRes rec : manHourOverTimeList.getResult()) {
				if(!"3".equals(rec.getEmployeeType())) {
					rowCount++;
					columnCount = 0;
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTyear()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTmonth()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getSpentOn(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeId(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getPosition(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDeptCode().concat(rec.getRankId())), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getJobGroup().concat(rec.getRankId()), cellStyleCenter));;
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDivisionId()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDeptCode()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getDeptName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getSectionCode()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRankId()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRoleId()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getJobGroup(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,7,0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,8,0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,9,0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",P"+(rowCount+1)+",0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",Q"+(rowCount+1)+",0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",R"+(rowCount+1)+",0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectCode(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getTaskName(), cellStyleLeft));
					String formula = "IF(AC"+(rowCount+1)+"=\"Chargable\",IF(AA"+(rowCount+1)+"=1,\"MA\",\"Project\"),IF(AC"+(rowCount+1)+"=\"Non Chargable\",IF(X"+(rowCount+1)+"=\"Company Meeting\",\"Company Meeting\",IF(X"+(rowCount+1)+"=\"Company Training\",\"Company Training\",IF(X"+(rowCount+1)+"=\"Internal Project\",\"Internal Project\",IF(X"+(rowCount+1)+"=\"Leave\",\"Leave\",IF(LEFT(X"+(rowCount+1)+",3)=\"Pre\",\"Presale\",\"Admin\")))))))";
					internalList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getInternalProject()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getMaProject()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDealProject()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectType(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getOrcStatusName(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getDealStatusName(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getSalesName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getCustomerName(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeStatus(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeApproveBy(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getNoteComment(), cellStyleLeft));
					columnCount++;
					internalList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getOtHour()), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(AK"+(rowCount+1)+":AL"+(rowCount+1)+")", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "+(AS"+(rowCount+1)+"*1)+(AT"+(rowCount+1)+"*1.5)+(AU"+(rowCount+1)+"*3)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getOtRequested(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getStartTime(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getEndTime(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getDateType(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getOtRate1(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getOtRate15(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getOtRate3(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getMobileService(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getCarAllowance(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getTaxiFee(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getOtApprovedStatus(), cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, rec.getApprovalUser(), cellStyleLeft));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(S"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(S"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(S"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(S"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					internalList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BA"+(rowCount+1)+":BB"+(rowCount+1)+")", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(T"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(T"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(T"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(T"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					internalList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BD"+(rowCount+1)+":BE"+(rowCount+1)+")", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(U"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(U"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(U"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(U"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					internalList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BG"+(rowCount+1)+":BH"+(rowCount+1)+")", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AV"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",350,0),0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AW"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",150,0),0)", cellStyleCenter));
					internalList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AY"+(rowCount+1)+"=\"APPROVED\",AX"+(rowCount+1)+",0)", cellStyleCenter));
				}
			}
			wb = createDataSheet(wb, "Internal Details", internalList, null);
			wb.getSheet("Internal Details").autoSizeColumn((short) 0);
			wb.getSheet("Internal Details").autoSizeColumn((short) 1);
			wb.getSheet("Internal Details").autoSizeColumn((short) 2);
			wb.getSheet("Internal Details").autoSizeColumn((short) 3);
			wb.getSheet("Internal Details").autoSizeColumn((short) 4);
			
			rowCount = 1;
			for (ManHourReportRes rec : manHourTimeSheetList.getResult()) {
				if("3".equals(rec.getEmployeeType())) {
					rowCount++;
					columnCount = 0;
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTyear()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTmonth()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getSpentOn(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeId(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getPosition(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDeptCode().concat(rec.getRankId())), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getJobGroup().concat(rec.getRankId()), cellStyleCenter));;
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDivisionId()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDeptCode()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getDeptName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getSectionCode()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRankId()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRoleId()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getJobGroup(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,7,0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,8,0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,9,0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",P"+(rowCount+1)+",0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",Q"+(rowCount+1)+",0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",R"+(rowCount+1)+",0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectCode(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getTaskName(), cellStyleLeft));
					String formula = "IF(AC"+(rowCount+1)+"=\"Chargable\",IF(AA"+(rowCount+1)+"=1,\"MA\",\"Project\"),IF(AC"+(rowCount+1)+"=\"Non Chargable\",IF(X"+(rowCount+1)+"=\"Company Meeting\",\"Company Meeting\",IF(X"+(rowCount+1)+"=\"Company Training\",\"Company Training\",IF(X"+(rowCount+1)+"=\"Internal Project\",\"Internal Project\",IF(X"+(rowCount+1)+"=\"Leave\",\"Leave\",IF(LEFT(X"+(rowCount+1)+",3)=\"Pre\",\"Presale\",\"Admin\")))))))";
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getInternalProject()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getMaProject()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDealProject()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectType(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getOrcStatusName(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getDealStatusName(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getSalesName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getCustomerName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeStatus(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeApproveBy(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getNoteComment(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getOfficeHour()), cellStyleCenter));
					columnCount++;
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(AK"+(rowCount+1)+":AL"+(rowCount+1)+")", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "+(AS"+(rowCount+1)+"*1)+(AT"+(rowCount+1)+"*1.5)+(AU"+(rowCount+1)+"*3)", cellStyleCenter));
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					columnCount++;
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(S"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(S"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(S"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(S"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BA"+(rowCount+1)+":BB"+(rowCount+1)+")", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(T"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(T"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(T"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(T"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BD"+(rowCount+1)+":BE"+(rowCount+1)+")", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(U"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(U"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(U"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(U"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BG"+(rowCount+1)+":BH"+(rowCount+1)+")", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AV"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",350,0),0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AW"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",150,0),0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AY"+(rowCount+1)+"=\"APPROVED\",AX"+(rowCount+1)+",0)", cellStyleCenter));
				}
			}

			for (ManHourReportRes rec : manHourOverTimeList.getResult()) {
				if("3".equals(rec.getEmployeeType())) {
					rowCount++;
					columnCount = 0;
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTyear()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTmonth()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getSpentOn(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeId(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getPosition(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDeptCode().concat(rec.getRankId())), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getJobGroup().concat(rec.getRankId()), cellStyleCenter));;
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDivisionId()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDeptCode()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getDeptName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getSectionCode()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRankId()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRoleId()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getJobGroup(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,7,0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,8,0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "VLOOKUP(H:H,'New Charge Rate'!A:I,9,0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",P"+(rowCount+1)+",0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",Q"+(rowCount+1)+",0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AC"+(rowCount+1)+"=\"Chargable\",R"+(rowCount+1)+",0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectCode(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getTaskName(), cellStyleLeft));
					String formula = "IF(AC"+(rowCount+1)+"=\"Chargable\",IF(AA"+(rowCount+1)+"=1,\"MA\",\"Project\"),IF(AC"+(rowCount+1)+"=\"Non Chargable\",IF(X"+(rowCount+1)+"=\"Company Meeting\",\"Company Meeting\",IF(X"+(rowCount+1)+"=\"Company Training\",\"Company Training\",IF(X"+(rowCount+1)+"=\"Internal Project\",\"Internal Project\",IF(X"+(rowCount+1)+"=\"Leave\",\"Leave\",IF(LEFT(X"+(rowCount+1)+",3)=\"Pre\",\"Presale\",\"Admin\")))))))";
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getInternalProject()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getMaProject()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDealProject()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getProjectType(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getOrcStatusName(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getDealStatusName(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getSalesName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getCustomerName(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeStatus(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeApproveBy(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getNoteComment(), cellStyleLeft));
					columnCount++;
					outsouceList.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getOtHour()), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(AK"+(rowCount+1)+":AL"+(rowCount+1)+")", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "+(AS"+(rowCount+1)+"*1)+(AT"+(rowCount+1)+"*1.5)+(AU"+(rowCount+1)+"*3)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getOtRequested(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getStartTime(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getEndTime(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getDateType(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getOtRate1(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getOtRate15(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getOtRate3(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getMobileService(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getCarAllowance(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getTaxiFee(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getOtApprovedStatus(), cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, rec.getApprovalUser(), cellStyleLeft));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(S"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(S"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(S"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(S"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BA"+(rowCount+1)+":BB"+(rowCount+1)+")", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(T"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(T"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(T"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(T"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BD"+(rowCount+1)+":BE"+(rowCount+1)+")", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AH"+(rowCount+1)+"=\"APPROVED\",(U"+(rowCount+1)+"/8)*AK"+(rowCount+1)+",0)", cellStyleCenter));
					formula = "IF(AO"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",(U"+(rowCount+1)+"/8)*AS"+(rowCount+1)+"*1+(U"+(rowCount+1)+"/8)*AT"+(rowCount+1)+"*1.5+(U"+(rowCount+1)+"/8)*AU"+(rowCount+1)+"*3,0),0)";
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, formula, cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "SUM(BG"+(rowCount+1)+":BH"+(rowCount+1)+")", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AV"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",350,0),0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AW"+(rowCount+1)+"=1,IF(AY"+(rowCount+1)+"=\"APPROVED\",150,0),0)", cellStyleCenter));
					outsouceList.add(new ExcelObject(rowCount, columnCount++, null, "IF(AY"+(rowCount+1)+"=\"APPROVED\",AX"+(rowCount+1)+",0)", cellStyleCenter));
				}
			}
			wb = createDataSheet(wb, "OS Details", outsouceList, null);
			wb.getSheet("OS Details").autoSizeColumn((short) 0);
			wb.getSheet("OS Details").autoSizeColumn((short) 1);
			wb.getSheet("OS Details").autoSizeColumn((short) 2);
			wb.getSheet("OS Details").autoSizeColumn((short) 3);
			wb.getSheet("OS Details").autoSizeColumn((short) 4);
		
			outByteStream = new ByteArrayOutputStream();
            wb.write(outByteStream);
            byte[] outArray = outByteStream.toByteArray();
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setContentLength(outArray.length); 
            response.setHeader("Content-Disposition", "attachment; filename=\"Man_Hour.xlsx\"");
            outputStream = response.getOutputStream();
            outputStream.write(outArray);
      } catch (Exception e) {
          e.printStackTrace();
      } finally {
      	outputStream.flush();
      	outputStream.close();
      	outByteStream.close();
      	wb.close();
      }
      
	}
    
    private JsonResultBean validateCriteria(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg    = "";
		String result_data   = "";

		if (StringUtils.isEmpty(json.get("startDate"))) {
			result_data   = "";
			result_status = "error";
			result_msg    = "Please Fill StartDate";
			return new JsonResultBean(result_status, result_msg , result_data );
		}
		 
		if (StringUtils.isEmpty(json.get("endDate"))) {
			result_data   = "";
			result_status = "error";
			result_msg    = "Please Fill EndDate";
			return new JsonResultBean(result_status, result_msg , result_data );
		}
		
		
		String startDate = json.get("startDate").toString();
		String endDate = json.get("endDate").toString();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date stDate = sdf.parse(startDate); 
		Date edDate = sdf.parse(endDate);

		long difference = edDate.getTime() - stDate.getTime();
		float daysBetween =  TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);
		
		if (daysBetween < 0) {
			 result_data   = "";
			 result_status = "error";
			 result_msg    = "EndDate more than equal StartDate";
			 return new JsonResultBean(result_status, result_msg , result_data );
		}
		return new JsonResultBean("success", "" , "" );
    }
    
    
    private ManHourReportCriteria getCriteria(JSONObject json) throws Exception {

		String startDate = json.get("startDate").toString();
		String endDate = json.get("endDate").toString();
		String division = json.get("division").toString();
		String department = json.get("department").toString();
		String section = json.get("section").toString();
		String employeeId = null;
		if (json.get("employeeId") != null) {
			employeeId = json.get("employeeId").toString();
		}
		String employeeType = json.get("employeeType").toString();
		String projectId = json.get("projectId").toString();
		 
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd");
		Date stDate = sdf.parse(startDate);
		String startDateFmt = output.format(stDate);
		Date edDate = sdf.parse(endDate);
		String endDateFmt = output.format(edDate);
		
		ManHourReportCriteria criteria = new ManHourReportCriteria();

		if(!StringUtils.isEmpty(startDateFmt)){
			criteria.setStartDate(startDateFmt);
		}
		if(!StringUtils.isEmpty(endDateFmt))
			criteria.setEndDate(endDateFmt);
		if(!StringUtils.isEmpty(division))	
			criteria.setDivision(division);
		if(!StringUtils.isEmpty(department))
			criteria.setDepartment(department);
		if(!StringUtils.isEmpty(section))
			criteria.setSection(section);
		if(!StringUtils.isEmpty(employeeId)){
			String ids = employeeId.replaceAll("\\[|\\]","");
		List<String>listId=Arrays.asList(ids.split(","));
			if(listId.size()>1){
				listId=JsonBeanUtils.jsonToList(employeeId);
			}
			criteria.setEmployeeId(listId);
		}
		if(!StringUtils.isEmpty(employeeType))
			criteria.setEmployeeType(employeeType);
		if(!StringUtils.isEmpty(projectId))
			criteria.setProjectId(projectId);
		return criteria;
    }
    
    private XSSFWorkbook createDataSheet(XSSFWorkbook wb,String sheetName,List<ExcelObject> excelObjects,List<Integer[]> mergeList) {
		XSSFSheet sheet = wb.getSheet(sheetName);
		XSSFCell cell = null;
		if (!CollectionUtils.isEmpty(excelObjects)) {
			XSSFRow row = null;
			int rowNum = -1;
			for (ExcelObject object : excelObjects) {
				
				if (rowNum != object.getRownum()) 
					row = sheet.createRow(object.getRownum());
				
				rowNum = object.getRownum();
					
				cell = row.createCell(object.getCellnum());

				cell.setCellStyle(object.getStyle());
				
				if (object.getValue() == null) {
					cell.setCellValue(ObjectBeanUtils.nvl(object.getValue(),""));
				} else if  (object.getValue() instanceof String) {
					cell.setCellValue((String) object.getValue());
	            } else if (object.getValue() instanceof Integer) {
            		cell.setCellValue((Integer) object.getValue());
            		cell.setCellType(CellType.NUMERIC);
	            } else if (object.getValue() instanceof Double) {
	            	cell.setCellValue((Double) object.getValue());
	            	cell.setCellType(CellType.NUMERIC);
	            }
				
				if(object.getCellFormula() != null) {
					cell.setCellFormula(object.getCellFormula());
					cell.setCellType(CellType.FORMULA);
				}
			}
		}
		return wb;
	}

}
