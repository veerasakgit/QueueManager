package com.locus.jlo.web.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class KeyValueBean {

    private String id;
    private String val;
}
