package com.locus.jlo.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.locus.jlo.web.beans.report.ExcelObject;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PoiUtils<T>{
	
	private Class<T> classObj;
	
	public PoiUtils(Class<T> tClass) {
		classObj = tClass;
	}
	
	private static final String FILE_NAME_TEST = "D:\\Users\\file\\importFile\\TestExcel.xlsx";
	
//	public static void main(String[] args) throws Exception {
//
//	}
	
	public static XSSFWorkbook createSheet(XSSFWorkbook wb,String sheetName,List<ExcelObject> excelObjects,List<Integer[]> mergeList) {
		return createSheet(wb, sheetName, excelObjects, mergeList, false);
	}
	
	
	public static XSSFWorkbook createSheet(XSSFWorkbook wb,String sheetName,List<ExcelObject> excelObjects,List<Integer[]> mergeList, boolean borderToMerge) {
		
		XSSFSheet sheet = wb.createSheet(sheetName);
		XSSFCell cell = null;
		CellRangeAddress cellMerge = null;
		if (!CollectionUtils.isEmpty(excelObjects)) {
			XSSFRow row = null;
			int rowNum = -1;
			for (ExcelObject object : excelObjects) {
				
				if (rowNum != object.getRownum()) 
					row = sheet.createRow(object.getRownum());
				
				rowNum = object.getRownum();
					
				cell = row.createCell(object.getCellnum());

				cell.setCellStyle(object.getStyle());
				
				if (object.getValue() == null) {
					cell.setCellValue(ObjectBeanUtils.nvl(object.getValue(),""));
				} else if  (object.getValue() instanceof String) {
					cell.setCellValue((String) object.getValue());
	            } else if (object.getValue() instanceof Integer) {
            		cell.setCellValue((Integer) object.getValue());
            		cell.setCellType(CellType.NUMERIC);
	            } else if (object.getValue() instanceof Double) {
	            	cell.setCellValue((Double) object.getValue());
	            	cell.setCellType(CellType.NUMERIC);
	            }
				
				//sheet.autoSizeColumn(object.getCellnum());
				
			}
			
			if (!CollectionUtils.isEmpty(mergeList)) {
				for (Integer[] merge : mergeList ) {
					cellMerge = new CellRangeAddress(merge[0],merge[1],merge[2],merge[3]);
					sheet.addMergedRegion(cellMerge);
					if (borderToMerge) {
				        setBordersToMergedCells(sheet, cellMerge);
				    }
				}
				
			}
			
		}

		return wb;
	}
	
	public static void setBordersToMergedCells(XSSFSheet sheet, CellRangeAddress rangeAddress) {
	    RegionUtil.setBorderTop(BorderStyle.THIN, rangeAddress, sheet);
	    RegionUtil.setBorderLeft(BorderStyle.THIN, rangeAddress, sheet);
	    RegionUtil.setBorderRight(BorderStyle.THIN, rangeAddress, sheet);
	    RegionUtil.setBorderBottom(BorderStyle.THIN, rangeAddress, sheet);
	}
	
	public static XSSFCellStyle creatCellStyle(XSSFWorkbook wb, String fontName, short fontColor, boolean isFontBold, HorizontalAlignment alignment, short color ) {
    	XSSFCellStyle cellStyle = wb.createCellStyle();
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setVerticalAlignment(VerticalAlignment.TOP);
        cellStyle.setFillForegroundColor(color);
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cellStyle.setAlignment(alignment);
        cellStyle.setWrapText(true);

		XSSFFont font = wb.createFont();
		font.setFontName(fontName);
		font.setBold(isFontBold);
		font.setColor(fontColor);
		cellStyle.setFont(font);
		return cellStyle;
    }
	
	public static XSSFCellStyle creatCellStyle(XSSFWorkbook wb, String fontName, boolean isFontBold, HorizontalAlignment alignment) {
    	XSSFCellStyle cellStyle = wb.createCellStyle();
        cellStyle.setAlignment(alignment);
		XSSFFont font = wb.createFont();
		font.setFontName(fontName);
		font.setBold(isFontBold);
		cellStyle.setFont(font);
		return cellStyle;
    }
	
//	public static List<LinkedHashMap<String,Object>> importExcelFileAutoMap(InputStream excelFile,int colRow,int colSize) {
//		
//		List<LinkedHashMap<String,Object>> list = null;
//		
//        try {
//
////            
//            Workbook workbook = new XSSFWorkbook(excelFile);
//            Sheet datatypeSheet = workbook.getSheetAt(0);
//            
//            Iterator<Row> iterator = datatypeSheet.iterator();
//            
//            list = new ArrayList<>();
//            
//            Row fieldRow = null;
//            
//            while (iterator.hasNext()) {
//            	
//                Row currentRow = iterator.next();
//                
//            	if (currentRow.getRowNum() <= colRow) {
//            		if (currentRow.getRowNum() == colRow && fieldRow==null) {
//            			//get fieldRow to fieldRow
//                		fieldRow = currentRow;
//                		
//					}else {
//						continue;
//					}
//					
//				}
//                
////                Iterator<Cell> cellIterator = currentRow.iterator();
//                
//                LinkedHashMap<String,Object> map = new LinkedHashMap<>();
//                
//                String[] fieldCellArr = new String[colSize];
//                
//                int blank = 0;
//                
//                for (int colNum = 0; colNum < colSize; colNum++) {
//
//                    Cell currentCell = currentRow.getCell(colNum);
//                    
//                    
//                    if (fieldCellArr[colNum] == null && fieldRow != null) {
//                    	//get fieldCell to key
//                    	fieldCellArr[colNum] = fieldRow.getCell(colNum).getStringCellValue();
//					}
//                    
//                    if (currentCell == null) {
//                    	map.put(fieldCellArr[colNum],"");
//                    	blank++;
//					}else {
//						
//				          if (currentCell.getCellTypeEnum() == CellType.STRING) {
//		                    	map.put(fieldCellArr[colNum],currentCell.getStringCellValue());
//		                    } else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
//		                    	
//		                    	if (HSSFDateUtil.isCellDateFormatted(currentCell)) {
//		                        	map.put(fieldCellArr[colNum],currentCell.getDateCellValue());
//								}else {
//			                    	map.put(fieldCellArr[colNum],currentCell.getNumericCellValue());
//								}
//
//		                    }
//					}
//          
//                    
//				}
//                
//                if (currentRow.getRowNum() != colRow && blank < colSize-1) {
//                	list.add(map);
//				}
//                
//            }
////            {
////            	//Show display
////	    		list.get(colRow).forEach((k,v)->{
////	    			System.out.print(k+"|");
////	    		});
////	    		
////	    		System.out.println();
////	    		
////	    		list.forEach((row)->{
////	
////	    			row.forEach((k,v)->{
////	    				System.out.print(v+"|");
////	    			});
////	    			
////	    			System.out.println();
////	              	
////	            });
////            }
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//		return list;
//
//	}
	
	public static List<Object[]> importExcelFileArr(InputStream excelFile,int starRow,int colSize) throws Exception {
		
		List<Object[]> list = null;
		
        try {
//            
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet datatypeSheet = workbook.getSheetAt(0);
            
            Iterator<Row> iterator = datatypeSheet.iterator();
            
            list = new ArrayList<>();
            
            int size = datatypeSheet.getRow(0).getLastCellNum();
            
           if (size != colSize  ) {
        	   throw new Exception();
           }
            
            while (iterator.hasNext()) {
            	
                Row currentRow = iterator.next();
                
                if (currentRow.getRowNum() < starRow) {
                	continue;
				}
                
                
//                Iterator<Cell> cellIterator = currentRow.iterator();
                
                List<Object> objList = new ArrayList<>(colSize);
//                System.out.println(currentRow.getLastCellNum());
//                while (cellIterator.hasNext()) {
                int blank = 0;
                int index = 0;
                for (int colNum = 0; colNum < colSize; colNum++) {
					
                    Cell currentCell = currentRow.getCell(colNum);
                    
                    Object value = null;
                    if (currentCell != null) {
                    	
					     if (currentCell.getCellTypeEnum() == CellType.STRING) {
					    	 value = currentCell.getStringCellValue();
		                 } else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
		                    	
		                    	if (DateUtil.isCellDateFormatted(currentCell)) {
		                    		value = currentCell.getDateCellValue();		                    		
								}else {
									value = currentCell.getNumericCellValue();
								}
		      
		                 }
					     
					}

					if (value == null) {
						objList.add("");
						blank++;
					}else {
						objList.add(value);
					}
					
//					System.out.print(index+" : "+value+" | ");
					index++;
				}

                if (blank < colSize-1) {
                    list.add(objList.toArray(new Object[objList.size()]));
                    System.out.println();
				}
                
    
               
            }
            
//            {
//            	//Show display
//	    		list.forEach((row)->{
//	    			int index = 0;
//	    			for (Object cell : row) {
//	    				System.out.print(index+" : "+cell+" | ");
//	    				index++;
//					}
//	    	 		System.out.println();
//
//	    		});
//	    		
//	   
//            }
            

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
		return list;

	}
	
	
	public static String getSheetName(InputStream excelFile, int index ) {
		
		try {
          //Workbook workbook = new XSSFWorkbook(excelFile);
          return new XSSFWorkbook(excelFile).getSheetAt(index).getSheetName();
        		  
		}catch (Exception e) {
			return null;
		}
	}
	

}
