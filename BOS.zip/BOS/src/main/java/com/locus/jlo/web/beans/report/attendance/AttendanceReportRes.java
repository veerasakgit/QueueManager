package com.locus.jlo.web.beans.report.attendance;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AttendanceReportRes {
	
	private String unit;
	private String noStaff;
	private String totalWorkingDay;
	private String leaveAn;
	private String totalOtherLeave;
	private String actualWorkingDay;
	private String leaveSi;
	private String leaveBu;
	private String leaveMa;
	private String leaveOr;
	private String leaveWp;
	private String leaveOthers;
	
}
