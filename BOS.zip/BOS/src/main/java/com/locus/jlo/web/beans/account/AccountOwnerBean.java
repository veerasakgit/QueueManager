package com.locus.jlo.web.beans.account;

import java.io.Serializable;
import java.math.BigInteger;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class AccountOwnerBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String accountOwnerId;
	private BigInteger accountId;
}
