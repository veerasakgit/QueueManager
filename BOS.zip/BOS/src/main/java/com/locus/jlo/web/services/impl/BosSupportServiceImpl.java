package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Set;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.BosServiceReqBean.BosServiceReqBean;
import com.locus.jlo.web.beans.leaveForm.LeaveFormDetailBean;
import com.locus.jlo.web.services.BosSupportService;
import com.locus.jlo.web.services.LeaveFormService;


import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class BosSupportServiceImpl extends BaseService implements BosSupportService{
	
	String SQL_SEARCH_SR = "BOS_SR.SEARCH_SERVICE_REQ";
	String SQL_SEARCH_SR_DETAIL = "BOS_SR.SEARCH_SERVICE_REQ_DETAIL";
	String SQL_INSERT_SR = "BOS_SR.INSERT_SERVICE_REQ"; 
	String SQL_UPDATE_SR = "BOS_SR.UPDATE_SERVICE_REQ"; 
	String SQL_REMOVE_SR = "BOS_SR.REMOVE_SERVICE_REQ"; 
	
	
	@Override
	public ServiceResult<List<DataBean>> qrySupportSR() throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		/*
		log.info("getYear: "+year);
		log.info("request_from_me: "+request_from_me);
		log.info("request_to_me: "+request_to_me);
		log.info("leaveStatus: "+leaveStatus);
		log.info("leaveType: "+leaveType);
		
	
		if(request_from_me == null){ request_from_me = null;}
		if(request_to_me == null){ request_to_me = null;}
		if(leaveStatus == null){ leaveStatus = null; }
		if(leaveType == null){ leaveType = null;}
		*/
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_SR,BeanPropertyRowMapper.newInstance(DataBean.class));
			
			/*
			 * 
					,new SimpleKeyValue("year",year)
					,new SimpleKeyValue("request_from_me",request_from_me)
					,new SimpleKeyValue("request_to_me",request_to_me)
					,new SimpleKeyValue("leaveStatus",leaveStatus)
					,new SimpleKeyValue("leaveType",leaveType)
			 */
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> qrySupportSRDetail(String id) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_SR_DETAIL,BeanPropertyRowMapper.newInstance(DataBean.class)
					, new SimpleKeyValue("id",id));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("search leave form :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("Error: "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> insertSupportSR( BosServiceReqBean bsr ) throws Exception{
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_SR, Boolean.TRUE, bsr );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateSupportSR(BosServiceReqBean bsr) throws Exception {
		
		//trace parameter
		/*
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		log.info("Timesheet control eid :"+eid);
		*/
		
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_SR, bsr );
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> removeSupportSR(String id) throws Exception {
		 
		//trace parameter
		log.info("Remove BOS Service request id: "+id);
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_SR, new SimpleKeyValue("id",id));
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("[removeSupportSR]: "+e);
			e.printStackTrace();
		}
	
		return result;
	}
	
	
	
 
}
