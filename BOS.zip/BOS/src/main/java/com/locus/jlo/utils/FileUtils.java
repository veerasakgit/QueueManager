package com.locus.jlo.utils;

import com.locus.jlo.web.constant.BOSConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.file.Paths;

@Slf4j
public class FileUtils {

	public static String uploadFile(MultipartFile uploadfile,String servPath) throws Exception{

		 log.info("Start upload");
		 
		 final String directory = BOSConstant.Path.DIRECTORY;
		 
		 String path = "";
		 
		 try {
		      // Get the filename and build the local file path
			  long mstime = System.currentTimeMillis();
		      String filename = uploadfile.getOriginalFilename();
		      String filenameInTime = mstime+"-"+filename;
		      
		      servPath = servPath+"temp";
		      
		      String filepath = Paths.get(directory+servPath, filenameInTime).toString();
		      
		      // Save the file locally
		      File file = new File(filepath);
		      file.getParentFile().mkdirs();
		      FileOutputStream output = new FileOutputStream(file);

		      BufferedOutputStream stream =  new BufferedOutputStream(output);
		      stream.write(uploadfile.getBytes());
		      stream.close();
		      
		      path = servPath+"/"+filenameInTime;

		      
	    }catch(Exception e){
	    	e.printStackTrace();
	    }

		return path;
	
	 
	}
	
	public static void moveToRealPath(String tempPath,String realPath) throws Exception{
		
		 tempPath = BOSConstant.Path.DIRECTORY+tempPath;
		 String filePath = BOSConstant.Path.DIRECTORY+realPath;
//		 String filePath = bean.getImg_path();
		 
		 File fileTemp = new File(tempPath);
		 File file = new File(filePath);
		 file.getParentFile().mkdirs();
		 fileTemp.renameTo(file);
	}

	public static String saveFile(MultipartFile uploadFile, String filePath, String oldPath, boolean clearOld) {
		String pic = oldPath;
		if (uploadFile != null) {
			log.debug("[{}][{}][{}]",uploadFile.getOriginalFilename(), uploadFile.getContentType(),uploadFile.getSize());

			if (clearOld) {
				if (!StringUtils.isEmpty(uploadFile.getOriginalFilename())) {
					// delete pld image
					deleteFile(oldPath, clearOld);
					// new image
					saveFile(uploadFile,filePath);

					pic = filePath;
				}
			} else {
				saveFile(uploadFile,filePath);
				pic = filePath;
			}			
		} else {
			log.debug("File is null !!!");
		}
		return pic;
	}


	private static void saveFile(MultipartFile uploadFile,String pathFile){
		File file = new File(pathFile);
		try {
			File parentDir = file.getParentFile();
			if (!parentDir.exists()) {
				parentDir.mkdirs();
			}
			uploadFile.transferTo(file);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			log.info("Cannot write message to file.");
		}

	}

	public static void deleteFile(String oldPic, boolean clearOld){
		// delete old image
		try {
			File oldFile = new File(oldPic);
			if(oldFile.exists()&&clearOld)
				oldFile.delete();
		} catch (Exception e) {
			log.error("Error delete {}:{}",oldPic,e.getMessage());
		}
	}

	public static void downloadFile(HttpServletRequest request, HttpServletResponse response, String filePath){
		downloadFile(request, response, filePath, null);
	}
	
	public static void downloadFile(HttpServletRequest request, HttpServletResponse response, String filePath, String orgFilename){
		File file = new File(filePath);
		FileInputStream is = null;
		try {
			is = new FileInputStream(file);
			byte[] content = new byte[(int) file.length()];
			is.read(content);
			ServletContext sc = request.getSession().getServletContext();
			String mimetype = sc.getMimeType(file.getName());
			String filename = file.getName();
			if (!StringUtils.isEmpty(orgFilename))
				filename = orgFilename;
			response.reset();
			response.setContentType(mimetype);
			response.setContentLength(content.length);
			response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");
			org.springframework.util.FileCopyUtils.copy(content, response.getOutputStream());
			is.close();
		} catch (FileNotFoundException e) {
			log.error("Error File Not Found {}:{}", filePath, e.getMessage());
		} catch (IOException e) {
			log.error("Error IOException {}:{}", filePath, e.getMessage());
		}
	}

	public static String convertBytesToMB(long bytes){
		// Get length of file in bytes
		long fileSizeInBytes = bytes;

		// Convert the bytes to Kilobytes (1 KB = 1024 Bytes)
		long fileSizeInKB = fileSizeInBytes / 1024;

		// Convert the KB to MegaBytes (1 MB = 1024 KBytes)
		long fileSizeInMB = fileSizeInKB / 1024;

		if(fileSizeInMB >= 1){
			return fileSizeInMB + " MB";
		}else if(fileSizeInKB >= 1){
			return fileSizeInKB + " KB";
		}else{
			return fileSizeInBytes + " B";
		}
	}
}
