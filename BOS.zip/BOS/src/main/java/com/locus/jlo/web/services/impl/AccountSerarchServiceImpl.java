package com.locus.jlo.web.services.impl;

import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.account.search.AccountSearchBean;
import com.locus.jlo.web.services.AccountSearchService;

@Service
public class AccountSerarchServiceImpl extends BaseService implements AccountSearchService{
	
	String SQL_SEARCH_ACCOUNT = "ACCOUNT.SQL_SEARCH_ACCOUNT";

	@Override
	public ServiceResult<List<AccountSearchBean>> searchAccount(AccountSearchBean accountDetailBean) throws Exception {
		ServiceResult<List<AccountSearchBean>> serviceResult = new ServiceResult<List<AccountSearchBean>>();
		List<AccountSearchBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_ACCOUNT,BeanPropertyRowMapper.newInstance(AccountSearchBean.class)
					,new SimpleKeyValue("accountName",accountDetailBean.getAccountName()));
			
			serviceResult = new ServiceResult<List<AccountSearchBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<AccountSearchBean>>(e);
		}
		return serviceResult;
	}

}
