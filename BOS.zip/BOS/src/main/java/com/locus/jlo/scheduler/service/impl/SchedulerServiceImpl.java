package com.locus.jlo.scheduler.service.impl;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.scheduler.bean.SchedulerHistoryBean;
import com.locus.jlo.scheduler.bean.SchedulerBean;
import com.locus.jlo.scheduler.config.QuartzCustomListener;
import com.locus.jlo.scheduler.config.SchedulerConstant;
import com.locus.jlo.scheduler.service.SchedulerService;
import com.locus.jlo.web.services.impl.BaseService;

import lombok.extern.slf4j.Slf4j;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import javax.servlet.ServletContext;
import org.quartz.CronExpression;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import static org.quartz.TriggerBuilder.newTrigger;
import org.quartz.TriggerKey;
import org.quartz.impl.JobDetailImpl;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.quartz.impl.matchers.KeyMatcher;
import static org.quartz.CronScheduleBuilder.cronSchedule;
import org.quartz.JobDataMap;
import org.springframework.beans.factory.annotation.Value;

@Slf4j
@Service
public class SchedulerServiceImpl extends BaseService implements SchedulerService {

    final static String SQL_FIND_ALL_SCHEDULER = "SCHEDULER.FIND_ALL_SCHEDULER";
    final static String SQL_FIND_SCHEDULER_BY_ID = "SCHEDULER.FIND_SCHEDULER_BY_ID";
    final static String SQL_FIND_SCHEDULER_HISTORY_BY_SCHEDULER_ID = "SCHEDULER.FIND_SCHEDULER_HISTORY_BY_SCHEDULER_ID";
    final static String SQL_INSERT_SCHEDULER = "SCHEDULER.INSERT_SCHEDULER";
    final static String SQL_INSERT_SCHEDULER_HISTORY = "SCHEDULER.INSERT_SCHEDULER_HISTORY";
    final static String SQL_UPDATE_HISTORY = "SCHEDULER.UPDATE_SCHEDULER";

    final static private SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");

    @Autowired
    private SchedulerFactoryBean schedulerFactoryBean;

    @Value("${scheduler.context}")
    private String schedulerContext;

    @Autowired
    private ServletContext servletContext;

    @Override
    public ServiceResult<List<SchedulerBean>> findAllScheduler() {
        final ServiceResult<List<SchedulerBean>> result = new ServiceResult<>();
        try {
            final List<SchedulerBean> obj = dynamicJdbcDao.findForList(SQL_FIND_ALL_SCHEDULER,
                    BeanPropertyRowMapper.newInstance(SchedulerBean.class));
            result.setResult(obj);
            result.setSuccess(Boolean.TRUE);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(result, e);
        }
        return result;
    }

    @Override
    public ServiceResult<Page<SchedulerBean>> findAllScheduler(Pageable pageable) {
        final ServiceResult<Page<SchedulerBean>> result = new ServiceResult<>();
        try {
            final Page<SchedulerBean> obj = dynamicJdbcDao.findForPage(SQL_FIND_ALL_SCHEDULER,
                    BeanPropertyRowMapper.newInstance(SchedulerBean.class), pageable);
            List<SchedulerBean> runningList = listRunningJobs();
            List<SchedulerBean> allJobsDetailList = listAllJobs();
            for (SchedulerBean schedulerBean : obj.getContent()) {
                for (SchedulerBean a : allJobsDetailList) {
                    if (schedulerBean.getSchedulerId().equals(a.getSchedulerId())) {
                        if (a.getNextFireTime() != null) {
                            schedulerBean.setStatus("Next run " + sdf.format(a.getNextFireTime()));
                        }
                    }
                }
                for (SchedulerBean r : runningList) {
                    if (schedulerBean.getSchedulerId().equals(r.getSchedulerId())) {
                        schedulerBean.setStatus("Running");
                    }
                }
            }
            result.setResult(obj);
            result.setSuccess(Boolean.TRUE);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(result, e);
        }
        return result;
    }

    @Override
    public ServiceResult<SchedulerBean> findSchedulerById(Long id) {
        final ServiceResult<SchedulerBean> result = new ServiceResult<>();
        try {
            final SchedulerBean obj = dynamicJdbcDao.findForObject(SQL_FIND_SCHEDULER_BY_ID,
                    BeanPropertyRowMapper.newInstance(SchedulerBean.class), new SimpleKeyValue("id", id));
            result.setResult(obj);
            result.setSuccess(Boolean.TRUE);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(result, e);
        }
        return result;
    }

    @Override
    public ServiceResult<Page<SchedulerHistoryBean>> findSchedulerHistoryBySchedulerId(Long schedulerId, Pageable pageable) {
        final ServiceResult<Page<SchedulerHistoryBean>> result = new ServiceResult<>();
        try {
            final Page<SchedulerHistoryBean> obj = dynamicJdbcDao.findForPage(SQL_FIND_SCHEDULER_HISTORY_BY_SCHEDULER_ID,
                    BeanPropertyRowMapper.newInstance(SchedulerHistoryBean.class),
                    pageable,
                    new SimpleKeyValue("schedulerId", schedulerId));
            result.setResult(obj);
            result.setSuccess(Boolean.TRUE);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(result, e);
        }
        return result;
    }

    @Override
    public ServiceResult<Long> insertScheduler(SchedulerBean schedulerModelBean) {
        final ServiceResult<Long> result = new ServiceResult<>();
        try {
            final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_SCHEDULER, Boolean.TRUE, schedulerModelBean);
            result.setResult(id);
            result.setSuccess(Boolean.TRUE);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(result, e);
        }
        return result;
    }

    @Override
    public ServiceResult<Long> insertSchedulerHistory(SchedulerHistoryBean schedulerHistoryModelBean) {
        final ServiceResult<Long> result = new ServiceResult<>();
        try {
        	
            final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_SCHEDULER_HISTORY, Boolean.TRUE,
                    schedulerHistoryModelBean);
            result.setResult(id);
            result.setSuccess(Boolean.TRUE);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(result, e);
        }
        return result;
    }

    @Override
    public void updateScheduler(SchedulerBean schedulerModelBean) {
        try {
            dynamicJdbcDao.executeUpdate(SQL_UPDATE_HISTORY, schedulerModelBean);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    @Override
    public void scheduleJob(SchedulerBean schedulerModelBean) throws ClassNotFoundException, SchedulerException
    {
        if (!runOnThisContext()) {
            log.info(">>>>> Scheduler Job " + schedulerModelBean.getSchedulerName() + " not running on this Context (" + servletContext.getContextPath() + ") <<<<<");
            return;
        }
        if (CronExpression.isValidExpression(schedulerModelBean.getExpressions())) {log.info("==========================>>>>> getHostName: [{}]", getHostName());
            final String jobName = schedulerModelBean.getSchedulerName();
            final String group = "group_" + jobName;
            final int priority = schedulerModelBean.getPriority();
            final long jobId = schedulerModelBean.getSchedulerId();
            final Class<?> klass = Class.forName(schedulerModelBean.getClasspath());
            final JobDetail jobDetail = createJob(jobName, group, klass, jobId);
            final Trigger trigger = newTrigger()
                    .forJob(jobDetail)
                    .withIdentity(jobName, group)
                    .withPriority(priority)
                    .withSchedule(cronSchedule(schedulerModelBean.getExpressions()).inTimeZone(TimeZone.getTimeZone("GMT+7")))
                    .build();
            if (schedulerFactoryBean.getScheduler().checkExists(new TriggerKey(jobName, group))) {
                log.info(">>>>> Delete Job : " + jobName + " <<<<<");
                schedulerFactoryBean.getScheduler().unscheduleJob(trigger.getKey());
                schedulerFactoryBean.getScheduler().deleteJob(new JobKey(jobName, group));
            }
            if (!active(schedulerModelBean)) {
                log.info(">>>>> Job " + jobName + " is not activated <<<<<");
                return;
            }
            setJobDataMap(jobDetail, schedulerModelBean);
            log.info(">>>>> Add Job " + jobName + " with expression : " + schedulerModelBean.getExpressions() + "<<<<<");
            schedulerFactoryBean.getScheduler().addJob(jobDetail, true, true);
            schedulerFactoryBean.getScheduler().scheduleJob(trigger);
            schedulerFactoryBean.getScheduler().getListenerManager()
                    .addJobListener(new QuartzCustomListener(jobName), KeyMatcher.keyEquals(jobDetail.getKey()));
        }
    }

    private boolean active(SchedulerBean schedulerModelBean) {
        return schedulerModelBean.getEnabled() && getHostName().equals(schedulerModelBean.getInstance());
    }

    private String getHostName() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException ex) {
            return "";
        }
    }

    @Override
    public void cancelJob(SchedulerBean schedulerModelBean) throws SchedulerException {
        final String jobName = schedulerModelBean.getSchedulerName();
        final String group = "group_" + jobName;
        if (schedulerFactoryBean.getScheduler().checkExists(new TriggerKey(jobName, group))) {
            log.info("Delete Job : " + jobName);
            schedulerFactoryBean.getScheduler().deleteJob(new JobKey(jobName, group));
        } else {
            log.info("Job " + jobName + " is not found");
        }
    }

    @Override
    public void shutdownScheduler() throws SchedulerException {
        log.info("Shutting down Scheduler");
        boolean waitJobsToComplete = false;
        schedulerFactoryBean.getScheduler().shutdown(waitJobsToComplete);
    }

    @Override
    public void interruptJob(SchedulerBean schedulerModelBean) throws SchedulerException {
        final String jobName = schedulerModelBean.getSchedulerName();
        final String group = "group_" + jobName;
        schedulerFactoryBean.getScheduler().interrupt(new JobKey(jobName, group));
    }

    @SuppressWarnings("unchecked")
	@Override
    public List<SchedulerBean> listAllJobs() throws SchedulerException {
        final Scheduler scheduler = schedulerFactoryBean.getScheduler();
        final List<SchedulerBean> schedulerModelBeans = new ArrayList<>();
        for (String groupName : scheduler.getJobGroupNames()) {
            for (JobKey jobKey : scheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName))) {
                final List<Trigger> triggers = (List<Trigger>) scheduler.getTriggersOfJob(jobKey);
                final Date nextFireTime = triggers.iterator().next().getNextFireTime();
                final JobDataMap jobDataMap = schedulerFactoryBean.getScheduler().getJobDetail(jobKey).getJobDataMap();
                final SchedulerBean schedulerModelBean = new SchedulerBean();
                schedulerModelBean.setSchedulerId(jobDataMap.getLong(SchedulerConstant.SCHEDULER_ID));
                schedulerModelBean.setSchedulerName(jobKey.getName());
                schedulerModelBean.setGroup(jobKey.getGroup());
                schedulerModelBean.setNextFireTime(nextFireTime);
                schedulerModelBeans.add(schedulerModelBean);
                log.info("[jobName] : " + jobKey.getName() + " [groupName] : " + jobKey.getGroup() + " - " + nextFireTime);
            }
        }
        return schedulerModelBeans;
    }

    @Override
    public List<SchedulerBean> listRunningJobs() throws SchedulerException {
        final List<JobExecutionContext> jobExecutionContexts
                = schedulerFactoryBean.getScheduler().getCurrentlyExecutingJobs();
        final List<SchedulerBean> schedulerModelBeans = new ArrayList<>();
        for (JobExecutionContext j : jobExecutionContexts) {
            final JobKey jobKey = j.getJobDetail().getKey();
            final JobDataMap jobDataMap = schedulerFactoryBean.getScheduler().getJobDetail(jobKey).getJobDataMap();
            final SchedulerBean schedulerModelBean = new SchedulerBean();
            schedulerModelBean.setSchedulerId(jobDataMap.getLong(SchedulerConstant.SCHEDULER_ID));
            schedulerModelBean.setSchedulerName(jobKey.getName());
            schedulerModelBean.setGroup(jobKey.getGroup());
            schedulerModelBean.setFireTime(j.getFireTime());
            schedulerModelBean.setNextFireTime(j.getNextFireTime());
            schedulerModelBeans.add(schedulerModelBean);
        }
        return schedulerModelBeans;
    }

    @Override
    public void executeJob(SchedulerBean schedulerBean) throws Exception {
    	executeJob(schedulerBean, null, null);
    }

    @Override
    public void executeJob(SchedulerBean schedulerBean, Date startDate, Date endDate) throws Exception {
        final Class<?> klass = Class.forName(schedulerBean.getClasspath());
        final String jobName = schedulerBean.getSchedulerName() + "_onetime";
        final String group = "group_" + jobName;
        final long jobId = schedulerBean.getSchedulerId();
        final JobDetail jobDetail = createJob(jobName, group, klass, jobId, startDate, endDate);

        final Trigger trigger = newTrigger()
                .forJob(jobDetail)
                .withIdentity(jobName, group)
                .withPriority(100)
                .startNow()
                .build();

        if (schedulerFactoryBean.getScheduler().checkExists(new TriggerKey(jobName, group))) {
            log.info("Job " + jobName + " is running");
        } else {
            log.info("adding one time job : " + jobName);
            schedulerFactoryBean.getScheduler().addJob(jobDetail, true, true);
            schedulerFactoryBean.getScheduler().scheduleJob(trigger);
            schedulerFactoryBean.getScheduler().getListenerManager()
                    .addJobListener(new QuartzCustomListener(jobName), KeyMatcher.keyEquals(jobDetail.getKey()));
            jobDetail.getJobDataMap().put(SchedulerConstant.MANUAL_EXECUTE, true);
        }
    }

    @SuppressWarnings("rawtypes")
	private JobDetail createJob(String jobName, String groupName, Class jobClass, long jobId) {
    	return createJob(jobName, groupName, jobClass, jobId, null, null);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	private JobDetail createJob(String jobName, String groupName, Class jobClass, long jobId, Date startDate, Date endDate) {
        JobDetailImpl jobDetail = new JobDetailImpl();
        jobDetail.setKey(new JobKey(jobName, groupName));
        jobDetail.setJobClass(jobClass);
        jobDetail.getJobDataMap().put(SchedulerConstant.RETRY_COUNT, 0);
        jobDetail.getJobDataMap().put(SchedulerConstant.SCHEDULER_ID, jobId);
        
        jobDetail.getJobDataMap().put(SchedulerConstant.SCHEDULE_START_DATE, startDate);
        jobDetail.getJobDataMap().put(SchedulerConstant.SCHEDULE_END_DATE, endDate);
        
        return jobDetail;
    }

    private void setJobDataMap(JobDetail jobDetail, SchedulerBean schedulerModelBean) {
        jobDetail.getJobDataMap().put(SchedulerConstant.EXPRESSION_ORIGINAL, schedulerModelBean.getExpressions());
        jobDetail.getJobDataMap().put(SchedulerConstant.PRIORITY, schedulerModelBean.getPriority());
        jobDetail.getJobDataMap().put(SchedulerConstant.RETRY_FLAG, schedulerModelBean.getRetry());
        final Integer delay = schedulerModelBean.getRetryDelay() == null ? 0 : schedulerModelBean.getRetryDelay();
        jobDetail.getJobDataMap().put(SchedulerConstant.RETRY_DELAY, delay);
        final Integer max = schedulerModelBean.getRetryMax() == null ? 0 : schedulerModelBean.getRetryMax();
        jobDetail.getJobDataMap().put(SchedulerConstant.RETRY_MAX, max);

    }

    @Override
    public ServiceResult<Boolean> deleteScheduler(Long id) {
        ServiceResult<Boolean> result = new ServiceResult<>();
        try {
            dynamicJdbcDao.executeUpdate("SCHEDULER.DELETE_SCHEDULER", new SimpleKeyValue("id", id));
            result.setResult(Boolean.TRUE);
        } catch (Exception ex) {
            setErrorResult(result, ex);
        }
        return result;
    }

	@Override
	public boolean runOnThisContext()
	{
		log.info("schedulerContext: [{}], servletContext: [{}]", schedulerContext, servletContext.getContextPath());
		boolean output = false;
		try
		{
			output = schedulerContext.equals(servletContext.getContextPath());
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			output = false;
		}
		return output;
	}
    
//========================================================================================================
	@Override
	public List<SchedulerBean> select(SchedulerBean bean) throws Exception
	{
		List<SchedulerBean> result = null;
		try
		{
			result = dynamicJdbcDao.findForList("SCHEDULER.SELECT", BeanPropertyRowMapper.newInstance(SchedulerBean.class), bean);
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			throw ex;
		}
		return result;
	}
	
	@Override
	public SchedulerBean save(final SchedulerBean schedulerBean, String userId, Date time) throws Exception
	{
		try
		{
			if (schedulerBean.getSchedulerId() != null)
			{
				schedulerBean.setChgId(new Long(userId));
				schedulerBean.setChgDt(time);
				
				update(schedulerBean);
			} else
			{
				if (schedulerBean.getInstance() == null || schedulerBean.getInstance().trim().length() > 0)
					schedulerBean.setInstance(getHostName());
				schedulerBean.setRegId(new Long(userId));
				schedulerBean.setRegDt(time);
				
				Long newId = insert(schedulerBean);
				schedulerBean.setSchedulerId(newId);
			}
			
			scheduleJob(schedulerBean);
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			throw ex;
		}
		return schedulerBean;
	}

	@Override
	public Long insert(SchedulerBean schedulerBean) throws Exception
	{
		Long output = null;
		try
		{
			output = dynamicJdbcDao.executeInsert("SCHEDULER.INSERT", true, schedulerBean);
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			throw ex;
		}
		return output;
	}
	
	@Override
	public int update(SchedulerBean schedulerBean) throws Exception
	{
		int rowEff = -1;
		try
		{
			rowEff = dynamicJdbcDao.executeUpdate("SCHEDULER.UPDATE", schedulerBean);
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			throw ex;
		}
		return rowEff;
	}
	
	@Override
	public int deleteById(Long schedulerId) throws Exception
	{
		int rowEff;
		try
		{
			rowEff = dynamicJdbcDao.executeUpdate("SCHEDULER.DELETE_BY_ID", new SimpleKeyValue("schedulerId", schedulerId));
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			throw ex;
		}
		return rowEff;
	}
	
	@Override
	public List<SchedulerHistoryBean> selectSchedulerHistory(SchedulerHistoryBean bean) throws Exception
	{
		List<SchedulerHistoryBean> output = null;
		try
		{
			output = dynamicJdbcDao.findForList("SCHEDULER_LOG.SELECT", BeanPropertyRowMapper.newInstance(SchedulerHistoryBean.class), bean);
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			throw ex;
		}
		return output;
	}
}
