package com.locus.jlo.web.controller.report;

import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.Chart;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.SheetConditionalFormatting;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFConditionalFormattingRule;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTAxDataSource;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBarChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBarSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTCatAx;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTLegend;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTNumDataSource;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTNumRef;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPlotArea;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTScaling;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSerTx;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTStrRef;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTValAx;
import org.openxmlformats.schemas.drawingml.x2006.chart.STAxPos;
import org.openxmlformats.schemas.drawingml.x2006.chart.STBarDir;
import org.openxmlformats.schemas.drawingml.x2006.chart.STLegendPos;
import org.openxmlformats.schemas.drawingml.x2006.chart.STOrientation;
import org.openxmlformats.schemas.drawingml.x2006.chart.STTickLblPos;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTCfRule;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTCfvo;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTColor;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTDataBar;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.STCfType;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.STCfvoType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.report.utilization.UtilizationAccumGroupReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationAccumReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationGraphReportCriteria;
import com.locus.jlo.web.beans.report.utilization.UtilizationGraphReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationMonthlyGroupReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationMonthlyReportRes;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class UtilizationReportController {

	@Autowired
	private ExcelReportService excelReportService;

	@RequestMapping(value = "/searchUtilizationGraphReport", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchUtilizationGraphReport(HttpServletRequest request, Locale locale) throws Exception {

		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);

		JsonResultBean validResult = validateCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		UtilizationGraphReportCriteria criteria = getCriteria(json);
		Map<String, Object> m = new HashMap<String, Object>();

		JsonResultBean result = null;
		ServiceResult<List<UtilizationGraphReportRes>> listResult = excelReportService.searchUtilizationGraphReport(criteria);

		if (listResult.isSuccess()) {
			m.put("result", listResult.getResult());
			result = new JsonResultBean("success", "", m);
		} else {
			log.info("fail_Respones : ");
		}
		return result;
	}

	@RequestMapping(value = "/validateCriteriaUtilization", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateCriteriaUtilization(HttpServletRequest request, Locale locale)	throws Exception {
		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);
		return validateCriteria(json);
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportUtilizationGraphReport", method = RequestMethod.POST)
	public @ResponseBody void exportUtilizationGraphReport(HttpServletRequest request, HttpServletResponse response, UtilizationGraphReportCriteria cr) throws Exception {

		OutputStream outputStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("employeeName", cr.getEmployeeName());
			jsonObj.put("yearSpentOn", cr.getYearSpentOn());
			jsonObj.put("monthSpentOn", cr.getMonthSpentOn());
			jsonObj.put("employeeNameTe", cr.getEmployeeNameTe());
			jsonObj.put("utilizeYear", cr.getUtilizeYear());
			jsonObj.put("utilizeMonth", cr.getUtilizeMonth());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());

			UtilizationGraphReportCriteria attendanceReportCriteria = getCriteria(jsonObj);

			ServiceResult<List<UtilizationGraphReportRes>> listResult = excelReportService.searchUtilizationGraphReport(attendanceReportCriteria);

			int rowCount = 0;
			int columnCount = 0;
			List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
			List<Integer[]> mergeList = new ArrayList<Integer[]>();

			XSSFCellStyle cellStyleR1 = PoiUtils.creatCellStyle(wb, "Angsana New", true, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleG1 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
			XSSFCellStyle cellStyleG3 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.RED.index);

			// row1
			columnCount = 0;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Utilization rate", cellStyleR1));
			mergeList.add(new Integer[] { 0, 0, 0, 13 });
			// row2
			rowCount++;
			columnCount = 0;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Division", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Jan", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Feb", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Mar", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Apr", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "May", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Jun", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Jul", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Aug", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Sep", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Oct", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Nov", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dec", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Acc", cellStyleG3));

			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);

			for (UtilizationGraphReportRes rec : listResult.getResult()) {
				rowCount++;
				columnCount = 0;
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDivision(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getJanPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getFebPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getMarPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getAprPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getMayPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getJunPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getJulPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getAugPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getSepPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getOctPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNovPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDecPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getAccPercentChargable()), cellStyleCenter));
			}

			wb = PoiUtils.createSheet(wb, "UtilizationGraphReport", lstExObj, mergeList, true);
			wb.getSheet("UtilizationGraphReport").autoSizeColumn((short) 0);
			
			XSSFSheet chartSheet = wb.createSheet("Chart");
			Drawing drawing = chartSheet.createDrawingPatriarch();
			ClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, 0, 10, 20);
			Chart chart = drawing.createChart(anchor);
			int firstCell = 1;
			int lastCell = firstCell + listResult.getResult().size();
			CellReference firstDataCell = new CellReference("UtilizationGraphReport", firstCell, 0, true, true);
			CellReference lastDataCell = new CellReference("UtilizationGraphReport", lastCell, 13, true, true);
			CTChart ctChart = ((XSSFChart) chart).getCTChart();
			CTPlotArea ctPlotArea = ctChart.getPlotArea();
			CTBarChart ctBarChart = ctPlotArea.addNewBarChart();
			CTBoolean ctBoolean = ctBarChart.addNewVaryColors();
			ctBoolean.setVal(true);
			ctBarChart.addNewBarDir().setVal(STBarDir.COL);

			int firstDataRow = firstDataCell.getRow();
			int lastDataRow = lastDataCell.getRow();
			int firstDataCol = firstDataCell.getCol();
			int lastDataCol = lastDataCell.getCol();
			String dataSheet = firstDataCell.getSheetName();

			int idx = 0;
			for (int r = firstDataRow + 1; r < lastDataRow + 1; r++) {
				CTBarSer ctBarSer = ctBarChart.addNewSer();
				CTSerTx ctSerTx = ctBarSer.addNewTx();
				CTStrRef ctStrRef = ctSerTx.addNewStrRef();
				ctStrRef.setF(new CellReference(dataSheet, r, firstDataCol, true, true).formatAsString());

				ctBarSer.addNewIdx().setVal(idx++);
				CTAxDataSource cttAxDataSource = ctBarSer.addNewCat();
				ctStrRef = cttAxDataSource.addNewStrRef();

				ctStrRef.setF(
						new AreaReference(new CellReference(dataSheet, firstDataRow, firstDataCol + 1, true, true),
								new CellReference(dataSheet, firstDataRow, lastDataCol, true, true),
								SpreadsheetVersion.EXCEL2007).formatAsString());

				CTNumDataSource ctNumDataSource = ctBarSer.addNewVal();
				CTNumRef ctNumRef = ctNumDataSource.addNewNumRef();

				ctNumRef.setF(new AreaReference(new CellReference(dataSheet, r, firstDataCol + 1, true, true),
						new CellReference(dataSheet, r, lastDataCol, true, true), SpreadsheetVersion.EXCEL2007)
								.formatAsString());
				// at least the border lines in Libreoffice Calc ;-)
				ctBarSer.addNewSpPr().addNewLn().addNewSolidFill().addNewSrgbClr().setVal(new byte[] { 0, 0, 0 });

			}

			ctBarChart.addNewAxId().setVal(123456);
			ctBarChart.addNewAxId().setVal(123457);

			// cat axis
			CTCatAx ctCatAx = ctPlotArea.addNewCatAx();
			ctCatAx.addNewAxId().setVal(123456); // id of the cat axis
			CTScaling ctScaling = ctCatAx.addNewScaling();
			ctScaling.addNewOrientation().setVal(STOrientation.MIN_MAX);
			ctCatAx.addNewDelete().setVal(false);
			ctCatAx.addNewAxPos().setVal(STAxPos.B);
			ctCatAx.addNewCrossAx().setVal(123457); // id of the val axis
			ctCatAx.addNewTickLblPos().setVal(STTickLblPos.NEXT_TO);

			// val axis
			CTValAx ctValAx = ctPlotArea.addNewValAx();
			ctValAx.addNewAxId().setVal(123457); // id of the val axis
			ctScaling = ctValAx.addNewScaling();
			ctScaling.addNewOrientation().setVal(STOrientation.MIN_MAX);
			ctValAx.addNewDelete().setVal(false);
			ctValAx.addNewAxPos().setVal(STAxPos.L);
			ctValAx.addNewCrossAx().setVal(123456); // id of the cat axis
			ctValAx.addNewTickLblPos().setVal(STTickLblPos.NEXT_TO);

			// legend
			CTLegend ctLegend = ctChart.addNewLegend();
			ctLegend.addNewLegendPos().setVal(STLegendPos.B);
			ctLegend.addNewOverlay().setVal(false);

			ctChart.getLegend().unsetLegendPos();
			ctChart.getLegend().addNewLegendPos().setVal(STLegendPos.R);

			// data labels:
			CTBoolean ctboolean = CTBoolean.Factory.newInstance();
			ctboolean.setVal(true);
			ctChart.getPlotArea().getBarChartArray(0).addNewDLbls().setShowVal(ctboolean);
			ctboolean.setVal(false);
			ctChart.getPlotArea().getBarChartArray(0).getDLbls().setShowSerName(ctboolean);
			ctChart.getPlotArea().getBarChartArray(0).getDLbls().setShowPercent(ctboolean);
			ctChart.getPlotArea().getBarChartArray(0).getDLbls().setShowLegendKey(ctboolean);
			ctChart.getPlotArea().getBarChartArray(0).getDLbls().setShowCatName(ctboolean);
			ctChart.getPlotArea().getBarChartArray(0).getDLbls().setShowLeaderLines(ctboolean);
			ctChart.getPlotArea().getBarChartArray(0).getDLbls().setShowBubbleSize(ctboolean);

			ctChart.getPlotArea().getValAxArray(0).getScaling().addNewMax().setVal(100);

			// cat axis title:
			ctChart.getPlotArea().getCatAxArray(0).addNewTitle().addNewOverlay().setVal(false);
			ctChart.getPlotArea().getCatAxArray(0).getTitle().addNewTx().addNewRich().addNewBodyPr();
			ctChart.getPlotArea().getCatAxArray(0).getTitle().getTx().getRich().addNewP().addNewR().setT("Utilization rate");

			// series colors:
			ctChart.getPlotArea().getBarChartArray(0).getSerArray(0).getSpPr().addNewSolidFill().addNewSrgbClr()
					.setVal(new byte[] { 0, 0, (byte) 255 });
			ctChart.getPlotArea().getBarChartArray(0).getSerArray(1).getSpPr().addNewSolidFill().addNewSrgbClr()
					.setVal(new byte[] { 0, (byte) 255, 0 });

			response.addHeader("Content-Disposition", "attachment; filename=\"UtilizationGraphReport.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			outputStream.flush();
			outputStream.close();
			wb.close();
		}
	}
	
	@RequestMapping(value = "/searchUtilizationMonthlyReport", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchUtilizationMonthlyReport(HttpServletRequest request, Locale locale) throws Exception {

		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);

		JsonResultBean validResult = validateCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		UtilizationGraphReportCriteria criteria = getCriteria(json);
		Map<String, Object> m = new HashMap<String, Object>();

		JsonResultBean result = null;
		ServiceResult<List<UtilizationMonthlyReportRes>> listResult = excelReportService.searchUtilizationMonthlyReport(criteria);

		if (listResult.isSuccess()) {
			m.put("result", listResult.getResult());
			result = new JsonResultBean("success", "", m);
		} else {
			log.info("fail_Respones : ");
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportUtilizationMonthlyReport", method = RequestMethod.POST)
	public @ResponseBody void exportUtilizationMonthlyReport(HttpServletRequest request, HttpServletResponse response, UtilizationGraphReportCriteria cr) throws Exception {

		OutputStream outputStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("employeeName", cr.getEmployeeName());
			jsonObj.put("yearSpentOn", cr.getYearSpentOn());
			jsonObj.put("monthSpentOn", cr.getMonthSpentOn());
			jsonObj.put("employeeNameTe", cr.getEmployeeNameTe());
			jsonObj.put("utilizeYear", cr.getUtilizeYear());
			jsonObj.put("utilizeMonth", cr.getUtilizeMonth());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());

			UtilizationGraphReportCriteria attendanceReportCriteria = getCriteria(jsonObj);

			ServiceResult<List<UtilizationMonthlyReportRes>> listResult = excelReportService.searchUtilizationMonthlyReport(attendanceReportCriteria);
			ServiceResult<List<UtilizationMonthlyGroupReportRes>> listGroupResult = excelReportService.searchUtilizationMonthlyGroupReport(attendanceReportCriteria);

			int rowCount = 0;
			int columnCount = 0;
			List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
			List<Integer[]> mergeList = new ArrayList<Integer[]>();

			XSSFCellStyle cellStyleR1 = PoiUtils.creatCellStyle(wb, "Angsana New", true, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleG1 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
			XSSFCellStyle cellStyleG2 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.LIGHT_BLUE.index);
			XSSFCellStyle cellStyleG3 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BROWN.index);
			XSSFCellStyle cellStyleG4 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.RED.index);
			XSSFCellStyle cellStyleG5 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.GREY_50_PERCENT.index);

			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleRight = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.RIGHT);

			// row1
			columnCount = 0;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Utilization Monthy", cellStyleR1));
			mergeList.add(new Integer[] { 0, 0, 0, 27 });
			
			for (UtilizationMonthlyGroupReportRes grp : listGroupResult.getResult()) {
				rowCount++;
				columnCount = 18;
				lstExObj.add(new ExcelObject(rowCount, columnCount++, grp.getDivision(), cellStyleRight));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(grp.getPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(grp.getPercentNonChargable()), cellStyleCenter));
			}
			// row2
			rowCount++;
			int firstDataRow = rowCount;
			int lastDataRow = 0;
			columnCount = 0;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp Name", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp. Code", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Division", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OC Code", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Level", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total wroking Hr", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Charagable", cellStyleG2));
			columnCount +=2;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Non Chargable(Hours)", cellStyleG3));
			columnCount +=5;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Not Booking Status not approved", cellStyleG4));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "% Chargable+OT", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total (Chargabel + Non Chargable)", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "% Chargable", cellStyleG2));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "% Non Chargable", cellStyleG3));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Non Chargable (Hours)", cellStyleG5));
			columnCount +=5;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Not Booking/Status not approved", cellStyleG4));

            mergeList.add(new Integer[]{ rowCount, rowCount+1, 0, 0});//Emp Name
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 1, 1});//Emp. Code
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 2, 2});//Division
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 3, 3});//OC Code
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 4, 4});//Level
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 5, 5});//Total wroking Hr
            mergeList.add(new Integer[]{ rowCount, rowCount, 6, 8});//Charagable
            mergeList.add(new Integer[]{ rowCount, rowCount, 9, 14});//Non Chargable(Hours)
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 15, 15});//Not Booking Status not approved
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 16, 16});//Total
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 17, 17});//% Chargable+OT
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 18, 18});//Total (Chargabel + Non Chargable)
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 19, 19});//% Chargable
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 20, 20});//% Non Chargable
            mergeList.add(new Integer[]{ rowCount, rowCount, 21, 26});//Non Chargable (Hours)
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 27, 27});//% Not Booking/Status not approved
            //row3
            rowCount++;
            columnCount = 6;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "(SI and MA)", cellStyleG2));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT HR", cellStyleG2));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total Work HR", cellStyleG2));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Presale", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Company Meeting", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Company Training", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Leave", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Admin/Unidentified", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Internal Project", cellStyleG3));
			columnCount +=6;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Presale", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Company Meeting", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Company Training", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Leave", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Admin/Unidentified", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Internal Project", cellStyleG5));
			
			for (UtilizationMonthlyReportRes rec : listResult.getResult()) {
				rowCount++;
				columnCount = 0;
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpname(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpCode(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDivision(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDivisionCode(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJobLevel(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTotalWorkingHr()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getChargeSima()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getChargeOtHr()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getChargeTotalWorkHr()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargePresale()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeCompanyMeeting()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeCompanyTraining()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeLeave()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeAdmin()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeInternal()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getStatusNotApproved()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTotal()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getPercentChargeOt(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTotalChargeNonCharge(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargePresale()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeCompanyMeeting()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeCompanyTraining()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeLeave()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeAdmin()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeInternal()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentStatusNotApproved()), cellStyleCenter));
			}
			lastDataRow = rowCount;

			wb = PoiUtils.createSheet(wb, "UtilizationMonthlyReport", lstExObj, mergeList, true);
			XSSFSheet sheet = wb.getSheet("UtilizationMonthlyReport");
			sheet.autoSizeColumn((short) 0);
			
			SheetConditionalFormatting cf = sheet.getSheetConditionalFormatting();
	        XSSFConditionalFormattingRule xcfrule = (XSSFConditionalFormattingRule)cf.createConditionalFormattingRule("");
	        Method m = XSSFConditionalFormattingRule.class.getDeclaredMethod("getCTCfRule");
	        m.setAccessible(true);
	        CTCfRule cfRule = (CTCfRule)m.invoke(xcfrule);
	        cfRule.removeFormula(0); // cleanup
	        cfRule.setType(STCfType.DATA_BAR);
	        CTDataBar databar = cfRule.addNewDataBar();
	        CTCfvo vfoMin = databar.addNewCfvo();
	        vfoMin.setType(STCfvoType.NUM);
	        vfoMin.setVal("0");
	        CTCfvo vfoMax = databar.addNewCfvo();
	        vfoMax.setType(STCfvoType.NUM);
	        vfoMax.setVal("100");
	        CTColor color = databar.addNewColor();
	        color.setRgb(new byte[]{(byte)0xFF, 0x00, 0x00, (byte)0xFF});

			int firstCell = 1;
			int lastCell = firstCell + listGroupResult.getResult().size();
	        CellRangeAddress cra[] = {new CellRangeAddress(firstCell, lastCell, 19, 19)};
	        CellRangeAddress craData[] = {new CellRangeAddress(firstDataRow, lastDataRow, 19, 19)};
	        cf.addConditionalFormatting(cra, xcfrule);
	        cf.addConditionalFormatting(craData, xcfrule);

			SheetConditionalFormatting cf2 = sheet.getSheetConditionalFormatting();
	        XSSFConditionalFormattingRule xcfrule2 = (XSSFConditionalFormattingRule)cf2.createConditionalFormattingRule("");
	        CTCfRule cfRule2 = (CTCfRule)m.invoke(xcfrule2);
	        cfRule2.removeFormula(0); // cleanup
	        cfRule2.setType(STCfType.DATA_BAR);
	        CTDataBar databar2 = cfRule2.addNewDataBar();
	        CTCfvo vfoMin2 = databar2.addNewCfvo();
	        vfoMin2.setType(STCfvoType.NUM);
	        vfoMin2.setVal("0");
	        CTCfvo vfoMax2 = databar2.addNewCfvo();
	        vfoMax2.setType(STCfvoType.NUM);
	        vfoMax2.setVal("100");
	        CTColor color2 = databar2.addNewColor();
	        color2.setRgb(new byte[]{(byte)0xFF, 0x00, (byte)0xFF});

	        CellRangeAddress cra2[] = {new CellRangeAddress(firstCell, lastCell, 20, 20)};
	        CellRangeAddress craData2[] = {new CellRangeAddress(firstDataRow, lastDataRow, 20, 26)};
	        cf.addConditionalFormatting(cra2, xcfrule2);
	        cf.addConditionalFormatting(craData2, xcfrule2);
	        
	        
			response.addHeader("Content-Disposition", "attachment; filename=\"UtilizationMonthlyReport.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			outputStream.flush();
			outputStream.close();
			wb.close();
		}
	}
	
	@RequestMapping(value = "/searchUtilizationAccumReport", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchUtilizationAccumReport(HttpServletRequest request, Locale locale) throws Exception {

		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);

		JsonResultBean validResult = validateCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		UtilizationGraphReportCriteria criteria = getCriteria(json);
		Map<String, Object> m = new HashMap<String, Object>();

		JsonResultBean result = null;
		ServiceResult<List<UtilizationAccumReportRes>> listResult = excelReportService.searchUtilizationAccumReport(criteria);

		if (listResult.isSuccess()) {
			m.put("result", listResult.getResult());
			result = new JsonResultBean("success", "", m);
		} else {
			log.info("fail_Respones : ");
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportUtilizationAccumReport", method = RequestMethod.POST)
	public @ResponseBody void exportUtilizationAccumReport(HttpServletRequest request, HttpServletResponse response, UtilizationGraphReportCriteria cr) throws Exception {

		OutputStream outputStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("employeeName", cr.getEmployeeName());
			jsonObj.put("yearSpentOn", cr.getYearSpentOn());
			jsonObj.put("monthSpentOn", cr.getMonthSpentOn());
			jsonObj.put("employeeNameTe", cr.getEmployeeNameTe());
			jsonObj.put("utilizeYear", cr.getUtilizeYear());
			jsonObj.put("utilizeMonth", cr.getUtilizeMonth());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());

			UtilizationGraphReportCriteria utilizationReportCriteria = getCriteria(jsonObj);

			ServiceResult<List<UtilizationAccumReportRes>> listResult = excelReportService.searchUtilizationAccumReport(utilizationReportCriteria);
			ServiceResult<List<UtilizationAccumGroupReportRes>> listGroupResult = excelReportService.searchUtilizationAccumGroupReport(utilizationReportCriteria);

			ServiceResult<List<UtilizationAccumReportRes>> listManDayResult = excelReportService.searchManDayFromUtilization(utilizationReportCriteria);
			String [] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sep", "Oct", "Nov", "Dec"};

			int rowCount = 0;
			int columnCount = 0;
			List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
			List<Integer[]> mergeList = new ArrayList<Integer[]>();

			XSSFCellStyle cellStyleR1 = PoiUtils.creatCellStyle(wb, "Angsana New", true, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleG1 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
			XSSFCellStyle cellStyleG2 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.LIGHT_BLUE.index);
			XSSFCellStyle cellStyleG3 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BROWN.index);
			XSSFCellStyle cellStyleG4 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.RED.index);
			XSSFCellStyle cellStyleG5 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.GREY_50_PERCENT.index);

			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleRight = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.RIGHT);

			// row1
			columnCount = 0;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Utilization Accum", cellStyleR1));
			mergeList.add(new Integer[] { 0, 0, 0, 42 });
			
			for (UtilizationAccumGroupReportRes grp : listGroupResult.getResult()) {
				rowCount++;
				columnCount = 33;
				lstExObj.add(new ExcelObject(rowCount, columnCount++, grp.getDivision(), cellStyleRight));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(grp.getPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(grp.getPercentNonChargable()), cellStyleCenter));
			}
			// row2
			rowCount++;
			int firstDataRow = rowCount;
			int lastDataRow = 0;
			columnCount = 0;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp Name", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp. Code", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Division", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OC Code", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Start Date", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "End Date", cellStyleG1));
			if(listManDayResult.isSuccess() && !listManDayResult.getResult().isEmpty()) {
				for(UtilizationAccumReportRes resp : listManDayResult.getResult()) {
					lstExObj.add(new ExcelObject(rowCount, columnCount++, resp.getManDay(), cellStyleG1));
				}
			}
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "No. of working day", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Level", cellStyleG1));;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total working Hr", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Charagable", cellStyleG2));
			columnCount +=2;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Non Chargable(Hours)", cellStyleG3));
			columnCount +=5;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Not Booking Status not approved", cellStyleG4));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total Working Hour(Chargabel + Non Chargable)", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "% Chargable+OT", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total (Chargabel + Non Chargable)", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "% Chargable", cellStyleG2));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "% Non Chargable", cellStyleG3));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Non Chargable (Hours)", cellStyleG5));
			columnCount +=5;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Not Booking/Status not approved", cellStyleG4));

            mergeList.add(new Integer[]{ rowCount, rowCount+1, 0, 0});//Emp Name
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 1, 1});//Emp. Code
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 2, 2});//Division
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 3, 3});//OC Code
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 4, 4});//Start Date
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 5, 5});//End Date
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 18, 18});//No. of working day
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 19, 19});//Level
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 20, 20});//Total working Hr
            mergeList.add(new Integer[]{ rowCount, rowCount, 21, 23});//Charagable
            mergeList.add(new Integer[]{ rowCount, rowCount, 24, 29});//Non Chargable(Hours)
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 30, 30});//Not Booking Status not approved
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 31, 31});//Total Working Hour(Chargabel + Non Chargable)
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 32, 32});//% Chargable+OT
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 33, 33});//Total (Chargabel + Non Chargable)
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 34, 34});//% Chargable
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 35, 35});//% Non Chargable
            mergeList.add(new Integer[]{ rowCount, rowCount, 36, 41});//Non Chargable (Hours)
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 42, 42});//% Not Booking/Status not approved
            //row3
            rowCount++;
            columnCount = 6;
            for (String month : months) {
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, month, cellStyleG1));
            }
            columnCount +=3;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "(SI and MA)", cellStyleG2));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT HR", cellStyleG2));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total Work HR", cellStyleG2));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Presale", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Company Meeting", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Company Training", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Leave", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Admin/Unidentified", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Internal Project", cellStyleG3));
			columnCount +=6;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Presale", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Company Meeting", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Company Training", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Leave", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Admin/Unidentified", cellStyleG5));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Internal Project", cellStyleG5));
			
			for (UtilizationAccumReportRes rec : listResult.getResult()) {
				rowCount++;
				columnCount = 0;
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpname(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpCode(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDivision(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDivisionCode(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getStartDate(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEndDate(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecWorkDay(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNoWorkingHr(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJobLevel(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTotalWorkingHr()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getChargeSima()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getChargeOtHr()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getChargeTotalWorkHr()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargePresale()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeCompanyMeeting()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeCompanyTraining()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeLeave()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeAdmin()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getNonChargeInternal()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getStatusNotApproved()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTotal()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getPercentChargeOt(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTotalChargeNonCharge(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargable()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargePresale()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeCompanyMeeting()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeCompanyTraining()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeLeave()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeAdmin()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentNonChargeInternal()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getPercentStatusNotApproved()), cellStyleCenter));
			}
			lastDataRow = rowCount;

			wb = PoiUtils.createSheet(wb, "UtilizationAccumReport", lstExObj, mergeList, true);
			XSSFSheet sheet = wb.getSheet("UtilizationAccumReport");
			sheet.autoSizeColumn((short) 0);
			
			SheetConditionalFormatting cf = sheet.getSheetConditionalFormatting();
	        XSSFConditionalFormattingRule xcfrule = (XSSFConditionalFormattingRule)cf.createConditionalFormattingRule("");
	        Method m = XSSFConditionalFormattingRule.class.getDeclaredMethod("getCTCfRule");
	        m.setAccessible(true);
	        CTCfRule cfRule = (CTCfRule)m.invoke(xcfrule);
	        cfRule.removeFormula(0); // cleanup
	        cfRule.setType(STCfType.DATA_BAR);
	        CTDataBar databar = cfRule.addNewDataBar();
	        CTCfvo vfoMin = databar.addNewCfvo();
	        vfoMin.setType(STCfvoType.NUM);
	        vfoMin.setVal("0");
	        CTCfvo vfoMax = databar.addNewCfvo();
	        vfoMax.setType(STCfvoType.NUM);
	        vfoMax.setVal("100");
	        CTColor color = databar.addNewColor();
	        color.setRgb(new byte[]{(byte)0xFF, 0x00, 0x00, (byte)0xFF});

			int firstCell = 1;
			int lastCell = firstCell + listGroupResult.getResult().size();
	        CellRangeAddress cra[] = {new CellRangeAddress(firstCell, lastCell, 34, 34)};
	        CellRangeAddress craData[] = {new CellRangeAddress(firstDataRow, lastDataRow, 34, 34)};
	        cf.addConditionalFormatting(cra, xcfrule);
	        cf.addConditionalFormatting(craData, xcfrule);

			SheetConditionalFormatting cf2 = sheet.getSheetConditionalFormatting();
	        XSSFConditionalFormattingRule xcfrule2 = (XSSFConditionalFormattingRule)cf2.createConditionalFormattingRule("");
	        CTCfRule cfRule2 = (CTCfRule)m.invoke(xcfrule2);
	        cfRule2.removeFormula(0); // cleanup
	        cfRule2.setType(STCfType.DATA_BAR);
	        CTDataBar databar2 = cfRule2.addNewDataBar();
	        CTCfvo vfoMin2 = databar2.addNewCfvo();
	        vfoMin2.setType(STCfvoType.NUM);
	        vfoMin2.setVal("0");
	        CTCfvo vfoMax2 = databar2.addNewCfvo();
	        vfoMax2.setType(STCfvoType.NUM);
	        vfoMax2.setVal("100");
	        CTColor color2 = databar2.addNewColor();
	        color2.setRgb(new byte[]{(byte)0xFF, 0x00, (byte)0xFF});

	        CellRangeAddress cra2[] = {new CellRangeAddress(firstCell, lastCell, 35, 35)};
	        CellRangeAddress craData2[] = {new CellRangeAddress(firstDataRow, lastDataRow, 35, 40)};
	        cf.addConditionalFormatting(cra2, xcfrule2);
	        cf.addConditionalFormatting(craData2, xcfrule2);
	        
	        
			response.addHeader("Content-Disposition", "attachment; filename=\"UtilizationAccumReport.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			outputStream.flush();
			outputStream.close();
			wb.close();
		}
	}

	private JsonResultBean validateCriteria(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg = "";
		String result_data = "";
		if (StringUtils.isEmpty(json.get("yearSpentOn"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill Year";
			return new JsonResultBean(result_status, result_msg, result_data);
		}
		if (StringUtils.isEmpty(json.get("monthSpentOn"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill Accum. to Month";
			return new JsonResultBean(result_status, result_msg, result_data);
		}
		return new JsonResultBean("success", "", "");
	}

	private UtilizationGraphReportCriteria getCriteria(JSONObject json) throws Exception {
		String yearSpentOn = json.get("yearSpentOn").toString();
		String monthSpentOn = json.get("monthSpentOn").toString();
		String department = json.get("department").toString();
		String division = json.get("division").toString();
		String section = json.get("section").toString();
		String employeeName = null;
		if (json.get("employeeName") != null) {
			employeeName = json.get("employeeName").toString();
		}
		UtilizationGraphReportCriteria criteria = new UtilizationGraphReportCriteria();

		if (!StringUtils.isEmpty(yearSpentOn)) {
			criteria.setYearSpentOn(yearSpentOn);
			criteria.setYearOt(yearSpentOn);
			criteria.setUtilizeYear(yearSpentOn);
		}
		if (!StringUtils.isEmpty(monthSpentOn)) {
			criteria.setMonthSpentOn(monthSpentOn);
			criteria.setMonthOt(monthSpentOn);
			criteria.setUtilizeMonth(monthSpentOn);
		}
		if (!StringUtils.isEmpty(division)) {
			criteria.setDivision(division);
		}
		if (!StringUtils.isEmpty(department)) {
			criteria.setDepartment(department);
		}
		if (!StringUtils.isEmpty(section)) {
			criteria.setSection(section);
			;
		}
		if (!StringUtils.isEmpty(employeeName)) {
			String ids = employeeName.replaceAll("\\[|\\]", "");
			List<String> listId = Arrays.asList(ids.split(","));
			if (listId.size() > 1) {
				listId = JsonBeanUtils.jsonToList(employeeName);
			}
			criteria.setEmployeeName(listId);
			criteria.setEmployeeNameOt(listId);
			criteria.setEmployeeNameTe(listId);
		}
		return criteria;
	}

}
