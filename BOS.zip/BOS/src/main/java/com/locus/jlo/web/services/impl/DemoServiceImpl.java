package com.locus.jlo.web.services.impl;

import com.locus.common.jdbc.DynamicJdbcDao;
import com.locus.jlo.web.services.DemoService;
import com.locus.jlo.web.beans.RoleBean;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class DemoServiceImpl implements DemoService {

    @Autowired
    private DynamicJdbcDao dynamicJdbcDao;

    @Override
    public List<RoleBean> getUserRoles() throws Exception {
        final List<RoleBean> claimBeans = dynamicJdbcDao.findForList("USER.FIND_ALL_ROLE",
                BeanPropertyRowMapper.newInstance(RoleBean.class));
        return claimBeans;
    }

}
