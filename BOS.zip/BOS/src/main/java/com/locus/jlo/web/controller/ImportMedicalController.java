package com.locus.jlo.web.controller;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.MedicalAllowanceService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class ImportMedicalController extends CoreController{

	
	 @Autowired private MedicalAllowanceService medicalAllowanceService;
	
	 @RequestMapping(value = {"/hr_import_medical"})
	 public String index() {
	        return "hr_import_medical";
	 }

	 @PostMapping(value = "importMedicalFile",consumes = "multipart/form-data")
	 //@RequestMapping(value = "/", method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean importMedicalFile( @RequestParam(value = "medicalFile", required = true) MultipartFile fileUpload,
             HttpServletRequest request, Locale locale) throws Exception{
	     
		 List<Object[]> list = new ArrayList<Object []>();
		 try{
			 log.info("File path : "+fileUpload.getOriginalFilename());
			 log.info("File size : "+fileUpload.getSize());
			 list = PoiUtils.importExcelFileArr(fileUpload.getInputStream(), 1 ,14);
			 
			 
		 }catch(Exception e){
			 e.printStackTrace();
		 }
	
		JsonResultBean result = new JsonResultBean("success", "", list);
   
		return result;
	}
	 
	 // create result array  for keep success of fail
	 // [LocusEmpID][data1][data2]...[end data] + [status][status message][user_id]
	 // loop save is success or not 
	//approve timesheet
	  @RequestMapping(value = "/checkAllMedicalAllowances", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	  public @ResponseBody JsonResultBean checkAllMedicalAllowances(HttpServletRequest request,Locale locale) throws Exception {
				log.info("approval save");
				
				 JsonResultBean res = null;
				
				 String result_status = "";
				 String result_msg    = "";
				 //String result_data   = "";
				
				 ServiceResult<List<DataBean>> result = new ServiceResult<>();
				 
				try{
			
				 String medicalAllowances = request.getParameter("mallowance");
		
				 JSONParser jParser = new JSONParser();
				 Object obj = jParser.parse(medicalAllowances);
				 JSONArray mallowanceArray = (JSONArray)obj;
				 log.info("get allowance size: "+mallowanceArray.size());
			
				 //keep current data + updated result 
				 List<DataBean> ma = new ArrayList<DataBean>();
				 
				 if(mallowanceArray.size() > 0){
					
					 for( int i=0;i<mallowanceArray.size();i++){
						 
						 result_status = "";
						 result_msg = "";
						 
						 JSONObject jObject = (JSONObject)mallowanceArray.get(i);
						 
						 
						 
						 DataBean db = new DataBean();
						 db.setA(jObject.get("empId").toString());
						 db.setB(convertTimestampToDate(jObject.get("receiptDate").toString()));
						 db.setC(jObject.get("receiptAmount").toString());
						 db.setD(convertTimestampToDate(jObject.get("paymentDate").toString()));
						 db.setE(jObject.get("hospital").toString());
						 db.setF(jObject.get("disease").toString());
						 db.setG(jObject.get("staffMedical").toString());
						 db.setH(jObject.get("staffDental").toString());
						 db.setI(jObject.get("staffEyes").toString());
						 db.setJ(jObject.get("familyMedical").toString());
						 db.setK(jObject.get("familyDental").toString());
						 db.setL(jObject.get("familyEyes").toString());
						 db.setM(jObject.get("note").toString());
						 db.setN(jObject.get("allowClaimAmount").toString());
						 
						result =  medicalAllowanceService.findUserByLocusEmpId( db.getA() );
						if( result.isSuccess()){
							
							   List<DataBean> tmp  = result.getResult();
							   if(tmp.size() != 0){
								   for(DataBean o : tmp ){
									 	if(StringUtils.isEmpty(o.getA())){
						            		result_status = "fail";
						            		result_msg = "Locus employee id is not found. ";
						            	}else
						            	if(StringUtils.isEmpty(o.getB())){
						            		if( o.getB().equals("N")){
						            			result_status = "fail";
							            		result_msg = "Staff not pass probation. ";
						            		}
						            	}else
						            	if(StringUtils.isEmpty(o.getC())){
						            		result_status = "fail";
						            		result_msg = "Staff account is not active. ";
						            	}else{
						            		//default is success
						            		//if success do insert
						            		result_status = "success";
						            		result_msg = "prepare do insert. ";
						            		
						            		//log.info("check receptDate :"+checkDateFormat(jObject.get("receiptDate").toString()));
						            		
						            		//check date format on last
						            		if(!StringUtils.isEmpty( convertTimestampToDate(jObject.get("receiptDate").toString()))){
						            			//log.info("check receptDate is not empty :"+checkDateFormat(jObject.get("receiptDate").toString()));
						            			
						            			//check 
						            			if( convertTimestampToDate(jObject.get("receiptDate").toString()).equals("dd/mm/yyyy")){
						            				
						            				//log.info("check receptDate equals dd/mm/yyyy :"+checkDateFormat(jObject.get("receiptDate").toString()));
						            				
						            				result_status = "fail";
								            		result_msg = "receipt date is wrong format (dd/mm/yyyy)";
						            			}
						            		
						            		}else{
						            			result_status = "fail";
							            		result_msg = "receipt date can not empty";
						            		}
						            		if(!StringUtils.isEmpty( convertTimestampToDate(jObject.get("paymentDate").toString()))){
						            			//check 
						            			if( convertTimestampToDate(jObject.get("paymentDate").toString()).equals("dd/mm/yyyy")){
						            				result_status = "fail";
								            		result_msg = "paymentDate date is wrong format (dd/mm/yyyy)";
						            			}
						            		}else{
						            			result_status = "fail";
							            		result_msg = "paymentDate date can not empty";
						            		}
						            	    
						            		
						            		// set user_id (prepare for insert );
						            		db.setT(o.getA());
						            		
						            		
						            		
						            		
						            	}
								
								 	
								   }
							   }else{
									result_status = "fail";
				            		result_msg = "Locus employee id is not found. ";
							   }
							
							
							 db.setU(result_status);
							 db.setV(result_msg);
								
								
						}else{ 
							//if can't not find records it mean no employee data found
							 
							//result_data   = "fail";
							result_status = "fail";
							result_msg    = "Locus employee miss match.";
							
							 db.setU(result_status);
							 db.setV(result_msg);
						}
						
						
						
						 ma.add(db);
						
						 
					 }
					 
					  log.info("data size : "+ma.size());
					  res = new JsonResultBean("success", "success" , ma);
					  
					
				 }else{
					 
					 //no updated records
					 //result_data   = "fail";
					 result_status = "fail";
					 result_msg    = "Data not found for process";
					 
				 }
			
				
			
				}catch(Exception e){
					
					result_status = "fail";
					result_msg    = "search fail";
					//result_data   = "";
					
					res = new JsonResultBean(result_status, result_msg , "" );
					log.info("Error !!"+e);
					e.printStackTrace();
				}
				
				
				 return res;
	 }
	  
	  
	  @RequestMapping(value = "/verifyMedicalAllowance", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean verifyMedicalAllowance(HttpServletRequest request,Locale locale) throws Exception{
		  
		  JsonResultBean res = null;
		  
		  String result_status = "";
		  String result_msg    = "";
		  //String result_data   = "";
		
		  ServiceResult<List<DataBean>> result = new ServiceResult<>();
		  
		  //keep current data + updated result 
		  List<DataBean> ma = new ArrayList<DataBean>();
			 
		  try{
			  
			     String medicalAllowances = request.getParameter("data");
				
				 JSONParser jParser = new JSONParser();
				 
				 Object obj = jParser.parse(medicalAllowances);
				 JSONArray mallowanceArray = (JSONArray)obj;
				 log.info("get allowance size: "+mallowanceArray.size());
			
				 
				 DataBean db = new DataBean();
				 
				 log.info("receipt date:"+mallowanceArray.get(1).toString());
				 log.info("payment date:"+mallowanceArray.get(4).toString());
				 
				 db.setA(mallowanceArray.get(0).toString());
				 db.setB(checkDateFormat(mallowanceArray.get(1).toString()));
				 db.setC(mallowanceArray.get(2).toString());
				 db.setN(mallowanceArray.get(3).toString());
				 db.setD(checkDateFormat(mallowanceArray.get(4).toString()));
				 db.setE(mallowanceArray.get(5).toString());
				 db.setF(mallowanceArray.get(6).toString());
				 db.setG(mallowanceArray.get(7).toString());
				 db.setH(mallowanceArray.get(8).toString());
				 db.setI(mallowanceArray.get(9).toString());
				 db.setJ(mallowanceArray.get(10).toString());
				 db.setK(mallowanceArray.get(11).toString());
				 db.setL(mallowanceArray.get(12).toString());
				 db.setM(mallowanceArray.get(13).toString());
			
				 
				 result =  medicalAllowanceService.findUserByLocusEmpId( db.getA() );
				 if( result.isSuccess()){
					
					   List<DataBean> tmp  = result.getResult();
					   if(tmp.size() != 0){
						   for(DataBean o : tmp ){
							 	if(StringUtils.isEmpty(o.getA())){
				            		result_status = "fail";
				            		result_msg = "Locus employee id is not found. ";
				            	}else
				            	if(StringUtils.isEmpty(o.getB())){
				            		if( o.getB().equals("N")){
				            			result_status = "fail";
					            		result_msg = "Staff not pass probation. ";
				            		}
				            	}else
				            	if(StringUtils.isEmpty(o.getC())){
				            		result_status = "fail";
				            		result_msg = "Staff account is not active. ";
				            	}else{
				            		//if success do insert
				            		result_status = "success";
				            		result_msg = "prepare do insert. ";
				            		//
				            		//last step is check date
				            		log.info("check receptDate :"+checkDateFormat(db.getB()));
				            		log.info("check paymentDate :"+checkDateFormat(db.getD()));
				            		
				            		//check date format on last
				            		//check payment date first
				            		if(!StringUtils.isEmpty( checkDateFormat(db.getD()))){
				            			//check 
				            			if( checkDateFormat(checkDateFormat(db.getD())).equals("dd/mm/yyyy")){
				            				result_status = "fail";
						            		result_msg = "paymentDate date is wrong format (dd/mm/yyyy)";
				            			}
				            		}else{
				            			result_status = "fail";
					            		result_msg = "paymentDate date can not empty";
				            		}
				            		
				            		//then check receipt date			            		
				            		if(!StringUtils.isEmpty( checkDateFormat(db.getB()))){
				            			//check 
				            			if( checkDateFormat(db.getB()).equals("dd/mm/yyyy")){
				            				result_status = "fail";
						            		result_msg = "receipt date is wrong format (dd/mm/yyyy)";
				            			} 
				            		
				            		}else{
				            			result_status = "fail";
					            		result_msg = "receipt date can not empty";
				            		}
				            		
				            	}
							 	
						   }
					   }else{
							result_status = "fail";
		            		result_msg = "Locus employee id is not found. ";
					   }
					   
					 
						 db.setU(result_status);
						 db.setV(result_msg);
						
						
				}else{ 
					//if can't not find records it mean no employee data found
					 
					//result_data   = "fail";
					result_status = "fail";
					result_msg    = "Locus employee miss match.";
					
				    db.setU(result_status);
				    db.setV(result_msg);
				}
				
				 
				 ma.add(db);  
				 log.info("data size : "+ma.size());
				 res = new JsonResultBean("success", "success" , ma);
			  
		  }catch(Exception e){
				
				result_status = "fail";
				result_msg    = "search fail";
				//result_data   = "";
				
				res = new JsonResultBean(result_status, result_msg , "" );
				log.info("Error !!"+e);
				e.printStackTrace();
			}
			
		  
		  return res;
	  }
	  
	  
	  @RequestMapping(value = "/startImportMedicalAllowance", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean startImportMedicalAllowance(HttpServletRequest request,Locale locale) throws Exception{
		  
		  
		  String UID = request.getSession().getAttribute("UID").toString();
		  
		  JsonResultBean res = null;
		  String result_status = "";
		  String result_msg    = "";
		  String result_data   = "";
		  
		  ServiceResult<Long> result = new ServiceResult<>();
			 
			try{
		
			 String medicalAllowances = request.getParameter("mallowance");
	
			 JSONParser jParser = new JSONParser();
			 Object obj = jParser.parse(medicalAllowances);
			 JSONArray mallowanceArray = (JSONArray)obj;
			 log.info("get allowance size: "+mallowanceArray.size());
		
			 //keep current data + updated result 
			 List<DataBean> ma = new ArrayList<DataBean>();
			 
			 if(mallowanceArray.size() > 0){
				
				 for( int i=0;i<mallowanceArray.size();i++){
					 
					 result_status = "";
					 result_msg = "";
					 
					 JSONObject jObject = (JSONObject)mallowanceArray.get(i);
					 
					 DataBean db = new DataBean();
					 db.setA(jObject.get("empId").toString());
					 db.setB(convertDate(jObject.get("receiptDate").toString())); //convert date
					 db.setC(jObject.get("receiptAmount").toString());
					 db.setD(convertDate(jObject.get("paymentDate").toString())); //convert date
					 db.setE(jObject.get("hospital").toString());
					 db.setF(jObject.get("disease").toString());
					 db.setG(nullToZero(jObject.get("staffMedical").toString()));
					 db.setH(nullToZero(jObject.get("staffDental").toString()));
					 db.setI(nullToZero(jObject.get("staffEyes").toString()));
					 db.setJ(nullToZero(jObject.get("familyMedical").toString()));
					 db.setK(nullToZero(jObject.get("familyDental").toString()));
					 db.setL(nullToZero(jObject.get("familyEyes").toString()));
					 db.setM(jObject.get("note").toString());
					 db.setN(jObject.get("allowClaimAmount").toString());
					 db.setT(UID); //create user id
					 
					
					 ma.add(db);
					 
				 }//end for
				 
				 
					result =  medicalAllowanceService.importMedicalAllowance( ma );
					if( result.isSuccess()){
							log.info( "get long : "+result.getResult().longValue() );
							result_data   = Long.toString(result.getResult().longValue());
							result_status = "success";
							result_msg    = "save successful";
							
					}else{
						result_status = "fail";
						result_msg    = "save fail";
					}
					
					res = new JsonResultBean(result_status, result_msg , result_data );
				 
				 
			 }//end if
						
						 
		}catch(Exception e){
		
			result_status = "fail";
			result_msg    = "search fail";
			result_data   = "";
			
			res = new JsonResultBean(result_status, result_msg , "" );
			log.info("Error !!"+e);
			e.printStackTrace();
			
		}
		  
		  return res;
	  }
	 
	  private static String checkDateFormat(String d){
		  
		  String result = d;
		  if(!StringUtils.isEmpty(d) ){
			try{
				 
				 //SimpleDateFormat parser = new SimpleDateFormat("dd/MM/yyyy");
				 //Date date = parser.parse(d);
				
				
			}catch(Exception e){
				result = "dd/mm/yyyy";
			}
		  }
			
			return result;
		  
	  }
	  
	  
	  //first import
	  private static String convertTimestampToDate(String d){
		    
		  //log.info("day : "+ d );
		  
		  String result = d;
		  if(!StringUtils.isEmpty(d) ){
			  
			  
			  
			/*
			  String[] m = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
			  
			  String[] str = d.split("-");
			  String day   = str[0];
			  String month = str[1];
			  String year  = str[2];
			  
			  
			  
			  switch(month){
				  case "Jan" : month = "01"; break;
				  case "Feb" : month = "02"; break;
				  case "Mar" : month = "03"; break;
				  case "Apr" : month = "04"; break;
				  case "May" : month = "05"; break;
				  case "Jun" : month = "06"; break;
				  case "Jul" : month = "07"; break;
				  case "Aug" : month = "08"; break;
				  case "Sep" : month = "09"; break;
				  case "Oct" : month = "10"; break;
				  case "Nov" : month = "11"; break;
				  case "Dec" : month = "12"; break;
			  }
			  
			 d = day+"/"+month+"/"+year;
			log.info("day : "+ d );
			*/
			
			try{
				 
				
				  Timestamp stamp = new Timestamp(Long.parseLong(d));
				  Date test = new Date(stamp.getTime());
				
				  //log.info(d+"|"+stamp);	
				  
				  SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				  // Date date = parser.parse(d);
				  
				  //log.info("date: "+test);
				  result = sdf.format(test);
				  
				  /*
				  Calendar spentOn = Calendar.getInstance();
				  spentOn.set(Calendar.DATE, Integer.parseInt(day));
				  spentOn.set(Calendar.MONTH, Integer.parseInt(month)-1);  //Calendar.MONTH start from 0 = JAN
				  spentOn.set(Calendar.YEAR, Integer.parseInt(year));
				  
				  Date d = parse
				  */
				  	
			}catch(Exception e){
				result = "dd/mm/yyyy";
			}
			  
		  }
		 
			 
		  return result;
	  }
	 
  private static String convertDate(String d){
		  
		  String result = "";
		  if(!StringUtils.isEmpty(d)){
			 
			  String[] str = d.split("/");
			  String day   = str[0];
			  String month = str[1];
			  String year  = str[2];
			  
			  result = year+"-"+month+"-"+day;
			  
		  }
		 
			 
		  return result;
	  }
  
  private static String nullToZero(String d){
	  String result = d;
	  if(StringUtils.isEmpty(d)){
		  result = "0";
	  }
	  return result;
  }
	  
	 /*
	
	@RequestMapping(value = "/searchAssets", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchAssets(HttpServletRequest request,Locale locale) throws Exception{

		String data = request.getParameter("data");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(data);
		
		HashMap<String, String> jsonMap = json;
		HashMap<String, String> criteria = new HashMap<>(3);
		
		jsonMap.forEach((key,value)->{
			if (!StringUtils.isEmpty(jsonMap.get(key))) {
				criteria.put(key, "%"+jsonMap.get(key)+"%");
			}
		});
		
		
		ServiceResult<AssetsCustomBean> listResult =  assetsService.searchAssets(criteria); 
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
		return result;
	 }
	
	 @RequestMapping(value = "/saveAssets", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveAssets(HttpServletRequest request,Locale locale) throws Exception{
			
			//https://www.tutorialspoint.com/json/json_java_example.htm
			 final int USER_ID = getUid(request);
			 String data = request.getParameter("data");
			 String userId = request.getParameter("userId");
			 
			 log.info("Setting User control");
			 log.info("data: "+data);
			 
			 List<AssetsBean> beans = new ArrayList<>();
			 
			 if (!(data.equals("{}"))) {
				 JSONParser jParser = new JSONParser();
				 JSONObject json = (JSONObject) jParser.parse(data);
				 
				 JsonBeanUtils<AssetsBean> utils = new JsonBeanUtils<>(AssetsBean.class);	 		 
				 beans = utils.convertFormAndBean(json,"action",USER_ID);
				 
				 log.info("data");
				 utils.testPrint(beans);
			}

			 String result_status = "";
			 String result_msg    = "";
			 ServiceResult<List<Long>> result = new ServiceResult<>();
			 
			 try{

				 result =  assetsService.saveAssets(beans, Integer.parseInt(userId));
	 	    			
	 	    	if(result.isSuccess()){
	 	    		log.info( "get long : "+result.getResult());
	 	    		result_status = "success";
	 	    		result_msg    = "save successful";
	 	    				
	 	    	}else{
	 	    			result_status = "fail";
	 	    			result_msg    = "save fail";
	 	    	}
		
				}catch(Exception e){
					log.info("Error !!"+e);
				}

			JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult());
			return res;
		   

		 }
	 
		@RequestMapping(value = "/deleteAssets", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean deleteAssets(HttpServletRequest request,Locale locale) throws Exception{
			
			String id  = request.getParameter("id");
			log.info("id: "+id);
			ServiceResult<Long> idResult =  assetsService.deleteAssets(Long.valueOf(id));
			JsonResultBean result = null;
			if(idResult.isSuccess()){
				result = new JsonResultBean("success", "" , idResult.getResult());
			}
			return result;
		 }
		 
		 */
	
}
