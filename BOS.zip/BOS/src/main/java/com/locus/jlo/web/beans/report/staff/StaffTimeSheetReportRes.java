package com.locus.jlo.web.beans.report.staff;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StaffTimeSheetReportRes {
	private String spentOn;
	private String employeeId;
	private String employeeName;
	private String position;
	private String divisionId;
	private String divisionName;
	private String deptCode;
	private String deptName;
	private String sectionCode;
	private String sectionName;
	private String projectName;
	private String projectCode;
	private String taskName;
	private String officeHour;
	private String noteComment;
	private String logtimeStatus;
	private String logtimeApproveBy;


	
}
