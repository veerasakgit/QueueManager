package com.locus.jlo.web.beans.setting;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SettingChargeRateBean {

	private String chargeCode;
	private String jobGroup;
	private String jobRank;
	private BigDecimal totalCost;
	private BigDecimal finalCost;
	private BigDecimal directCost;
	private BigDecimal sga;
	private Integer annualYear;
}
