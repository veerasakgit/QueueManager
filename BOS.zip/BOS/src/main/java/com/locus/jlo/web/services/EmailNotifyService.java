package com.locus.jlo.web.services;

import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;


public interface EmailNotifyService {

	
	//find approval email
	ServiceResult<List<DataBean>> findApprovalEmailByProjectId(String project_id , String user_id) throws Exception;
	
	//email workhour submit timesheet
	ServiceResult<List<DataBean>> qryTimesheetWorkhourData(String project_id , String user_id, String month_id , String year) throws Exception;
	ServiceResult<List<DataBean>> qryTimesheetOTData(String project_id , String user_id, String month_id , String year) throws Exception;
	
	
    //query timesheet utilize hour summary
	ServiceResult<List<DataBean>> qryUtilizeHourSummary(String month_id , String year) throws Exception;
	
	//email workhour reject timsheet
	ServiceResult<List<DataBean>> getTimesheetRejectData(String month_id, String year , String project_id, String user_id) throws Exception;
	
	

	
	
}
