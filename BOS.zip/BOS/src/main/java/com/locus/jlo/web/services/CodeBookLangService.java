package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;

public interface CodeBookLangService {
	
	ServiceResult<List<Map<String, Object>>> searchCodeBookLangByType(String codeType) throws Exception;
	
}
