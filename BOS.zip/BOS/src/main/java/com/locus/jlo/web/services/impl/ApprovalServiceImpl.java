package com.locus.jlo.web.services.impl;

import java.util.ArrayList;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.services.ApprovalService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ApprovalServiceImpl extends BaseService implements ApprovalService{
	
	//initial approval
	String SQL_APPROVAL_PROGRESS = "APPROVAL.SQL_APPROVAL_PROGRESS";
	
	String SQL_INITIAL_APPROVE_PROJECT = "APPROVAL.SQL_FILTER_APPROVAL_PROJECT";
	String SQL_INITIAL_APPROVE_PM_N_TEAM_HEAD = "APPROVAL.SQL_FILTER_APPROVAL_PM_N_TEAM_HEAD";
	String SQL_INITIAL_APPROVE_INTERNAL_PROJECT = "APPROVAL.SQL_FILTER_APPROVAL_INTERNAL_PROJECT";
	
	
	String SQL_INITIAL_APPROVE_PROJECT_FOR_ADMIN_ROLE = "APPROVAL.SQL_FILTER_APPROVAL_PROJECT_FOR_ADMIN_ROLE";
	String SQL_INITIAL_APPROVE_DEPT    = "APPROVAL.SQL_FILTER_APPROVAL_DEPARTMENT";
	String SQL_INITIAL_APPROVE_STAFF   = "APPROVAL.SQL_FILTER_APPROVAL_STAFF";
	String SQL_INITIAL_APPROVE_STAFF_FOR_ADMIN_ROLE = "APPROVAL.SQL_FILTER_APPROVAL_STAFF_FOR_ADMIN_ROLE";
	
	//approval staff all
	String SQL_STAFF_APPROVE_ALL = "APPROVAL.SQL_STAFF_APPROVE_ALL";
	String SQL_STAFF_REJECT_ALL = "APPROVAL.SQL_STAFF_REJECT_ALL";
	
	//approval
	String SQL_APPROVAL_WORKHOUR = "APPROVAL.SQL_APPROVAL_WORKHOUR";
	String SQL_APPROVAL_OT = "APPROVAL.SQL_APPROVAL_OVERTIME"; 
	String SQL_SUMMARY_APPROVAL = "APPROVAL.SQL_SUMMARY_APPROVAL";
	
	//timesheet report
	String SQL_TIMESHEET_APPROVAL = "APPROVAL.SEARCH_TIMESHEET_APPROVAL";
	String SQL_TIMESHEET_APPROVAL_STAFFDTL = "APPROVAL.SEARCH_TIMESHEET_APPROVAL_STAFF_DTL";
	String SQL_OT_STAFF_DETAIL = "APPROVAL.SQL_OT_STAFF_DETAIL";
	
	String SQL_OT_STAFF_DETAIL_APPROVED = "APPROVAL.SQL_OT_STAFF_DETAIL_APPROVED";
	String SQL_OT_STAFF_DETAIL_REJEDCTED = "APPROVAL.SQL_OT_STAFF_DETAIL_REJEDCTED";
	
	//ot report
	String SQL_OT_APPROVAL = "APPROVAL.SEARCH_OT_APPROVAL";
	String SQL_OT_APPROVAL_STAFFDTL = "APPROVAL.SQL_OT_APPROVAL_STAFFDTL";

	String SQL_QRY_TIMESHEET_REJECT_DATA = "APPROVAL_EMAIL_NOTIFY.SQL_QRY_TIMESHEET_REJECT_DATA";
	String SEARCH_OT_APPROVAL_BY_ALLOWANCE_ID = "APPROVAL.SEARCH_OT_APPROVAL_BY_ALLOWANCE_ID";
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetApprovalProgress(String year, String approverId ) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		
		try{
			result = dynamicJdbcDao.findForList(SQL_APPROVAL_PROGRESS,BeanPropertyRowMapper.newInstance(DataBean.class), 
					new SimpleKeyValue("year", year),
					new SimpleKeyValue("approverId",approverId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> initFilterTimesheetProject(String year, String monthId, String approverId  ) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = null;
		try{
			
			String month = "";
			int tmp_month = Integer.parseInt(monthId);
			month = Integer.toString(tmp_month);
			if(tmp_month < 10){
				month = "0"+tmp_month;
			}
			String yearmonth = year+""+month;
			
			/*
			 List<DataBean> arr = db;
			int dataLength = arr.size();
			Integer success = 0;
			for(int a=0;a<dataLength;a++){ 
				
				DataBean d = arr.get(a);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_SUBMIT_WORKHOUR, new SimpleKeyValue("entry_id",d.getA()) 
						, new SimpleKeyValue("status",d.getB()) 
						, new SimpleKeyValue("hours",d.getE()) 
						, new SimpleKeyValue("staffId",d.getC()));
				if(cnt==1){
					success++;
				}
			}  
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
            /*
			if(result.size() > 0 ){
				
				for(int i=0;i<result.size();i++ ){
					result.get(i).getA();
					result.get(i).getB();
					result.get(i).getC();
					result.get(i).getD();
				}
			}
			
			
			*/
			
			List<DataBean> arr = new ArrayList<DataBean>();

			
			//query 1 ) PM approved
			List<DataBean> pm_approve_project = dynamicJdbcDao.findForList(SQL_INITIAL_APPROVE_PROJECT, BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId), new SimpleKeyValue("approverId",approverId) , new SimpleKeyValue("yearMonth",yearmonth));
			System.out.println("pm approve project :"+pm_approve_project.size());
			arr.addAll(pm_approve_project);
		
			//query 2 ) Internal approved
			List<DataBean> internal_project = dynamicJdbcDao.findForList(SQL_INITIAL_APPROVE_INTERNAL_PROJECT, BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId), new SimpleKeyValue("approverId",approverId) , new SimpleKeyValue("yearMonth",yearmonth));
			System.out.println("internal_project :"+internal_project.size());
			arr.addAll(internal_project);
			
			//query 3 ) approve PM 
			List<DataBean> approve_pm_and_team_head = dynamicJdbcDao.findForList(SQL_INITIAL_APPROVE_PM_N_TEAM_HEAD, BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId), new SimpleKeyValue("approverId",approverId) , new SimpleKeyValue("yearMonth",yearmonth));
			System.out.println("approve_pm_and_team_head :"+approve_pm_and_team_head.size());
			arr.addAll(approve_pm_and_team_head);
			
			
			serviceResult = new ServiceResult<List<DataBean>>(arr);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<KeyValueBean>> initFilterTimesheetProjectForAdminRole(String year, String monthId ) throws Exception{
		ServiceResult<List<KeyValueBean>> serviceResult = null;
		try{
			
			String month = "";
			int tmp_month = Integer.parseInt(monthId);
			month = Integer.toString(tmp_month);
			if(tmp_month < 10){
				month = "0"+tmp_month;
			}
			String yearmonth = year+""+month;
			List<KeyValueBean> result = dynamicJdbcDao.findForList(SQL_INITIAL_APPROVE_PROJECT_FOR_ADMIN_ROLE, BeanPropertyRowMapper.newInstance(KeyValueBean.class),
					new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId) , new SimpleKeyValue("yearMonth",yearmonth));
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<KeyValueBean>> initFilterTimesheetDepartment(String year, String monthId, List projectId, String isAdmin) throws Exception{
		ServiceResult<List<KeyValueBean>> serviceResult = new ServiceResult<List<KeyValueBean>>();
		try{
			
			//check if role admin set approverId to null
			if( isAdmin.equals("Y")){
				projectId = null;
			}
 
			List<KeyValueBean> result = dynamicJdbcDao.findForList(SQL_INITIAL_APPROVE_DEPT, BeanPropertyRowMapper.newInstance(KeyValueBean.class), 
					new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId), new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> initFilterTimesheetStaff(String year, String monthId, List projectId , String isAdmin, String approverId ) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
			
			if (isAdmin.equals("Y")) {
				result = dynamicJdbcDao.findForList(SQL_INITIAL_APPROVE_STAFF_FOR_ADMIN_ROLE,BeanPropertyRowMapper.newInstance(DataBean.class),
						new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId), new SimpleKeyValue("projectId",projectId) );
			} else {
				result = dynamicJdbcDao.findForList(SQL_INITIAL_APPROVE_STAFF,BeanPropertyRowMapper.newInstance(DataBean.class),
						new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId), new SimpleKeyValue("approverId", approverId )
						, new SimpleKeyValue("projectId",projectId), new SimpleKeyValue("notEqApproverId", approverId ));
			
			}
			
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	

	@Override
	public ServiceResult<List<DataBean>> searchTimesheetApproval(String year, String monthId , String projectId, List<String> staffId ) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		 
		try{
			result = dynamicJdbcDao.findForList(SQL_TIMESHEET_APPROVAL,BeanPropertyRowMapper.newInstance(DataBean.class), 
					new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId), 
					new SimpleKeyValue("projectId",projectId), new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetApprovalStaffDetail(String year,String monthId,String staffId,String projectId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_TIMESHEET_APPROVAL_STAFFDTL,
					BeanPropertyRowMapper.newInstance(DataBean.class), 
					new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId), new SimpleKeyValue("staffId",staffId),new SimpleKeyValue("projectId",projectId) );
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	/* search ot */
	@Override
	public ServiceResult<List<DataBean>> searchOTApproval(String year, String monthId , String projectId, List<String> staffId ) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_OT_APPROVAL,BeanPropertyRowMapper.newInstance(DataBean.class), 
					new SimpleKeyValue("year", year), 
					new SimpleKeyValue("monthId",monthId), 
					new SimpleKeyValue("projectId",projectId), 
					new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchOvertimeStaffDtl(String otId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_OT_STAFF_DETAIL,BeanPropertyRowMapper.newInstance(DataBean.class), 
					new SimpleKeyValue("otId", otId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	/* summary all timesheet  */
	@Override
	public ServiceResult<List<DataBean>> summaryApprovalTimesheet(String year, String monthId ,String projectId, List<String> staffId ) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SUMMARY_APPROVAL,BeanPropertyRowMapper.newInstance(DataBean.class), 
					new SimpleKeyValue("year", year), 
					new SimpleKeyValue("monthId",monthId), 
					new SimpleKeyValue("projectId",projectId), 
					new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	

	
	
	/* approve staff all */
	@Override
	public ServiceResult<Long> staffApprovalAll(List<DataBean> db) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			List<DataBean> arr = db;
			int dataLength = arr.size();
			Integer success = 0;
			for(int i=0;i<dataLength;i++){
				DataBean d = arr.get(i);
				int cnt  = 0;
				log.info("found status "+d.getC());
				if( d.getC().equals("3")){
					cnt = dynamicJdbcDao.executeUpdate(SQL_STAFF_REJECT_ALL, 
							new SimpleKeyValue("staffId",d.getA()) , 
							new SimpleKeyValue("projectId",d.getB()) , 
							new SimpleKeyValue("status",d.getC()),
							new SimpleKeyValue("approvalId",d.getD()) , 
							new SimpleKeyValue("year",d.getE()) , 
							new SimpleKeyValue("monthId",d.getF()));
				}else if( d.getC().equals("4") ){
					 cnt = dynamicJdbcDao.executeUpdate(SQL_STAFF_APPROVE_ALL, 
							new SimpleKeyValue("staffId",d.getA()) , 
							new SimpleKeyValue("projectId",d.getB()) , 
							new SimpleKeyValue("status",d.getC()),
							new SimpleKeyValue("approvalId",d.getD()) , 
							new SimpleKeyValue("year",d.getE()) , 
							new SimpleKeyValue("monthId",d.getF()));
				}
				
				
				if(cnt==1){
					success++;
				}
			}
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			log.info("staffApprovalAll Error: "+e);
		}
	
		return result;
	}
	
	
	
	 
	/* approve save */
	@Override
	public ServiceResult<Long> approveWorkhour(List<DataBean> db) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			List<DataBean> arr = db;
			int dataLength = arr.size();
			Integer success = 0;
			for(int i=0;i<dataLength;i++){
				DataBean d = arr.get(i);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_APPROVAL_WORKHOUR, new SimpleKeyValue("entry_id",d.getA()) , new SimpleKeyValue("status",d.getB()) , new SimpleKeyValue("staffId",d.getC()));
				if(cnt==1){
					success++;
				}
			}
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			log.info("submitWorkhour Error: "+e);
		}
	
		return result;
	}
	
	@Override
	public ServiceResult<Long> approveOvertime(List<DataBean> db) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			List<DataBean> arr = db;
			int dataLength = arr.size();
			Integer success = 0;
			for(int i=0;i<dataLength;i++){
				DataBean d = arr.get(i);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_APPROVAL_OT, new SimpleKeyValue("otId",d.getA()) , new SimpleKeyValue("status",d.getB()) , new SimpleKeyValue("staffId",d.getC()));
				if(cnt==1){
					success++;
				}
			}
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			log.info("submitOvertime Error: "+e);
		}
	
		return result;
	}
	
	
	
	/*Overtime detail staff approved*/
	@Override
	public ServiceResult<Long> approvedOvertimeStaffDetail( String otId , String approverId )throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_OT_STAFF_DETAIL_APPROVED , new SimpleKeyValue("otId",otId), new SimpleKeyValue("approverId",approverId));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	/*Overtime detail staff rejected*/
	@Override
	public ServiceResult<Long> rejectedOvertimeStaffDetail( String otId , String approverId , String data )throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_OT_STAFF_DETAIL_REJEDCTED , new SimpleKeyValue("otId",otId), new SimpleKeyValue("approverId",approverId)
					, new SimpleKeyValue("rejectedReason",data));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}


	@Override
	public ServiceResult<List<KeyValueBean>> initFilterTimesheetApproveAuthorizePerson(String year, String monthId,
			String approverId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public ServiceResult<DataBean> getTimesheetRejectDataByTimeEntries(String eid) throws Exception {
		ServiceResult<DataBean> serviceResult = new ServiceResult<DataBean>();
		DataBean result = null;	
		try {
			
			result = dynamicJdbcDao.findForObject(SQL_QRY_TIMESHEET_REJECT_DATA,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("eid",eid));
			 
			serviceResult = new ServiceResult<DataBean>(result);
			System.out.println("Database return result : "+serviceResult.getResult());
				
		} catch (Exception e) {
			log.info("get timesheet reject data error: "+e);
		}
	
		return serviceResult;
	}


	@Override
	public ServiceResult<DataBean> searchOTApprovalByAllowanceId(String allwanceId) throws Exception {
		ServiceResult<DataBean> serviceResult = new ServiceResult<DataBean>();
		DataBean result = null;	
		
		try{
			result = dynamicJdbcDao.findForObject(SEARCH_OT_APPROVAL_BY_ALLOWANCE_ID,BeanPropertyRowMapper.newInstance(DataBean.class), 
					new SimpleKeyValue("allwanceId", allwanceId));
			
			serviceResult = new ServiceResult<DataBean>(result);
			System.out.println("Element result :: "+serviceResult.getResult());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<DataBean>(e);
		}
		return serviceResult;
	}
	
	/*
	@Override
	public ServiceResult<List<DataBean>> searchReportTimesheet(String year,String monthId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{

			result = dynamicJdbcDao.findForList(SQL_REPROT_SEARCH_TIMESHEET,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	//staff profile ( should move to staff page )
	@Override
	public ServiceResult<List<DataBean>> searchStaffDetail(String staffId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{

			result = dynamicJdbcDao.findForList(SQL_STAFF_PROFILE,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("staffId", staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimesheetDetail(String year, String monthId, String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_REPROT_SEARCH_TIMESHEET_DETAIL,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));

			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimesheetNote(String year,String monthId, String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_REPORT_SEARCH_TIMESHEET_NOTE,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));
				serviceResult = new ServiceResult<List<DataBean>>(result);
			   System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimeshhetOvertime(String year,String monthId, String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_REPORT_SEARCH_TIMESHEET_OVERTIME,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));
				serviceResult = new ServiceResult<List<DataBean>>(result);
			   System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	
	
	
	
	//UPDATE TIMESHEET ENTRY
	@Override
	public ServiceResult<Long> updateTimeSheetEntry(String udata) throws Exception{
		//trace parameter
		log.info("Get data :"+udata);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
		     //count success
			 Integer success = 0;
			
			 JSONParser parser = new JSONParser();
			 Object obj = parser.parse(udata);
			 JSONArray jarr = (JSONArray)obj;
			 int size = jarr.size();
			 log.info("update record length: "+size);
			
			 for(int i=0;i<size;i++){
				 	JSONObject data = (JSONObject)jarr.get(i);
					final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REPORT_TIMESHEET_UPDATE, new SimpleKeyValue("id",data.get("id").toString()),
																								  new SimpleKeyValue("status",data.get("sts").toString()), 
																								  new SimpleKeyValue("hour",data.get("hour").toString()));
					
					log.info("UPDATE time_entries SET status = "+data.get("sts").toString()+", hours = "+data.get("hour").toString()+"  WHERE id = "+data.get("id").toString()+";");
					
					if(cnt==1){
						success++;
					}
				 
			 }
			
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Update record Error: "+e);
			e.printStackTrace();
		}
	
		return result;
	}
	
	
	//DELETE TIMESHEET ENTRY
	@Override
	public ServiceResult<Long> removeTimeSheetEntry(String rdata) throws Exception {
		//trace parameter
		log.info("Get data :"+rdata);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
		     //count success
			 Integer success = 0;
			
			 JSONParser parser = new JSONParser();
			 Object obj = parser.parse(rdata);
			 JSONArray jarr = (JSONArray)obj;
			 int size = jarr.size();
			 log.info("update record length: "+size);
			
			 for(int i=0;i<size;i++){
				 	JSONObject data = (JSONObject)jarr.get(i);
					final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REPORT_TIMESHEET_DELETE, new SimpleKeyValue("id",data.get("id").toString()));
					log.info("DELETE FROM time_entries WHERE id = "+data.get("id").toString()+";");
					if(cnt==1){
						success++;
					}
				 
			 }
			
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Update record Error: "+e);
			e.printStackTrace();
		}
	
		return result;
	
	}
	
	
	
	@Override
	public ServiceResult<List<DataBean>> getHolidayConfig(String year, String monthId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			
			result = dynamicJdbcDao.findForList(SQL_REPORT_GET_HOLIDAY,BeanPropertyRowMapper.newInstance(DataBean.class),new SimpleKeyValue("year",year),new SimpleKeyValue("monthId",monthId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> getHolidayConfigBetweenDate(String startDate, String endDate) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			
			result = dynamicJdbcDao.findForList(SQL_REPORT_GET_HOLIDAY_BETWEEN_DAY,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("startDate", startDate),new SimpleKeyValue("endDate",endDate));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	
	
	
	/*
	@Override
	public ServiceResult<List<DataBean>> searchTimesheet_beforeSubmit() throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_TEIMSHEET_BEFORE_SUBMIT,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("accountName",""));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<Long> submitTimesheet(String data_eid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control data_eid :"+data_eid);
	
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			data_eid = data_eid.replaceAll("\"", "");
			String[] arr = data_eid.split(",");
//			List<String> lst = new ArrayList<>();
			Integer success = 0;
			for(int i=0;i<arr.length;i++){
				log.info("Timesheet control data_eid :"+arr[i]);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_SUBMIT_TIMESHEET, new SimpleKeyValue("data_eid",arr[i]));
				if(cnt==1){
					success++;
				}
			}
			
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	
	
	
	
	@Override
	public ServiceResult<Long> insertLogtime(String pid,String tid,String date,String hour,String status , String uid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_LOGTIME, Boolean.TRUE, new SimpleKeyValue("pid",pid),
																							   new SimpleKeyValue("tid",tid),
																							   new SimpleKeyValue("date",date), 
																							   new SimpleKeyValue("hour",hour),
																							   new SimpleKeyValue("status",status),
																							   new SimpleKeyValue("uid",uid));
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateLogtime(String pid, String tid, String date, String hour, String status, String uid, String eid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		log.info("Timesheet control eid :"+eid);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_LOGTIME, new SimpleKeyValue("pid",pid),
																			   new SimpleKeyValue("tid",tid),
																			   new SimpleKeyValue("date",date), 
																			   new SimpleKeyValue("hour",hour),
																			   new SimpleKeyValue("status",status),
																			   new SimpleKeyValue("uid",uid),
																			   new SimpleKeyValue("eid",eid));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> removeLogtime(String eid) throws Exception {
		 
		//trace parameter
		log.info("Timesheet control eid :"+eid);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_LOGTIME, new SimpleKeyValue("eid",eid));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	/*
	@Override
	public String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception {
		//ServiceResult<String> result = null;
		
		log.info("Timesheet control"+pid);
		 
		String result = "";
		try {
			List<String> lst = dynamicJdbcDao.findForList(SQL_CHECK_LOGTIME, String.class , 
					new SimpleKeyValue("pid",pid));
			  log.info("size : "+lst.size());
			  if(lst.size()>0){
				  result = lst.get(0);
			log.info("Timesheet control"+lst.get(0));
			  }
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
		return result;
	}
  */
}
