package com.locus.jlo.web.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.setting.SettingCalendarBean;
import com.locus.jlo.web.services.SettingCalendarService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class SettingCalendarServiceImpl extends BaseService implements SettingCalendarService{
	
	//Query
	final String SQL_SEARCH = "SETTING_CALENDAR.SQL_SEARCH_SETTING_CALENDAR";
	final String SQL_SEARCH_DETAIL = "SETTING_CALENDAR.SQL_SEARCH_SETTING_CALENDAR_DETAIL";
	//Excute
	final String SQL_INSERT = "SETTING_CALENDAR.INSERT_SETTING_CALENDAR";
	final String SQL_UPDATE = "SETTING_CALENDAR.UPDATE_SETTING_CALENDAR";
	final String SQL_REMOVE = "SETTING_CALENDAR.DELETE_SETTING_CALENDAR";

	@Override
	public ServiceResult<List<Map<String, Object>>> searchSettingCalendar(String id,String dateType) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>> ();
		
		try{
			
			HashMap<String, Object> map = new HashMap<>();
			map.put("id", id);
			map.put("date_type", dateType);
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH,map);
			dataNotFound(result);
			serviceResult = new ServiceResult<List<Map<String, Object>> >(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> insertSettingCalendar(SettingCalendarBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}


	@Override
	public ServiceResult<Long> updateSettingCalendar(SettingCalendarBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE,bean);
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}


	@Override
	public ServiceResult<Long> removeSettingCalendar(String id) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
			
				final int returnId = dynamicJdbcDao.executeUpdate(SQL_REMOVE,new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(returnId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}

}
