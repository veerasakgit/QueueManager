package com.locus.jlo.web.controller.report;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFPicture;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.report.attendance.AttendanceReportCriteria;
import com.locus.jlo.web.beans.report.attendance.AttendanceReportRes;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;
	
@Slf4j
@Controller
public class AttendanceReportController {

	@Autowired
	private ExcelReportService excelReportService;

	@RequestMapping(value = "/searchAttendanceReport", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchAttendanceReport(HttpServletRequest request, Locale locale)
			throws Exception {

		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);

		JsonResultBean validResult = validateCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		AttendanceReportCriteria attendanceReportCriteria = getCriteria(json);
		Map<String, Object> m = new HashMap<String, Object>();

		JsonResultBean result = null;
		ServiceResult<List<AttendanceReportRes>> listResult = excelReportService.searchAttendanceReport(attendanceReportCriteria);

		if (listResult.isSuccess()) {
			m.put("result", listResult.getResult());
			result = new JsonResultBean("success", "", m);
			log.info("successRespones : " + result.toString());
			log.info(" total : " + listResult.getResult().size());
		} else {
			log.info("fail_Respones : ");
		}
		return result;
	}

	@RequestMapping(value = "/validateCriteriaAttendance", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateCriteriaAttendance(HttpServletRequest request, Locale locale) throws Exception {
		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);
		return validateCriteria(json);
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportAttendanceReport", method = RequestMethod.POST)
	public @ResponseBody void exportAttendanceReport(HttpServletRequest request, HttpServletResponse response, AttendanceReportCriteria cr) throws Exception {

		OutputStream outputStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("reportType", cr.getReportType());
			jsonObj.put("startDate", cr.getStartDate());
			jsonObj.put("endDate", cr.getEndDate());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("employeeName", cr.getEmployeeName());
			jsonObj.put("employeeType", cr.getEmployeeType());
			jsonObj.put("leaveType", cr.getLeaveType());

			AttendanceReportCriteria attendanceReportCriteria = getCriteria(jsonObj);

			ServiceResult<List<AttendanceReportRes>> listResult = excelReportService.searchAttendanceReport(attendanceReportCriteria);

			int rowCount = 0;
			int columnCount = 0;
          	List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
          	List<Integer[]> mergeList = new ArrayList<Integer[]>();
          	
			XSSFCellStyle cellStyleR1 = PoiUtils.creatCellStyle(wb, "Angsana New", true, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleG1 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
			XSSFCellStyle cellStyleG3 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.RED.index);

			//row1
            columnCount = 0;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Attendance Report", cellStyleR1));
            mergeList.add(new Integer[]{ 0, 0, 0, 12});
        	//row2
            rowCount++;
            columnCount = 0;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "ตั้งแต่ " + cr.getStartDate() + " ถึง "+ cr.getEndDate(), cellStyleR1));
            mergeList.add(new Integer[]{ 1, 1, 0, 12});
        	//row3
            rowCount++;
            columnCount = 0;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Unit", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "No. of staff", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total working day", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Annual Leave", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total other leave", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Actual working day(not include Annual leave)", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "", null));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "LEAVE", cellStyleG3));
            //row4
            rowCount++;
            columnCount = 7;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Sick", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Business", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Maternity", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Ordination ", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Leave w/o pay", cellStyleG3));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "others", cellStyleG3));

            mergeList.add(new Integer[]{ 2, 3, 0, 0});//Unit
            mergeList.add(new Integer[]{ 2, 3, 1, 1});//No. of staff
            mergeList.add(new Integer[]{ 2, 3, 2, 2});//Total working day
            mergeList.add(new Integer[]{ 2, 3, 3, 3});//Annual Leave
            mergeList.add(new Integer[]{ 2, 3, 4, 4});//Total other leave
            mergeList.add(new Integer[]{ 2, 3, 5, 5});//Actual working day(not include Annual leave)
            mergeList.add(new Integer[]{ 2, 2, 7, 12});//LEAVE
            
            XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
            double annualLeave = 0;    
            double totalOtherLeave = 0;    
            double actualWorkingDay = 0;    
			for (AttendanceReportRes rec: listResult.getResult()) {
                rowCount++;
                columnCount = 0;
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getUnit(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleLeft));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNoStaff(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTotalWorkingDay(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getLeaveAn(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTotalOtherLeave(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getActualWorkingDay(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, "", null));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getLeaveSi(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getLeaveBu(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getLeaveMa(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getLeaveOr(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getLeaveWp(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getLeaveOthers(), getCellstyle(rec.getUnit() ,wb)!=null?getCellstyle(rec.getUnit() ,wb):cellStyleCenter));

        		if("Working day in this month".equals(rec.getUnit())) {
        			annualLeave = Double.parseDouble(rec.getLeaveAn().replaceAll("%", ""));
        			totalOtherLeave = Double.parseDouble(rec.getTotalOtherLeave().replaceAll("%", ""));
        			actualWorkingDay = Double.parseDouble(rec.getActualWorkingDay().replaceAll("%", ""));
        		} 
			}
            
			wb = PoiUtils.createSheet(wb, "AttendanceReport", lstExObj, mergeList, true);
			wb.getSheet("AttendanceReport").autoSizeColumn((short) 0);
			

            XSSFSheet chartSheet = wb.createSheet("Chart");
            DefaultPieDataset pieChartData = new DefaultPieDataset();
            if(annualLeave != 0)
            	pieChartData.setValue("Annual leave",annualLeave);
            if(totalOtherLeave != 0)
            	pieChartData.setValue("Total other leave",totalOtherLeave);
            if(actualWorkingDay != 0)
            	pieChartData.setValue("Actual working day",actualWorkingDay);
            JFreeChart myPieChart = ChartFactory.createPieChart("Attendance Report",pieChartData,true,true,false);
            PiePlot colorConfigurator = (PiePlot) myPieChart.getPlot();
            colorConfigurator.setExplodePercent("Annual leave", 0.30);
            colorConfigurator.setExplodePercent("Total other leave", 0.30);
            colorConfigurator.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}:{1}"));
            int width=640; /* Width of the chart */
            int height=480; /* Height of the chart */
            float quality=1; /* Quality factor */
            ByteArrayOutputStream chart_out = new ByteArrayOutputStream();          
            ChartUtilities.writeChartAsJPEG(chart_out,quality,myPieChart,width,height);
            int chartPicture = wb.addPicture(chart_out.toByteArray(), Workbook.PICTURE_TYPE_JPEG);                
            chart_out.close();
            XSSFDrawing drawing = chartSheet.createDrawingPatriarch();
            ClientAnchor anchor = new XSSFClientAnchor();
            anchor.setCol1(0);
            anchor.setRow1(0);
            XSSFPicture  picture = drawing.createPicture(anchor, chartPicture);
            picture.resize();
            
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.addHeader("Content-Disposition", "attachment; filename=\"AttendanceReport.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			outputStream.flush();
			outputStream.close();
			wb.close();
		}

	}
	
	private XSSFCellStyle getCellstyle(String unit, XSSFWorkbook wb) {
		XSSFCellStyle result = null;
		if("Grand Total".equals(unit)) {
			result = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
		} 
		return result;
	}

	private JsonResultBean validateCriteria(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg = "";
		String result_data = "";
		
		if(json.get("reportType").toString().equals("1")) {
			if (StringUtils.isEmpty(json.get("division"))) {
				result_data = "";
				result_status = "error";
				result_msg = "Please Fill Division";
				return new JsonResultBean(result_status, result_msg, result_data);
			}
		} else if(json.get("reportType").toString().equals("2")) {
			if (StringUtils.isEmpty(json.get("division"))) {
				result_data = "";
				result_status = "error";
				result_msg = "Please Fill Division";
				return new JsonResultBean(result_status, result_msg, result_data);
			}
			if (StringUtils.isEmpty(json.get("department"))) {
				result_data = "";
				result_status = "error";
				result_msg = "Please Fill Department";
				return new JsonResultBean(result_status, result_msg, result_data);
			}
		} 

		if (StringUtils.isEmpty(json.get("startDate"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill StartDate";
			return new JsonResultBean(result_status, result_msg, result_data);
		}

		if (StringUtils.isEmpty(json.get("endDate"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill EndDate";
			return new JsonResultBean(result_status, result_msg, result_data);
		}

		String startDate = json.get("startDate").toString();
		String endDate = json.get("endDate").toString();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date stDate = sdf.parse(startDate);
		Date edDate = sdf.parse(endDate);

		long difference = edDate.getTime() - stDate.getTime();
		float daysBetween = TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);

		if (daysBetween < 0) {
			result_data = "";
			result_status = "error";
			result_msg = "EndDate more than equal StartDate";
			return new JsonResultBean(result_status, result_msg, result_data);
		}

		if (daysBetween > 366) {

			result_data = "";
			result_status = "error";
			result_msg = "StartDate-EndDate not over 1 Year";
			return new JsonResultBean(result_status, result_msg, result_data);

		}

		Calendar calSt = Calendar.getInstance();
		calSt.setTime(stDate);

		Calendar calEd = Calendar.getInstance();
		calEd.setTime(edDate);
		if (calSt.get(Calendar.YEAR) != calEd.get(Calendar.YEAR)) {
			result_data = "";
			result_status = "error";
			result_msg = "StartDate-EndDate must be the same year";
			return new JsonResultBean(result_status, result_msg, result_data);
		}
		return new JsonResultBean("success", "", "");
	}

	private AttendanceReportCriteria getCriteria(JSONObject json) throws Exception {
		String reportType = json.get("reportType").toString();
		String startDate = json.get("startDate").toString();
		String endDate = json.get("endDate").toString();
		String department = json.get("department").toString();
		String division = json.get("division").toString();
		String employeeName = null;
		if (json.get("employeeName") != null) {
			employeeName = json.get("employeeName").toString();
		}
		String employeeType = json.get("employeeType").toString();
		String leaveType = json.get("leaveType").toString();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd");
		Date stDate = sdf.parse(startDate);
		String startDateFmt = output.format(stDate);
		Date edDate = sdf.parse(endDate);
		String endDateFmt = output.format(edDate);

		AttendanceReportCriteria attendanceReportCriteria = new AttendanceReportCriteria();

		if (!StringUtils.isEmpty(reportType)) {
			attendanceReportCriteria.setReportType(reportType);
		}
		if (!StringUtils.isEmpty(startDateFmt)) {
			attendanceReportCriteria.setStartDate(startDateFmt);
			attendanceReportCriteria.setStartDateSelect(startDateFmt);
		}
		if (!StringUtils.isEmpty(endDateFmt)) {
			attendanceReportCriteria.setEndDate(endDateFmt);
			attendanceReportCriteria.setEndDateSelect(endDateFmt);
		}
		if (!StringUtils.isEmpty(division)) {
			attendanceReportCriteria.setDivision(division);
		}
		if (!StringUtils.isEmpty(department)) {
			attendanceReportCriteria.setDepartment(department);
		}
		if (!StringUtils.isEmpty(employeeName)) {
			String ids = employeeName.replaceAll("\\[|\\]", "");
			List<String> listId = Arrays.asList(ids.split(","));
			if (listId.size() > 1) {
				listId = JsonBeanUtils.jsonToList(employeeName);
			}
			attendanceReportCriteria.setEmployeeName(listId);
		}
		if (!StringUtils.isEmpty(employeeType))
			attendanceReportCriteria.setEmployeeType(employeeType);
		if (!StringUtils.isEmpty(leaveType)) {
			attendanceReportCriteria.setLeaveType(leaveType);
		}
		return attendanceReportCriteria;
	}

}
