package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.account.AccountDetailBean;

public interface AccountDetailService {
	ServiceResult<Boolean> saveAccountDetail(AccountDetailBean accountDetailModelBean) throws Exception;
	ServiceResult<Boolean> updateAccountDetail(AccountDetailBean accountDetailModelBean) throws Exception;
}
