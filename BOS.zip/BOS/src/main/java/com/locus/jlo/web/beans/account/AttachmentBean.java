package com.locus.jlo.web.beans.account;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class AttachmentBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String attId;
	private BigInteger attFileType;
	private String attName;
	private String attPath;
	private String attSize;
	private BigInteger attStatus;
	private String attType;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
}
