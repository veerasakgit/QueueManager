package com.locus.jlo.web.beans.project;

import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TicketsBean extends StampBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6374775555028449618L;
	private Integer id;
	private Integer project_id;
	private String subject;
	private String subject_detail;
	private String subject_type;
	private Date due_date;
	private Integer priority;
	private String request_by;
	private Integer channel;
	private Integer assign_uid;
	private Integer category1;
	private Integer category2;
	private Integer category3;
	private Integer owner_uid;
	private Integer status;
	private Date inform_dt;
	private String inform_person;
	private Date closed_dt;
	private Integer closed_uid;
	private Date cancel_dt;
	private Integer cancel_uid;

}
