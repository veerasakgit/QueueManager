package com.locus.jlo.web.services.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


import java.util.List;
import java.util.Locale;


import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;


import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;

import com.locus.jlo.web.services.BashService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BashServiceImpl extends BaseService implements BashService {

	final String SQL_BASH_AUTO_ADD_PROBATION_DATE = "BASH.SQL_BASH_AUTO_ADD_PROBATION_DATE";
	final String SQL_BASH_SEARCH_PASS_PROBATION = "BASH.SQL_BASH_SEARCH_PASS_PROBATION";
	final String SQL_BASH_UPDATE_PASS_PROBATION = "BASH.SQL_BASH_UPDATE_PASS_PROBATION";
	 
	final String SQL_STAFF_LEAVE_HOUR = "BASH.SQL_BASH_SEARCH_STAFF_LEAVE_HOUR";
	final String SQL_STAFF_LEAVE_HOUR_UPDATE = "BASH.SQL_BASH_UPDATE_STAFF_LEAVE_HOUR";
	final String SQL_STAFF_FIND_HOLIDAY_BETWEEN_DAY = "BASH.FIND_HOLIDAY_BETWEEN_DAY";
	
	
	final static private SimpleDateFormat yyyyMMddHHmm = new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);
	
	@Override
	public ServiceResult<Long> reCalLeaveHour(String userId) {
	
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
			
			List<DataBean> arr =  dynamicJdbcDao.findForList(SQL_STAFF_LEAVE_HOUR
															,BeanPropertyRowMapper.newInstance(DataBean.class) 
															, new SimpleKeyValue("userId", userId ));
			int dataLength = arr.size();
			Integer success = 0;
			for(int i=0;i<dataLength;i++){
				DataBean d = arr.get(i);
				log.info("checking > leaveid : "+d.getA()+"| user_id : "+d.getB()+" | start dt: "+d.getC()+"| end dt: "+d.getD()+"  | leave_hour :"+d.getE());
				
				
				//step1 check probation date
				String leaveHour = calculateNewLeaveHour( d.getC().toString() , d.getD().toString() );
				
				Integer cnt = dynamicJdbcDao.executeUpdate(SQL_STAFF_LEAVE_HOUR_UPDATE
								,new SimpleKeyValue("leaveId",d.getA())
								,new SimpleKeyValue("leaveHour",leaveHour));
				 
			}
			
			
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		
		return result;
			
	}
	
	@Override
	public ServiceResult<Long> autoUpdatePassProbation() throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
		
		
		List<DataBean> db = null;	
		
		/*
		log.info("getYear: "+year);
		log.info("request_from_me: "+request_from_me);
		log.info("request_to_me: "+request_to_me);
		log.info("leaveStatus: "+leaveStatus);
		log.info("leaveType: "+leaveType);
		
	
		if(request_from_me == null){ request_from_me = null;}
		if(request_to_me == null){ request_to_me = null;}
		if(leaveStatus == null){ leaveStatus = null; }
		if(leaveType == null){ leaveType = null;}
		*/
		
	
		try{
			
			List<DataBean> arr =  dynamicJdbcDao.findForList(SQL_BASH_SEARCH_PASS_PROBATION,BeanPropertyRowMapper.newInstance(DataBean.class));
			int dataLength = arr.size();
			Integer success = 0;
			for(int i=0;i<dataLength;i++){
				DataBean d = arr.get(i);
				log.info("checking : "+d.getA()+"|"+d.getB()+" > appearance_date "+d.getE()+"| check extend probation is ["+d.getH()+"]");
				System.out.println("checking : "+d.getA()+"|"+d.getB()+" > appearance_date "+d.getE()+"| check extend probation is ["+d.getH()+"]");
				
				//step1 check probation date
				if(!d.getH().equals("")){
					//if not empty
					int probation_day_left = Integer.parseInt(d.getI());
					if( probation_day_left <= 0){
						log.info("staff id ["+d.getA()+"|"+d.getB()+"] is extend and now are pass probation ");
						  Integer cnt = dynamicJdbcDao.executeUpdate(SQL_BASH_UPDATE_PASS_PROBATION,new SimpleKeyValue("userId",d.getA()));
						  if(cnt==1){
								success++;
						  }
					}else{
						log.info("staff id ["+d.getA()+"|"+d.getB()+"] is extend probation :"+d.getI()+" day(s) left.");
						System.out.println("staff id ["+d.getA()+"|"+d.getB()+"] is extend probation :"+d.getI()+" day(s) left.");
					}
					
				}else{
					//if emtpy check working day is morethan 119 day
					int working_day =  Integer.parseInt(d.getG());
					if( working_day >= 119 ){
						log.info("staff id ["+d.getA()+"] is working more than 119 : actual["+d.getG()+"]");
						System.out.println("staff id ["+d.getA()+"] is working more than 119 : actual["+d.getG()+"]");
						Integer cnt = dynamicJdbcDao.executeUpdate(SQL_BASH_UPDATE_PASS_PROBATION,new SimpleKeyValue("userId",d.getA()));
						if(cnt==1){
								success++;
						}
					}
				}
				/*
				
				String uid = "";
				int success = 0;
				if( probation_date != null ){
					  if(  DATEDIFF(  probation_date , NOW()  ) < 0 ){
						  //update
						  final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_BASH_UPDATE_PASS_PROBATION,new SimpleKeyValue("uid",uid));
						  if(cnt==1){
								success++;
						  }
					  }
				}else{
					   if ( DATEDIFF(  NOW() , appearance_date ) + 1 >= 119 )){
						   final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_BASH_UPDATE_PASS_PROBATION,new SimpleKeyValue("uid",uid));
						   if(cnt==1){
								success++;
						  }
					   } 
					   
					   
				}
				*/
				
				
			
			}
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
            
		
		
			 /*
				//qry
				
	
				
				result.setResult(Long.valueOf(delId));
	            result.setSuccess(Boolean.TRUE);
	            
	            */
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           //setErrorResult(result, e);
			   throw e;
		}
		
		return result;
		
	
	}
	
	
	private String calculateNewLeaveHour(String startDate , String endDate){
		
	 String leaveHour = "";
	 try{
		 
		 log.info("startdt : "+startDate);
		 log.info("endDate : "+endDate);
		 
		 Date startdt = yyyyMMddHHmm.parse(startDate);
		 Date enddt = yyyyMMddHHmm.parse(endDate);
		 
		 leaveHour = findLeaveHour(startdt , enddt);
		 
		 
	 }catch(Exception e){
		 
		 log.error(e.getMessage(), e);
		 
	 }
		 log.info("return leave hour : "+leaveHour );
		
	 return leaveHour;
	}

	
	private String findLeaveHour(Date startdt, Date enddt) throws Exception{
		 
		 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
		 
		 double leave_hour = 0;
		 
		 Calendar st = Calendar.getInstance();
		 Calendar et   = Calendar.getInstance();
		 
		 //use tmp_start , tmp_end to calculate each leave hour
		 Calendar tmp_start = Calendar.getInstance();
		 Calendar tmp_end = Calendar.getInstance();
		 
		 st.setTime(startdt);
		 et.setTime(enddt);
		 
		 
		 //find holiday
		 String[] dayOfWeek = {"wk","wd","wd","wd","wd","wd","wk"};
		 
		 
		 	ServiceResult<List<DataBean>> hConf = new ServiceResult<List<DataBean>>();
			List<DataBean> result = null;
			try{
				
				
					
				result  =  dynamicJdbcDao.findForList(SQL_STAFF_FIND_HOLIDAY_BETWEEN_DAY, BeanPropertyRowMapper.newInstance(DataBean.class), 
															  new SimpleKeyValue("startDate", df.format(startdt)),
															  new SimpleKeyValue("endDate",df.format(enddt)) );
				
				hConf = new ServiceResult<List<DataBean>>(result);
		  
			}catch(Exception e){
				
			}

		 List<DataBean> holidays = new ArrayList<DataBean>();
		 //from query we will know holiday on leave date
		  
		 //keep dd-mm-yyyy to arraylist for check holiday again
		 ArrayList holiday = new ArrayList<String>();
		 if(hConf.isSuccess()){
			 holidays = hConf.getResult();
			 log.info("holiday : "+holidays.size()); //total leave day
			 for(DataBean h : holidays ){
				 log.info(h.getA());
				 holiday.add(h.getB()+"-"+h.getC()+"-"+h.getD());
			 } 
		 }
		 
		 //find each day from start to end
		 //eg. if leave on 31-03-2018 13:00 -> 01-04-2018 12:00
		 //this will find 
		 // 31-03-2018 as 1 day
		 // 01-04-2018 as 1 day
		
		 Calendar start_date = Calendar.getInstance();
		 start_date.set(Calendar.DATE, st.get(Calendar.DATE));
		 start_date.set(Calendar.MONTH, st.get(Calendar.MONTH));
		 start_date.set(Calendar.YEAR, st.get(Calendar.YEAR));
		 
		 Calendar end_date = Calendar.getInstance();
		 end_date.set(Calendar.DATE, et.get(Calendar.DATE));
		 end_date.set(Calendar.MONTH, et.get(Calendar.MONTH));
		 end_date.set(Calendar.YEAR, et.get(Calendar.YEAR));
		 
		 int total_loop_day = 0;
		 while( !start_date.after(end_date)){
			
			    log.info("today is "+start_date.get(Calendar.DATE)+start_date.get(Calendar.MONTH)+start_date.get(Calendar.YEAR));
			    total_loop_day++;
			    
			    start_date.add(Calendar.DATE, 1);
		 }
		
		 
		 /* Main algorithm
		  
		 8.30           12.00                13.00          17.30
		 |  Morning (A)   |                   | After noon (B) |
		                  12.30 ->(ceil)-> 13.00
		           
		    | Start |  End  |
		       A    |   B     -> -1  #this is pass noon total leave -1 hour
		       A    |   A     ->  0
		       B    |   B     ->  0
		       B    |   A     ->  0
		 */
		 
		 //find date diff
		 // Get the represented date in milliseconds
		 double millis1 = st.getTimeInMillis();
		 double millis2 = et.getTimeInMillis();
	     // Calculate difference in milliseconds
		 double diff = millis2 - millis1;
	     // Calculate difference in days
		 double diffDays = Math.ceil(diff / (24 * 60 * 60 * 1000));
		// log.info("from " +st.get(Calendar.DATE)+" to "+et.get(Calendar.DATE)+"  is : "+ Math.ceil(diffDays) + " days.");
		 log.info("from " +st.get(Calendar.DATE)+" to "+et.get(Calendar.DATE)+"  is : "+ total_loop_day + " days.");
		
		 //loop date
		 //for(int i=1;i<=(int)diffDays;i++){
		  for(int i=1;i<=total_loop_day;i++){
			 
			 //log.info("start time : "+ st.getTime());
			// log.info("end   time : "+ et.getTime());
			
			// if(i == diffDays){
			if(i == total_loop_day){
				 //last day 
				 log.info("last day");
				
				 //if loop day is only 1 day it mean this start date will set by custom
				 //not start from 8.30 
				 if( total_loop_day == 1){
					 
					 tmp_start.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_start.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_start.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_start.set(Calendar.HOUR_OF_DAY, st.get(Calendar.HOUR_OF_DAY));
					 tmp_start.set(Calendar.MINUTE,st.get(Calendar.MINUTE));
					 
				 }else{
					 
					 st.set(Calendar.HOUR_OF_DAY, 8);  st.set(Calendar.MINUTE,30);
					 tmp_start.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_start.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_start.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_start.set(Calendar.HOUR_OF_DAY, 8 );
					 tmp_start.set(Calendar.MINUTE,30);
				 }
				
				 if( et.get(Calendar.HOUR_OF_DAY) == 8 &&  et.get(Calendar.MINUTE) == 0 ){
					 et.set(Calendar.MINUTE, 30 );
				 }
				 
				 tmp_end.set(Calendar.DATE,et.get(Calendar.DATE));
				 tmp_end.set(Calendar.MONTH,et.get(Calendar.MONTH));
				 tmp_end.set(Calendar.YEAR,et.get(Calendar.YEAR));
				 tmp_end.set(Calendar.HOUR_OF_DAY, et.get(Calendar.HOUR_OF_DAY));
				 tmp_end.set(Calendar.MINUTE,et.get(Calendar.MINUTE));
				
				 
			 }else{
				 
				 if(i==1){
					 log.info("start i=1");
					 tmp_start.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_start.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_start.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_start.set(Calendar.HOUR_OF_DAY, st.get(Calendar.HOUR_OF_DAY));
					 tmp_start.set(Calendar.MINUTE,st.get(Calendar.MINUTE));
					 
					 tmp_end.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_end.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_end.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_end.set(Calendar.HOUR_OF_DAY, 17 );
					 tmp_end.set(Calendar.MINUTE,30);
					   
				 }else{
					 log.info("start i!=1");
					 tmp_start.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_start.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_start.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_start.set(Calendar.HOUR_OF_DAY, 8 );
					 tmp_start.set(Calendar.MINUTE,30);
					 
					 tmp_end.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_end.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_end.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_end.set(Calendar.HOUR_OF_DAY, 17 );
					 tmp_end.set(Calendar.MINUTE,30);
					 
				 }
				 
				// log.info(i+"> day start "+st.get(Calendar.DATE)+"-"+st.get(Calendar.MONTH)+"-"+st.get(Calendar.YEAR)+" | "+st.get(Calendar.HOUR_OF_DAY)+":"+st.get(Calendar.MINUTE));
				 
				// st.set(Calendar.HOUR_OF_DAY, 17);  st.set(Calendar.MINUTE,30);
				// log.info(i+"> day end "+st.get(Calendar.DATE)+"-"+st.get(Calendar.MONTH)+"-"+st.get(Calendar.YEAR)+" | "+st.get(Calendar.HOUR_OF_DAY)+":"+st.get(Calendar.MINUTE));
				 
				//add one day
				st.add(Calendar.DATE, 1);
				 
			 }//end if diffDay
			 
			 //prepare calculation
			 
			
			 
		 
			 int mm = tmp_start.get(Calendar.MONTH) + 1; // java Calendar.MONTH  start JANUARY from 0
			 String check_holiday = tmp_start.get(Calendar.DATE)+"-"+mm+"-"+tmp_start.get(Calendar.YEAR);
			 boolean is_holiday = false;
			  
			 //log.info("holiday : "+holiday.size());
			 //log.info("check holiday "+check_holiday);
			 if( holiday.contains(check_holiday)){
				 log.info(i+"> today is (holiday ) : result is -> ["+tmp_start.get(Calendar.DATE)+"-"+tmp_start.get(Calendar.MONTH)+"-"+st.get(Calendar.YEAR)+"]");
				 is_holiday = true;
			 }else{
				 //check is today is weekend
				 if( dayOfWeek[tmp_start.get(Calendar.DAY_OF_WEEK)-1].equals("wk")){
					 is_holiday = true; // today is weekend
					 log.info(i+"> today is (weekend) : result is -> "+dayOfWeek[tmp_start.get(Calendar.DAY_OF_WEEK)-1]);
				 }else{
					 log.info(i+"> today is (weekday) : result is -> "+dayOfWeek[tmp_start.get(Calendar.DAY_OF_WEEK)-1]);
				 }
			 }
			 
			 double h = (double)tmp_start.get(Calendar.HOUR_OF_DAY); //0 - 24
			 double m = (double)(tmp_start.get(Calendar.MINUTE)) * 0.01; // convert minute to hour 
			 double starth = h+m;
			 
			 String start_flag = "";
			 String end_flag   = ""; 
			 boolean isLaunchTime = false;
			 if( starth <= 12.01 ){
				// log.info("start is A");
				 start_flag = "A";
			 }else if(starth >= 12.01 && starth <= 13 ){
				 //ceil starth to 13.00
				// starth = 13;
				 tmp_start.set(Calendar.HOUR_OF_DAY,13);
				 tmp_start.set(Calendar.MINUTE,0);
				 start_flag = "B";
				// log.info("start is B");
			 }else if(starth >= 13 ){
				// log.info("start is B");
				 start_flag = "B";
			 }
			
			 h = tmp_end.get(Calendar.HOUR_OF_DAY); //0 - 24
			 m = tmp_end.get(Calendar.MINUTE) * 0.01; // convert minute to hour  
			 double endh = h+m;
			 
			 if( endh <= 12.01 ){
				// log.info("end is A");
				 end_flag = "A";
			 }else if(endh >= 12.01 && endh <= 13 ){
				 //ceil starth to 13.00
				// endh = 13;
				 tmp_end.set(Calendar.HOUR_OF_DAY,13);
				 tmp_end.set(Calendar.MINUTE,0);
				//log.info("end is B");
				 end_flag = "B";
			 }else if(endh >= 13 ){
				// log.info("end is B");
				 end_flag = "B";
			 }
			  
			 log.info(i+"> day start "+tmp_start.get(Calendar.DATE)+"-"+tmp_start.get(Calendar.MONTH)+"-"+tmp_start.get(Calendar.YEAR)+" | "+tmp_start.get(Calendar.HOUR_OF_DAY)+":"+tmp_start.get(Calendar.MINUTE));
			 log.info(i+"> day end "+tmp_end.get(Calendar.DATE)+"-"+tmp_end.get(Calendar.MONTH)+"-"+tmp_end.get(Calendar.YEAR)+" | "+tmp_end.get(Calendar.HOUR_OF_DAY)+":"+tmp_end.get(Calendar.MINUTE));
			
			 
			 //cal leave hour
			 double leave_start = tmp_start.getTimeInMillis();
			 double leave_end   = tmp_end.getTimeInMillis();
		     // Calculate difference in milliseconds
		     double tmp_hour = leave_end - leave_start;
		    // log.info("diff :"+tmp_hour);
		     // Calculate difference in days
		     Double diffHours = tmp_hour / 3600000; //(60 * 60 * 1000);
		     log.info(diffHours.toString());
			 log.info("total leave hours: " + diffHours + " hours.");
			 //----------------------------------
			 
			 if(!is_holiday ){
			    // log.info("START is ["+start_flag+"] | END is ["+end_flag+"]");
				 if( start_flag.equals("A") && end_flag.equals("B")){
					 isLaunchTime = Boolean.TRUE; 
					 log.info(i+"> pass launch time -1 ");
					 leave_hour =  leave_hour + ( diffHours - 1);
				 }else{
					 log.info(i+"> not pass launch time do nothing ");
					 leave_hour =  leave_hour + diffHours;
				 }
			 }
			 
		 }
		 
		 
		 
		 /*
		 if( df.format(startdt).equals(df.format(enddt)) ){
			 log.info("same day");
			 log.info("start date "+st.get(Calendar.HOUR_OF_DAY));
			 
			 double h = (double)st.get(Calendar.HOUR_OF_DAY); //0 - 24
			 double m = (double)(st.get(Calendar.MINUTE)) * 0.01; // convert minute to hour 
			 double starth = h+m;
			 
			 String start_flag = "";
			 String end_flag   = ""; 
			 boolean isLaunchTime = false;
			 if( starth <= 12.01 ){
				 log.info("start is A");
				 start_flag = "A";
			 }else if(starth >= 12.01 && starth <= 13 ){
				 //ceil starth to 13.00
				 starth = 13;
				 start_flag = "B";
				 log.info("start is B");
			 }else if(starth >= 13 ){
				 log.info("start is B");
				 start_flag = "B";
			 }
			
			 h = et.get(Calendar.HOUR_OF_DAY); //0 - 24
			 m = et.get(Calendar.MINUTE) * 0.01; // convert minute to hour  
			 double endh = h+m;
			 
			 if( endh <= 12.01 ){
				 log.info("end is A");
				 end_flag = "A";
			 }else if(endh >= 12.01 && starth <= 13 ){
				 //ceil starth to 13.00
				 endh = 13;
				 log.info("start is B");
				 end_flag = "B";
			 }else if(endh >= 13 ){
				 log.info("start is B");
				 end_flag = "B";
			 }
			 
		     log.info("START is ["+start_flag+"] | END is ["+end_flag+"]");
			 if( start_flag.equals("A") && end_flag.equals("B")){
				 isLaunchTime = Boolean.TRUE;
				 log.info("pass launch time -1 ");
			 }else{
				 log.info("not pass launch time do nothing");
			 }
			 
	
			 
			 
		 }else{
			 log.info("more than one day");
			 
			
			 
		 }
		 */
		// Calendar startDate =  Calendar.getInstance();
		// startDate.setTime(df.parse(df.format(startdt)));
		 
		 log.info("total leave hour : "+leave_hour);
		 return String.valueOf(leave_hour);
	 }
	
}
