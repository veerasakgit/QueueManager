package com.locus.jlo.web.beans.account;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountAttachmentBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private BigInteger accountId;
	private BigInteger attId;
	private BigInteger attStatus;
	private String comment;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate; 
}
