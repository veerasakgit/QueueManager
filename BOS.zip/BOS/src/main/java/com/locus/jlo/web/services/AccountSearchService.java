package com.locus.jlo.web.services;

import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.account.search.AccountSearchBean;

public interface AccountSearchService {
	
	ServiceResult<List<AccountSearchBean>> searchAccount(AccountSearchBean accountSearchBean) throws Exception;

}
