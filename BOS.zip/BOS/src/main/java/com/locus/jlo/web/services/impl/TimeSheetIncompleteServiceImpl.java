package com.locus.jlo.web.services.impl;

import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetApproveBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetIncompleteBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetIncompleteDetailBean;
import com.locus.jlo.web.services.TimeSheetIncompleteService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TimeSheetIncompleteServiceImpl extends BaseService implements TimeSheetIncompleteService{
	
	final static String SQL_TIME_SHEET_INCOMPLETE_USER_LIST = "TIME_SHEET_INCOMPLETE.SQL_TIME_SHEET_INCOMPLETE_USER_LIST";
	final static String SQL_TIME_SHEET_INCOMPLETE_USER_LIST_BY_USER_ID = "TIME_SHEET_INCOMPLETE.SQL_TIME_SHEET_INCOMPLETE_USER_LIST_BY_USER_ID";
	final static String SQL_TIME_SHEET_INCOMPLETE_DETAIL_BY_USER_ID = "TIME_SHEET_INCOMPLETE.SQL_TIME_SHEET_INCOMPLETE_DETAIL_BY_USER_ID";
	final static String SQL_TIME_SHEET_APPROVE_SEND_EMAIL_LIST = "TIME_SHEET_APPROVE.SQL_TIME_SHEET_APPROVE_SEND_EMAIL_LIST";
	
	@Override
	public ServiceResult<List<TimeSheetIncompleteBean>> findTimeSheetIncomplete(TimeSheetIncompleteBean timeSheetIncompleteBean) throws Exception {
		ServiceResult<List<TimeSheetIncompleteBean>> serviceResult = new ServiceResult<List<TimeSheetIncompleteBean>>();
		List<TimeSheetIncompleteBean> result = null;	
		try {
			
			result = dynamicJdbcDao.findForList(SQL_TIME_SHEET_INCOMPLETE_USER_LIST,BeanPropertyRowMapper.newInstance(TimeSheetIncompleteBean.class)
					,new SimpleKeyValue("monthId",timeSheetIncompleteBean.getMonthId())
					,new SimpleKeyValue("year",timeSheetIncompleteBean.getYear()));
			 
			serviceResult = new ServiceResult<List<TimeSheetIncompleteBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
				
		} catch (Exception e) {
			log.info("submitWorkhour Error: "+e);
		}
	
		return serviceResult;
	}

	@Override
	public ServiceResult<List<TimeSheetIncompleteDetailBean>> findTimeSheetIncompleteDetailByUserId(TimeSheetIncompleteBean timeSheetIncompleteBean) throws Exception {
		ServiceResult<List<TimeSheetIncompleteDetailBean>> serviceResult = new ServiceResult<List<TimeSheetIncompleteDetailBean>>();
		List<TimeSheetIncompleteDetailBean> result = null;	
		try {
			
			result = dynamicJdbcDao.findForList(SQL_TIME_SHEET_INCOMPLETE_DETAIL_BY_USER_ID,BeanPropertyRowMapper.newInstance(TimeSheetIncompleteDetailBean.class)
					,new SimpleKeyValue("monthId",timeSheetIncompleteBean.getMonthId())
					,new SimpleKeyValue("uid",timeSheetIncompleteBean.getUid())
					,new SimpleKeyValue("year",timeSheetIncompleteBean.getYear()));
			 
			serviceResult = new ServiceResult<List<TimeSheetIncompleteDetailBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
				
		} catch (Exception e) {
			log.info("submitWorkhour Error: "+e);
		}
	
		return serviceResult;
	}

	@Override
	public ServiceResult<TimeSheetIncompleteBean> findTimeSheetIncompleteByUserId(TimeSheetIncompleteBean timeSheetIncompleteBean) throws Exception {
		ServiceResult<TimeSheetIncompleteBean> serviceResult = new ServiceResult<TimeSheetIncompleteBean>();
		
		try{
		
			TimeSheetIncompleteBean db = dynamicJdbcDao.findForObject(SQL_TIME_SHEET_INCOMPLETE_USER_LIST_BY_USER_ID,
					BeanPropertyRowMapper.newInstance(TimeSheetIncompleteBean.class)
					,new SimpleKeyValue("userId",timeSheetIncompleteBean.getUid())
					,new SimpleKeyValue("monthId",timeSheetIncompleteBean.getMonthId())
					,new SimpleKeyValue("year",timeSheetIncompleteBean.getYear())); 
			
			serviceResult.setResult(db);
			serviceResult.setSuccess(Boolean.TRUE);
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<TimeSheetIncompleteBean>(e);
			serviceResult.setSuccess(Boolean.FALSE);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<TimeSheetApproveBean>> findTimeSheetApproveSendEmailAlert(TimeSheetApproveBean timeSheetApproveBean) throws Exception {
		ServiceResult<List<TimeSheetApproveBean>> serviceResult = new ServiceResult<List<TimeSheetApproveBean>>();
		List<TimeSheetApproveBean> result = null;	
		try {
			
			result = dynamicJdbcDao.findForList(SQL_TIME_SHEET_APPROVE_SEND_EMAIL_LIST,BeanPropertyRowMapper.newInstance(TimeSheetApproveBean.class)
					,new SimpleKeyValue("monthId",timeSheetApproveBean.getMonthId())
					,new SimpleKeyValue("year",timeSheetApproveBean.getYear()));
			 
			serviceResult = new ServiceResult<List<TimeSheetApproveBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
				
		} catch (Exception e) {
			log.info("approve send email Error: "+e);
		}
	
		return serviceResult;
	}

}
