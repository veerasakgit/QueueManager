package com.locus.jlo.web.beans.contacts;

import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactBean extends StampBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3950350928681717283L;
	private Integer id;
	private Integer is_company;
	private String first_name;
	private String last_name;
	private String middle_name;
	private Integer company_id;
	private String company;
	private Integer contact_industry_id;
	private String address;
	private String street;
	private String amphur_city;
	private String province_state;
	private String postal_code;
	private String country;
	private String latitude;
	private String longitude;
	private String phone;
	private String phone2;
	private String phone3;
	private String email;
	private String email2;
	private String email3;
	private String website;
	private String skype_name;
	private Date birthday;
	private String avatar;
	private String background;
	private String job_title;
	private Integer author_id;
	private Integer assigned_to_id;
	private String cached_tag_list;
	private Integer visibility;
}
