package com.locus.jlo.web.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.AbstractHashedMap;
import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.setting.SettingCalendarBean;
import com.locus.jlo.web.beans.setting.SettingPrivilegesBean;
import com.locus.jlo.web.beans.setting.SettingProjectRoleBean;
import com.locus.jlo.web.services.SettingCalendarService;
import com.locus.jlo.web.services.SettingProjectRoleService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SettingProjectRoleServiceImpl extends BaseService implements SettingProjectRoleService {

	// Query
	private final String SQL_SEARCH = "SETTING_PROJECT_ROLE.SQL_SEARCH";
	private final String SQL_SEARCH_MENU = "SETTING_MENU.SQL_SEARCH";
	// Excute
	private final String SQL_INSERT = "SETTING_PROJECT_ROLE.SQL_INSERT";
	private final String SQL_UPDATE = "SETTING_PROJECT_ROLE.SQL_UPDATE";
	private final String SQL_DELETE = "SETTING_PROJECT_ROLE.SQL_DELETE";
	
	private final String SQL_INSERT_MENU = "SETTING_MENU.SQL_INSERT";
	private final String SQL_UPDATE_MENU = "SETTING_MENU.SQL_UPDATE";
	private final String SQL_DELETE_MENU = "SETTING_MENU.SQL_DELETE";

	@Override
	public ServiceResult<List<Map<String, Object>>> searchProjectRole(String id,String status) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();

		try {

			HashMap<String, Object> map = new HashMap<>();
			map.put("id", StringUtils.isEmpty(id) ? null : id);
			map.put("status", StringUtils.isEmpty(status) ? null : status);
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH, map);
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());

		} catch (Exception e) {
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> insertProjectRole(SettingProjectRoleBean bean) throws Exception {

		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	
	}

	@Override
	public ServiceResult<Long> updateProjectRole(SettingProjectRoleBean bean) throws Exception {
	
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, bean );
				
				if (!ObjectBeanUtils.isNullOrZero(id)) {
					
					int size = 0;
					String[] menuArr = null;
					String[] roleMenuArr = null;
					{//set array and size
						if (!StringUtils.isEmpty(bean.getMenu_arr())||!StringUtils.isEmpty(bean.getRole_menu_arr())) {
							if (StringUtils.isEmpty(bean.getMenu_arr())) {
								roleMenuArr = bean.getRole_menu_arr().split(",");
								size = roleMenuArr.length;
							}else if (StringUtils.isEmpty(bean.getRole_menu_arr())) {
								menuArr = bean.getMenu_arr().split(",");
								size = menuArr.length;
							}else {
								roleMenuArr = bean.getRole_menu_arr().split(",");
								menuArr = bean.getMenu_arr().split(",");
								if (menuArr.length >= roleMenuArr.length) {
									size = menuArr.length;
								}else {
									size = roleMenuArr.length;
								}
							}
						}
					}
					
					if (StringUtils.isEmpty(menuArr)&&StringUtils.isEmpty(roleMenuArr)) {
						throw new Exception();
					}
					
					for (int i = 0; i < size; i++) {
						
						SettingPrivilegesBean subBean = new SettingPrivilegesBean();
						subBean.setRole_id(bean.getId());
						subBean.setCreate_uid(bean.getCreate_uid());
						subBean.setUpdate_uid(bean.getUpdate_uid());
						
						if (StringUtils.isEmpty(menuArr) || menuArr.length <= i || StringUtils.isEmpty(menuArr[i])) {
							subBean.setId(Integer.parseInt(roleMenuArr[i]));
							dynamicJdbcDao.executeUpdate(SQL_DELETE_MENU, subBean);
						}
						else if (StringUtils.isEmpty(roleMenuArr) || roleMenuArr.length <= i || StringUtils.isEmpty(roleMenuArr[i])) {
							subBean.setMenu_id(Integer.parseInt(menuArr[i]));
							dynamicJdbcDao.executeInsert(SQL_INSERT_MENU,Boolean.TRUE,subBean);
						}else {
							subBean.setId(Integer.parseInt(roleMenuArr[i]));
							subBean.setMenu_id(Integer.parseInt(menuArr[i]));
							dynamicJdbcDao.executeUpdate(SQL_UPDATE_MENU, subBean);
						}
					}
				}
				
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}

	@Override
	public ServiceResult<Long> deleteProjectRole(String id) throws Exception {
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer delId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(delId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	
	}

	@Override
	public ServiceResult<List<Map<String, Object>>> searchMenu() throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();

		try {
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH_MENU, new SimpleKeyValue());
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());

		} catch (Exception e) {
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}

}
