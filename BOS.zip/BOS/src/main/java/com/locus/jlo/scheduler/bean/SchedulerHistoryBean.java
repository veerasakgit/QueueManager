package com.locus.jlo.scheduler.bean;

import java.util.Date;

import lombok.Data;

@Data
public class SchedulerHistoryBean extends SchedulerBean
{
	private static final long serialVersionUID = 8346538602673442286L;

	private Long schedulerLogId;
	private Date executeDt;
	private Integer statusCode;
	private String statusMessage;
	private String errorMessage;
	
	private String executeDtStr;
}
