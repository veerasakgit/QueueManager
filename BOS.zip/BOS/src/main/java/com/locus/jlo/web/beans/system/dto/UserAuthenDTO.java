package com.locus.jlo.web.beans.system.dto;


import java.util.List;
import org.springframework.security.core.GrantedAuthority;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.security.core.userdetails.User;

@Getter
@Setter
public class UserAuthenDTO {
    private static final long serialVersionUID = -7155518853403064085L;
    private String userId;
    private String login;
    private String password;
    private String authenMode;
 
}
