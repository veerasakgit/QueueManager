package com.locus.jlo.web.services;

import java.util.List;
import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.ReportTimesheetUtilizeBean;

public interface ReportService {
	
	ServiceResult<List<ReportTimesheetUtilizeBean>> searchReportTimesheetUtilize(String year, String monthId) throws Exception;
	
	
	ServiceResult<List<DataBean>> searchReportTimesheet(String year, String monthId) throws Exception;
	ServiceResult<List<DataBean>> searchReportTimesheetDetail(String year, String monthId, String staffId) throws Exception;
	
	ServiceResult<List<DataBean>> searchReportTimesheetNote(String year, String monthId, String staffId) throws Exception;
	ServiceResult<List<DataBean>> searchReportTimeshhetOvertime(String year, String monthId, String staffId) throws Exception;

	ServiceResult<List<DataBean>> getHolidayConfig(String year, String monthId) throws Exception;
	ServiceResult<List<DataBean>> getHolidayConfigBetweenDate(String startDate , String endDate ) throws Exception;
	
	
	ServiceResult<Long> updateTimeSheetEntry(String data) throws Exception;
	ServiceResult<Long> removeTimeSheetEntry(String data) throws Exception;
	
	
	ServiceResult<List<DataBean>> searchStaffDetail(String staffId) throws Exception;
	

	/*timesheet approval*/
	ServiceResult<List<DataBean>> searchTimesheetApproval(String year, String monthId , String projectId, String deptId, String staffId, String approverId ) throws Exception;
	ServiceResult<List<DataBean>> searchTimesheetApprovalStaffDetail(String year, String monthId , String staffId) throws Exception;
	
	
	
	/* approval */
	ServiceResult<Long> approveWorkhour(List<DataBean> db) throws Exception;
	ServiceResult<Long> approveOvertime(List<DataBean> db) throws Exception;
	
	
	//String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception;
	/*
	ServiceResult<Long> insertLogtime(String pid, String tid, String date, String hour, String status, String uid) throws Exception;
	ServiceResult<Long> updateLogtime(String pid, String tid, String date, String hour, String status, String uid, String eid ) throws Exception;
	ServiceResult<Long> removeLogtime(String eid) throws Exception;
	
	ServiceResult<List<DataBean>> searchTimesheet_beforeSubmit() throws Exception;
	ServiceResult<Long> submitTimesheet(String data_eid) throws Exception;
 
	ServiceResult<Integer> insertLogtime(String id) throws Exception;
	ServiceResult<Integer> updateLogtime(String id) throws Exception;
	ServiceResult<Integer> deleteLogtime(String id) throws Exception;
	*/
	
	ServiceResult<List<DataBean>> searchTimesheetForAdmin(String year, String monthId,String division, String departement, String section, String staffId) throws Exception;
}
