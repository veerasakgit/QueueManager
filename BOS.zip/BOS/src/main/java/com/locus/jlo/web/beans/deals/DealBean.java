package com.locus.jlo.web.beans.deals;

import java.math.BigDecimal;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DealBean extends StampBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4517931589837508726L;
	private Integer id;
	private String name;
	private String background;
	private Integer orc_status_id;
	private Integer status_id;
	private String lost_reason_id;
	private String competitor;
	private Integer account_id;
	private Integer contact_id;
	private Integer sales_id;
	private Integer project_manager_id;
	private String forecast_quarter_id;
	private String forecast_month_id;
	private BigDecimal price;
	private Integer currency_id;
	private Integer margin;
	private String chance_of_sale;
	private BigDecimal total_cost_baseline;
	private Date start_date;
	private Date end_date;
	private String project_code;
	private Integer project_id;
	private Integer author_id;
	private Integer assigned_to_id;
	private Integer duration;

	private String saleName;
	private String osCodeName;
	private String dsCodeName;

	private String product_id;

	//UI
	private String action;
	private String deal_id;
}
