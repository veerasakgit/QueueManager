package com.locus.jlo.web.controller;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.web.beans.setting.SettingProjectTaskTemplateBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.SettingProjectTaskTemplateService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class SettingProjectTaskTemplateController extends CoreController{
	

	@Autowired
	private SettingProjectTaskTemplateService settingProjectTemplateService;
	
	@RequestMapping(value = "/searchProjectTaskTemplate", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchProjectTemplate(HttpServletRequest request,Locale locale) throws Exception{
			
		  	String id = request.getParameter("id");
		
			ServiceResult<List<Map<String, Object>>> listResult =  settingProjectTemplateService.searchProjectTaskTemplate(id); 
			JsonResultBean result = null;
			if(listResult.isSuccess()){
				result = new JsonResultBean("success", "" , listResult.getResult());
			}
			return result;
	}
	

	 @RequestMapping(value = "/saveProjectTaskTemplate", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveProjectTemplate(HttpServletRequest request,Locale locale) throws Exception{

		 	final int USER_ID = getUid(request);
			String data = request.getParameter("data");
			 
			log.info("data: "+data);
			 
			JSONParser jParser = new JSONParser();
			JSONObject json = (JSONObject) jParser.parse(data);
				 
			JsonBeanUtils<SettingProjectTaskTemplateBean> utils = new JsonBeanUtils<>(SettingProjectTaskTemplateBean.class);	 		 
			SettingProjectTaskTemplateBean bean = utils.convertFormAndBeanWithUser(json,USER_ID);
				 
			log.info("data");
			utils.print(bean);

			String result_status = "";
			String result_msg    = "";
			ServiceResult<Long> result = new ServiceResult<>();
						 
			 try{
				 if (bean.getId() == null) {
					 result =  settingProjectTemplateService.insertProjectTaskTemplate(bean);
	 	    			
			 	    if(result.isSuccess()){
			 	   		log.info( "get long : "+result.getResult());
			 	   		result_status = "success";
			 	   		result_msg    = "save successful";
			 	    				
			 	   	}else{
			     		result_status = "fail";
			    		result_msg    = "save fail";
		 	    	}
			 	    
				 }else {
					
					result =  settingProjectTemplateService.updateProjectTaskTemplate(bean);
	 	    			
				 	if(result.isSuccess()){
				 	   	log.info( "get long : "+result.getResult());
				 	   	result_status = "success";
				 	   	result_msg    = "save successful";
				 	    				
				 	}else{
				    	result_status = "fail";
				    	result_msg    = "save fail";
			 	    }
				 }
	
		
				}catch(Exception e){
					log.info("Error !!"+e);
				}
			 
			JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult());
//			}
			return res;
		   
		 }
	
	
		@RequestMapping(value = "/deleteProjectTaskTemplate", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean deleteProjectTemplate(HttpServletRequest request,Locale locale) throws Exception{
			
			String id  = request.getParameter("id");
			log.info("id: "+id);
			ServiceResult<Long> idResult =  settingProjectTemplateService.deleteProjectTaskTemplate(id);
			JsonResultBean result = null;
			if(idResult.isSuccess()){
				result = new JsonResultBean("success", "" , idResult.getResult());
			}
			return result;
		 }

		 
}