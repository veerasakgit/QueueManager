package com.locus.jlo.utils;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestSPU {

	private static final String FILE_NAME = "D:/AddressData.xlsx";

	public static void main(String[] args) {
		setObj();
//			while (iterator.hasNext()) {
//
//				Row currentRow = iterator.next();
//				Iterator<Cell> cellIterator = currentRow.iterator();
//
//				while (cellIterator.hasNext()) {
//
//					Cell currentCell = cellIterator.next();
//					// getCellTypeEnum shown as deprecated for version 3.15
//					// getCellTypeEnum ill be renamed to getCellType starting from version 4.0
//					if (currentCell.getCellTypeEnum() == CellType.STRING) {
//						System.out.print(currentCell.getStringCellValue() + "|");
//					} else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
//						
//						Object value = null;	
//						if (DateUtil.isCellDateFormatted(currentCell)) {
//                    		Date date = currentCell.getDateCellValue();
//                    		System.out.print(date + "|");
//						}else {
//							
//							System.out.print(currentCell.getNumericCellValue() + "|");
//						}
//						
//						
//					}
//
//				}
//				System.out.println();
//
//			}


	}
	
	public static void setObj () {
		
		try {

			FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
			Workbook workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = datatypeSheet.iterator();
			
			TestSPU testSPU = new TestSPU();
			
			List<Persons> personsList = new ArrayList<>();
			List<Address> addressList = new ArrayList<>();
			
			while (iterator.hasNext()) {
				
				Row currentRow = iterator.next();
				
				if (currentRow.getRowNum() == 0) {
					continue;
				}
				
				Persons persons =  testSPU.new Persons();
				
				persons.setId(currentRow.getRowNum());
				persons.setIdCard(currentRow.getCell(1).getStringCellValue());
				persons.setName(currentRow.getCell(2).getStringCellValue());
				persons.setBirthDate(currentRow.getCell(3).getDateCellValue());
				persons.setPhoneNumber(Integer.parseInt(currentRow.getCell(5).getStringCellValue()));
	
				Address address =  testSPU.new Address();
				address.setId(currentRow.getRowNum());
				address.setAddress(currentRow.getCell(4).getStringCellValue());
				
				addressList.add(address);
				
				persons.setAddressId(address.getId());
				personsList.add(persons);
				
			}
			System.out.println("Persons");
			testPrint(personsList);
			System.out.println("Address");
			testPrint(addressList);
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void testPrint(List list) {
		
		list.forEach((item)->{
			
			print(item);

			System.out.println();
		});
	}
	
	public static void print(Object item) {
		
		for (Field f : item.getClass().getDeclaredFields()) {
			try {
				if (!f.getName().equals("this$0")) {
					f.setAccessible(true);
					System.out.print(f.getName()+" : "+f.get(item)+" | ") ;
				}
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
	}

	// Connection connect = null;
	//
	// try {
	// Class.forName("com.mysql.jdbc.Driver");
	// connect = DriverManager.getConnection("jdbc:mysql://localhost/test" +
	// "?user=root&password=");
	//
	// if(connect != null){
	// System.out.println("Database Connected.");
	// } else {
	// System.out.println("Database Connect Failed.");
	// }
	//
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// // Close
	// try {
	// if(connect != null){
	// connect.close();
	// }
	// } catch (SQLException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	
	public class Persons{
		
		private int id;
		private String idCard;
		private String name;
		private Date birthDate;
		private int phoneNumber;
		private int addressId;
		

		public String getIdCard() {
			return idCard;
		}
		public void setIdCard(String idCard) {
			this.idCard = idCard;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Date getBirthDate() {
			return birthDate;
		}
		public void setBirthDate(Date birthDate) {
			this.birthDate = birthDate;
		}
		public int getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(int phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		
		public int getAddressId() {
			return addressId;
		}
		public void setAddressId(int addressId) {
			this.addressId = addressId;
		}
	}
	
	public class Address{
		
		private int id;
		private String address;
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}

	}
	
}
