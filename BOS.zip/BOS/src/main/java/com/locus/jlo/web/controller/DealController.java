package com.locus.jlo.web.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.web.beans.deals.DealBean;
import com.locus.jlo.web.beans.deals.DealProductBean;
import com.locus.jlo.web.beans.paymentTerms.PaymentTermsBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.DealProductService;
import com.locus.jlo.web.services.DealService;
import com.locus.jlo.web.services.IdentifyKeyService;
import com.locus.jlo.web.services.PaymentTermsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class DealController extends CoreController {


    @Autowired
    private DealService dealService;

    @Autowired
    private IdentifyKeyService identifyKeyService;

    @Autowired
    private PaymentTermsService paymentTermsService;

    @Autowired
    private DealProductService dealProductService;

    @RequestMapping(value = {"/deal"})
    public String index() {
        return "deal";
    }


    @RequestMapping(value = "/searchDeal", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
    public @ResponseBody
    JsonResultBean searchDeal(@RequestParam(required = false) String id,
                              @RequestParam(required = false) String filter_status,
                              HttpServletRequest request, Locale locale) throws Exception {
        if("all".equals(filter_status)){
            filter_status = null;
        }
        ServiceResult<List<Map<String, Object>>> listResult = dealService.searchDeal(id,filter_status);
        JsonResultBean result = null;
        if (listResult.isSuccess()) {
            result = new JsonResultBean("success", "", listResult.getResult());
        }
        return result;
    }


    @RequestMapping(value = "/dealDetail", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.GET)
    public @ResponseBody
    ModelAndView searchDealDetail(HttpServletRequest request, Locale locale) throws Exception {
        String id = request.getParameter("id");
        log.info("id: " + id);
        DealBean deal = new DealBean();
        if (StringUtils.isEmpty(id)) {
            deal.setAction(BOSConstant.DBAction.INSERT);
        } else {
            deal.setAction(BOSConstant.DBAction.UPDATE);
            deal.setDeal_id(id);
        }
        return new ModelAndView("dealDetail", "dealBean", deal);
    }

    @RequestMapping(value = "/searchDealDetailById/{id}", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.GET)
    public @ResponseBody
    JsonResultBean searchDealDetailById(@PathVariable("id") String id, HttpServletRequest request, Locale locale) throws Exception {
        log.info("id: " + id);
        ServiceResult<DealBean> resultObj = dealService.searchDealDetailById(id);
        JsonResultBean result = null;
        if (resultObj.isSuccess()) {
            result = new JsonResultBean("success", "", resultObj.getResult());
        }
        return result;
    }

    @Transactional(rollbackFor=Exception.class, propagation = Propagation.REQUIRED)
    @RequestMapping(value = "/saveDeal", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
    public @ResponseBody
    JsonResultBean saveDealDetail(@RequestParam String params,
                                       @RequestParam String payments,
                                       HttpServletRequest request, Locale locale) throws Exception {

        final Integer USER_ID = getUid(request);

        ServiceResult<Long> result = new ServiceResult<>();

        String result_status = "";
        String result_msg = "";
        String result_data = "";

        JSONParser jParser = new JSONParser();
        JSONObject json = (JSONObject) jParser.parse(params);

        //convert between form and bean
        JsonBeanUtils<DealBean> utils = new JsonBeanUtils<>(DealBean.class);
        DealBean bean = utils.convertFormAndBeanWithUser(json, USER_ID);
        utils.print(bean);

        bean.setStart_date(parseStrToDate(json.get("start_date").toString()));
        bean.setEnd_date(parseStrToDate(json.get("end_date").toString()));

        if (BOSConstant.DBAction.INSERT.equals(bean.getAction())) {
            log.info("insert identifyKey");
            ServiceResult<Integer> identifyKey =
                    identifyKeyService.insertIdentifyKey("D", bean.getName().trim(),bean.getName(), USER_ID);
            bean.setId(identifyKey.getResult());
            log.info("insert deal...");

            result = dealService.insertDeal(bean);
        } else if (BOSConstant.DBAction.UPDATE.equals(bean.getAction())) {
            log.info("update deal...");
            bean.setUpdate_uid(USER_ID);
            result = dealService.updateDeal(bean);
        } else {
            log.info("No action");
        }
        List<DealProductBean> dpList = this.setDealProductList(bean);

        List<PaymentTermsBean> rawBeans = new ArrayList<>();
        if (!StringUtils.isEmpty(payments) && !(payments.equals("[]"))) {
            rawBeans = this.setPaymentTerms(bean,payments);
        }

        ServiceResult<Integer> delProd = dealProductService.removeDealProjectByDeal(bean.getId());
        if(delProd.isSuccess() && dpList.size()>0){
            for(DealProductBean d : dpList){
                ServiceResult<Integer> dpIns = dealProductService.insertDealProduct(d);
            }
        }

        ServiceResult<Integer> delPay = paymentTermsService.removeProjectPayTermByDeal(bean.getId());
        if(delPay.isSuccess() && rawBeans.size()>0){
            ServiceResult<Integer> payUp = paymentTermsService.savePaymentTerms(rawBeans, USER_ID);
        }

        if (result.isSuccess()) {
            log.info("get long : " + result.getResult());
            result_data = Long.toString(result.getResult());
            result_status = "success";
            result_msg = "save successful";
        } else {
            result_status = "fail";
            result_msg = "save fail";
        }
        JsonResultBean res = new JsonResultBean(result_status, result_msg, bean.getId());
        return res;
    }

    private List<PaymentTermsBean> setPaymentTerms(DealBean bean, String payments) {
        JSONParser jParser = new JSONParser();
        List<PaymentTermsBean> rawBeans = new ArrayList<>();
        JSONArray subJson = null;
        try {
            subJson = (JSONArray) jParser.parse(payments);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < subJson.size(); i++) {
            JSONObject jsonobject = (JSONObject) subJson.get(i);
            String minestone_name = jsonobject.get("minestone_name").toString();
            
            String percentText = jsonobject.get("percent").toString();
            String percentParse = "";
            
            if(percentText.isEmpty()){
            	percentParse = "0";
            }else{
            	percentParse = percentText;
            }
            Integer percent = Integer.parseInt(percentParse);
            
            String amountText = jsonobject.get("amount").toString();
            String amountParse = "";
            
            if(amountText.isEmpty()){
            	amountParse = "0";
            }else{
            	amountParse = amountText;
            }
            
            BigDecimal amount = BigDecimal.valueOf(Double.parseDouble(amountParse));
            String fa_target_dt = jsonobject.get("fa_target_dt").toString();

            PaymentTermsBean b = new PaymentTermsBean();
            b.setAction("I");
            b.setDeal_id(bean.getId());
            b.setMinestone_name(minestone_name);
            b.setAmount(amount);
            b.setPercent(percent);
            b.setFa_target_dt(fa_target_dt);
            rawBeans.add(b);

        }
        return rawBeans;
    }

    private List<DealProductBean> setDealProductList(DealBean bean){
        JSONParser jParser = new JSONParser();
        List<DealProductBean> dpList = new ArrayList<>();
        if (!StringUtils.isEmpty(bean.getProduct_id())) {
            JSONArray productList = null;
            try {
                productList = (JSONArray) jParser.parse(bean.getProduct_id());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            for(int i=0; i<productList.size();i++){
                String prodId = (String) productList.get(i);
                DealProductBean dp = new DealProductBean();
                dp.setDeal_id(bean.getId());
                dp.setProduct_id(Integer.parseInt(prodId));
                dpList.add(dp);
            }
        }
        return dpList;
    }

    @RequestMapping(value = "/deleteDeal", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
    public @ResponseBody
    JsonResultBean deleteDeal(HttpServletRequest request, Locale locale) throws Exception {

        String id = request.getParameter("id");
        log.info("id: " + id);
        ServiceResult<Long> idResult = dealService.deleteDeal(id);
        JsonResultBean result = null;
        if (idResult.isSuccess()) {
            result = new JsonResultBean("success", "", idResult.getResult());
        }
        return result;
    }


}