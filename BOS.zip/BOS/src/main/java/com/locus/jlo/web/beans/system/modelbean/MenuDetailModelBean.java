package com.locus.jlo.web.beans.system.modelbean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MenuDetailModelBean extends BaseModelBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5827049702006919222L;
	private Integer privilegeId;
	private String	privilegesYn;
	private Integer deptId;
	private String	deptName;

	private Integer menuId;
	private String menuName;
	private String menuAction;
	private Integer menuSeq;
	private String menuEnabled;
	public String menuIcon;
	public String menuLevel;
	public String menuParentId;
	private String systemYn;
	private String menuNumber;

	public String checked;

	public MenuDetailModelBean() {
		this.menuEnabled = "Y";
	}


}
