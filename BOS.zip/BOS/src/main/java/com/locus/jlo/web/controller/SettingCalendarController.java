package com.locus.jlo.web.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.setting.SettingCalendarBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.SettingCalendarService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class SettingCalendarController extends CoreController{
	

	@Autowired
	private SettingCalendarService settingCalendar;

	 @RequestMapping(value = {"/setting_calendar"})
	 public String setting_calendar() {
	        return "setting_calendar";
	 }
	 
		@RequestMapping(value = "/searchSettingCalendar", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean searchSettingCalendar(HttpServletRequest request,Locale locale) throws Exception{
			
			String id = request.getParameter("id");
			String dateType = request.getParameter("dateType");
			
			ServiceResult<List<Map<String, Object>>> listResult =  settingCalendar.searchSettingCalendar(id,dateType); 
			JsonResultBean result = null;
			if(listResult.isSuccess()){
				result = new JsonResultBean("success", "" , listResult.getResult());
			}
			return result;
		 }
	 		
		@RequestMapping(value = "/removeSettingCalendar", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean removeSettingCalendar(HttpServletRequest request,Locale locale) throws Exception{
			
			String id  = request.getParameter("id");
			log.info("id: "+id);
			ServiceResult<Long> idResult =  settingCalendar.removeSettingCalendar(id);
			JsonResultBean result = null;
			if(idResult.isSuccess()){
				result = new JsonResultBean("success", "" , idResult.getResult());
			}
			return result;
		 }
		
	 @RequestMapping(value = "/saveSettingCalendar", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveSettingCalendar(HttpServletRequest request,Locale locale) throws Exception{
	     
		 //hard
		 final Integer USER_ID = getUid(request);
		 
		 //
		 
		 String data = request.getParameter("data");
		 String act  = request.getParameter("action");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		 		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
//		 log.info("Timesheet control");
		 log.info("data: "+data);
		 log.info("action : "+act);
		 	 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
		 
		 log.info( ""+json );
		 
		 //convert between form and bean
		 JsonBeanUtils<SettingCalendarBean> utils = new JsonBeanUtils<>(SettingCalendarBean.class);
		 SettingCalendarBean bean = utils.convertFormAndBean(json);

		 bean.setCreate_uid(USER_ID);
		 bean.setUpdate_uid(USER_ID);
		
		 try{
			 
				switch (act){
			 	    case "I" : log.info("insert data");
			 	    			result =  settingCalendar.insertSettingCalendar(bean);
		
			 	    			
			 	    			if( result.isSuccess()){
			 	    			   log.info( "get long : "+result.getResult().longValue() );
			 	    			   result_data   = Long.toString(result.getResult().longValue());
			 	    			   result_status = "success";
								   result_msg    = "save successful";
			 	    				
			 	    			}else{
			 	    				result_status = "fail";
									result_msg    = "save fail";
			 	    			}
			 	    		
							break;
						
			 	    case "U" : log.info("update data");
			 	    				
			 	    				String id = request.getParameter("id");
			 	    				
			 	    				bean.setId(Integer.parseInt(id));
			 	    				
			 						result =  settingCalendar.updateSettingCalendar(bean);
									if( result.isSuccess()){
									log.info( "get long : "+result.getResult().longValue() );
									result_data   = Long.toString(result.getResult().longValue());
									result_status = "success";
									result_msg    = "save successful";
									
									}else{
									result_status = "fail";
									result_msg    = "save fail";
									}

			 	   			break;

			 	   		 
			 	   default : log.error("No action");
					
				}
					
			}catch(Exception e){
				log.info("Error !!"+e);
			}
		 
		 JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		 return res;
	 }
	 
	 
	 
    
}