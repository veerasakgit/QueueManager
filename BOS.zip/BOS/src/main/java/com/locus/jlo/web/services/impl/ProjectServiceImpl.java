package com.locus.jlo.web.services.impl;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.common.mapper.PrimitiveSafeBeanPropertyRowMapper;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.project.ProjectBean;
import com.locus.jlo.web.beans.project.ProjectMembersBean;
import com.locus.jlo.web.services.ProjectMembersService;
import com.locus.jlo.web.services.ProjectService;
import com.mysql.jdbc.StringUtils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
@Slf4j
@Service
public class ProjectServiceImpl extends BaseService implements ProjectService{
	
	private static final String SQL_SEARCH_PROJECT = "PROJECT.SQL_SEARCH_PROJECT";
	private static final String  SQL_SEARCH_PROJECT_DETAIL_BY_ID = "PROJECT.SQL_SEARCH_PROJECT_DETAIL_BY_ID";
	
	private static final String  SQL_INSERT = "PROJECT.SQL_INSERT";
	private static final String  SQL_UPDATE_PROJECT = "PROJECT.SQL_UPDATE_PROJECT";
	private static final String  SQL_DELETE_PROJECT = "PROJECT.SQL_DELETE_PROJECT";
	

	@Autowired
	private ProjectMembersService projectMembersService;
	
	@Override
	public ServiceResult<List<DataBean>> searchProject(String filter_my_project,String filter_project_type,String filter_project_status, String filter_active_project) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		
		try{
			
			
			List<DataBean> result = dynamicJdbcDao.findForList(SQL_SEARCH_PROJECT
						,PrimitiveSafeBeanPropertyRowMapper.newInstance(DataBean.class)
						,new SimpleKeyValue("filter_my_project",filter_my_project)
						,new SimpleKeyValue("filter_project_type",filter_project_type)
						,new SimpleKeyValue("filter_project_status",filter_project_status)
						,new SimpleKeyValue("filter_active_project",filter_active_project)
					);
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<ProjectBean> searchProjectDetail(String project_id) throws Exception {
		ServiceResult<ProjectBean> serviceResult = new ServiceResult<>();
		try{
			ProjectBean result = dynamicJdbcDao.findForObject(SQL_SEARCH_PROJECT_DETAIL_BY_ID
					,PrimitiveSafeBeanPropertyRowMapper.newInstance(ProjectBean.class)
					,new SimpleKeyValue("id",project_id));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<Long> insertNewProject(ProjectBean projectBean) throws Exception {
		
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.FALSE, projectBean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
	            
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
		
	}
	
	
	@Override
	public ServiceResult<Long> insertProject(ProjectBean projectBean,List<ProjectMembersBean> subBeans) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, projectBean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
	            
	            if (!ObjectBeanUtils.isNullOrZero(id)) {
	            	if (!CollectionUtils.isEmpty(subBeans)) {
	            	   	subBeans.forEach((subBean)->{
		            		subBean.setProject_id(id.intValue());
		            	});
	            	   	ServiceResult<List<Long>> subResult = projectMembersService.saveProjectMembers(subBeans);
	            	   	
	            	   	if (CollectionUtils.isEmpty(subResult.getResult())) {
							throw new Exception();
						}
	            	   	
					}
				}
	            
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}
	
	@Override
	public ServiceResult<Long> updateProject(ProjectBean projectBean) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_PROJECT, projectBean);
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.info("updateProject control Error: "+e);
		}
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> removeProject(String project_id) throws Exception {
		 
		//trace parameter
		/*
		log.info("Timesheet control eid :"+eid);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_SETTING_DEPT, new SimpleKeyValue("eid",eid));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
		*/
		return null;
	}
	
	/*
	@Override
	public String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception {
		//ServiceResult<String> result = null;
		
		log.info("Timesheet control"+pid);
		 
		String result = "";
		try {
			List<String> lst = dynamicJdbcDao.findForList(SQL_CHECK_LOGTIME, String.class , 
					new SimpleKeyValue("pid",pid));
			  log.info("size : "+lst.size());
			  if(lst.size()>0){
				  result = lst.get(0);
			log.info("Timesheet control"+lst.get(0));
			  }
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
		return result;
	}
  */
	
	
 
}
