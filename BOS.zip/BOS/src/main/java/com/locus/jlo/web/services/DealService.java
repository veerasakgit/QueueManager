package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.deals.DealBean;

import java.util.List;
import java.util.Map;

public interface DealService {
	
	ServiceResult<List<Map<String, Object>>> searchDeal(String id, String filter_status) throws Exception;
	
	ServiceResult<Long> insertDeal(DealBean bean) throws Exception;
	ServiceResult<Long> updateDeal(DealBean bean) throws Exception;
	ServiceResult<Long> deleteDeal(String id) throws Exception;

    ServiceResult<DealBean> searchDealDetailById(String id);
}
