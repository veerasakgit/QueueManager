package com.locus.jlo.config.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.util.Base64Utils;

@Slf4j
@Configuration
@EnableWebSecurity
@Profile("dev")
public class SecurityConfigurationDev extends WebSecurityConfigurerAdapter {

    @Autowired
    private SecUserDetailsService secUserDetailsService;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .authorizeRequests()
		        .antMatchers("/assets/**").permitAll()
		        .antMatchers("/login*").permitAll()
		        .antMatchers("/expired*").permitAll()
		        .antMatchers("/emailLeaveReply*").permitAll()
		        .antMatchers("/scheduleNotify/**").permitAll()
            .anyRequest()
                .authenticated()
            .and()
                .csrf()
                    .disable()
            .formLogin()
                .loginPage("/login")
                .loginProcessingUrl("/login-process")
                .successHandler(new SuccessLoginHandler())
                .failureHandler(new FailureLoginHandler())
                .permitAll()
            .and()
                .logout()
                .logoutUrl("/logout")
                .permitAll()
            .and()
                .httpBasic()
            .and()
                .sessionManagement()
                    .maximumSessions(10)
                    .maxSessionsPreventsLogin(false)
                    .expiredUrl("/expired")
                .sessionRegistry(sessionRegistry());
    }
    
  //Base64Utils.encodeToString("");
	//Base64Utils.decodeFromString("");
    
    /*	
  @Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
    	
 
    	auth.ldapAuthentication()
        .userDnPatterns("uid={0},ou=people")
        .groupSearchBase("ou=groups")
        .contextSource(contextSource()).passwordCompare()
        .passwordEncoder(new LdapShaPasswordEncoder())
        .passwordAttribute("userPassword");
    	
   
    	
    	auth
		.ldapAuthentication()
			//.userSearchBase("dc=locus,dc=co,dc=th")
			//.userSearchFilter("(sAMAccountName={0})")
			.userSearchBase("ou=users,dc=locus,dc=co,dc=th")
			.userSearchFilter("(uid={0})")
			.contextSource()
				.url("ldap://192.168.200.101:389/DC=locus,DC=co,DC=th")
				.managerDn("arnon@locus.co.th")
				.managerPassword("locus123");
     
    	
    	
				/*
				.and()
				.passwordCompare()
				.passwordAttribute("userPassword");
    	
    	/*
		auth
			.ldapAuthentication()
				.userDnPatterns("CN=arnon@locus.co.th")
				.contextSource()
					.url("ldap://192.168.200.101:389/DC=locus,DC=co,DC=th")
					.and()
					.passwordCompare()
						.passwordAttribute("userPassword");
	
		
		/*
				.userSearchFilter("(sAMAccountName={0})")
				.userSearchBase("DC=locus,DC=co,DC=th")
				.userDnPatterns("uid={0}")
				//.userDnPatterns("uid={0},ou=people")
				//.groupSearchBase("ou=groups")
				.contextSource()
					.url("ldap://192.168.200.101")
					.port(389)
					.managerDn("CN=arnon@locus.co.th")
					.managerPassword("locus123");
					/*	
					.managerDn("CN=sAMAccountName,DC=locus,DC=co,DC=th");
							.managerPassword("locus123");
			
					.and()
				.passwordCompare()
					//.passwordEncoder(new LdapShaPasswordEncoder())
					.passwordAttribute("userPassword");
		*/
		 
//	}


    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(secUserDetailsService);
    	/*
        auth
                .inMemoryAuthentication()
                .withUser("locus").password("locus123").roles("USER")
                .and()
                .withUser("pm").password("locus123").roles("PM");
                */
    }

    @Bean
    public static ServletListenerRegistrationBean httpSessionEventPublisher() {
        return new ServletListenerRegistrationBean(new HttpSessionEventPublisher());
    }

    @Bean
    public SessionRegistry sessionRegistry() {
        SessionRegistry sessionRegistry = new SessionRegistryImpl();
        return sessionRegistry;
    }
}
