package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.scheduler.bean.SchedulerBean;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.department.DepartmentBean;
import com.locus.jlo.web.beans.setting.SettingDeptBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.SettingDeptService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class SettingDeptServiceImpl extends BaseService implements SettingDeptService{
	
	private static final String SQL_SEARCH = "SETTING_DEPT.SQL_SEARCH";	
	private static final  String SQL_INSERT = "SETTING_DEPT.SQL_INSERT";
	private static final  String SQL_UPDATE = "SETTING_DEPT.SQL_UPDATE";
	private static final  String SQL_DELETE = "SETTING_DEPT.SQL_DELETE";
	
	private static final  String SQL_SEARCH_MEMBER = "DEPT_MEMBER.SQL_SEARCH";
	private static final  String SQL_UPDATE_MEMBER = "DEPT_MEMBER.SQL_UPDATE";
	private static final  String SQL_DELETE_MEMBER = "DEPT_MEMBER.SQL_DELETE";
	
	private static final String SQL_SEARCH_DIVISION = "SETTING_DEPT.SQL_SEARCH_DIVISION";	
	private static final String SQL_SEARCH_DEPARTMENT = "SETTING_DEPT.SQL_SEARCH_DEPARTMENT";	
	private static final String SQL_SEARCH_SECTION = "SETTING_DEPT.SQL_SEARCH_SECTION";	
	private static final String SQL_SEARCH_NEW = "SETTING_DEPT.SQL_SEARCH_NEW";	
	
	private static final String SQL_SEARCH_DEPARTMENT_FRIST = "SETTING_DEPT.SQL_SEARCH_DEPARTMENT_FRIST";
	private static final String SQL_SEARCH_SECTION_FRIST = "SETTING_DEPT.SQL_SEARCH_SECTION_FRIST";	
	
	private static final String SQL_INSERT_PROJECT = "SETTING_DEPT_PROJ.SQL_INSERT_PROJECT";	
	private static final String SQL_UPDATE_PROJECT = "SETTING_DEPT_PROJ.SQL_UPDATE_PROJECT";	
	private static final String SQL_INSERT_PROJECT_INDENTIFY = "SETTING_DEPT_PROJ.SQL_INSERT_PROJECT_INDENTIFY";	
	private static final String SQL_SEARCH_PROJECT_DETAIL_BY_ID = "SETTING_DEPT.SQL_SEARCH_PROJECT_DETAIL_BY_ID";	
	private static final String SQL_INSERT_TASK_TEMPLATE_DEPARTMENT_PROJECT = "SETTING_DEPT.SQL_INSERT_TASK_TEMPLATE_DEPARTMENT_PROJECT";
	
	private static final String SQL_SEARCH_DIVISION_BY_DEPARTMENT_ID = "SETTING_DEPT.SQL_SEARCH_DIVISION_BY_DEPARTMENT_ID";	
	private static final String SQL_SEARCH_DEPARTMENT_BY_SECTION_ID = "SETTING_DEPT.SQL_SEARCH_DEPARTMENT_BY_SECTION_ID";	

	@Override 
	public ServiceResult<List<Map<String, Object>>> searchSettingDept(String id) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();
		
		try{
			
			List<Map<String, Object>> result  = dynamicJdbcDao.findForList(SQL_SEARCH_NEW,new SimpleKeyValue("id",id));
				
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}
	
//	@Override
//	public ServiceResult<List<DataBean>> searchSettingDeptDetail(String dept_id) throws Exception {
//		
//	
//		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
//		List<DataBean> result = null;	
//		
//		try{
//			
////			result = dynamicJdbcDao.findForList(SQL_SEARCH_DETAIL,BeanPropertyRowMapper.newInstance(DataBean.class)
////					,new SimpleKeyValue("accountName",""));
//			
//			serviceResult = new ServiceResult<List<DataBean>>(result);
//			System.out.println("Element result :: "+serviceResult.getResult().size());
//			
//		}catch(Exception e){
//			serviceResult = new ServiceResult<List<DataBean>>(e);
//		}
//		return serviceResult;
//	}
	
	@Override
	public ServiceResult<Long> insertSettingDept(SettingDeptBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}
	
	@Override
	public ServiceResult<Long> updateSettingDept(SettingDeptBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, bean);			
//				if (!CollectionUtils.isEmpty(subBeans)) {
//					if (!ObjectBeanUtils.isNullOrZero(id)) {
//						subBeans.forEach((subBean)->{
//						
//						try {
//							
//							Integer deptId = subBean.getDept_id();
//							
//							switch (subBean.getAction()) {
//							case BOSConstant.DBAction.INSERT:
//								dynamicJdbcDao.executeInsert(SQL_INSERT_MEMBER,Boolean.TRUE,subBean);
//								break;
//							case BOSConstant.DBAction.UPDATE:
//								dynamicJdbcDao.executeUpdate(SQL_UPDATE_MEMBER,Boolean.TRUE,subBean);
//								break;
//							case BOSConstant.DBAction.DELETE:
//								dynamicJdbcDao.executeUpdate(SQL_DELETE_MEMBER,Boolean.TRUE,subBean);
//								deptId = 0;
//								break;
//
//							default:
//								break;
//							}
//							
//							dynamicJdbcDao.executeInsert(SQL_UPDATE_USER,Boolean.TRUE,new SimpleKeyValue("dept_id", deptId));
//							
//							
//						} catch (Exception e) {
//							  log.error(e.getMessage()+" "+subBean.getId(),e);
//					          setErrorResult(result, e);
//						}
//							
//						});
//					}
//				}
				
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}
	
	
	@Override
	public ServiceResult<Long> removeSettingDept(String id) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final int delId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id) );
				result.setResult(Long.valueOf(delId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}

	@Override
	public ServiceResult<Long> saveSettingDeptMember(List<SettingUserBean> beans) throws Exception {

		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{		
				if (!CollectionUtils.isEmpty(beans)) {

					beans.forEach((bean)->{

						try {
							
							switch (bean.getAction()) {
							case BOSConstant.DBAction.INSERT:
//								dynamicJdbcDao.executeInsert(SQL_UPDATE_MEMBER,Boolean.TRUE,bean);
//								break;
							case BOSConstant.DBAction.UPDATE:
								dynamicJdbcDao.executeUpdate(SQL_UPDATE_MEMBER,Boolean.TRUE,bean);
								break;
							case BOSConstant.DBAction.DELETE:
								dynamicJdbcDao.executeUpdate(SQL_DELETE_MEMBER,Boolean.TRUE,bean);
								break;

							default:
								break;
							}
							
						} catch (Exception e) {
							  log.error(e.getMessage()+" "+bean.getId(),e);
					          setErrorResult(result, e);
						}
							
					});
					
				}
				
				result.setResult(Long.valueOf("1"));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	
	}

	@Override
	public ServiceResult<List<Map<String, Object>>> searchSettingDeptMember(String id) throws Exception {

		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();
		
		try{

			List<Map<String, Object>> result  = dynamicJdbcDao.findForList(SQL_SEARCH_MEMBER,new SimpleKeyValue("deptId",id));

			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	
	}
	
	/*
	@Override
	public String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception {
		//ServiceResult<String> result = null;
		
		log.info("Timesheet control"+pid);
		 
		String result = "";
		try {
			List<String> lst = dynamicJdbcDao.findForList(SQL_CHECK_LOGTIME, String.class , 
					new SimpleKeyValue("pid",pid));
			  log.info("size : "+lst.size());
			  if(lst.size()>0){
				  result = lst.get(0);
			log.info("Timesheet control"+lst.get(0));
			  }
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
		return result;
	}
  */
	
	
	
	@Override 
	public ServiceResult<List<KeyValueBean>> searchSettingDevision() throws Exception {
		ServiceResult<List<KeyValueBean>> serviceResult = new ServiceResult<List<KeyValueBean>>();   
		try{
			List<KeyValueBean> result  = dynamicJdbcDao.findForList(SQL_SEARCH_DIVISION,BeanPropertyRowMapper.newInstance(KeyValueBean.class));
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}
	
	@Override 
	public ServiceResult<List<KeyValueBean>> searchSettingDepartment(String division) throws Exception {
		ServiceResult<List<KeyValueBean>> serviceResult = new ServiceResult<List<KeyValueBean>>();   
		try{
			List<KeyValueBean> result  = dynamicJdbcDao.findForList(SQL_SEARCH_DEPARTMENT,BeanPropertyRowMapper.newInstance(KeyValueBean.class),new SimpleKeyValue("division",division));
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}
	
	@Override 
	public ServiceResult<List<KeyValueBean>> searchSettingSection(String department) throws Exception {
		ServiceResult<List<KeyValueBean>> serviceResult = new ServiceResult<List<KeyValueBean>>();   
		try{
			List<KeyValueBean> result  = dynamicJdbcDao.findForList(SQL_SEARCH_SECTION,BeanPropertyRowMapper.newInstance(KeyValueBean.class),new SimpleKeyValue("department",department));
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}
	
	@Override 
	public ServiceResult<List<KeyValueBean>> searchSettingDepartment() throws Exception {
		ServiceResult<List<KeyValueBean>> serviceResult = new ServiceResult<List<KeyValueBean>>();   
		try{
			List<KeyValueBean> result  = dynamicJdbcDao.findForList(SQL_SEARCH_DEPARTMENT_FRIST,BeanPropertyRowMapper.newInstance(KeyValueBean.class));
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}
	
	@Override 
	public ServiceResult<List<KeyValueBean>> searchSettingSection() throws Exception {
		ServiceResult<List<KeyValueBean>> serviceResult = new ServiceResult<List<KeyValueBean>>();   
		try{
			List<KeyValueBean> result  = dynamicJdbcDao.findForList(SQL_SEARCH_SECTION_FRIST,BeanPropertyRowMapper.newInstance(KeyValueBean.class));
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<DepartmentBean> searchSettingDeptDetailById(String id) throws Exception {
		ServiceResult<DepartmentBean> serviceResult = new ServiceResult<DepartmentBean>();
		
		try{
			
			DepartmentBean result  = dynamicJdbcDao.findForObject(SQL_SEARCH_NEW,
                    BeanPropertyRowMapper.newInstance(DepartmentBean.class), new SimpleKeyValue("id", id));
			serviceResult = new ServiceResult<DepartmentBean>(result);
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
            setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> insertSettingDeptProject(DepartmentBean departmentBean) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_PROJECT, Boolean.FALSE, departmentBean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	}

	@Override
	public ServiceResult<Long> insertSettingDeptProjectIndentifyKey(DepartmentBean departmentBean) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_PROJECT_INDENTIFY, Boolean.TRUE, departmentBean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	}

	@Override
	public ServiceResult<Long> updateSettingDeptProject(DepartmentBean departmentBean) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		
		try{
				final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE_PROJECT, departmentBean);			
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	}

	@Override
	public ServiceResult<DepartmentBean> searchSettingDeptProjectDetailById(String id) throws Exception {
ServiceResult<DepartmentBean> serviceResult = new ServiceResult<DepartmentBean>();
		
		try{
			
			DepartmentBean result  = dynamicJdbcDao.findForObject(SQL_SEARCH_PROJECT_DETAIL_BY_ID,
                    BeanPropertyRowMapper.newInstance(DepartmentBean.class), new SimpleKeyValue("id", id));
			serviceResult = new ServiceResult<DepartmentBean>(result);
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
            setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> updateProjectSettingDept(SettingDeptBean bean) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		
		try{
				final int id = dynamicJdbcDao.executeUpdate("SETTING_DEPT.SQL_UPDATE_PROJECT_ID", bean);			
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	}

	@Override
	public ServiceResult<Long> insertTaskTemplateDepartmentProject(DepartmentBean departmentBean) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_TASK_TEMPLATE_DEPARTMENT_PROJECT, Boolean.FALSE, departmentBean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	}

	@Override
	public ServiceResult<List<KeyValueBean>> searchDivisionByDepartmentId(String division) throws Exception {
		ServiceResult<List<KeyValueBean>> serviceResult = new ServiceResult<List<KeyValueBean>>();   
		try{
			List<KeyValueBean> result  = dynamicJdbcDao.findForList(SQL_SEARCH_DIVISION_BY_DEPARTMENT_ID,BeanPropertyRowMapper.newInstance(KeyValueBean.class),new SimpleKeyValue("division",division));
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<KeyValueBean>> searchDepartmentBySectionId(String division) throws Exception {
		ServiceResult<List<KeyValueBean>> serviceResult = new ServiceResult<List<KeyValueBean>>();   
		try{
			List<KeyValueBean> result  = dynamicJdbcDao.findForList(SQL_SEARCH_DEPARTMENT_BY_SECTION_ID,BeanPropertyRowMapper.newInstance(KeyValueBean.class),new SimpleKeyValue("division",division));
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}

}
