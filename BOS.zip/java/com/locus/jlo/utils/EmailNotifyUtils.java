package com.locus.jlo.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EmailNotifyUtils {
	
	@Autowired
	ServletContext context;
	
	//send mail notify to user
		//mailTo is String and format is "user1@email.com,user2@email.com";
		//template = email body data
		 private static void sendMailNotify(String mailSubject , String mailTo , String template){
				 try{
					 
					    log.info("-----start send email");
					  	Properties props = new Properties();
				        props.put("mail.smtp.host", "smtp.office365.com");
				        props.put("mail.smtp.socketFactory.port", "587");
				        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
				        props.put("mail.smtp.auth", "true");
				        props.put("mail.smtp.port", "587");
				        props.put("mail.smtp.starttls.enable", "true");
					 
					    Session session = Session.getDefaultInstance(props,
					        	new javax.mail.Authenticator() {
			                 protected PasswordAuthentication getPasswordAuthentication() {
			                     return new PasswordAuthentication("locus_smtp@locus.co.th","locus@123+");
			                 }
			             });
					     
			             Message message = new MimeMessage(session);
			             message.setFrom(new InternetAddress("no-reply@locus.co.th")); 
			             message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(mailTo));
			  
			             
			             message.setSubject(mailSubject);
			             message.setContent(template, "text/html; charset=utf-8");
			             Transport.send(message);
							
			             log.info("-----email successfully sent..");
					
					 
				 }catch(Exception e){
					 log.info("Error !!"+e);
					 e.printStackTrace();
				 }
				 
		 }
		
		 //util
		 //get template path
		 //template type request will have approve and reject link
		 //tempate notify will have only information
		 public String mailTemplate( String template_type ){
			 
			 String relativeWebPath = "/WEB-INF";
			 String filePath = context.getRealPath(relativeWebPath);
			 
			 log.info("relativeWebPath: "+relativeWebPath);

			 switch( template_type ){
				 case "workhour_submitted" : 
									 filePath +=  "/view/emailTemplate/timesheetSubmitNotify.html";
									 break;
				 case "ot_submitted" : 
									 filePath +=  "/view/emailTemplate/otSubmitNotify.html";
									 break;
				 case "workhour_approved"  :
					 				filePath += "";
					 				break;
			 
			 }
				
			 File file = new File(filePath);
			 String msg = "";
			 if (file.exists() && !file.isDirectory()) {
				log.info("filePath: file exist");
				 msg = readContentFromFile(filePath);
			 } else {
				log.info("[filePath] file doesn't exist");
			 }
			 
			 file = new File(file.getAbsolutePath());
			 
			 log.info("getAbsolutePath: "+file);
			 msg = "";
			 if (file.exists() && !file.isDirectory()) {
				log.info("file absolute path: file exist");
				 msg = readContentFromFile(filePath);
			 } else {
				log.info("[file absolute path] file doesn't exist");
			 }
			 
			 return msg;
		 }
		
		  
	 	  //util
		 //read file template 
		 private String readContentFromFile(String fileName){
		     StringBuffer contents = new StringBuffer();
		     
		     try {
		       //use buffering, reading one line at a time
		       BufferedReader reader =  new BufferedReader(new FileReader(fileName));
		       try {
		         String line = null; 
		         while (( line = reader.readLine()) != null){
		           contents.append(line);
		           contents.append(System.getProperty("line.separator"));
		         }
		       }
		       finally {
		           reader.close();
		       }
		     }
		     catch(IOException ex){
		       ex.printStackTrace();
		     }
		     return contents.toString();
		 }
		 
		 //util
		 //remove last character from string
		 public static String removeLastChar(String s) {
			    return (s == null || s.length() == 0)
			      ? null
			      : (s.substring(0, s.length() - 1));
		}
	
	
}