package com.locus.jlo.exception;

import com.locus.common.exception.SQLNameNotMatchException;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalExceptionHandler {

    private final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    @ExceptionHandler(SQLNameNotMatchException.class)
    public Exception sQLNameNotMatchExceptionHandler(HttpServletRequest request, Exception ex) {
        logger.info("SQLNameNotMatchException Occured:: URL=" + request.getRequestURL());
        logger.error(ex.getMessage(), ex);
        return ex;
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    @ExceptionHandler(NullPointerException.class)
    public Exception nullPointerExceptionHandler(HttpServletRequest request, Exception ex) {
        logger.error(ex.getMessage(), ex);
//        logger.log(Level.INFO, "NullPointerException Occured:: URL={0}", request.getRequestURL());
        return ex;
    }
    
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    @ExceptionHandler(Exception.class)
    public Exception exceptionHandler(HttpServletRequest request, Exception ex) {
        logger.error(ex.getMessage(), ex);
//        logger.log(Level.INFO, "NullPointerException Occured:: URL={0}", request.getRequestURL());
        return ex;
    }
}
