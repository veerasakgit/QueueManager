package com.locus.jlo.web.beans.leaveForm;

import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LeaveFormDetailBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String leave_id;
	private String user_id;
	private Date start_dt;
	private Date end_dt;
	private String leave_type_id;
	private String justification;
	private String project_support;
	private String leave_hour;
	private String leave_status;
	private Date request_dt;
	private String request_user_id;

	 
	private Date approve_dt;
	private String approve_user_id;
	private Date approve_wh_pay_dt;
	private String approve_wh_pay_user_id;

	private Date cancel_dt;
	private String cancel_user_id;

	private Date reject_dt;
	private String reject_user_id;
	private String reject_reason;
	 
	private Date create_date;
	private String create_user_id;
	private Date update_date;
	private String update_user_id;
	 
}
