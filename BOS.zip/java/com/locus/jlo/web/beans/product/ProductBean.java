package com.locus.jlo.web.beans.product;

import java.math.BigDecimal;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ProductBean extends StampBean{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8118610262268758769L;
	private Integer id;
	private String image_url;
	private String code;
	private String name;
	private String description;
	private Integer status_id;
	private String currency;
	private BigDecimal price;
	private BigDecimal amount;
	private Integer project_id;
	private Integer category_id;
	private Integer main_product_id;
	private Integer is_main_product;
	private String catch_tag_list;
	
}
