package com.locus.jlo.web.beans.setting;

import java.io.Serializable;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SettingCalendarBean extends StampBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Date calendar_date;
	private String title;
	private Integer date_type;
	private String status;

		
}
