package com.locus.jlo.web.beans.setting;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class SettingPrivilegesBean extends StampBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1625189737189665356L;
	private Integer id;
	private Integer role_id;
	private Integer menu_id;
	private String privileges;
}
