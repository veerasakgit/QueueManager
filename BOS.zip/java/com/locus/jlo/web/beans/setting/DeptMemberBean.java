package com.locus.jlo.web.beans.setting;

import java.io.Serializable;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeptMemberBean extends StampBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer dept_id;
	private Integer user_id;
	private Integer is_dept_head;
	private Integer is_approval;
	
	private String action;
	
	private String is_dept_head_arr;
	private String is_approval_arr;
	


}
