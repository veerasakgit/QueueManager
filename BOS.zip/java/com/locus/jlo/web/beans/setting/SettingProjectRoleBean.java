package com.locus.jlo.web.beans.setting;

import java.io.Serializable;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SettingProjectRoleBean extends StampBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String role_name;
	private String role_detail;
	private String status;
	
	private String role_menu_arr;
	private String menu_arr;
	
		
}
