package com.locus.jlo.web.beans.setting;

import java.io.Serializable;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SettingDeptBean extends StampBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String dept_code;
	private String dept_name;
	private String dept_info;
	private String parent_id;
	//add
	private String dept_type;
	private String implement_team;
	private String project_id;

//	private String create_dt;
//	private String create_user_id;
//	private String update_dt;
//	private String update_user_id;
	
}
