package com.locus.jlo.web.beans.setting;

import java.io.Serializable;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SettingUserBean extends StampBean implements Serializable{
	private static final long serialVersionUID = 1L;

	private Integer id;
	
	private String login_id;
	private String password;
	private String first_name;
	private String middle_name;
	private String last_name;
	private String nick_name;
	private String email;
	private String img_path; 
	private Integer main_dept_id;
	private Integer authentication_type_id;
	private Integer user_status;
	private Date last_login;
	private String is_admin;
	private Date appearance_date;
	private Date  resign_date;
	private String  probation;
	private Date  probation_date;
	private String  employee_id;
	private String  position;
	private Date  birth_date;
	private String  gender;
	private String  address;
	private Integer employee_type;
	private Integer report_to_person_id1;
	private Integer report_to_person_id2;
	private String  emergency_contact_person;
	private String  emergency_contact_phone;
	private String  emergency_contact_addr;
	private Integer  allow_timesheet_backward;
	private Integer  allow_leave_on_probation;
	private String employee_work_hours;
	
	private Integer create_uid;
	private Date create_dt;
	private Integer  update_uid;
	private Date  update_dt;
	
	private Integer job_level;
	private String mobile;
	private String outsource_company_name;
	
	private String is_dept_head;
	private String is_dept_appr;
	private String is_dept_head_arr;
	private String is_dept_appr_arr;
	
	//New
	private Integer division;
	private Integer department;
	private Integer section;
	private Integer jobGroup;
	
	//ui
	private String action;
	
	private String userId;
	private String loginId;
	private String divisionId;
	private String mainDepartmentId;
	private String sectionId;
	private String jobGroupId;
}
