package com.locus.jlo.web.beans.paymentTerms;

import com.locus.jlo.web.beans.StampBean;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@ToString
public class PaymentTermsBean extends StampBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2329923563467923410L;
	private Integer id;
	private Integer deal_id;
	private String minestone_name;
	private String target_date;
	private Integer percent;
	private BigDecimal amount;
	private String collection_dt;
	private String fa_target_dt;

	private Integer seq;
	
	//UI
	private String action;
	private String role_arr;
	private String id_arr;

}
