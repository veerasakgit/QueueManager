package com.locus.jlo.web.beans.cv;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class CvBean extends StampBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5427454792522170211L;
	private Integer id;
	private Integer user_id;
	private String file_name;
	private String file_path;	
}
