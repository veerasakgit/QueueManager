package com.locus.jlo.web.beans.leave.report;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LeaveReportCriteria {

	private String year;
	private String startDate;
	private String endDate;
	private String division;
	private String department;
	private String section;
	private List<String> employeeName;
	private String employeeType;
	private String leaveType;
	private String leaveType_lq;
	private String startDate_1;
	private List<String> employeeName_1;
}
