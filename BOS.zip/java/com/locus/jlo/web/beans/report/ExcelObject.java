package com.locus.jlo.web.beans.report;

import org.apache.poi.xssf.usermodel.XSSFCellStyle;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExcelObject  {
	
	public ExcelObject(int rownum,int cellnum,Object value,XSSFCellStyle style ) {
		this.rownum = rownum;
		this.cellnum = cellnum;
		this.value = value;
		this.style = style;
	}
	
	public ExcelObject(int rownum,int cellnum,Object value,String cellFormula,XSSFCellStyle style ) {
		this.rownum = rownum;
		this.cellnum = cellnum;
		this.cellFormula = cellFormula;
		this.style = style;
	}
	
	//position
	private int rownum;
	private int cellnum;
	
	//value
	private Object value;
	//cellFormula
	private String cellFormula;
	
	//style
	private XSSFCellStyle style;
	
}
