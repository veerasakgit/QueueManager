package com.locus.jlo.web.beans.report.utilization;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UtilizationMonthlyReportRes {

	private String userId;
	private String empname;
	private String empCode;
	private String division;
	private String divisionCode;
	private String gender;
	private String startDate;
	private String endDate;
	private String resignFlag;
	private String noWorkingDay;
	private String jobLevel;
	private String totalWorkingHr;
	private String chargeSima;
	private String chargeOtHr;
	private String chargeTotalWorkHr;
	private String nonChargePresale;
	private String nonChargeCompanyMeeting;
	private String nonChargeCompanyTraining;
	private String nonChargeLeave;
	private String nonChargeAdmin;
	private String nonChargeInternal;
	private String statusNotApproved;
	private String total;
	private String percentChargeOt;
	private String totalChargeNonCharge;
	private String percentChargable;
	private String percentNonChargable;
	private String percentNonChargePresale;
	private String percentNonChargeCompanyMeeting;
	private String percentNonChargeCompanyTraining;
	private String percentNonChargeLeave;
	private String percentNonChargeAdmin;
	private String percentNonChargeInternal;
	private String percentStatusNotApproved;
	
}
