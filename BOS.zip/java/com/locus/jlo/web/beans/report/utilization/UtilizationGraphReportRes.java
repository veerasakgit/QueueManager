package com.locus.jlo.web.beans.report.utilization;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UtilizationGraphReportRes {
	
	private String division;
	private String janPercentChargable;
	private String febPercentChargable;
	private String marPercentChargable;
	private String aprPercentChargable;
	private String mayPercentChargable;
	private String junPercentChargable;
	private String julPercentChargable;
	private String augPercentChargable;
	private String sepPercentChargable;
	private String octPercentChargable;
	private String novPercentChargable;
	private String decPercentChargable;
	private String accPercentChargable;
	
}
