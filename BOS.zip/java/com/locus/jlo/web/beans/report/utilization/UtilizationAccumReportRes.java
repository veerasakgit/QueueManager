package com.locus.jlo.web.beans.report.utilization;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UtilizationAccumReportRes {

	private String userId;
	private String empname;
	private String empCode;
	private String division;
	private String divisionCode;
	private String gender;
	private String department;
	private String startDate;
	private String endDate;
	private String resignDate;
	private String resignFlag;
	private String janWorkDay;
	private String febWorkDay;
	private String marWorkDay;
	private String aprWorkDay;
	private String mayWorkDay;
	private String junWorkDay;
	private String julWorkDay;
	private String augWorkDay;
	private String sepWorkDay;
	private String octWorkDay;
	private String novWorkDay;
	private String decWorkDay;
	private String noWorkingHr;
	private String jobLevel;
	private String totalWorkingHr;
	private String chargeSima;
	private String chargeOtHr;
	private String chargeTotalWorkHr;
	private String nonChargePresale;
	private String nonChargeCompanyMeeting;
	private String nonChargeCompanyTraining;
	private String nonChargeLeave;
	private String nonChargeAdmin;
	private String nonChargeInternal;
	private String statusNotApproved;
	private String total;
	private String percentChargeOt;
	private String totalChargeNonCharge;
	private String percentChargable;
	private String percentNonChargable;
	private String percentNonChargePresale;
	private String percentNonChargeCompanyMeeting;
	private String percentNonChargeCompanyTraining;
	private String percentNonChargeLeave;
	private String percentNonChargeAdmin;
	private String percentNonChargeInternal;
	private String percentStatusNotApproved;

	private String manDay;
	
}
