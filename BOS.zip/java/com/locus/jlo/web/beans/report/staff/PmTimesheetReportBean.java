package com.locus.jlo.web.beans.report.staff;

import java.util.List;
import lombok.Data;

@Data
public class PmTimesheetReportBean {

	private String year;
	private List<String> monthId;
	private List<String> project;
	private List<String> employeeName;
	private String searchMode;
	private String approveId;
}
