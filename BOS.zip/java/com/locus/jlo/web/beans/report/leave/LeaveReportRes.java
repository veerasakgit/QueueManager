package com.locus.jlo.web.beans.report.leave;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LeaveReportRes {
	private String userId;
	private String empId;
	private String fullName;
	private String empType;
	private String employmentDate;
	private String probationDate;
	private String previousYearBal;
	private String resignDate;
	private String resignFlag;
	private String carryPrevious;
	private String newEntitle;
	private String additionalDay;
	private String additionalDate;
	private String annualTotal;
	
	private String usedSi;
	private String usedBu;
	private String usedAn;
	private String usedMa;
	private String usedOr;
	private String usedWp;
	private String usedOthers;
	
	private String balSi;
	private String balBu;
	private String balAn;
	private String balMa;
	private String balOr;
	private String balWp;
	private String balOthers;
	
	private String janSi;
	private String janBu;
	private String janAn;
	private String janMa;
	private String janOr;
	private String janWp;
	private String janOthers;
	
	private String febSi;
	private String febBu;
	private String febAn;
	private String febMa;
	private String febOr;
	private String febWp;
	private String febOthers;
	
	private String marSi;
	private String marBu;
	private String marAn;
	private String marMa;
	private String marOr;
	private String marWp;
	private String marOthers;
	
	private String aprSi;
	private String aprBu;
	private String aprAn;
	private String aprMa;
	private String aprOr;
	private String aprWp;
	private String aprOthers;
	
	private String maySi;
	private String mayBu;
	private String mayAn;
	private String mayMa;
	private String mayOr;
	private String mayWp;
	private String mayOthers;
	
	private String junSi;
	private String junBu;
	private String junAn;
	private String junMa;
	private String junOr;
	private String junWp;
	private String junOthers;
	
	private String julySi;
	private String julyBu;
	private String julyAn;
	private String julyMa;
	private String julyOr;
	private String julyWp;
	private String julyOthers;
	
	private String augSi;
	private String augBu;
	private String augAn;
	private String augMa;
	private String augOr;
	private String augWp;
	private String augOthers;
	
	private String sepSi;
	private String sepBu;
	private String sepAn;
	private String sepMa;
	private String sepOr;
	private String sepWp;
	private String sepOthers;
	
	private String octSi;
	private String octBu;
	private String octAn;
	private String octMa;
	private String octOr;
	private String octWp;
	private String octOthers;
	
	private String novSi;
	private String novBu;
	private String novAn;
	private String novMa;
	private String novOr;
	private String novWp;
	private String novOthers;
	
	private String decSi;
	private String decBu;
	private String decAn;
	private String decMa;
	private String decOr;
	private String decWp;
	private String decOthers;


}
