package com.locus.jlo.web.beans.report.attendance;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AttendanceReportCriteria {

	private String reportType;
	private String startDateSelect;
	private String endDateSelect;
	private String startDate;
	private String endDate;
	private String division;
	private String department;
	private List<String> employeeName;
	private String employeeType;
	private String leaveType;
	
}
