package com.locus.jlo.web.beans.report.utilization;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UtilizationAccumGroupReportRes {

	private String division;
	private String percentChargable;
	private String percentNonChargable;
	
}
