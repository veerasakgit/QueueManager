package com.locus.jlo.web.beans.report.hr;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OTReportCriteria {

	private List<String> employeeId;
	private String yearOt;
	private String monthOt;
	private String division;
	private String department;
	private String section;
	private String employeeType;
	
}
