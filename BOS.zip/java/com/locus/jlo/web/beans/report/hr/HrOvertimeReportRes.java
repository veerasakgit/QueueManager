package com.locus.jlo.web.beans.report.hr;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class HrOvertimeReportRes {
	
	private String tyear;
	private String tmonth;
	private String spentOn;
	private String employeeId;
	private String employeeName;
	private String position;
	private String divisionId;
	private String divisionName;
	private String deptCode;
	private String deptName;
	private String sectionCode;
	private String sectionName;
	private String rankId;
	private String roleId;
	private String projectName;
	private String projectCode;
	private String taskName;
	private String internalProject;
	private String implementProject;
	private String maProject;
	private String dealProject;
	private String projectType;
	private String orcStatusName;
	private String dealStatusName;
	private String salesName;
	private String customerName;
	//private String logtimeStatus;
	//private String logtimeApproveBy;
	private String noteComment;
	//private String officeHour;
	private String otHours;
	//private String totalHours;
	private String otRequested;
	private String startTime;
	private String endTime;
	private String dateType;
	private String otRate1;
	private String otRate15;
	private String otRate3;
	private String mobileService;
	private String carAllowance;
	private String taxiFee;
	private String otApprovedStatus;
	private String approvalUserId;
	private String approvalUser;
	
	
	
}
