package com.locus.jlo.web.beans.account;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountCustomerActivationBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String customerActivationId;
	private BigInteger accountId;
	private String b2cMember;
	private String createdBy; 
	private Date createdDate;
	private String memberProject2;
	private String memberProject3;
	private String memberProject4;
	private String memberProject5;
	private String mhaMember;
	private String mraAdvisor;
	private String mraCode;
	private String mraNote;
	private Date mraRegistrationDate;
	private String mraStatusCode;
	private String updatedBy;
	private Date updatedDate;
}
