package com.locus.jlo.web.beans.account;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AccountDetailBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String accountId;
	private String accountName;//
	private String applicationNo;//
	private Date approvedDate;
	private Date bgEndDate;
	private Date bgStartDate;
	private int blockStatus;
	private String branchNo;
	private String callFlag;
	private String cardHolderFirstName;//
	private String cardHolderLastName;//
	private int cardIssuedBy;
	private String checkDigit;//
	private int collateral;
	private int collateralIssuesBy;
	private String commCertNo;//
	private String creditLine;//
	private String creditSalesCustomer;
	private int creditTerm;
	private Date dataAmendmentDate;
	private int degreeOfProductPotential;
	private int distance;
	private String ecommerceAccount;
	private String eligibleForMakroMail;
	private String emailFlag;
	private String facebook;
	private String facebookFlag;
	private String fax;
	private int headOffice;
	private String idCardNo;//
	private int idCardType;//
	private Date lastPurchasedDate;
	private String lineFlag;
	private String lineId;
	private String mailFlag;
	private String memberCardNo;//
	private String memo1;
	private String memo2;
	private String otherBusinessName;//
	private int portfolioStatus;//
	private String recorderCode;
	private Date registrationDate;//
	private int registrationStore;//
	private int salesOpportunity;
	private String shareOfSpending;
	private String smsFlag;
	private int stageLifeCycle;//
	private Date submittedDate;
	private String totalSpendingMonth;
	private String twitterFlag;
	private int typeOfCreditDebit;
	private int typeOfMemberCard;//
	private String vatRegistered;
	private String whatsapp;
	private String whatsappFlag; 
}
