package com.locus.jlo.web.beans.account.search;

import com.locus.jlo.web.beans.account.AccountDetailBean;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter

public class AccountSearchBean extends AccountDetailBean {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int size;
	private int page;
}
