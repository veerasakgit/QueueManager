package com.locus.jlo.web.beans.account;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ContactAccountBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String contactId;
	private BigInteger accountId;
	private BigInteger contactCommIdEmail;
	private BigInteger contactCommIdMainPhone;
	private BigInteger contactCommIdMobilePhone;
	private String contactStatus;
	private String contactType;
	private String createdBy;
	private Date createdDate;
	private String dateOfBirth;
	private String facebook;//
	private String fax;//
	private String firstName;
	private String idCardNo;
	private String idCardType;
	private String lastName;
	private String lineId;//
	private String partyRowId;
	private String prefix;
	private String relationType;
	private String rowId;
	private String updatedBy;
	private Date updatedDate;
	private String whatsapp;//
}
