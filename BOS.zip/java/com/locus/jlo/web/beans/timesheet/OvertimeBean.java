package com.locus.jlo.web.beans.timesheet;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
public class OvertimeBean {

    private String id;
    private String project_id;
    private String task_id;
    private String user_id;
    private String ot_status;
    private Date ot_date;
    private Date start_time;
    private Date end_time;
    private String date_type;
    private String ot_requested;
    private String mobile_service;
    private String car_allowance;
    private String taxi_requested;
    private String taxi_fare;
    private String ot_note;
    private String create_uid;
    private String create_date;
    private String update_uid;
    private String update_date;
    private String submitted_uid;
    private String submitted_date;
    private String approved_uid;
    private String approved_date;
    private String rejected_uid;
    private String rejected_date;
    
}
