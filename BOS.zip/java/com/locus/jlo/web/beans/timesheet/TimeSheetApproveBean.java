package com.locus.jlo.web.beans.timesheet;

import lombok.Data;

@Data
public class TimeSheetApproveBean {
	private String approverId;
	private String approveName;
	private String approveProjectId;
	private String approveProjectName;
	private String staffId;
	private String staffName;
	private String utilizeHour;
	private String clocking;
	private String draft;
	private String submitted;
	private String monthId;
	private String year;
	private String email;
}
