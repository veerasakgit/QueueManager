package com.locus.jlo.web.beans.timesheet;

import lombok.Data;

@Data
public class TimeSheetIncompleteBean {
	private String uid;
	private String staff;
	private String dept;
	private String email;
	
	private String draft;
	private String submitted;
	private String rejected;
	private String approved;
	private String monthUtilize;
	
	private String monthId;
	private String year;
	
	private String userId;
	
}
