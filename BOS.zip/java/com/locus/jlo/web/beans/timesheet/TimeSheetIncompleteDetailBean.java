package com.locus.jlo.web.beans.timesheet;

import lombok.Data;

@Data
public class TimeSheetIncompleteDetailBean {
	private String projectId;
	private String projectName;
	private String taskId;
	private String taskName;
	private String hours;
	private String days;
	private String dates;
	private String status;
}
