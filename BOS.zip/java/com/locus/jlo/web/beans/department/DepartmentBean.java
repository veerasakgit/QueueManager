package com.locus.jlo.web.beans.department;

import java.io.Serializable;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DepartmentBean extends StampBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String dept_id;
	private String dept_name;
	private String dept_detail;
	private String dept_header;
	private String dept_member;
	private String dept_parent;
	
	private String id;
	private String deptCode;
	private String deptName;
	private String deptType;
	private String deptParentId;
	private String deptLevel;
	private String deptInfo;
	private String deptCreateBy;
	private String deptUpdateBy;
	private String deptCreateDate;
	private String deptUpdateDate;
	
	private String deptProjectId;
	private String deptProjectName;
	private String deptProjectCode;
	private String deptProjectUniName;
	private String deptProjectType;
	private String deptProjectDetail;
	private String deptProjectPlanStartDate;
	private String deptProjectPlanEndDate;
	private String deptProjectActualStartDate;
	private String deptProjectActualEndDate;
	private String deptProjectStatus;
	private String deptProjectStatusIndentity;
	private String deptProjectTypePd;
	
}
