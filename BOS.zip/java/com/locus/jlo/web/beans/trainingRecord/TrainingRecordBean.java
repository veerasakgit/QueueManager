package com.locus.jlo.web.beans.trainingRecord;

import java.math.BigDecimal;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class TrainingRecordBean extends StampBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5427454792522170211L;
	private Integer id;
	private Integer user_id;
	private String certificate_name;
	private Date certificate_date;
	private Date certificate_expire_date;
	private String company;
	private Integer internal;
	private Integer external;
	private Date contribute_by_company;
	private Date contribute_by_company_ending;
	private BigDecimal certificate_allowance;
	private String no_certificate;
	private String po_no;
	private String approved_by;
	private Date approved_date;
	private Date training_contract_date;
	private BigDecimal training_fee;
}
