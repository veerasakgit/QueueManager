package com.locus.jlo.web.beans.deals;

import com.locus.jlo.web.beans.StampBean;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
public class DealProductBean extends StampBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4517931589837508726L;
	private Integer id;
	private Integer deal_id;
	private Integer product_id;

	//UI
	private String action;

}
