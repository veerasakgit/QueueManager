package com.locus.jlo.web.beans;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchBean {
	
	private String id;
	private String field1;
	private String field2;
	private String field3;
	private String field4;
	private String field5;
	private String field6;
	private String field7;
	private String field8;
	private String field9;
	private String field10;
	private String field11;
	private String field12;
	private String field13;
	private String field14;
	private String field15;
	private String field16;
	private String field17;
	private String field18;
	private String field19;
	private String field20;
	private String field21;
	
}
