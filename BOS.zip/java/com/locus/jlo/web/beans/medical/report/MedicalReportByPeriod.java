package com.locus.jlo.web.beans.medical.report;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MedicalReportByPeriod{

	private List<String> employeeName;
	private String startDate;
	private String endDate;
	private String department;
	private String section;
	private String division;

}
