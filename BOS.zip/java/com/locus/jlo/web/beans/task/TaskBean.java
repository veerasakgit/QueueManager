package com.locus.jlo.web.beans.task;

import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TaskBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String task_id;
	private String task_assignee_id;
	private String task_name;
	private Integer seq;
	private Integer task_assign_role_id;
	private String task_role_name;
	private String project_id;
	private String user_id;
	private String status;
	private String progress;
	private String start_dt;
	private String end_dt;
	private String parent_id;
	private String create_dt;
	private String create_user_id;
	private String act;
	
	private String taskId;
	private String taskSeq;
	private String taskName;
	private String taskProjectId;
	private String taskStartDate;
	private String taskEndDate;

}
