package com.locus.jlo.web.beans.task;

import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaskAssigneeBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String task_id;
	private String task_name;
	private String task_assignee_id;
	private Integer status;
	private String project_id;
	private String progress;
	private String start_dt;
	private String end_dt;
	private String create_dt;
	private String create_user_id;
	
	
	private String projectId;
	private String taskId;
	private String userId;
	private String createBy;
	private String startDate;
	private String endDate;
	private String sumHour;
}
