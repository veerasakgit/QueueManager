package com.locus.jlo.web.beans;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RoleBean {

    private String roleId;
    private String roleName;
}
