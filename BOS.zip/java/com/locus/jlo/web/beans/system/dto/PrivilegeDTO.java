package com.locus.jlo.web.beans.system.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrivilegeDTO extends BaseDTO{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9032375057027188575L;
	private Integer sectionId;
	private String sectionName;
	private String sectionValue;
	
}
