package com.locus.jlo.web.beans.system.modelbean;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserLoginInfoModelBean extends BaseModelBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4299176246314524661L;

	private String userId;
	private String password;
	private String roleId;
	private String roleName;
	private String firstName;
	private String lastName;
	private String email;
	private String mobile;
	private String branchCd;
	private String branchName;
	private String teamCd;
	private String teamName;
	private String orgCd;
	private String orgName;
	private Integer creditLevel;
	private String reserveCredit;
	private String paymentCredit;
	private String updatedBy;
	private Date updatedDate;
	private String useYn;
	private String reopenClaimYn;
	private String closeClaimYn;
	private String createPaymentYn;
	private String reservePaymentYn; 
	private String cancelPaymentYn; 
	private String ou;
}
