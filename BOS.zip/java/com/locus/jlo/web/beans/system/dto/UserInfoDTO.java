package com.locus.jlo.web.beans.system.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserInfoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8671194131375095378L;
	
	private String uid;
	private String empId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String nickName;
	private String email;
	private String mobile;
	private String avatar;
	private String deptId;
	private String deptName;
	private String approvalId;
	private String approvalName;
	private String appearanceDate;
	private String curDate;
	private String curDay;
	private String curMonth;
	private String curMonthId;
	private String curYear;
	private String employeeType;
	private String probation_YN;
	private String allowLeaveOnProbation;
	private String allowTimesheetBackward;
	private String resignDate;
	private String probationDate;
	private String isDeptHeadYN;
	private String isAdminYN;
	private String position;
	private String permLevel; //1-staff,2-hr,3-teamlead,4-pm & admin
	private String appLevel; // project_member role id in(1,10,11)
	private String employeeWorkHours;
	
	private String organizeUnit;     // division , dept , section ( last minimal unit group that staff are member )
	private String organizeUnitName; // division , dept , section ( last minimal unit group that staff are member )  
}

