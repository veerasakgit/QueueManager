package com.locus.jlo.web.beans.system.dto;

public class RolePrivilegeDTO {

}
