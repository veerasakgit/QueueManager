package com.locus.jlo.web.beans.assets;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AssetCriteria {

	private String id;
	private String userId;
	private String status;
	private String assetNo;
	private String brand;
	private String serialNo;
	private String division;
	private String department;
	private String section;

	
}
