package com.locus.jlo.web.beans.project;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CalendarBean {


	private String date;
	private String dayType;
	private String dayNameInWeek;
	private String dd;
	private String mmyy;
	private int dayOfMonth;
	private int monthCnt;



}
