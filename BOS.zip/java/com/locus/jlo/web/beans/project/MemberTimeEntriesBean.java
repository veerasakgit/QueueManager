package com.locus.jlo.web.beans.project;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MemberTimeEntriesBean {
		
		
	private String userId;
	private String hours;
	private String spentOn;
	private String dayType;
	

}
