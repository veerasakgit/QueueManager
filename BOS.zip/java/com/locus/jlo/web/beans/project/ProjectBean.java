package com.locus.jlo.web.beans.project;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProjectBean extends StampBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private Integer parent_id;
	private String project_code;
	private String project_name;
	private String project_detail;
	private Integer project_type;
	private Date kick_off_date;
	private Date plan_start_date;
	private Date actual_start_date;
	private Date plan_end_date;
	private Date actual_end_date;
	private Integer project_status;
	private String customer_name;
	private Integer deal_id;
	private Integer account_id;
	private BigDecimal project_value;
	private BigDecimal project_margin;
	private String warranty_info;
	private String project_note;
	private String sales_id;
	private String sales_name;
	private String deals_name;
	private String created_date_text;
	private String create_name;
	private String deals_status;


}
