package com.locus.jlo.web.beans.project;

import com.locus.jlo.web.beans.StampBean;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ProjectProgressBean extends StampBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2329923563467923410L;
	private Integer id;
	private Integer project_id;
	private Integer project_month;
	private Integer project_year;
	private Integer plan_percent;
	private Integer actual_percent;
	
	//UI
	private String action;
	private String role_arr;
	private String id_arr;
}
