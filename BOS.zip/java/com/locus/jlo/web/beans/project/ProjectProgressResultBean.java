package com.locus.jlo.web.beans.project;

import java.util.List;

import com.locus.jlo.web.beans.StampBean;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ProjectProgressResultBean extends StampBean {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 2329923563467923410L;
		
	private String projectMemberId;
	private String userId;
	private String roleId;
	private String userFullname;
	private String roleName;
	private String deptName;
	private String manday;
	private String manHour;
	private String plan;
	private String planStartDate;
	private String planEndDate;
	private String actualHourDisp;
	private Double actualHour;
	private String consumed;
	private String create_date;
	private List<MemberTimeEntriesBean> timeEntries;
	

}
