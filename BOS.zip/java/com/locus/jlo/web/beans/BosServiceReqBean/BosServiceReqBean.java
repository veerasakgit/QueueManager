package com.locus.jlo.web.beans.BosServiceReqBean;

import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BosServiceReqBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String id;
	private String subject;
	private String type;
	private String sub_type;
	private String sr_status;
	private String assigned_uid;
	private Date closed_date;
	private String closed_uid;
	private Date create_dt;
	private String create_uid;
	private Date update_dt;
	private String update_uid;
	 
}
