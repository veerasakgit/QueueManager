package com.locus.jlo.web.beans.tokenBean;

import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TokenBean implements Serializable{
	private static final long serialVersionUID = 1L;
	
	
	private String id;
	private String notify_id;
	private String notify_email;
	private String action;
	private String token;
	private String verify_token;
	private String token_valid_YN;
	private String owner_id;
	private Date expire_date;
	private String create_uid;
	private Date create_dt;
	private String update_uid;
	private Date update_dt;
	private String owner_uid;
	
}
