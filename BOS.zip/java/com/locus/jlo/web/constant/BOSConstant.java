package com.locus.jlo.web.constant;

public interface BOSConstant {
	
	public interface DBAction{
		
		public final static String INSERT = "I";
		public final static String UPDATE = "U";
		public final static String DELETE = "D";
		
	}
	
	public interface User{
		
		public final static String UID = "UID";
		public final static String USER = "USER";
		
	}
	
	public interface Suffix{
		
		public final static String EMAIL = "@locus.co.th";
		
	}
	
	public interface ImportData{
		public final static String SAVE_SUCCESS = "SaveSuccess";
		public final static String SAVE_FAILED = "SaveFailed";
	}

	public interface Path{
		
		public final static String DIRECTORY  = "C:/Max/Work/Project/Locus/BOS/src/main/webapp/";
		//only use in local
//		public final static String DIRECTORY  = "C:/Temp/Upload/";
		
	}
	
	public interface BosSupport{
		
		public final static Integer PROJECT_ID = 0; 
		public final static Integer ASSIGN_UID = 131; 
	}
	
	//Session message result
    public static final String STRING_RESULT_CODE = "RESULT_CODE";
    public static final String STRING_RESULT_DESC = "RESULT_DESC";
    public static final String STRING_RESULT_TITLE = "RESULT_TITLE";
    
    public static final String USER_PROFILE = "USER_PROFILE";
    public static final String PRIVILEGE_PROFILE = "PRIVILEGE_PROFILE";
	
}
