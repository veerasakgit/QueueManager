package com.locus.jlo.web.controller;

import javax.servlet.http.HttpServletRequest;

import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.constant.BOSConstant;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public abstract class CoreController {
	
	protected static final String SEARCH_ALL = "All";
	private static String UPLOADED_FOLDER = "D://";
	final static public SimpleDateFormat yyyyMMdd = new SimpleDateFormat("dd/MM/yyyy", Locale.US);

	protected UserInfoDTO getUser(HttpServletRequest request) {
		
		UserInfoDTO user = (UserInfoDTO) request.getSession().getAttribute(BOSConstant.User.USER);
		
		return user;
	}
	
	protected Integer getUid(HttpServletRequest request) {
		
		String uid = request.getSession().getAttribute(BOSConstant.User.UID).toString();
		
		return Integer.parseInt(uid);
	}

	protected String getUserFullName(HttpServletRequest request) {
		
		UserInfoDTO user = (UserInfoDTO) request.getSession().getAttribute(BOSConstant.User.USER);
		
		return user.getFirstName()+" "+user.getLastName();
	}

	protected Date parseStrToDate(String str){
		Date result = null;
		if(!"".equals(str)){
			try {
				result = yyyyMMdd.parse(str);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}else{
			result = null;
		}
		return result;
	}
	
	
//	@Value("#{google.recaptcha.site-key}")
//    public String recaptchaSiteKey; 

}
