package com.locus.jlo.web.controller;

import java.io.OutputStream;
import java.security.Principal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetApproveBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetIncompleteBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetIncompleteDetailBean;
import com.locus.jlo.web.services.EmailService;
import com.locus.jlo.web.services.TimeSheetIncompleteService;
import com.locus.jlo.web.services.TimesheetService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class TimeSheetIncompleteController {
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private TimeSheetIncompleteService timeSheetIncompleteService;
	
	
	//auto update probation staff
	//every day 
	
	//scheduler on 1 0 1,2,3,4 * *
	//month should be -1 ( data is from previous month )
	@RequestMapping(value = "/scheduleNotify/timeSheetIncompleteEmailAlert", method = RequestMethod.GET)
	public void notifyIncompleteTimesheetEmailAlert(HttpServletRequest request, Locale locale, Principal principal,HttpServletResponse response) throws Exception {
	
		
		String monthId = "";
		String year    = ""; ;
		
		//JAVA.Calendar MONTH start from 0 in db JAN start from 1
		int current_month = Calendar.getInstance().get(Calendar.MONTH)+1;
		int current_year  = Calendar.getInstance().get(Calendar.YEAR);
		int current_day   = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		log.info("current day    : "+current_day);
		log.info("current month  : "+current_month);
		log.info("current year   : "+current_year);
		//log.info("force send notify: "+forceSendNotify);
				
		if(request.getParameter("month")!=null && !request.getParameter("month").isEmpty()){
			 monthId = request.getParameter("month");
		}else{
			 monthId = Integer.toString(current_month);
		}
	
	    if( request.getParameter("year") != null && !request.getParameter("year").isEmpty() ){
		   year = request.getParameter("year");
	    }else{
		   year = Integer.toString(current_year);
	    }
	   
	   log.info("monthID : "+monthId);
	   log.info("year    : "+year);
		
		TimeSheetIncompleteBean timeSheetBean = new TimeSheetIncompleteBean();
		timeSheetBean.setYear(year);
		timeSheetBean.setMonthId(monthId);
		
		ServiceResult<List<TimeSheetIncompleteBean>> listUser = timeSheetIncompleteService.findTimeSheetIncomplete(timeSheetBean);
		
		String template = "";
		String sendTo = "";
		
		//prepare data
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US);
		Date date = new Date();
		
		int month  = Integer.parseInt(monthId) -1;
		String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
		
		if( listUser.isSuccess() ){
			List<TimeSheetIncompleteBean> user = listUser.getResult();
			for(int i=0;i< user.size();i++){
				
				
				TimeSheetIncompleteBean u = user.get(i);
				
				StringBuilder tmpHeader = new StringBuilder();
				StringBuilder tmpBody = new StringBuilder();
		
				
				
				//1. (Header) Summary timesheet 
				tmpHeader.append("<tr>");
				tmpHeader.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Utilize</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+u.getMonthUtilize()+"</p></td>");
				//tmp.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Total</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHour.toString()+"</p></td>");
				tmpHeader.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Draft</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+u.getDraft()+"</p></td>");
				tmpHeader.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Submitted</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+u.getSubmitted()+"</p></td>");
				tmpHeader.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Rejected</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+u.getRejected()+"</p></td>");
				tmpHeader.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Approved</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+u.getApproved()+"</p></td>");
				tmpHeader.append("</tr>");
				
				//2. (Body)  Timesheet detail
				
				//search Timesheet by user id
				timeSheetBean.setUid(u.getUid());
				ServiceResult<List<TimeSheetIncompleteDetailBean>> listTimesheetDetailResult = timeSheetIncompleteService.findTimeSheetIncompleteDetailByUserId(timeSheetBean);
				
				if( listTimesheetDetailResult.isSuccess() && listTimesheetDetailResult.getResult().size() > 0 ){
					List<TimeSheetIncompleteDetailBean> listTimesheetDetail = listTimesheetDetailResult.getResult();
					for (TimeSheetIncompleteDetailBean bean : listTimesheetDetail) {
						//Loop timsheet data
						tmpBody.append("<tr>");
						tmpBody.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:10px; margin:0; padding:0\">"+bean.getDays()+"</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;margin:0; padding:0\">"+bean.getDates()+"</p></td>");
						tmpBody.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+bean.getProjectName()+"</td>");
						tmpBody.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+bean.getTaskName()+"</td>");
						tmpBody.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+bean.getHours()+"</td>");
						tmpBody.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+bean.getStatus()+"</td>");
						tmpBody.append("</tr>");
					}
				}
				
				
				//3. Get Template then set data to template
				template = emailService.mailTemplate("get_time_sheet_incomplete");
				template = template.replaceAll("#createdon",dateFormat.format(date));
				template = template.replaceAll("#staffName",u.getStaff());
				template = template.replaceAll("#staffDept",u.getDept());
				template = template.replaceAll("#timesheet",tmpBody.toString());
				template = template.replaceAll("#month_year",monthName[month]+" "+year);
				template = template.replaceAll("#summary",tmpHeader.toString());
					
				//set email subject
				String mailSubject = "Timesheet on " + monthName[month] + " " +  year + " incomplete notification";
				
				//System.out.println(template.toString());
				log.info("send mail to "+u.getEmail());
				
				//send submit mail notify
				sendTo = u.getEmail();
				emailService.sendMailNotify(mailSubject,sendTo,template);
				
			}
			
		}
		
		
		/*
		String monthId = request.getParameter("monthId");
		String year = request.getParameter("year");
		
		String forceSendNotify = request.getParameter("force");
		
		log.info("monthId: "+monthId);
		log.info("year: "+year);
		
		
		
		
		//test user
		/*
		String[] email = {"arnon@locus.co.th","denvit@locus.co.th","tongta@locus.co.th"}; //, "38", "366"
		for(int i=0;i<email.length;i++){
			
			String mailSubject = "Workspace Test Scheduler Email Notify ";
			String template = "<html><body> Test Scheduler Email Notify </body></html>";
			String sendTo = email[i];
			
			emailService.sendMailNotify(mailSubject,sendTo,template);
			
			
		}//end for
		*/
		
	}
	
	
/*
	@RequestMapping(value = "/timeSheetIncompleteEmailAlert", method = RequestMethod.GET)
	public void timeSheetIncompleteEmailAlert(HttpServletRequest request, Locale locale, Principal principal,HttpServletResponse response) throws Exception {

		Map<String, Object> m = new HashMap<String, Object>();
		JsonResultBean result = null;

		String monthId = request.getParameter("monthId");
		String year = request.getParameter("year");
		
		TimeSheetIncompleteBean timeSheetBean = new TimeSheetIncompleteBean();
		timeSheetBean.setYear(year);
		timeSheetBean.setMonthId(monthId);
		
	
		
		//List User
		ServiceResult<List<TimeSheetIncompleteBean>> listUserIncompleteResult = timeSheetIncompleteService.findTimeSheetIncomplete(timeSheetBean);
		 
		log.info("timesheet incomplete email alert total :"+listUserIncompleteResult.getResult().size());
		
		if(listUserIncompleteResult.isSuccess()){
			List<TimeSheetIncompleteBean> listUserIncomplete = listUserIncompleteResult.getResult();
			
			if(listUserIncomplete != null && listUserIncomplete.size() != 0){
				
				for (TimeSheetIncompleteBean timeSheetIncompleteBean : listUserIncomplete) {
					log.info("Email  : "+timeSheetIncompleteBean.getEmail());
					
					//1. Get Send mail to 
					String sendTo = timeSheetIncompleteBean.getEmail(); //"kanokporn@locus.co.th";
//					String sendTo = "kanokporn@locus.co.th";
					String template = "";
					String totalUtilizeHour = timeSheetIncompleteBean.getTotal();
					String emailSubjectProjectName = "";
					StringBuilder tmp = new StringBuilder();
					Double sumHour = 0d;
					Double sumHourDraft = 0d;
					Double sumHourSubmitted = 0d;
					Double sumHourRejected = 0d;
					Double sumHourApproved = 0d;
					
					TimeSheetIncompleteBean timesheetDetail = new TimeSheetIncompleteBean();
					timesheetDetail.setUid(timeSheetIncompleteBean.getUid());
					timesheetDetail.setMonthId(monthId);
					timesheetDetail.setYear(year);
					
					//Get date Time sheet by user id
					ServiceResult<List<TimeSheetIncompleteDetailBean>> listTimesheetDetailResult = timeSheetIncompleteService.findTimeSheetIncompleteDetailByUserId(timesheetDetail);
					
					if(listTimesheetDetailResult.isSuccess()){
						List<TimeSheetIncompleteDetailBean> listTimesheetDetail = listTimesheetDetailResult.getResult();
						
						StringBuilder tmpSummary = new StringBuilder();
						
						if(listTimesheetDetail != null && listTimesheetDetail.size() != 0){
							
							// Draw tbody in table time sheet
							for (TimeSheetIncompleteDetailBean bean : listTimesheetDetail) {
								//Timsheet data
								 tmp.append("<tr>");
								 tmp.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:10px; margin:0; padding:0\">"+bean.getDays()+"</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;margin:0; padding:0\">"+bean.getDates()+"</p></td>");
								 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+bean.getProjectName()+"</td>");
								 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+bean.getTaskName()+"</td>");
								 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+bean.getHours()+"</td>");
								 tmp.append("<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+bean.getStatus()+"</td>");
								 tmp.append("</tr>");
							 
								 try{
								    sumHour += Double.parseDouble(bean.getHours());
								    
								    if(bean.getStatus().equals("DRAFT")){
								    	sumHourDraft += Double.parseDouble(bean.getHours());
								    	
								    }else if(bean.getStatus().equals("SUBMITTED")){
								    	sumHourSubmitted += Double.parseDouble(bean.getHours());
								    	
								    }else if(bean.getStatus().equals("REJECTED")){
								    	sumHourRejected += Double.parseDouble(bean.getHours());
								    	
								    }else if(bean.getStatus().equals("APPROVED")){
								    	sumHourApproved += Double.parseDouble(bean.getHours());
								    }
									 
								 }catch(Exception e){
									 
								 }
							}
							emailSubjectProjectName = listTimesheetDetail.get(0).getProjectName();
						}
						
						//Time sheet summary
						tmpSummary.append("<tr>");
						tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Utilize</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+totalUtilizeHour+"</p></td>");
						tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Total</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHour.toString()+"</p></td>");
						tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Draft</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHourDraft+"</p></td>");
						tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Submitted</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHourSubmitted+"</p></td>");
						tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Rejected</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHourRejected+"</p></td>");
						tmpSummary.append("<td><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size: 14px; font-weight: 600;text-align: center; margin:0; padding:0\">Approved</p><p style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400;text-align: center; line-height: 1.4;margin:0; padding:0\">"+sumHourApproved+"</p></td>");
						tmpSummary.append("</tr>");
						
						//prepare data
						DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US);
						Date date = new Date();
						
						int month  = Integer.parseInt(monthId) -1;
						String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
						
						//2. Get Template
						template = emailService.mailTemplate("get_time_sheet_incomplete");
						template = template.replaceAll("#createdon",dateFormat.format(date));
						template = template.replaceAll("#staffName",timeSheetIncompleteBean.getStaff());
						template = template.replaceAll("#staffDept",timeSheetIncompleteBean.getDept());
						template = template.replaceAll("#timesheet",tmp.toString());
						template = template.replaceAll("#month_year",monthName[month]+" "+year);
						template = template.replaceAll("#totalHour",sumHour.toString());
						template = template.replaceAll("#utilizeHour",totalUtilizeHour);
						template = template.replaceAll("#summary",tmpSummary.toString());
						
						String mailSubject = "Timesheet on " + monthName[month] + " " +  year + " incomplete notification";
						
						//send submit mail notify
						emailService.sendMailNotify(mailSubject,sendTo,template);
					}
					
					log.info("sendEmailTo : "+sendTo);
					
					
				}
				
			}
		}	
		
		log.info("year : "+year);
		log.info("month: "+monthId);
	}
	*/
	
	//scheduler on 1 0 1,2,3,4 * *
	//month should be -1 ( data is from previous month )
	@RequestMapping(value = "/scheduleNotify/timeSheetApproveSendEmailAlert", method = RequestMethod.GET)
	public void timeSheetApproveSendEmailAlert(HttpServletRequest request, Locale locale, Principal principal,HttpServletResponse response) throws Exception {

		Map<String, Object> m = new HashMap<String, Object>();
		JsonResultBean result = null;

		String monthId = "";
		String year    = ""; ;
				
		//JAVA.Calendar MONTH start from 0 in db JAN start from 1
		int current_month = Calendar.getInstance().get(Calendar.MONTH)+1;
		int current_year  = Calendar.getInstance().get(Calendar.YEAR);
		int current_day   = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		log.info("current day    : "+current_day);
		log.info("current month  : "+current_month);
		log.info("current year   : "+current_year);
		//log.info("force send notify: "+forceSendNotify);
				
		if(request.getParameter("month")!=null && !request.getParameter("month").isEmpty()){
			 monthId = request.getParameter("month");
		}else{
			 monthId = Integer.toString(current_month);
		}
	
	    if( request.getParameter("year") != null && !request.getParameter("year").isEmpty() ){
		   year = request.getParameter("year");
	    }else{
		   year = Integer.toString(current_year);
	    }
	   
	    log.info("monthID : "+monthId);
	    log.info("year    : "+year);
	    
		TimeSheetApproveBean timeSheetBean = new TimeSheetApproveBean();
		timeSheetBean.setYear(year);
		timeSheetBean.setMonthId(monthId);
		
		//List User
		ServiceResult<List<TimeSheetApproveBean>> listApproveResult = timeSheetIncompleteService.findTimeSheetApproveSendEmailAlert(timeSheetBean);
		
		if(listApproveResult.isSuccess()){
			List<TimeSheetApproveBean> listApprove = listApproveResult.getResult();
			
			if(listApprove != null && listApprove.size() != 0){
				int count = 0 ;
				String pointApproveId = "";
				StringBuilder txtDetailBuilder = new StringBuilder();
				String template = "";
				String txtDetail = "";
				String sendTo = "";
				
				for (TimeSheetApproveBean timeSheetApproveBean : listApprove) {
					count++;
					String approveId = timeSheetApproveBean.getApproverId();
					String projectName = timeSheetApproveBean.getApproveProjectName();
					String staffName = timeSheetApproveBean.getStaffName();
					String utilizeHour = timeSheetApproveBean.getUtilizeHour();
					String clocking = timeSheetApproveBean.getClocking();
					String draft = timeSheetApproveBean.getDraft();
					String submitted = timeSheetApproveBean.getSubmitted();
					String emailApprove = timeSheetApproveBean.getEmail();
					
					
					if(!approveId.equals(pointApproveId) && !pointApproveId.equals("")){
						txtDetailBuilder.append(txtDetail);
						
						//prepare data
						DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US);
						Date date = new Date();
						
						int month  = Integer.parseInt(monthId) -1;
						String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
						
						//2. Get Template
						template = emailService.mailTemplate("get_time_sheet_approve_send_email");
						template = template.replaceAll("#createdon",dateFormat.format(date));
						template = template.replaceAll("#timesheet",txtDetail.toString());
						template = template.replaceAll("#month_year",monthName[month]+" "+year);
						
						String mailSubject = "Approve time sheet for staff on project";
					   
						//send submit mail notify
						emailService.sendMailNotify(mailSubject,sendTo,template);
						
						txtDetail = "";
						template = "";
						sendTo = "";
					}
					
					pointApproveId = approveId;
					sendTo = emailApprove;
//					sendTo = "kanokporn@locus.co.th";
					txtDetail += "<tr>";
					txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+projectName+"</td>";
					txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"+staffName+"</td>";
					//txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+utilizeHour+"</td>";
					txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+clocking+"</td>";
					txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+draft+"</td>";
					txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4; text-align:right;\">"+submitted+"</td>";
					txtDetail += "</tr>";
					
					if(count == listApprove.size()){
						txtDetailBuilder.append(txtDetail);
						
						//prepare data
						DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US);
						Date date = new Date();
						
						int month  = Integer.parseInt(monthId) -1;
						String[] monthName = {"January", "February", "March", "April", "May", "June", "July",  "August", "September", "October", "November", "December"};
						
						//2. Get Template
						template = emailService.mailTemplate("get_time_sheet_approve_send_email");
						template = template.replaceAll("#createdon",dateFormat.format(date));
						template = template.replaceAll("#timesheet",txtDetail.toString());
						template = template.replaceAll("#month_year",monthName[month]+" "+year);
						
						String mailSubject = "Approve time sheet for staff on project";
					   
						//send submit mail notify
						emailService.sendMailNotify(mailSubject,sendTo,template);
					}
					
				}
				
			}
		}	
	}
	
}
