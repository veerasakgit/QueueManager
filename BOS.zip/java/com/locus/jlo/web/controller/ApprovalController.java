package com.locus.jlo.web.controller;

import java.security.Principal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.EmailNotifyUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ApprovalService;
import com.locus.jlo.web.services.EmailNotifyService;
import com.locus.jlo.web.services.EmailService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class ApprovalController {

	@Autowired
	private ApprovalService approvalService;

	@Autowired
	private EmailNotifyService emailNotifyService;

	@Autowired
	private EmailService emailService;

	@RequestMapping(value = { "/approval" })
	public String index() {
		return "approval";
	}

	// approval page
	@RequestMapping(value = "/initialApprovalTimesheet", headers = {
			"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean initialApprovalTimesheet(HttpServletRequest request, Locale locale,
			Principal principal) throws Exception {

		Map<String, Object> m = new HashMap<String, Object>();
		JsonResultBean res = null;

		String result_status = "success";
		String result_msg = "success";
		String result_data = "";

		String year = request.getParameter("searchYear");
		String monthId = request.getParameter("searchMonth");

		UserInfoDTO uinfo = (UserInfoDTO) request.getSession().getAttribute("USER");
		String approverId = uinfo.getUid();
		String isAdmin = uinfo.getIsAdminYN();

		try {
			// search filter approve project , Approval can approve only on
			// his/her project but admin can view see all project
			// separate service between admin and non-admin cause query speed (
			// when admin join table project_members it got slow );
			ServiceResult<List<DataBean>> project = new ServiceResult<List<DataBean>>();

			// show all project for admin role
			//if (isAdmin.equals("Y")) {

				// project =
				// approvalService.initFilterTimesheetProjectForAdminRole(year,monthId);

			//} else {

				// normal approval
				project = approvalService.initFilterTimesheetProject(year, monthId, approverId);

				// approve [ PM , authorize approval , backup authorize ] use
				// report to role
				// manager =
				// approvalService.initFilterTimesheetApproveAuthorizePerson(year,monthId,approverId);

			//}

			if (project.isSuccess()) {

				m.put("filterProj", project.getResult());

				// loop only prjectId for search
				/*
				 * List<String> projectId = new ArrayList<String>(); for(int
				 * i=0; i< project.getResult().size(); i++){ DataBean db =
				 * project.getResult().get(i); projectId.add(db.getA()); }
				 */
				// loop for report to person that approve PM , Authorize person
				/*
				 * for(int i=0; i< manager.getResult().size(); i++){
				 * KeyValueBean kb = manager.getResult().get(i);
				 * projectId.add(kb.getId()); }
				 */
				// m.put("filterProj", )

				// add search filter by staff
				/*
				 * ServiceResult<List<DataBean>> staff =
				 * approvalService.initFilterTimesheetStaff(year,monthId,
				 * projectId,isAdmin,approverId); if( staff.isSuccess()){
				 * m.put("filterStaff",staff.getResult()); }
				 * 
				 * //add search filter by department
				 * ServiceResult<List<KeyValueBean>> department =
				 * approvalService.initFilterTimesheetDepartment(year,monthId,
				 * projectId,isAdmin); if( department.isSuccess()){
				 * m.put("filterDept",department.getResult()); }
				 */

				// Timesheet
				// @Deprecate ServiceResult<List<KeyValueBean>> project =
				// approvalService.initFilterTimesheetProject(year,monthId,approverId,isAdmin);
				/*
				 * ServiceResult<List<DataBean>> approveTimesheetList =
				 * approvalService.searchTimesheetApproval(year,monthId,
				 * projectId,deptId,staffId,approverId); if(
				 * approveTimesheetList.isSuccess()){
				 * m.put("approveTimesheetList",approveTimesheetList.getResult()
				 * ); } //OT ServiceResult<List<DataBean>> approveOTList =
				 * approvalService.searchOTApproval(year, monthId, projectId,
				 * deptId, staffId, approverId); if( approveOTList.isSuccess()){
				 * m.put("approveOTList",approveOTList.getResult()); }
				 */

			}

		} catch (Exception e) {
			result_status = "fail";
			result_msg = "fail";

			res = new JsonResultBean(result_status, result_msg, result_data);
			log.info("Error !!" + e);
			e.printStackTrace();

		}

		res = new JsonResultBean(result_status, result_msg, m);
		return res;

	}

	// approval page
	@RequestMapping(value = "/searchApprovalTimesheet", headers = {
			"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchApprovalTimesheet(HttpServletRequest request, Locale locale,
			Principal principal) throws Exception {

		Map<String, Object> m = new HashMap<String, Object>();

		JsonResultBean res = null;

		String result_status = "success";
		String result_msg = "success";
		String result_data = "";

		UserInfoDTO uinfo = (UserInfoDTO) request.getSession().getAttribute("USER");
		String approverId = uinfo.getUid();
		String isAdmin = uinfo.getIsAdminYN();

		String year = request.getParameter("searchYear");
		String monthId = request.getParameter("searchMonth");

		// optional filter
		String searchProject = request.getParameter("searchProject");
		String searchStaff = request.getParameter("searchStaff");

		// all
		String searchAll = request.getParameter("searchAll");

		/**/
		// front-end structure for search all
		// searchAll
		// [{"pid":"674","sid":"87|188|206|242|288|327"},{"pid":"946","sid":"87"}]

		// front-end structure for search by project
		// searchProject 1110
		// searchStaff ["242","25"]

		try {

			// List<String> projectId = jsonToList(searchProject);
			List<String> staffId = new ArrayList<String>();

			// keep result data to approve list
			List<DataBean> aprWorkHour = new ArrayList<DataBean>();
			List<DataBean> aprOverTime = new ArrayList<DataBean>();
			List<DataBean> summaryApproval = new ArrayList<DataBean>();

			// specific project search
			if (!searchProject.equalsIgnoreCase("")) {

				log.info("found search by project : " + searchProject);
				// from json array to java list
				staffId = jsonToList(searchStaff);

				// search workhour
				ServiceResult<List<DataBean>> workhour = approvalService.searchTimesheetApproval(year, monthId,
						searchProject, staffId);
				log.info("workhour return size: " + workhour.getResult().size());
				if (workhour.isSuccess()) {
					aprWorkHour.addAll(workhour.getResult());
				}

				// search overtime
				ServiceResult<List<DataBean>> overtime = approvalService.searchOTApproval(year, monthId, searchProject,
						staffId);
				log.info("overtime return size: " + overtime.getResult().size());
				if (overtime.isSuccess()) {
					aprOverTime.addAll(overtime.getResult());
				}

				// Summary All
				ServiceResult<List<DataBean>> summary = approvalService.summaryApprovalTimesheet(year, monthId,
						searchProject, staffId);
				if (summary.isSuccess()) {
					m.put("approveSummarySheet", summary.getResult());
				}

			} else {

				log.info("search all");

				// search all
				JSONParser jParser = new JSONParser();
				Object oobj = jParser.parse(searchAll);
				JSONArray ojArray = (JSONArray) oobj;
				// log.info("get ot size: "+ojArray.size());

				if (ojArray.size() > 0) {
					// List<DataBean> ot = new ArrayList<DataBean>();
					for (int i = 0; i < ojArray.size(); i++) {
						JSONObject jObject = (JSONObject) ojArray.get(i);

						String pid = jObject.get("pid").toString();
						String sid = jObject.get("sid").toString();

						List<String> staff = new ArrayList<String>();

						String[] parts = sid.split("\\|");
						for (int j = 0; j < parts.length; j++) {
							staff.add(parts[j]);
						}

						ServiceResult<List<DataBean>> workhour = approvalService.searchTimesheetApproval(year, monthId,
								pid, staff);
						log.info("return size: " + workhour.getResult().size());
						if (workhour.isSuccess()) {
							aprWorkHour.addAll(workhour.getResult());
						}

						ServiceResult<List<DataBean>> overtime = approvalService.searchOTApproval(year, monthId, pid,
								staff);
						log.info("return size: " + overtime.getResult().size());
						if (overtime.isSuccess()) {
							aprOverTime.addAll(overtime.getResult());
						}

						ServiceResult<List<DataBean>> summary = approvalService.summaryApprovalTimesheet(year, monthId,
								pid, staff);
						log.info("return size: " + summary.getResult().size());
						if (summary.isSuccess()) {
							summaryApproval.addAll(summary.getResult());
						}

					}
				} // end if

			} // end if-else

			m.put("approveTimesheetList", aprWorkHour);
			m.put("approveOTList", aprOverTime);
			m.put("approveSummarySheet", summaryApproval);

			// step1 check search condition is filter by select project [one
			// project at time]
			// step2 check search condition is filter by select staff in project
			// [Multi value] if not specific it mean all staff
			// step3 all

			// search timesheet approve records
			// ServiceResult<List<DataBean>> result =
			// approvalService.searchTimesheetApproval(year,monthId,projectId,staffId,approverId);
			// if( result.isSuccess()){
			// m.put("approveTimesheetList",result.getResult());
			// }
			/*
			 * ServiceResult<List<DataBean>> approveOTList =
			 * approvalService.searchOTApproval(year, monthId, projectId,
			 * deptId, staffId, approverId); if( approveOTList.isSuccess()){
			 * m.put("approveOTList",approveOTList.getResult()); }
			 * 
			 * //Summary All ServiceResult<List<DataBean>> approveSummarySheet =
			 * approvalService.summaryApprovalTimesheet(year,monthId,projectId,
			 * deptId,staffId,approverId); if( approveSummarySheet.isSuccess()){
			 * m.put("approveSummarySheet",approveSummarySheet.getResult()); }
			 */

			ServiceResult<List<DataBean>> approvalProgress = new ServiceResult<List<DataBean>>();
			if (isAdmin.equals("Y")) {
				// query for admin ( improve for performance )
				approvalProgress = approvalService.searchTimesheetApprovalProgress(year, approverId);
				if (approvalProgress.isSuccess()) {

				}
			} else {
				// query for approval
				approvalProgress = approvalService.searchTimesheetApprovalProgress(year, approverId);
				if (approvalProgress.isSuccess()) {
					m.put("approvalProgress", approvalProgress.getResult());
				}
			}

			// information show last day of month
			// java calendar JAN start from 0
			// int month = Integer.parseInt(monthId) -1;

			Calendar calendar = Calendar.getInstance();
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.MONTH, Integer.parseInt(monthId));
			calendar.set(Calendar.YEAR, Integer.parseInt(year));
			calendar.add(Calendar.DATE, -1);

			String[] monthNames = { "January", "February", "March", "April", "May", "June", "July", "August",
					"September", "October", "November", "December" };
			String info = "1 - " + calendar.get(Calendar.DAY_OF_MONTH) + " " + monthNames[calendar.get(Calendar.MONTH)]
					+ " " + calendar.get(Calendar.YEAR);

			m.put("searchDataLabelInfo", info);

		} catch (Exception e) {

			result_status = "fail";
			result_msg = "fail";

			res = new JsonResultBean(result_status, result_msg, result_data);
			log.info("Error !!" + e);
			e.printStackTrace();

		}

		res = new JsonResultBean(result_status, result_msg, m);
		return res;

	}

	// approve ot
	@RequestMapping(value = "/saveStaffOTApprovalAll", headers = {
			"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveStaffOTApprovalAll(HttpServletRequest request, Locale locale)
			throws Exception {

		JsonResultBean res = null;

		String result_status = "";
		String result_msg = "";
		String result_data = "";
		
		// prepare email header
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US);
		Date date = new Date();

		try {

			String overtime = request.getParameter("ot");
			String UID = request.getSession().getAttribute("UID").toString();

			ServiceResult<Long> result = new ServiceResult<>();

			// loop ot
			JSONParser jParser = new JSONParser();
			Object oobj = jParser.parse(overtime);
			JSONArray ojArray = (JSONArray) oobj;
			log.info("get ot size: " + ojArray.size());
			if (ojArray.size() > 0) {
				List<DataBean> ot = new ArrayList<DataBean>();
				List<DataBean> listAllowanceOt = new ArrayList<DataBean>();
				for (int i = 0; i < ojArray.size(); i++) {
					JSONObject jObject = (JSONObject) ojArray.get(i);
					DataBean db = new DataBean();
					db.setA(jObject.get("oid").toString());
					db.setB(jObject.get("sts").toString());
					db.setC(UID);
					ot.add(db);

					String statusReject = jObject.get("sts").toString();
					if (statusReject.equals("3")) {
						listAllowanceOt.add(db);
					}
				}

				result = approvalService.approveOvertime(ot);
				if (result.isSuccess()) {
					log.info("get long : " + result.getResult().longValue());
					result_data = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg = "save successful";

					String pointUserId = "";
					String txtDetail = "";
					String template = "";
					int count = 0 ;
					String sendTo = "";
					String sendToName = "";
					
					StringBuilder tmp = new StringBuilder();
					
					// send email reject
					if (listAllowanceOt != null && listAllowanceOt.size() != 0) {
						
						for (DataBean dataBean : listAllowanceOt) {
							count++;
							
							String aid = dataBean.getA();
							//Send Email Reject
							ServiceResult<DataBean> getDataTimesheetOvertimeRejected = approvalService.searchOTApprovalByAllowanceId(aid);
							
							if(getDataTimesheetOvertimeRejected.isSuccess()){
								
								DataBean tmRejectBean = getDataTimesheetOvertimeRejected.getResult();
								String userId = tmRejectBean.getV();
								String nameSendEmail = tmRejectBean.getU();
								
								if(!userId.equals(pointUserId) && !pointUserId.equals("")){//check new userId >> send email before user 
									tmp.append(txtDetail);
									
									//2. Get Template
									template = emailService.mailTemplate("reject_time_sheet_send_email_overtime");
									template = template.replaceAll("#createdon",dateFormat.format(date));
									template = template.replaceAll("#timesheet",txtDetail.toString());
									
									String mailSubject = "*** Reject Overtime Timesheet of**** "+sendToName;
								   
									//send submit mail notify
									emailService.sendMailNotify(mailSubject,sendTo,template);
									log.info("in for send mail to ----------------->"+sendToName);
									
									txtDetail = "";
									template = "";
									sendTo = "";
									sendToName = "";
									tmp = new StringBuilder();
								}
									
								pointUserId = userId;
								sendTo = tmRejectBean.getW(); 
//								sendTo = "kanokporn@locus.co.th";
								sendToName = nameSendEmail;
								
								txtDetail += "<tr>";
								txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">";
								txtDetail += "<p class='nospace' style='color:#999'><small>"+tmRejectBean.getD()+"</small></p>";
								txtDetail += "<p class='nospace'>"+tmRejectBean.getE()+"</p>";
								txtDetail += "</td>";
								txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:left;\">"+tmRejectBean.getC()+"</td>";
								txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"+tmRejectBean.getF()+"</td>";
								txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"+tmRejectBean.getG()+"</td>";
								txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"+tmRejectBean.getH()+"</td>";
								
								if(tmRejectBean.getI().equals("fas fa-check checked-active")){
									txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">&#10003;</td>";
								}else{
									txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\"></td>";
								}
								
								if(tmRejectBean.getJ().equals("fas fa-check checked-active")){
									txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">&#10003;</td>";
								}else{
									txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\"></td>";
								}
								
								if(tmRejectBean.getK().equals("fas fa-check checked-active")){
									txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">&#10003; </td>";
								}else{
									txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\"></td>";
								}
								
								if(tmRejectBean.getL().equals("fas fa-check checked-active")){
									txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">&#10003;<br>"+tmRejectBean.getM()+"</td>";
								}else{
									txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\"></td>";
								}
								txtDetail += "<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:left;\">"+tmRejectBean.getX()+"</td>";
								
								
								if(count == listAllowanceOt.size()){
									tmp.append(txtDetail);
									
									//2. Get Template
									template = emailService.mailTemplate("reject_time_sheet_send_email_overtime");
									template = template.replaceAll("#createdon",dateFormat.format(date));
									template = template.replaceAll("#timesheet",txtDetail.toString());
									
									String mailSubject = "*** Reject Overtime Timesheet of**** "+sendToName;
								   
									//send submit mail notify
									emailService.sendMailNotify(mailSubject,sendTo,template);
									log.info("in for send mail to ----------------->"+sendToName);
									
									txtDetail = "";
									template = "";
									sendTo = "";
									sendToName = "";
									tmp = new StringBuilder();
								}
								
							}
							
							
						}//End loop Allowance
					}

				} else {
					result_status = "fail";
					result_msg = "save fail";
				}
			} else {
				result_data = "";
				result_status = "warning";
				result_msg = "No updated records";
			}

			res = new JsonResultBean(result_status, result_msg, result_data);

		} catch (Exception e) {

			result_status = "fail";
			result_msg = "search fail";
			result_data = "";

			res = new JsonResultBean(result_status, result_msg, result_data);
			log.info("Error !!" + e);
			e.printStackTrace();
		}

		return res;

	}

	// approve timesheet
	@RequestMapping(value = "/saveStaffApprovalAll", headers = {
			"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveStaffApprovalAll(HttpServletRequest request, Locale locale)
			throws Exception {
		log.info("approval save");

		JsonResultBean res = null;

		String result_status = "";
		String result_msg = "";
		String result_data = "";

		try {

			String workhour = request.getParameter("workhour");
			String approvalId = request.getSession().getAttribute("UID").toString();

			String year = request.getParameter("searchYear");
			String monthId = request.getParameter("searchMonth");

			ServiceResult<Long> result = new ServiceResult<>();

			JSONParser jParser = new JSONParser();
			Object wobj = jParser.parse(workhour);
			JSONArray wjArray = (JSONArray) wobj;
			log.info("get workhour size: " + wjArray.size());

			// loop workhour
			if (wjArray.size() > 0) {

				// This arrayList keep unique project_id for send notify to each
				// staff
				List<String> rejectMail = new ArrayList<String>();
				List<DataBean> rejectData = new ArrayList<DataBean>();

				// List<String> approveMail = new ArrayList<String>();

				List<DataBean> wh = new ArrayList<DataBean>();

				for (int i = 0; i < wjArray.size(); i++) {

					JSONObject jObject = (JSONObject) wjArray.get(i);

					String staffid = jObject.get("staffid").toString();
					String projectid = jObject.get("projid").toString();
					String sts = jObject.get("sts").toString();

					DataBean db = new DataBean();
					db.setA(staffid);
					db.setB(projectid);
					db.setC(sts);
					db.setD(approvalId);
					db.setE(year);
					db.setF(monthId);
					wh.add(db);

					// send mail notify do on rejected status
					if (jObject.get("sts").toString().equalsIgnoreCase("3")) {

						log.info("found rejected status " + projectid + "|" + staffid);

						// check not same project_id|staff_id
						if (!rejectMail.contains(projectid + "|" + staffid)) {
							// add data to list for check duplicate
							rejectMail.add(projectid + "|" + staffid);

							DataBean rejData = new DataBean();
							rejData.setA(jObject.get("projid").toString());
							rejData.setB(jObject.get("staffid").toString());
							rejData.setC(monthId);
							rejData.setD(year);
							rejectData.add(rejData);
						}

					}
					// send mail notify do on approve status
					/*
					 * }else if(
					 * jObject.get("sts").toString().equalsIgnoreCase("4")){
					 * if(rejectMail.contains(jObject.get("projid").toString()))
					 * { //do nothing }else{ //insert new data to array
					 * approveMail.add(jObject.get("projid").toString()); } }
					 */

				}

				log.info("wh size : " + wh.size());
				result = approvalService.staffApprovalAll(wh);
				if (result.isSuccess()) {
					log.info("get udpate records : " + result.getResult().longValue());
					result_data = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg = "save successful";

				} else {

					result_data = "fail";
					result_status = "fail";
					result_msg = "save fail";
				}

				// if found reject email send notify to user
				if (rejectMail.size() > 0) {
					log.info("----------------------- found reject email ");
					sendMailNotify(rejectData, "from_screen_approval_all");
				}

			} else {
				// no updated records
				result_data = "";
				result_status = "warning";
				result_msg = "No updated records";
			}

			// send email back to staff after approve or reject

			res = new JsonResultBean(result_status, result_msg, result_data);
			// loop ot
			/*
			 * Object oobj = jParser.parse(overtime); JSONArray ojArray =
			 * (JSONArray)oobj; log.info("get ot size: "+ojArray.size());
			 * if(ojArray.size() > 0){ List<DataBean> ot = new
			 * ArrayList<DataBean>(); for( int i=0;i<ojArray.size();i++){
			 * JSONObject jObject = (JSONObject)ojArray.get(i);
			 * 
			 * DataBean db = new DataBean();
			 * db.setA(jObject.get("oid").toString());
			 * db.setB(jObject.get("sts").toString()); db.setC( UID );
			 * ot.add(db); }
			 * 
			 * result = approvalService.approveOvertime( ot ); if(
			 * result.isSuccess()){ log.info(
			 * "get long : "+result.getResult().longValue() ); result_data =
			 * Long.toString(result.getResult().longValue()); result_status =
			 * "success"; result_msg = "save successful";
			 * 
			 * }else{ result_status = "fail"; result_msg = "save fail"; } } //
			 * JSONObject jObject = (JSONObject)jArray.get(0);
			 */

			// ServiceResult<List<DataBean>> listResult =
			// timesheetService.searchTimesheet_beforeSubmit();
			/*
			 * JsonResultBean result = null; if(listResult.isSuccess()){ result
			 * = new JsonResultBean("success", "" , listResult.getResult()); }
			 */

		} catch (Exception e) {

			result_status = "fail";
			result_msg = "search fail";
			result_data = "";

			res = new JsonResultBean(result_status, result_msg, result_data);
			log.info("Error !!" + e);
			e.printStackTrace();
		}

		return res;
	}

	@RequestMapping(value = "/searchApprovalStaffDtl", headers = {
			"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchApprovalStaffDtl(HttpServletRequest request, Locale locale,
			Principal principal) throws Exception {

		JsonResultBean res = null;

		String result_status = "fail";
		String result_msg = "search fail";
		String result_data = "";

		String year = request.getParameter("searchYear");
		String monthId = request.getParameter("searchMonth");
		String staffId = request.getParameter("staffId");
		String projectId = request.getParameter("projectId");

		try {

			ServiceResult<List<DataBean>> result = approvalService.searchTimesheetApprovalStaffDetail(year, monthId,
					staffId, projectId);
			if (result.isSuccess()) {
				log.info("get long : " + result.getResult().size());
				result_status = "success";
				result_msg = "save successful";
				res = new JsonResultBean(result_status, result_msg, result.getResult());

			} else {
				result_status = "fail";
				result_msg = "save fail";
				res = new JsonResultBean(result_status, result_msg, result_data);
			}

		} catch (Exception e) {
			res = new JsonResultBean(result_status, result_msg, result_data);
			log.info("Error !!" + e);
			e.printStackTrace();

		}

		return res;

	}

	// save approval
	@RequestMapping(value = "/saveApproval", headers = {
			"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveApproval(HttpServletRequest request, Locale locale) throws Exception {
		log.info("approval save");

		String workhour = request.getParameter("workhour");
		String overtime = request.getParameter("ot");
		// String act = request.getParameter("action");
		String UID = request.getSession().getAttribute("UID").toString();

		ServiceResult<Long> result = new ServiceResult<>();

		String result_status = "";
		String result_msg = "";
		String result_data = "";

		JSONParser jParser = new JSONParser();
		Object wobj = jParser.parse(workhour);
		JSONArray wjArray = (JSONArray) wobj;
		log.info("get workhour size: " + wjArray.size());
		// loopt workhour
		if (wjArray.size() > 0) {

			List<DataBean> wh = new ArrayList<DataBean>();
			List<DataBean> listTimeSheetReject = new ArrayList<DataBean>();

			for (int i = 0; i < wjArray.size(); i++) {

				JSONObject jObject = (JSONObject) wjArray.get(i);

				DataBean db = new DataBean();
				db.setA(jObject.get("eid").toString());
				db.setB(jObject.get("sts").toString());
				db.setC(UID);
				wh.add(db);

				String taskStatus = jObject.get("sts").toString();
				if (taskStatus.equals("3")) {
					// Find data time sheet by task id
					ServiceResult<DataBean> timesheetByTaskId = approvalService
							.getTimesheetRejectDataByTimeEntries(jObject.get("eid").toString());
					if (timesheetByTaskId.isSuccess()) {
						listTimeSheetReject.add(timesheetByTaskId.getResult());
					}
				}

			}

			result = approvalService.approveWorkhour(wh);
			if (result.isSuccess()) {
				log.info("get long : " + result.getResult().longValue());
				result_data = Long.toString(result.getResult().longValue());
				result_status = "success";
				result_msg = "save successful";

			} else {
				log.info("no record update");
				result_status = "fail";
				result_msg = "save fail";
			}

			// Send Email task Reject
			StringBuilder tmp = new StringBuilder();
			String send_mail_to = "";
			String staffName = "";
			String template = "";

			if (listTimeSheetReject != null && listTimeSheetReject.size() != 0) {

				for (DataBean dataBean : listTimeSheetReject) {
					String email = dataBean.getA();
					String name = dataBean.getC();
					String project = dataBean.getD();
					String task = dataBean.getE();
					String statusReject = dataBean.getF();
					String rejectHour = dataBean.getG();
					String rejectDate = dataBean.getH();
					String rejectBy = dataBean.getI();

					send_mail_to = email;
					// send_mail_to = "kanokporn@locus.co.th";
					staffName = name;
					// loop data
					tmp.append("<tr>");
					tmp.append(
							"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"
									+ rejectDate + "</td>");
					tmp.append(
							"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"
									+ project + "</td>");
					tmp.append(
							"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"
									+ task + "</td>");
					tmp.append(
							"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"
									+ rejectHour + "</td>");
					tmp.append(
							"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"
									+ rejectBy + "</td>");
					tmp.append("</tr>");
				}
				// prepare email header
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US);
				Date date = new Date();

				// 2. Get Template
				template = emailService.mailTemplate("reject_time_sheet_send_email");
				template = template.replaceAll("#createdon", dateFormat.format(date));
				template = template.replaceAll("#timesheet", tmp.toString());

				String mailSubject = "*** Reject Timesheet of**** " + staffName;

				// send submit mail notify
				emailService.sendMailNotify(mailSubject, send_mail_to, template);
				log.info("in for send mail to ----------------->" + send_mail_to);
			}

		} else {
			// no updated records
			result_data = "";
			result_status = "warning";
			result_msg = "No updated records";
		}

		JsonResultBean res = new JsonResultBean(result_status, result_msg, result_data);
		return res;
	}

	// ot staff detail search
	@RequestMapping(value = "/searchOvertimeStaffDtl", headers = {
			"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchOvertimeStaffDtl(HttpServletRequest request, Locale locale,
			Principal principal) throws Exception {

		JsonResultBean res = null;

		String result_status = "";
		String result_msg = "";
		String result_data = "";

		String otId = request.getParameter("id");
		try {

			ServiceResult<List<DataBean>> result = approvalService.searchOvertimeStaffDtl(otId);
			if (result.isSuccess()) {
				log.info("get long : " + result.getResult().size());
				result_status = "success";
				result_msg = "save successful";
				res = new JsonResultBean(result_status, result_msg, result.getResult());

			} else {
				result_status = "fail";
				result_msg = "save fail";
				res = new JsonResultBean(result_status, result_msg, result_data);
			}

		} catch (Exception e) {
			res = new JsonResultBean(result_status, result_msg, result_data);
			log.info("Error !!" + e);
			e.printStackTrace();

		}

		return res;

	}

	@RequestMapping(value = "/saveOvertimeDtlApproval", headers = {
			"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveOvertimeDtlApproval(HttpServletRequest request, Locale locale)
			throws Exception {

		JsonResultBean res = null;

		String result_status = "";
		String result_msg = "";
		String result_data = "";

		// prepare data
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US);
		Date date = new Date();

		try {

			String action = request.getParameter("action");
			String otId = request.getParameter("otid");
			String approverId = request.getSession().getAttribute("UID").toString();
			String data = request.getParameter("data");

			ServiceResult<Long> result = new ServiceResult<>();

			// a = approved
			if (action.equals("a")) {

				result = approvalService.approvedOvertimeStaffDetail(otId, approverId);
				if (result.isSuccess()) {
					log.info("get long : " + result.getResult().longValue());
					result_data = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg = "save successful";

				} else {
					result_status = "fail";
					result_msg = "save fail";
				}

			} else
			// r= rejected
			if (action.equals("r")) {

				result = approvalService.rejectedOvertimeStaffDetail(otId, approverId, data);
				if (result.isSuccess()) {
					log.info("get long : " + result.getResult().longValue());
					result_data = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg = "save successful";

					// Send Email Reject
					ServiceResult<DataBean> getDataTimesheetOvertimeRejected = approvalService
							.searchOTApprovalByAllowanceId(otId);

					if (getDataTimesheetOvertimeRejected.isSuccess()) {

						DataBean tmRejectBean = getDataTimesheetOvertimeRejected.getResult();

						String template = "";
						StringBuilder tmp = new StringBuilder();
						String sendTo = tmRejectBean.getW();
//						String sendTo = "kanokporn@locus.co.th";

						tmp.append("<tr>");
						tmp.append(
								"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">");
						tmp.append(
								"<p class='nospace' style='color:#999'><small>" + tmRejectBean.getD() + "</small></p>");
						tmp.append("<p class='nospace'>" + tmRejectBean.getE() + "</p>");
						tmp.append("</td>");
						tmp.append(
								"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:left;\">"
										+ tmRejectBean.getC() + "</td>");
						tmp.append(
								"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"
										+ tmRejectBean.getF() + "</td>");
						tmp.append(
								"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"
										+ tmRejectBean.getG() + "</td>");
						tmp.append(
								"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"
										+ tmRejectBean.getH() + "</td>");

						if (tmRejectBean.getI().equals("fas fa-check checked-active")) {
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">&#10003;</td>");
						} else {
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\"></td>");
						}

						if (tmRejectBean.getJ().equals("fas fa-check checked-active")) {
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">&#10003;</td>");
						} else {
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\"></td>");
						}

						if (tmRejectBean.getK().equals("fas fa-check checked-active")) {
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">&#10003; </td>");
						} else {
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\"></td>");
						}

						if (tmRejectBean.getL().equals("fas fa-check checked-active")) {
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">&#10003;<br>"
											+ tmRejectBean.getM() + "</td>");
						} else {
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\"></td>");
						}
						tmp.append(
								"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:left;\">"
										+ tmRejectBean.getX() + "</td>");

						// 2. Get Template
						template = emailService.mailTemplate("reject_time_sheet_send_email_overtime");
						template = template.replaceAll("#createdon", dateFormat.format(date));
						template = template.replaceAll("#timesheet", tmp.toString());

						String mailSubject = "*** Reject Overtime Timesheet of**** " + tmRejectBean.getU();

						// send submit mail notify
						emailService.sendMailNotify(mailSubject, sendTo, template);
						log.info("in for send mail to ----------------->" + sendTo);

					}

				} else {
					result_status = "fail";
					result_msg = "save fail";
				}
			}

			res = new JsonResultBean(result_status, result_msg, result_data);

		} catch (Exception e) {

			result_status = "fail";
			result_msg = "search fail";
			result_data = "";

			res = new JsonResultBean(result_status, result_msg, result_data);
			log.info("Error !!" + e);
			e.printStackTrace();
		}

		return res;
	}

	@RequestMapping(value = "/fillterStaff", headers = {
			"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean fillterStaff(HttpServletRequest request, Locale locale, Principal principal)
			throws Exception {

		Map<String, Object> m = new HashMap<String, Object>();
		JsonResultBean res = null;

		String result_status = "success";
		String result_msg = "success";
		String result_data = "";

		String year = request.getParameter("searchYear");
		String monthId = request.getParameter("searchMonth");
		String project = request.getParameter("searchProject");

		UserInfoDTO uinfo = (UserInfoDTO) request.getSession().getAttribute("USER");
		String approverId = uinfo.getUid();
		String isAdmin = uinfo.getIsAdminYN();

		try {
			List<String> projectId = jsonToList(project);

			ServiceResult<List<KeyValueBean>> initProject = new ServiceResult<List<KeyValueBean>>();
			if (projectId.isEmpty()) {
				if (isAdmin.equals("Y")) {
					initProject = approvalService.initFilterTimesheetProjectForAdminRole(year, monthId);
				} else {
					// initProject =
					// approvalService.initFilterTimesheetProject(year,monthId,approverId);
				}

				if (initProject.isSuccess()) {

					projectId = new ArrayList<String>();
					for (int i = 0; i < initProject.getResult().size(); i++) {
						KeyValueBean kb = initProject.getResult().get(i);
						projectId.add(kb.getId());
					}
				}
			}

			// add search filter by staff
			ServiceResult<List<DataBean>> staff = approvalService.initFilterTimesheetStaff(year, monthId, projectId,
					isAdmin, approverId);
			if (staff.isSuccess()) {
				log.info("Staff total: " + staff.getResult().size());
				m.put("filterStaff", staff.getResult());
			}

		} catch (Exception e) {
			result_status = "fail";
			result_msg = "fail";

			res = new JsonResultBean(result_status, result_msg, result_data);
			log.info("Error !!" + e);
			e.printStackTrace();

		}

		res = new JsonResultBean(result_status, result_msg, m);
		return res;

	}

	private List<String> jsonToList(String jsonString) {
		List<String> tmp = new ArrayList<String>();
		if (jsonString != null) {
			try {
				JSONParser jParser = new JSONParser();
				Object obj = jParser.parse(jsonString);
				JSONArray jArray = (JSONArray) obj;

				// projectId = project.toString().replaceAll("\\[|\\]", "");
				// //remove [ ]

				for (int i = 0; i < jArray.size(); i++) {
					tmp.add(jArray.get(i).toString());
					// log.info("project id :"+project.get(i));
				}

			} catch (Exception e) {
				log.info("Error !!" + e);
				e.printStackTrace();
			}
		}
		return tmp;
	}

	private void sendMailNotify(List<DataBean> data, String screen_type) {

		try {
			log.info("start check -------------------------------------------------");
			if (screen_type.equals("from_screen_approval_all")) {

				// prepare email header
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US);
				Date date = new Date();
				String template = "";

				// DataBean D is month_id
				int month = Integer.parseInt(data.get(0).getD()) - 1;
				String[] monthName = { "January", "February", "March", "April", "May", "June", "July", "August",
						"September", "October", "November", "December" };

				// on this screen we will got project id, user_id as a where
				// condition
				for (int j = 0; j < data.size(); j++) {
					DataBean db = data.get(j);
					db.getA(); // project id
					db.getB(); // staff id

					log.info("project id :" + db.getA());
					log.info("staff id :" + db.getB());

					// get data
					// C = year
					// D = month
					// A = project
					// B = staff
					ServiceResult<List<DataBean>> mail = emailNotifyService.getTimesheetRejectData(db.getC(), db.getD(),
							db.getA(), db.getB());

					// loop mail data
					if (mail.isSuccess()) {

						String send_mail_to = "";
						String staffName = "";
						List<DataBean> lists = mail.getResult();
						StringBuilder tmp = new StringBuilder();

						for (int i = 0; i < lists.size(); i++) {
							String email = lists.get(i).getA();
							String name = lists.get(i).getC();
							String project = lists.get(i).getD();
							String task = lists.get(i).getE();
							String statusReject = lists.get(i).getF();
							String rejectHour = lists.get(i).getG();
							String rejectDate = lists.get(i).getH();
							String rejectBy = lists.get(i).getI();

							send_mail_to = email;
							// send_mail_to = "kanokporn@locus.co.th";
							staffName = name;
							// loop data
							tmp.append("<tr>");
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"
											+ rejectDate + "</td>");
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"
											+ project + "</td>");
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"
											+ task + "</td>");
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;text-align:center;\">"
											+ rejectHour + "</td>");
							tmp.append(
									"<td style=\"font-family:'Helvetica Neue',sans-serif; color:#666; font-size:13px; font-weight: 400; line-height: 1.4;\">"
											+ rejectBy + "</td>");
							tmp.append("</tr>");

						}

						// 2. Get Template
						template = emailService.mailTemplate("reject_time_sheet_send_email");
						template = template.replaceAll("#createdon", dateFormat.format(date));
						template = template.replaceAll("#timesheet", tmp.toString());

						String mailSubject = "*** Reject Timesheet of**** " + staffName;

						// send submit mail notify
						emailService.sendMailNotify(mailSubject, send_mail_to, template);
						log.info("in for send mail to ----------------->" + send_mail_to);

					}

				} // end loop for

			} else if (screen_type.equals("from_screen_approval_person")) {
				// this screen will send time_entry_id

			}

		} catch (Exception e) {

			log.info("Error !!" + e);
			e.printStackTrace();
		}

	}

}