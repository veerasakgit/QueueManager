package com.locus.jlo.web.controller;

import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.ReportTimesheetUtilizeBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ReportService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
public class ReportController {
	
	
	@Autowired
	private ReportService reportService;
	
	
	 @RequestMapping(value = {"/report"})
	 public String index() {
	        return "report";
	 }
	 
	 @RequestMapping(value = {"/report_hr_overtime"})
	 public String report_hr_overtime() {
	        return "report_hr_overtime";
	 }
	 
	 @RequestMapping(value = {"/ot_report"})
	 public String ot_report() {
	        return "ot_report";
	 }
	 
	 @RequestMapping(value = {"/man_hour_report"})
	 public String man_hour_report() {
	        return "man_hour_report";
	 }
	 
	 @RequestMapping(value = {"/report_hr_timesheet"})
	 public String report_hr_timesheet() {
	        return "report_hr_timesheet";
	 }
	 
	 @RequestMapping(value = {"/report_timesheet_utilize"})
	 public String report_timesheet_utilize() {
	        return "report_timesheet_utilize";
	 }
	 
	 @RequestMapping(value = {"/report_timesheet_by_project"})
	 public String report_timesheet_by_project() {
	        return "report_timesheet_by_project";
	 }
	 
	 @RequestMapping(value = {"/report_timesheet_by_staff"})
	 public String report_timesheet_by_staff() {
	        return "report_timesheet_by_staff";
	 }
	
	 @RequestMapping(value = {"/medical_allowance_report_by_period_new"})
	 public String medical_allowance_report_by_period_new() {
	        return "medical_allowance_report_by_period_new";
	 }
	 
	 @RequestMapping(value = {"/medical_allowance_report_sum_new"})
	 public String medical_allowance_report_sum_new() {
	        return "medical_allowance_report_sum_new";
	 }
	 
	 @RequestMapping(value = {"/utilization_graph_report"})
	 public String utilization_graph_report() {
		 return "utilization_graph_report";
	 }
	 
	 @RequestMapping(value = {"/utilization_monthly_report"})
	 public String utilization_monthly_report() {
		 return "utilization_monthly_report";
	 }
	 
	 @RequestMapping(value = {"/utilization_accum_report"})
	 public String utilization_accum_report() {
		 return "utilization_accum_report";
	 }
	 
	 @RequestMapping(value = {"/report_staff_timesheet"})
	 public String report_staff_timesheet() {
		 return "report_staff_timesheet";
	 }
	 
	 @RequestMapping(value = {"/report_staff_overtime"})
	 public String report_staff_overtime() {
		 return "report_staff_overtime";
	 }
	 

	 @RequestMapping(value = {"/report_pm_timesheet"})
	 public String report_pm_timesheet() {
		 return "report_pm_timesheet";
	 }
	 
	 @RequestMapping(value = {"/leave_report_new"})
	 public String leave_report_new() {
		 return "leave_report_new";
	 }
	 
	 @RequestMapping(value = "/searchTimesheetUtilize", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean searchTimesheetUtilize(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
	 
			JsonResultBean res = null;
			
			String result_status = "fail";
			String result_msg    = "search fail";
			String result_data   = "";
			
			String data = request.getParameter("data");
			String year = request.getParameter("searchYear");
			String monthId = request.getParameter("searchMonth");
			
			try{
				
				ServiceResult<List<ReportTimesheetUtilizeBean>> result =  reportService.searchReportTimesheetUtilize(year,monthId); 
				if( result.isSuccess()){
						log.info( "get long : "+result.getResult().size() );
						result_status = "success";
						result_msg    = "save successful";
						res = new JsonResultBean(result_status, result_msg , result.getResult() );
						
				}else{
						result_status = "fail";
						result_msg    = "save fail";
						res = new JsonResultBean(result_status, result_msg , result_data );
				}
				
				
			}catch(Exception e){
				res = new JsonResultBean(result_status, result_msg , result_data );
				log.info("Error !!"+e);
				e.printStackTrace();
				
			}
			
			return res;
		
		}
	  
	 
	//req from setting page
	@RequestMapping(value = { "/timesheetAdmin" })
	  public String timesheetReport() {
		return "timesheetAdmin";
	}
	
	//req from setting page
	@RequestMapping(value = "/searchTimesheetReport", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean getTimesheet(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
		
		JsonResultBean res = null;
		
		String result_status = "fail";
		String result_msg    = "search fail";
		String result_data   = "";
		
		String data = request.getParameter("data");
		
		String year = request.getParameter("searchYear");
		String monthId = request.getParameter("searchMonth");
		
		try{
			
			ServiceResult<List<DataBean>> result =  reportService.searchReportTimesheet(year,monthId); 
			if( result.isSuccess()){
					log.info( "get long : "+result.getResult().size() );
					result_status = "success";
					result_msg    = "save successful";
					res = new JsonResultBean(result_status, result_msg , result.getResult() );
					
			}else{
					result_status = "fail";
					result_msg    = "save fail";
					res = new JsonResultBean(result_status, result_msg , result_data );
			}
			
			
		}catch(Exception e){
			res = new JsonResultBean(result_status, result_msg , result_data );
			log.info("Error !!"+e);
			e.printStackTrace();
			
		}
		
		return res;
	
	}
	
	//req from setting page
	@RequestMapping(value = "/searchTimesheetReportDetail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchTimesheetReportDetail(HttpServletRequest request) throws Exception{
		
		JsonResultBean result = null;
		Map<String, Object> m = new HashMap<String, Object>();
		
		String result_status = "success";
		String result_msg    = "search success";
		String result_data   = "";
		
		String year = request.getParameter("searchYear");
		String monthId = request.getParameter("searchMonth");
		String staffId = request.getParameter("staffId");
		
		try{
			
			 //start day , end day of month
			 //java calendar.MONTH january start from 0
			 int startDay = 1;
			 Calendar calendar = Calendar.getInstance();
			 calendar.set(Calendar.YEAR,Integer.parseInt(year));
			 calendar.set(Calendar.MONTH,Integer.parseInt(monthId)-1); 
			 int endDay = calendar.getActualMaximum(Calendar.DATE);
			   
			 log.info("year: "+calendar.get(Calendar.YEAR));
			 log.info("month:"+calendar.get(Calendar.MONTH));
			 log.info(startDay+"|"+endDay);
		     //get from success login handler
			// String getFromSession = request.getSession().getAttribute("testMe").toString();
			// log.info("session :"+getFromSession);
			 
			 String uid = request.getSession().getAttribute("UID").toString();
			 List<KeyValueBean> month = new ArrayList<KeyValueBean>();
			 
			 String[] dayOfWeek = {"wk","wd","wd","wd","wd","wd","wk"};
			 
			 //Calendar.DAy_OF_WEEK => SUNDAY = 1 MONDAY = 2 TUESDAY = 3  WEDNESDAY = 4 THURSDAY = 5 FRIDAY = 6 SATURDAY = 7 
			 for(int i=1;i<=endDay;i++){
				 calendar.set(Calendar.DATE,i);
				 KeyValueBean kv = new KeyValueBean();
				 kv.setId(""+i);
				 kv.setVal(dayOfWeek[calendar.get(Calendar.DAY_OF_WEEK)-1]);
				// log.info("day:"+i+"|"+dayOfWeek[calendar.get(Calendar.DAY_OF_WEEK)-1]);
				 month.add(kv);
			 }
			
			 
			
			log.info("session: "+uid);
			 
			 //holiday configuration table
			 
			 ServiceResult<List<DataBean>> hConf = reportService.getHolidayConfig(year, monthId); 
			 if(hConf.isSuccess()){
				 
				 List<DataBean> holidays = hConf.getResult();
				 log.info("holiday : "+holidays.size());
				 
				 for(DataBean holiday : holidays ){
					// dayOfWeek[ Integer.parseInt(holiday.getA())] = "hd";
					
					 KeyValueBean kv = month.get(Integer.parseInt(holiday.getA())-1);
					 kv.setVal("hd");
					 
					 //log.info("holiday date :"+ holiday.getA());
				 } 
				// m.put("hConf",  hConf.getResult());
			 }
			 
			 //insert configuration month
			 m.put("monthConf", month); 
			 
			//staff header detail
			//timesheet
			 List<DataBean> staffDtl = null;
			 ServiceResult<List<DataBean>> staff = reportService.searchStaffDetail(staffId); 
			 if(staff.isSuccess()){
				 staffDtl = staff.getResult();
			 }
			 m.put("staffDtl", staffDtl);
		
			
			//timesheet
			 List<DataBean> timesheets = null;
			 ServiceResult<List<DataBean>> tsDtl = reportService.searchReportTimesheetDetail(year, monthId, staffId); 
			 if(tsDtl.isSuccess()){
				 timesheets = tsDtl.getResult();
			 }
			 
			 //timesheet note
			 List<DataBean> notes = null;
			 ServiceResult<List<DataBean>> tsNote = reportService.searchReportTimesheetNote(year, monthId,staffId); 
			 if(tsDtl.isSuccess()){
				notes = tsNote.getResult();
				// m.put("tsNote",  tsNote.getResult());
			 }
			 
			 //insert note to timesheet
			 if(tsNote.getResult().size() > 0){
				 for(DataBean  sheet: timesheets ){
					//log.info("timesheet date :"+sheet.getB()+"|project_id:"+sheet.getJ()+"|issue id:"+sheet.getK());
					StringBuilder str = new StringBuilder(); 
					 for(DataBean  note: notes ){
						 
						//log.info("note date"+ note.getC()+"|note pid:"+note.getE()+"|note issue:"+note.getF());
						 if(sheet.getB().equalsIgnoreCase(note.getC()) && sheet.getJ().equalsIgnoreCase(note.getE())  && sheet.getK().equalsIgnoreCase(note.getF())){
							str.append( "<p class=\"nospace\" style=\"color:#aaa;font-size:12px\"><i class=\"fas fa-circle\" style=\"font-size:9px;\"></i> "+note.getB()+""+note.getG()+"</p>" );
						 }
						 
						 //for performance 
						 //stop loop if date of timesheet < note
						/*
						 if(compare2DateString(sheet.getC(),note.getB())){
							 break; 
						 }
					   */
					
					 }
					 sheet.setN( str.toString());
					 str = null;
				 }
			 }
			 m.put("tsDtl",  tsDtl.getResult());
			 
		
			 //allowance
			 List<DataBean> ot = null;
			 ServiceResult<List<DataBean>> tsOT = reportService.searchReportTimeshhetOvertime(year, monthId, staffId); 
			 if(tsOT.isSuccess()){
				 ot = tsOT.getResult();
			 }
			 m.put("tsOT", ot);
			 
			 
		 /*
			if( result.isSuccess()){
					log.info( "get long : "+result.getResult().size() );
					result_status = "success";
					result_msg    = "save successful";
					res = new JsonResultBean(result_status, result_msg , result.getResult() );
					
			}else{
					result_status = "fail";
					result_msg    = "save fail";
					res = new JsonResultBean(result_status, result_msg , result_data );
			}
		 */	
			
		}catch(Exception e){
			//res = new JsonResultBean(result_status, result_msg , result_data );
			log.info("Error !!"+e);
			e.printStackTrace();
			
		}
		
		result = new JsonResultBean(result_status, result_msg , m);
		return result;
	
	}
 
	//req from setting page
	@RequestMapping(value = "/saveTimesheetReport", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveTimesheetReport(HttpServletRequest request,Locale locale) throws Exception {
		
		 
		//https://www.tutorialspoint.com/json/json_java_example.htm
		 String USER_ID = "131";
		 String udata = request.getParameter("udata");
		 String rdata = request.getParameter("rdata");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		
		 String result_status = "";
		 String result_data = "";
		 String result_msg = "";
		 
		 try{
			 	
			 log.info(udata);
			 log.info(rdata);
	 
	 		 //remove first
			 if( rdata != null && rdata.length() > 0){
				 log.info("found data remove");
				 
				 result =  reportService.removeTimeSheetEntry(rdata);
				 if( result.isSuccess()){
					log.info( "remove get long : "+result.getResult().longValue() );
					result_data   = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg    = "save successful";
				
				 }else{
					result_status = "fail";
					result_msg    = "save fail";
				 }
			 }
			  
			 //update after
			 if( udata != null && udata.length() > 0){
				 log.info("found data update");
				 
				 result = reportService.updateTimeSheetEntry(udata);
			 	 if( result.isSuccess()){
			 		log.info( "update get long : "+result.getResult().longValue() );
					result_data   = Long.toString(result.getResult().longValue());
					result_status = "success";
					result_msg    = "save successful";
				
				}else{
					result_status = "fail";
					result_msg    = "save fail";
				}
			 }
				 
		
		 }catch(Exception e){
				log.info("Error !!"+e);
				e.printStackTrace();
		 }
		
		 
		 JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		 return res;
			
		 
	}
	
	//req from setting page
	private boolean compare2DateString( String sdate , String edate ){
			boolean result = false;
		    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		  
			try{
				  Date date1 = format.parse(sdate);
				  Date date2 = format.parse(edate);

				  log.info( date1 +"|"+date2);
			      if(date1.compareTo(date2) >= 0) {
			    	  result = true;
			    	  log.info("date1 > date2 ");
			      }else{
			    	  result = false;
			    	  log.info("date1 < date2 ");
			      }
				
			} catch (ParseException e) {
				e.printStackTrace();
			}
		  

		
		return true;
	}
	
	//req from setting page
		@RequestMapping(value = "/searchTimesheetForAdmin", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean searchTimesheetForAdmin(HttpServletRequest request) throws Exception{
			
			JsonResultBean result = null;
			Map<String, Object> m = new HashMap<String, Object>();
			
			String result_status = "success";
			String result_msg    = "search success";
			
			String year = request.getParameter("year");
			String monthId = request.getParameter("monthId");
			String division = request.getParameter("division");
			String department = request.getParameter("department");
			String section = request.getParameter("section");
			String staffId = request.getParameter("staffId");
			
			try{
				 if(division.isEmpty()){
					 division = null;
				 }
				 
				 if(department.isEmpty()){
					 department = null;
				 }
				 
				 if(section.isEmpty()){
					 section = null;
				 }
				 
				 if(staffId.isEmpty()){
					 staffId = null;
				 }
				 
				 ServiceResult<List<DataBean>> listResult = reportService.searchTimesheetForAdmin(year, monthId, division, department, section, staffId);
				 if(listResult.isSuccess()){
					 
					 List<DataBean> list = listResult.getResult();
					 m.put("listTimesheetForAdmin", list); 
				 }
				 
			}catch(Exception e){
				log.info("Error !!"+e);
				e.printStackTrace();
			}
			
			result = new JsonResultBean(result_status, result_msg , m);
			return result;
		}
	
	 
}