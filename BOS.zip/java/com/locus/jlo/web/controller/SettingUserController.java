package com.locus.jlo.web.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.department.DepartmentBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.beans.task.TaskAssigneeBean;
import com.locus.jlo.web.beans.task.TaskBean;
import com.locus.jlo.web.services.SettingDeptService;
import com.locus.jlo.web.services.SettingUserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@MultipartConfig
public class SettingUserController extends CoreController {
	
//	private final static String SERV_PATH = "assets/attach_file/avatar/";
	
	@Autowired
	private SettingUserService settingUserService;
	
	@Autowired
	private UserProfileController userProfileController;
	
	@Autowired
	private SettingDeptService settingDeptService;

	 @RequestMapping(value = {"/setting_user_save"})
	 public String setting_user() {
	        return "setting_user";
	 }
	 
	 @RequestMapping(value = {"/setting_user_remove"})
	 public String setting_department() {
	        return "setting_department";
	 }
	 
	 
	 @RequestMapping(value = "/searchSettingUserList", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchSettingUserList(HttpServletRequest request,Locale locale) throws Exception{

		String userStatus  = request.getParameter("userStatus");
		log.info("controller get status :"+userStatus);
		if(!StringUtils.isEmpty(userStatus) && userStatus == "all") {
			userStatus = null;
		}
		
		ServiceResult<List<Map<String, Object>>> listResult =  settingUserService.searchSettingUserList(userStatus);
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
	   
		return result;
	   
	 }
	 
	 
	 @RequestMapping(value = "/searchSettingUser", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchSettingUser(HttpServletRequest request,Locale locale) throws Exception{

		String id  = request.getParameter("id");
		String userStatus  = request.getParameter("userStatus");
		String deptId  = request.getParameter("deptId");

		 if("all".equals(deptId)){
			 deptId = null;
		 }
		ServiceResult<List<Map<String, Object>>> listResult =  settingUserService.searchSettingUser(id,userStatus,deptId);
		JsonResultBean result = null;
		if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		}
	   
		return result;
	   
	 }
	 
	 @RequestMapping(value = "/searchSettingUserDetail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchSettingUserDetail(HttpServletRequest request,HttpServletResponse response,Locale locale) throws Exception{
		 
		 String id  = request.getParameter("id");
		 log.info("id: "+id);
		 ServiceResult<List<Map<String, Object>>> listResult =  settingUserService.searchSettingUserDetail(id); 
		 JsonResultBean result = null;
		 if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());

		 }
		 
		return result;
	 }
	 
	 
	 @PostMapping(value = "/saveSettingUser")
	 public @ResponseBody JsonResultBean saveSettingUser(@RequestParam(value = "fileAvatar",required = false) MultipartFile uploadfile ,
														 @RequestParam String data,
														 @RequestParam String viewId,
														 HttpServletRequest request,
														 Locale locale) throws Exception{
		
		//https://www.tutorialspoint.com/json/json_java_example.htm
		 final int USER_ID = getUid(request);
		 ServiceResult<Long> result = new ServiceResult<>();
		 		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 log.info("Setting User control");
		 log.info("data: "+data);

		 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
		 
		 //convert between form and bean
		 JsonBeanUtils<SettingUserBean> utils = new JsonBeanUtils<>(SettingUserBean.class);
		 
		 SettingUserBean bean = utils.convertFormAndBean(json);
		 
		 //convert not def data
		 bean.setUpdate_uid(USER_ID);
		 bean.setIs_admin(convertToflagYN(bean.getIs_admin()));
		 bean.setProbation(convertToflagYN(bean.getProbation()));
		 
		 if (bean.getProbation_date() == null) {
			 Calendar c = Calendar.getInstance();
			 c.setTime(bean.getAppearance_date());
			 c.add(Calendar.DATE, 119);
			 bean.setProbation_date(c.getTime());
			 
		}
		 
		if (bean.getProbation_date().compareTo(new Date()) <= 0) {
			 bean.setProbation("Y");
		}
		 
		 bean.setAllow_timesheet_backward(ObjectBeanUtils.isNullOrZero(bean.getAllow_timesheet_backward())?0:1);

//			 String loginId = bean.getEmail().substring(0,bean.getEmail().indexOf("@")).trim();
//			 bean.setLogin_id(loginId);
//			 bean.setReport_to_person_id1(NumberUtils.parseNumber(json.get("reportToPerson").toString(),Integer.class));

		 try{
			 
			 // get Old division, department, section of User
			List<String> inDeptId = new ArrayList<String>(); 
			String xId = "";
			if(StringUtils.isEmpty(viewId)){
				xId = Integer.toString(USER_ID);
			} else {
				xId = viewId;
			}
			 
			 ServiceResult<SettingUserBean> userOldDivisionDetail = settingUserService.searchUserDetailById(xId);
			 if (userOldDivisionDetail.isSuccess()) {
				 SettingUserBean userBean = userOldDivisionDetail.getResult();
				 
				 if (userBean != null) {
					 if (!StringUtils.isEmpty(userBean.getDivisionId())) 
						 inDeptId.add(userBean.getDivisionId());
					 
					 if (!StringUtils.isEmpty(userBean.getMainDepartmentId()))
						 inDeptId.add(userBean.getMainDepartmentId());
					 
					 if (!StringUtils.isEmpty(userBean.getSectionId()))
						 inDeptId.add(userBean.getSectionId());		 
				 }
					 
				 
			 }
			 
			 if(StringUtils.isEmpty(viewId)){
				 	bean.setCreate_uid(USER_ID);
					result =  settingUserService.insertSettingUser(bean);
 	    			if( result.isSuccess()){
					   if(null!=uploadfile){
					   	String pathImage = userProfileController.uploadAvater(uploadfile,result.getResult().intValue());
					   	bean.setImg_path(pathImage);
						result =  settingUserService.updateSettingUser(bean);
					   }
 	    			}
			}else{
				bean.setId(Integer.parseInt(viewId));
				if(null!=uploadfile){
					bean.setImg_path(userProfileController.uploadAvater(uploadfile,Integer.parseInt(viewId)));
				}
				result =  settingUserService.updateSettingUser(bean);
			}

			 if( result.isSuccess()){
				 log.info( "get long : "+result.getResult().longValue() );
				 
				 //Search division id in user table
				 String userId = String.valueOf(result.getResult().longValue());
				 if(StringUtils.isEmpty(viewId)){
					 userId = String.valueOf(result.getResult().longValue());
				 }else{
					 userId = viewId;
				 }
				 ServiceResult<SettingUserBean> userDivisionDetail = settingUserService.searchUserDetailById(userId);
				 
				 if(userDivisionDetail.isSuccess()){
					 SettingUserBean userBean = userDivisionDetail.getResult();
					 String departId = "";
					 if(StringUtils.isEmpty(userBean.getSectionId())){
						 if(StringUtils.isEmpty(userBean.getMainDepartmentId())){
							 departId = userBean.getDivisionId();
						 }else{
							 departId = userBean.getMainDepartmentId();
						 }
						 
					 }else{
						 departId = userBean.getSectionId();
					 }
					 
					 //search project id in department table
					 ServiceResult<DepartmentBean> departResult =  settingDeptService.searchSettingDeptDetailById(departId);
					 
					 if(departResult.isSuccess()){
						 DepartmentBean deptBean = new DepartmentBean();
						 deptBean = departResult.getResult();
						 String deptProjectId = deptBean.getDeptProjectId();
						 
						 
						 //Check time sheet in this project
//						 ServiceResult<TaskAssigneeBean> findTimesheetTaskAssigneeResult = settingUserService.searchTimesheetTaskAssigneeByUserId(userId, deptProjectId);
//						 boolean isDelete = false;
//						 if(findTimesheetTaskAssigneeResult.isSuccess()){
//							 TaskAssigneeBean taskAssignBean = findTimesheetTaskAssigneeResult.getResult();
//							 Double sumHour = Double.parseDouble(taskAssignBean.getSumHour());
//							 
//							 if(sumHour != 0 ){
//								ServiceResult<Long> idResult =  settingUserService.deleteTimesheetTaskAssigneeByUserId(userId, deptProjectId);
//								if(idResult.isSuccess()){
//									isDelete = true;
//								}
//							 }
//						 }
						 
						 //Start delete
//						 if(isDelete){
							//Searh Task list By project id
						 	if(deptProjectId != null){
								
						 		// step1 find dept_project_id of previous user_profile
						 		if (!StringUtils.isEmpty(inDeptId.toString())) {
						 			ServiceResult<List<DataBean>> res =  settingUserService.findCurrentDeptProjectId(inDeptId);
						 			if (res.isSuccess()) {
						 				List<DataBean> list = res.getResult();
						 				if (list!= null) {
						 					List<String> project = new ArrayList<String>();
						 					for (DataBean b : list) {
						 						project.add(b.getA());
						 					}
						 					if (project != null && !project.isEmpty()) {
						 		 // step2 delete old task_assignee when sum_hours = 0 , ot = null
										 		settingUserService.deleteOldTaskAssignee(userId, project);
						 					}
						 				}
						 			}
						 		}
						 		
						 		
						 		// step3 save task_assignee only not exits
						 		ServiceResult<List<TaskBean>> listTaskResult = settingUserService.searchTaskListByProjectId(deptProjectId, userId);
								 List<TaskBean> listTask = new ArrayList<TaskBean>();
								 List<TaskAssigneeBean> listTaskAssignee = new ArrayList<TaskAssigneeBean>();
								 
								 if(listTaskResult.isSuccess()){
									 listTask = listTaskResult.getResult();
									 
									 for (TaskBean taskBean : listTask) {
										 TaskAssigneeBean taskAssigneeBean = new TaskAssigneeBean();
										 taskAssigneeBean.setTaskId(taskBean.getTaskId());
										 taskAssigneeBean.setProjectId(deptProjectId);
										 taskAssigneeBean.setUserId(userId);
										 taskAssigneeBean.setCreateBy(String.valueOf(USER_ID));
										 taskAssigneeBean.setStartDate(taskBean.getTaskStartDate());
										 taskAssigneeBean.setEndDate(taskBean.getTaskEndDate());
										 taskAssigneeBean.setStatus(1);
										 
										 listTaskAssignee.add(taskAssigneeBean);
									 }
									 
									 if(listTaskAssignee != null && listTaskAssignee.size() != 0){
										//Batch Insert
										ServiceResult<int[]> resultInsert = settingUserService.insertInsertTaskAssignee(listTaskAssignee);
										
										if(resultInsert.isSuccess()){
											result_data   = String.valueOf(result.getResult().intValue());
											 result_status = "success";
											 result_msg    = "save successful";
										}else{
											 result_status = "fail";
											 result_msg    = "save fail";
										 }
									 }
								 }
						 	}else{
						 		result_status = "success";
								 result_msg    = "save successful";
						 	}
							 
//						 }//End Check delete
						 
					 }
				 }
				  
			 }else{
				 result_status = "fail";
				 result_msg    = "save fail";
			 }

			}catch(Exception e){
				log.info("Error !!"+e);
			}
		  
		 /*		  
		 result_data   =  "OK";
		 result_status = "success";
		 result_msg    = "save successful";
		  */
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
	   

	 }
	 
	 private String convertToflagYN(String value) {
		 
		return !(StringUtils.isEmpty(value))?"Y":"N";
	}

	@RequestMapping(value = "/userStatusUpdate", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean userStatusUpdate(HttpServletRequest request,Locale locale) throws Exception{
		
		String id = request.getParameter("id");
		String status  = request.getParameter("status");
		
		ServiceResult<Long> idResult =  settingUserService.userStatusUpdate(id,Integer.parseInt(status));
		JsonResultBean result = null;
		if(idResult.isSuccess()){
			result = new JsonResultBean("success", "" , idResult.getResult());
		}
		return result;
		 
	 }
	
	@RequestMapping(value = "/removeSettingUser", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean removeSettingUser(HttpServletRequest request,Locale locale) throws Exception{

		
		String id = request.getParameter("id");

		ServiceResult<Long> idResult =  settingUserService.removeSettingUser(id);
		JsonResultBean result = null;
		if(idResult.isSuccess()){
			result = new JsonResultBean("success", "" , idResult.getResult());
		}
		return result;
		 
	 }
	
//	 private static final String FILE_NAME = "D:\\Users\\file\\importFile\\userExcelFormat.xlsx";
	
	 @RequestMapping(value = "/importSettingUser", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean importSettingUser(HttpServletRequest request,Locale locale) throws Exception{
		
		Part part = request.getPart("userFile");

		List<Object[]> list = PoiUtils.importExcelFileArr(part.getInputStream(),1,28);
		
		JsonResultBean result = new JsonResultBean("success", "" , list);

		return result;
	   
	 }
	 
	 @RequestMapping(value = "/saveImportSettingUser", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveImportSettingUser(HttpServletRequest request,Locale locale) throws Exception{
			
		 log.info("Import Userser saveImportSettingUser");
			//https://www.tutorialspoint.com/json/json_java_example.htm
			 final int USER_ID = getUid(request);
			 String data = request.getParameter("data");
//			 String viewId  = request.getParameter("viewId");
			 
			 ServiceResult<Integer> result = new ServiceResult<>();

			 
			 JSONParser jParser = new JSONParser();
			 JSONObject json = (JSONObject)jParser.parse(data);
			 
			 JsonBeanUtils<SettingUserBean> utils = new JsonBeanUtils<>(SettingUserBean.class);
			 
			 SettingUserBean bean = utils.convertFormAndBeanWithUser(json, USER_ID);
			 if(null == bean.getMain_dept_id()) {
					bean.setMain_dept_id(bean.getDepartment());
					if(null != bean.getMain_dept_id()) {
						log.info("getMain_dept_id : "+bean.getMain_dept_id().toString());
					}
				}
				
			/*	if(null != bean.getDivision()) {
					log.info("getDivision : "+bean.getDivision().toString());
				}
				if(null == bean.getMain_dept_id()) {
					bean.setMain_dept_id(bean.getDepartment());
					if(null != bean.getMain_dept_id()) {
						log.info("getMain_dept_id : "+bean.getMain_dept_id().toString());
					}
				}
				if(null != bean.getDepartment()) {
					log.info("getDepartment : "+bean.getDepartment().toString());
				}
				if(null != bean.getSection()) {
					log.info("getSection : "+bean.getSection().toString());
				}*/
				
			 utils.print(bean);
			 
			 String result_status = "";
			 String result_msg    = "";
			 
			 try{

				result =  settingUserService.saveImportSettingUser(bean);
				
	 	    	if( result.isSuccess()){

	 	    		result_status = "success";
	 	    		result_msg    = "save successful";
	 	    				
	 	    	}else{
	 	    			result_status = "fail";
	 	    			result_msg    = "save fail";
	 	    	}
		
				}catch(Exception e){
					log.info("Error !!"+e);
				}

			JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult() );
			return res;
		   

		 }



}