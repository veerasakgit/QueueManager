package com.locus.jlo.web.controller.rest;

import com.locus.jlo.web.services.DemoService;
import com.locus.jlo.web.beans.RoleBean;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Slf4j
@RestController
public class DemoRestController {

    @Autowired
    private DemoService demoService;

    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public List<RoleBean> test() throws Exception {
        List<RoleBean> roleBeans = demoService.getUserRoles();
        roleBeans.forEach((roleBean) -> {
            log.info(roleBean.toString());
        });
        return roleBeans;
    }
    
    @RequestMapping(value = "/pass", method = RequestMethod.GET)
    public String pass() throws Exception {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        return "" + passwordEncoder.matches("locus123", "$2a$10$2IpS9dljmoKSQG6qXbhjiep9pUsBpL8we0bnAlENpkcoeRzLuUvPC");
//        return passwordEncoder.encode("locus123");
    }
    
    
    public static void main(String args[]){
    	 BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    	 System.out.println("passwordEncoder : "+passwordEncoder.encode("00000"));
    }
}
