package com.locus.jlo.web.controller;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.web.beans.setting.SettingProjectRoleBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.SettingProjectRoleService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class SettingProjectRoleController extends CoreController{
	

	@Autowired
	private SettingProjectRoleService settingProjectRoleService;
	
	@RequestMapping(value = "/searchProjectRole", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchProjectRole(HttpServletRequest request,Locale locale) throws Exception{
			
			String id = request.getParameter("id");
			String status = request.getParameter("status");
			
			ServiceResult<List<Map<String, Object>>> listResult =  settingProjectRoleService.searchProjectRole(id,status); 
			JsonResultBean result = null;
			if(listResult.isSuccess()){
				result = new JsonResultBean("success", "" , listResult.getResult());
			}
			return result;
	}
	

	 @RequestMapping(value = "/saveProjectRole", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveProjectRole(HttpServletRequest request,Locale locale) throws Exception{
			
			//https://www.tutorialspoint.com/json/json_java_example.htm
//			 final int USER_ID = Integer.parseInt(request.getSession().getAttribute("staffId").toString());
		 	 final int USER_ID = getUid(request);
			 String data = request.getParameter("data");
			 String id = request.getParameter("id");
			 
			 log.info("data: "+data);
			 
//			 List<TicketsBean> beans = new ArrayList<>();
			 
//			 if (!StringUtils.isEmpty(data)&&!(data.equals("{}"))) {
				 JSONParser jParser = new JSONParser();
				 JSONObject json = (JSONObject) jParser.parse(data);
				 
//				 json.put("menuArr", json.get("menuArr").toString());
//				 json.put("roleMenuArr", json.get("roleMenuArr").toString());
				 
				 JsonBeanUtils<SettingProjectRoleBean> utils = new JsonBeanUtils<>(SettingProjectRoleBean.class);	 		 
				 SettingProjectRoleBean bean = utils.convertFormAndBeanWithUser(json,USER_ID);
				 
				 log.info("data");
				 utils.print(bean);

			 String result_status = "";
			 String result_msg    = "";
			 ServiceResult<Long> result = new ServiceResult<>();
						 
			 try{
				 if (bean.getId() == null) {
					 result =  settingProjectRoleService.insertProjectRole(bean);
	 	    			
			 	    if(result.isSuccess()){
			 	   		log.info( "get long : "+result.getResult());
			 	   		result_status = "success";
			 	   		result_msg    = "save successful";
			 	    				
			 	   	}else{
			     		result_status = "fail";
			    		result_msg    = "save fail";
		 	    	}
			 	    
				 }else {
					
					result =  settingProjectRoleService.updateProjectRole(bean);
	 	    			
				 	if(result.isSuccess()){
				 	   	log.info( "get long : "+result.getResult());
				 	   	result_status = "success";
				 	   	result_msg    = "save successful";
				 	    				
				 	}else{
				    	result_status = "fail";
				    	result_msg    = "save fail";
			 	    }
				 }
	
		
				}catch(Exception e){
					log.info("Error !!"+e);
				}
			 
			JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult());
//			}
			return res;
		   
		 }
	
	
		@RequestMapping(value = "/deleteProjectRole", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean deleteProjectRole(HttpServletRequest request,Locale locale) throws Exception{
			
			String id  = request.getParameter("id");
			log.info("id: "+id);
			ServiceResult<Long> idResult =  settingProjectRoleService.deleteProjectRole(id);
			JsonResultBean result = null;
			if(idResult.isSuccess()){
				result = new JsonResultBean("success", "" , idResult.getResult());
			}
			return result;
		 }
		
		@RequestMapping(value = "/searchMenu", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean searchMenu(HttpServletRequest request,Locale locale) throws Exception{
				
				ServiceResult<List<Map<String, Object>>> listResult =  settingProjectRoleService.searchMenu(); 
				JsonResultBean result = null;
				if(listResult.isSuccess()){
					result = new JsonResultBean("success", "" , listResult.getResult());
				}
				return result;
		}
		 
}