package com.locus.jlo.web.controller;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.TreeParentBean;
import com.locus.jlo.web.beans.system.modelbean.MenuDetailModelBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.controller.StaffController.DataTree;
import com.locus.jlo.web.services.SettingPrivilegesService;

import lombok.Getter;
import lombok.Setter;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Controller
public class SettingPrivilegesController extends CoreController{

    @Autowired
    private SettingPrivilegesService settingPrivilegesService;
    
    @Setter
	@Getter
	public class DataTree{
		 String title;
		 String key;
		 boolean folder;
		 String level;
		 List<DataTree>children;	 
		 
	 }

    
    @PostMapping("searchPrivileges")
    public @ResponseBody  JsonResultBean initialMenuByDepartment(@RequestParam Integer deptId, HttpServletRequest request) throws Exception {
    	List<MenuDetailModelBean> listDepartMenu = new ArrayList<>();
    	List<MenuDetailModelBean> listPrivilegesForInsert = new ArrayList<>();
    	MenuDetailModelBean menuBean = new MenuDetailModelBean();
    	
    	menuBean.setDeptId(deptId);
        ServiceResult<List<MenuDetailModelBean>> listServiceResult = settingPrivilegesService.initialMenuByDepartment(menuBean);
        
        if(listServiceResult.isSuccess()){
        	listDepartMenu = listServiceResult.getResult();
        	
        	if(listDepartMenu == null || listDepartMenu.size() == 0){
        		
        		//Get list menu
        		ServiceResult<List<MenuDetailModelBean>> listMenuResult = settingPrivilegesService.searchMenuByAdminRole();
        		if(listMenuResult.isSuccess()){
        			List<MenuDetailModelBean> listMenuTemp = listMenuResult.getResult();
        			
        			for (MenuDetailModelBean menuDetailModelBean : listMenuTemp) { // loop set privileges object for insert
        				MenuDetailModelBean meneAddListBean = new  MenuDetailModelBean();
        				meneAddListBean.setDeptId(deptId);
        				meneAddListBean.setMenuId(menuDetailModelBean.getMenuId());
        				meneAddListBean.setPrivilegesYn("Y");
        				meneAddListBean.setCreateBy(String.valueOf(getUid(request)));
        				listPrivilegesForInsert.add(meneAddListBean);
					}
        		}
        		
        		// Insert privilileges
        		if(listPrivilegesForInsert != null && listPrivilegesForInsert.size() != 0){
        			Integer countInsert = 0;
        			for (MenuDetailModelBean menuDetailInsertModelBean : listPrivilegesForInsert) { // loop set privileges object for insert
        				ServiceResult<Long> resultInsert = settingPrivilegesService.insertPrivileges(menuDetailInsertModelBean);

            			if(resultInsert.isSuccess()) {
            				countInsert++;
            			}
					}
        			
        			if(countInsert == listPrivilegesForInsert.size()){
        				listServiceResult = settingPrivilegesService.initialMenuByDepartment(menuBean);
        				 if(listServiceResult.isSuccess()){
        			        	listDepartMenu = listServiceResult.getResult();
        				 }
        			}
        			
        		}
        		
        		
        	}
        }
        return  new JsonResultBean("success", "" , listDepartMenu);
    }
   
    @PostMapping("updatePrivileges")
    public @ResponseBody  JsonResultBean updatePrivileges(@RequestBody List<MenuDetailModelBean> menuDetailModelBeanList, HttpServletRequest request) throws Exception {

        ServiceResult<Integer> integerServiceResult = settingPrivilegesService.updatePrivileges(menuDetailModelBeanList,getUid(request));
        if(integerServiceResult.isSuccess()){
            return  new JsonResultBean("success", "" , integerServiceResult.getResult());
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
	 @PostMapping("/getTreeDepartmentPrivileges")
	    public @ResponseBody  JsonResultBean getTreeDepartmentPrivileges(HttpServletRequest request, Locale locale) throws Exception {
	    	

    	JsonResultBean res = null;
    	Map<String, Object> m = new HashMap<String, Object>();
    	
    	String result_status = "success";
		String result_msg    = "success";
		String result_data   = ""; 
    	
    	try{
    		
    		ServiceResult<List<TreeParentBean>> listResult =  settingPrivilegesService.getTreeDepartmentPrivileges();
    		List<DataTree>  organize = new ArrayList<DataTree>();
            if (listResult.isSuccess()) {
            	List<TreeParentBean> listOrg = listResult.getResult();
            	
            	
				List<TreeParentBean> listDivision = (List<TreeParentBean>) CollectionUtils.select(listOrg, new Predicate() {
					
					@Override
					public boolean evaluate(Object object) {
						TreeParentBean b = (TreeParentBean)object;
						return b.getLevel().equals("1") || b.getLevel().equals("0");
					}
				});
            	
            	
            	for (TreeParentBean en: listDivision) {
            		List<DataTree> lch1 = new ArrayList<DataTree>();
	            	
	            	
            		DataTree parent = new DataTree();
            		parent.setTitle(en.getName());
            		if (en.getLevel().equals("0")) {
            			parent.setKey("all");
            		} else {
            			parent.setKey(en.getId());
	            		
            		}
            		parent.setFolder(true);
            		String parent_id = en.getId();
            		if (!en.getLevel().equals("0")) {
            			List<TreeParentBean> listDept = (List<TreeParentBean>) CollectionUtils.select(listOrg, new Predicate() {
							
							@Override
							public boolean evaluate(Object object) {
								TreeParentBean b = (TreeParentBean)object;
								return b.getParentId().equals(parent_id);
							}
						});
	            		
	            		for (TreeParentBean en1 : listDept) {
	            			List<DataTree> lch2 = new ArrayList<DataTree>();
	            			DataTree child1 = new DataTree();
	            			child1.setTitle(en1.getName());
	            			child1.setKey(en1.getId());
	            			child1.setFolder(true);
	            			child1.setLevel("2");
	            			String parent_id1 = en1.getId();
	            			lch1.add(child1);

	            			List<TreeParentBean> listSec = (List<TreeParentBean>) CollectionUtils.select(listOrg, new Predicate() {
								
								@Override
								public boolean evaluate(Object object) {
									TreeParentBean b = (TreeParentBean)object;
									return b.getParentId().equals(parent_id1);
								}
							});
	            			
	            			for (TreeParentBean en2 : listSec) {
		            			DataTree child2 = new DataTree();
		            			child2.setTitle(en2.getName());
		            			child2.setKey(en2.getId());
		            			child2.setFolder(false);
		            			lch2.add(child2);
		            			
		            		}
	            			child1.setChildren(lch2);
	            		}
	            		parent.setChildren(lch1);
            		}
            		
            		organize.add(parent);
            	}
            }


  			m.put("tree", organize);
  		
    		
    	}catch( Exception e){
    		
    		 result_status = "fail";
			 result_msg    = "fail";
			
			res = new JsonResultBean(result_status, result_msg , result_data );
			//log.info("Error !!"+e);
			e.printStackTrace();
    		
    	}
    	
    	res = new JsonResultBean(result_status, result_msg , m );
		return res;
	      
	       
	    }

}
