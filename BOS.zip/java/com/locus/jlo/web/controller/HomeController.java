package com.locus.jlo.web.controller;

import lombok.extern.slf4j.Slf4j;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;

@Slf4j
@Controller
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HomeController {
	
	/*
	@Value("${mail.smtp.host}")
    private String host;
	
	@Value("${mail.smtp.port}")
    private String port;
    
    @Value("${mail.smtp.ssl}")
    private String ssl;
    */

    //@RequestMapping(value = {"/", "/home"})
    @RequestMapping(value = {"/", "/home"})
    public String index() {
    	//log.info("get smtp host :"+host);
        return "home";
    }  
    
    @RequestMapping(value = "/myTeamLeaveSummary")
    public String myTeamLeaveSummary() {
        return "myTeamLeaveSummary";
    }    
    
    
    @RequestMapping(value = "/myProjectSummary")
    public String myProjectSummary() {
        return "myProjectSummary";
    }    
    
    
    /*
    @RequestMapping(value = {"/multiFile"})
    public String multiFile() {
        return "multiFile";
    }
    
    
    @RequestMapping(value="/testSendMail")
	public @ResponseBody JsonResultBean sendMail(HttpServletRequest request, HttpServletResponse response)throws Exception {
		
    	
    	//request.getSession("");
    	
		String result_status = "";
		String result_msg = "";
		String result_data = "";
				
		try{
			
			  	Properties props = new Properties();
		        props.put("mail.smtp.host", "smtp.office365.com");
		        props.put("mail.smtp.socketFactory.port", "587");
		        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		        props.put("mail.smtp.auth", "true");
		        props.put("mail.smtp.port", "587");
		        props.put("mail.smtp.starttls.enable", "true");
		        
		        Session session = Session.getDefaultInstance(props,
		        	new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication("arnon@locus.co.th","locus123");
                    }
                });

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress("arnon@locus.co.th"));
                message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("arnon@locus.co.th"));
                message.setSubject("This is testing message");
                message.setText("Hi this is testing email....not spam");
                //message.setContent("<h1>Hello</h1>", "text/html");
                //message.setContent(someHtmlMessage, "text/html; charset=utf-8");
                Transport.send(message);
                System.out.println("email successfully sent..");
			
			
		}catch(Exception e){
			throw new RuntimeException(e);
		}
		
	
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
		
	
	}
	*/
    
}