package com.locus.jlo.web.controller;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.FileUtils;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.web.beans.contacts.ContactBean;
import com.locus.jlo.web.beans.product.ProductBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ContactService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class ContactController extends CoreController {
	
	private final static String SERV_PATH = "assets/attach_file/contact/";
	
	@Autowired
	public ContactService contactService;
	
	
	@RequestMapping(value = {"/contact"})
	public String contact() {
		return "contact";
	}
	
	@RequestMapping(value = {"/contact_detail"})
	public String contact_detail() {
		return "contact_detail";
	}

	@RequestMapping(value = "/searchContact", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchContact(HttpServletRequest request,Locale locale) throws Exception{
						
			ServiceResult<List<Map<String, Object>>> listResult =  contactService.searchContact();
			JsonResultBean result = null;
			if(listResult.isSuccess()){
				result = new JsonResultBean("success", "" , listResult.getResult());
			}
			return result;
	}
	
	@RequestMapping(value = "/searchContactDetail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchContactDetail(@RequestParam(required = false) String id,
															@RequestParam(required = false) String is_company,
															@RequestParam(required = false) String company_id,
															HttpServletRequest request,Locale locale) throws Exception{
		
			ServiceResult<List<Map<String, Object>>> listResult =  contactService.searchContactDetail(id,is_company,company_id);
			JsonResultBean result = null;
			if(listResult.isSuccess()){
				result = new JsonResultBean("success", "" , listResult.getResult());
			}
			return result;
	}
	
	@RequestMapping(value = "/searchIndustries", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchIndustries(HttpServletRequest request,Locale locale) throws Exception{

			ServiceResult<List<Map<String, Object>>> listResult =  contactService.searchIndustries();
			JsonResultBean result = null;
			if(listResult.isSuccess()){
				result = new JsonResultBean("success", "" , listResult.getResult());
			}
			return result;
	}
	
	 @RequestMapping(value = "/saveContact", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveContact(HttpServletRequest request,Locale locale) throws Exception{
		
		//https://www.tutorialspoint.com/json/json_java_example.htm
		 final int USER_ID = getUid(request);
		 String data = request.getParameter("data");
		 String viewId  = request.getParameter("viewId");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		 		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
		 
		 //convert between form and bean
		 JsonBeanUtils<ContactBean> utils = new JsonBeanUtils<>(ContactBean.class);
		 
		 ContactBean bean = utils.convertFormAndBeanWithUser(json, USER_ID);
		 bean.setIs_company(StringUtils.isEmpty(bean.getIs_company())?0:1);
		 bean.setVisibility(1);
		 		 
		 utils.print(bean);
					
		 try{
			 
			 if (StringUtils.isEmpty(viewId)) {
					result =  contactService.insertContact(bean);
					
	    			if( result.isSuccess()){
	    			   log.info( "get long : "+result.getResult().longValue() );
	    			   result_data   = Long.toString(result.getResult().longValue());
	    			   result_status = "success";
					   result_msg    = "save successful";
	    				
	    			}else{
	    				result_status = "fail";
						result_msg    = "save fail";
	    			}
			}else {
				
				bean.setId(Integer.parseInt(viewId));
				
				result =  contactService.updateContact(bean);
	    		
	    			if( result.isSuccess()){
	    			   log.info( "get long : "+result.getResult().longValue() );
	    			   result_data   = Long.toString(result.getResult().longValue());
	    			   result_status = "success";
				   result_msg    = "save successful";
	    				
	    			}else{
	    				result_status = "fail";
					result_msg    = "save fail";
	    			}
			}
			 					
			}catch(Exception e){
				log.info("Error !!"+e);
			}
		  
		 /*		  
		 result_data   =  "OK";
		 result_status = "success";
		 result_msg    = "save successful";
		  */
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
	   

	 }
	
	
	@RequestMapping(value = "/uploadContactImg", method = RequestMethod.POST)
	public @ResponseBody JsonResultBean uploadProductImg( @RequestParam("fileImage") MultipartFile uploadfile , HttpServletResponse response, HttpServletRequest request,Locale locale) throws Exception{
			 log.info("Start upload");
			 JsonResultBean result = null;
			 
			 String result_status = "success";
			 String result_msg = "success";

			 String path = FileUtils.uploadFile(uploadfile,SERV_PATH);

			 result = new JsonResultBean(result_status, result_msg , path );
			 
			 return result;
		
	}
	
	@RequestMapping(value = "/deleteContact", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean deleteContact(HttpServletRequest request,Locale locale) throws Exception{
		
		String id  = request.getParameter("id");
		log.info("id: "+id);
		ServiceResult<Long> idResult =  contactService.deleteContact(id);
		JsonResultBean result = null;
		if(idResult.isSuccess()){
			result = new JsonResultBean("success", "" , idResult.getResult());
		}
		return result;
	 }
 
	
	
    
}