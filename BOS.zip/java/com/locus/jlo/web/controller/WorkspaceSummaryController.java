package com.locus.jlo.web.controller;

import lombok.extern.slf4j.Slf4j;

import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.util.StringUtil;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ReportService;
import com.locus.jlo.web.services.TimesheetSummaryService;


@Slf4j
@Controller
public class WorkspaceSummaryController {
	
	
	@Autowired
	private TimesheetSummaryService TimesheetSummaryService;
	
	
	
	/*
	@RequestMapping(value = "/homeTimesheetInitial", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean homeTimesheetInitial(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
		
		
	}
	*/
	
	@RequestMapping(value = "/workspaceInitial", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean workspaceInitial(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
		
		JsonResultBean result = null;
		Map<String, Object> m = new HashMap<String, Object>();
		
		String result_status = "success";
		String result_msg    = "search success";
		String result_data   = "";
		
		try{
			
			//get session user
			UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
			
			//check staff is dept head  
			if( uinfo.getIsDeptHeadYN().equals("Y")){
				//show  members
				 ServiceResult<List<DataBean>> staffMember = TimesheetSummaryService.searchMemberInDept(uinfo.getUid()); 
				 if(staffMember.isSuccess()){
					 m.put("staffMember", staffMember.getResult() );
				 }
			}
			
			
		}catch(Exception e){
			//res = new JsonResultBean(result_status, result_msg , result_data );
			log.info("Error !!"+e);
			e.printStackTrace();
			
		}
	
		result = new JsonResultBean(result_status, result_msg , m);
		return result;
		
	}
	
	
	
	@RequestMapping(value = "/workspaceSummary", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean workspaceSummary(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
		
	
		
		JsonResultBean result = null;
		Map<String, Object> m = new HashMap<String, Object>();
		
		String result_status = "success";
		String result_msg    = "search success";
		String result_data   = "";
		
		String year = request.getParameter("searchYear");
		String monthId = request.getParameter("searchMonth");
		String userId = request.getParameter("searchUserId");
		
		//get session user
		UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
	 
	 	
		//check if staff is not dev head can't used this function
		log.info("get user: "+userId);
		if( StringUtils.isEmpty(userId)){
			userId = uinfo.getUid();
		}
	  
		//String staffId = request.getSession().getAttribute("UID").toString();
		
		
		//find start of month , end of month
		//find month
		//find working day
		
		//find all timsheet
		
		//find all timesheet group by charge and non charge
		
		//find all timesheet group by project
		
		
		try{
			 
			//staff profile
			 ServiceResult<DataBean> staffProfile = TimesheetSummaryService.searchReportStaffDetail(userId); 
			 if(staffProfile.isSuccess()){
				 m.put("staffProfile", staffProfile.getResult() );
			 }
			 
			 //dashboard start-end time
			 ServiceResult<DataBean> reportStartEnd = TimesheetSummaryService.searchReportStartEndDetail(year, monthId); 
			 if(reportStartEnd.isSuccess()){
				 m.put("reportStartEnd", reportStartEnd.getResult() );
			 }
			 
			 //timesheet 
			 ServiceResult<List<DataBean>> tsDtl = TimesheetSummaryService.searchReportTimesheetDetail(year, monthId, userId); 
			 if(tsDtl.isSuccess()){
				 m.put("tsDtl", tsDtl.getResult() );
			 }
			 
			 //timesheet note
			 ServiceResult<List<DataBean>> tsNote = TimesheetSummaryService.searchReportTimesheetNote(year, monthId, userId); 
			 if(tsNote.isSuccess()){
				 m.put("tsNote", tsNote.getResult() );
			 }
			 
			 //overtime
			 ServiceResult<List<DataBean>> tsOt = TimesheetSummaryService.searchReportTimeshhetOvertime(year, monthId, userId); 
			 if(tsOt.isSuccess()){
				 m.put("tsOt", tsOt.getResult() );
			 }
			 
			 
			 //pie graph A
			 ServiceResult<List<DataBean>> overallLogtimePieA = TimesheetSummaryService.searchOverallLogitmePieA(year,monthId,userId);
			 if(overallLogtimePieA.isSuccess()){
				 m.put("tsOverallA", overallLogtimePieA.getResult() );
			 }
			 
			 //pie graph B
			 ServiceResult<List<DataBean>> overallLogtimePieB = TimesheetSummaryService.searchOverallLogitmePieB(year,monthId,userId);
			 if(overallLogtimePieB.isSuccess()){
				 m.put("tsOverallB", overallLogtimePieB.getResult() );
			 }
			 
			 //utilize summary ( all year )
			 ServiceResult<List<DataBean>> utilizeSummary = TimesheetSummaryService.searchUtilizeSummary(year,userId);
			 if(utilizeSummary.isSuccess()){
				 m.put("utilizeSummary", utilizeSummary.getResult() );
			 }
			
			 
			 
			 
			 /*
			 //start day , end day of month
			 //java calendar.MONTH january start from 0
			 int startDay = 1;
			 Calendar calendar = Calendar.getInstance();
			 calendar.set(Calendar.YEAR,Integer.parseInt(year));
			 calendar.set(Calendar.MONTH,Integer.parseInt(monthId)-1); 
			 int endDay = calendar.getActualMaximum(Calendar.DATE);
			   
			 log.info("year: "+calendar.get(Calendar.YEAR));
			 log.info("month:"+calendar.get(Calendar.MONTH));
			 log.info(startDay+"|"+endDay);
			 
			 List<KeyValueBean> month = new ArrayList<KeyValueBean>();
			 String[] dayOfWeek = {"wk","wd","wd","wd","wd","wd","wk"};
			 
			 //Calendar.DAy_OF_WEEK => SUNDAY = 1 MONDAY = 2 TUESDAY = 3  WEDNESDAY = 4 THURSDAY = 5 FRIDAY = 6 SATURDAY = 7 
			 for(int i=1;i<=endDay;i++){
				 calendar.set(Calendar.DATE,i);
				 KeyValueBean kv = new KeyValueBean();
				 kv.setId(""+i);
				 kv.setVal(dayOfWeek[calendar.get(Calendar.DAY_OF_WEEK)-1]);
				 month.add(kv);
			 }
			
			 //holiday configuration table
			 ServiceResult<List<DataBean>> hConf = reportService.getHolidayConfig(year, monthId); 
			 if(hConf.isSuccess()){
				 
				 List<DataBean> holidays = hConf.getResult();
				 log.info("holiday : "+holidays.size());
				 
				 for(DataBean holiday : holidays ){
					// dayOfWeek[ Integer.parseInt(holiday.getA())] = "hd";
					
					 KeyValueBean kv = month.get(Integer.parseInt(holiday.getA())-1);
					 kv.setVal("hd");
					 
					 //log.info("holiday date :"+ holiday.getA());
				 } 
				// m.put("hConf",  hConf.getResult());
			 }
			 
			 //insert configuration month
			 m.put("monthConf", month); 
			 
			//staff header detail
			//timesheet
			 List<DataBean> staffDtl = null;
			 ServiceResult<List<DataBean>> staff = reportService.searchStaffDetail(uid); 
			 if(staff.isSuccess()){
				 staffDtl = staff.getResult();
			 }
			 m.put("staffDtl", staffDtl);
		 
			
		
			 
			 //timesheet note
			 List<DataBean> notes = null;
			 ServiceResult<List<DataBean>> tsNote = timesheetDashboardService.searchReportTimesheetNote(year, monthId,uid); 
			 if(tsDtl.isSuccess()){
				notes = tsNote.getResult();
				// m.put("tsNote",  tsNote.getResult());
			 }
			 
			 //insert note to timesheet
			 if(tsNote.getResult().size() > 0){
				 for(DataBean  sheet: timesheets ){
					//log.info("timesheet date :"+sheet.getB()+"|project_id:"+sheet.getJ()+"|issue id:"+sheet.getK());
					StringBuilder str = new StringBuilder(); 
					 for(DataBean  note: notes ){
						 
						//log.info("note date"+ note.getC()+"|note pid:"+note.getE()+"|note issue:"+note.getF());
						 if(sheet.getB().equalsIgnoreCase(note.getC()) && sheet.getJ().equalsIgnoreCase(note.getE())  && sheet.getK().equalsIgnoreCase(note.getF())){
							str.append( "<p class=\"nospace\" style=\"color:#aaa;font-size:12px\"><i class=\"fas fa-circle\" style=\"font-size:9px;\"></i> "+note.getB()+" "+note.getG()+"</p>" );
						 }
						 
						 //for performance 
						 //stop loop if date of timesheet < note
						
						// if(compare2DateString(sheet.getC(),note.getB())){
						//	 break; 
						 //}
					  
					
					 }
					 sheet.setN( str.toString());
					 str = null;
				 }
			 }
			 m.put("tsDtl",  tsDtl.getResult());
			
		
			 //allowance
			 List<DataBean> ot = null;
			 ServiceResult<List<DataBean>> tsOT = reportService.searchReportTimeshhetOvertime(year, monthId, uid); 
			 if(tsOT.isSuccess()){
				 ot = tsOT.getResult();
			 }
			 m.put("tsOT", ot);
			 */ 
			  	
		
			
		
			
		}catch(Exception e){
			//res = new JsonResultBean(result_status, result_msg , result_data );
			log.info("Error !!"+e);
			e.printStackTrace();
			
		}
		
		result = new JsonResultBean(result_status, result_msg , m);
		return result;
	
	}
	
	
	private boolean compare2DateString( String sdate , String edate ){
			boolean result = false;
		    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		  
			try{
				  Date date1 = format.parse(sdate);
				  Date date2 = format.parse(edate);

				  log.info( date1 +"|"+date2);
			      if(date1.compareTo(date2) >= 0) {
			    	  result = true;
			    	  log.info("date1 > date2 ");
			      }else{
			    	  result = false;
			    	  log.info("date1 < date2 ");
			      }
				
			} catch (ParseException e) {
				e.printStackTrace();
			}
		  

		
		return true;
	}
	
	 
}