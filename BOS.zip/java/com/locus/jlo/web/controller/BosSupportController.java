package com.locus.jlo.web.controller;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.project.TicketsBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.BosSupportService;
import com.locus.jlo.web.services.TicketsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class BosSupportController extends CoreController {
	
	@Autowired
	private BosSupportService bosSupportService;
	@Autowired  
	private TicketsService ticketsService;

	 @RequestMapping(value = {"/supportSR"})
	  public String supportSR() {
	        return "supportSR";
	  }
	 
	 @RequestMapping(value = "/qrySupportSR", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean qrySupportSR(HttpServletRequest request,Locale locale) throws Exception{
		
		 ServiceResult<List<DataBean>> serviceResult =  new ServiceResult<>();
		 JsonResultBean result = null;
		 try{
			 
			 	String userId  = (String)request.getSession().getAttribute("UID");
			 	log.info("getUSEr from session : "+userId);
			 	
				String year    = request.getParameter("year");
				String filter_request_by = request.getParameter("filter_request_by");
				String filter_status = request.getParameter("filter_status");
				String filter_category = request.getParameter("filter_category");
				
				if(year.equals("all")){
					year = null;
				}
				
				String request_to_me = "";
				String request_from_me = "";
				if(filter_request_by.equals("request-to-me")){
					request_to_me = userId;
					request_from_me = null;
				}else if(filter_request_by.equals("request-from-me")){
					request_to_me = null;
					request_from_me = userId;;
				}
				String leaveStatus = filter_status;
				if(filter_status.equals("all")){
					leaveStatus = null;
				}
				String leaveType = filter_category;
				if(filter_category.equals("all")){
					leaveType = null;
				}
				
				
				serviceResult =  bosSupportService.qrySupportSR();
				if(serviceResult.isSuccess()){
					result = new JsonResultBean("success", "" , serviceResult.getResult());
				}
			   
		 }catch(Exception e){
			 log.info("Error !!"+e);
		 }
		return result;
		
	 }
	 
	 @RequestMapping(value = "/qrySupportSRDetail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean qrySupportSRDetail(HttpServletRequest request,Locale locale) throws Exception{
		 
		 String id  = request.getParameter("id");
		 log.info("id: "+id);
		 ServiceResult<List<DataBean>> listResult =  bosSupportService.qrySupportSRDetail(id); 
		 JsonResultBean result = null;
		 if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		 }
		 
		return result;
	 }
	 
	 
//	 @RequestMapping(value = "/saveSupportSR", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
//	 public @ResponseBody JsonResultBean saveSupportSR(HttpServletRequest request,Locale locale) throws Exception{
//			
//			//https://www.tutorialspoint.com/json/json_java_example.htm
//			 final int USER_ID = getUid(request);
//			 String data = request.getParameter("data");
//			 
//			 log.info("Setting User control");
//			 log.info("data: "+data);
//			 
////			 List<TicketsBean> beans = new ArrayList<>();
//			 
////			 if (!StringUtils.isEmpty(data)&&!(data.equals("{}"))) {
//				 JSONParser jParser = new JSONParser();
//				 JSONObject json = (JSONObject) jParser.parse(data);
//				 
//				 JsonBeanUtils<TicketsBean> utils = new JsonBeanUtils<>(TicketsBean.class);	 		 
//				 TicketsBean bean = utils.convertFormAndBeanWithUser(json,USER_ID);
//				 
//				 String owner = getUser(request).getFirstName()+" "+getUser(request).getLastName();
//				 
//				 bean.setProject_id(1);
//				 bean.setAssign_uid(USER_ID);
//				 bean.setStatus(1);
////				 bean.setOwner_uid(owner);
//
//				 log.info("data");
//				 utils.print(bean);
//
//
//			 String result_status = "";
//			 String result_msg    = "";
//			 ServiceResult<Long> result = new ServiceResult<>();
//			 
//			 try{
//				 if (bean.getId() == null) {
//					 result =  ticketsService.insertTickets(bean);
//	 	    			
//			 	    if(result.isSuccess()){
//			 	   		log.info( "get long : "+result.getResult());
//			 	   		result_status = "success";
//			 	   		result_msg    = "save successful";
//			 	    				
//			 	   	}else{
//			     		result_status = "fail";
//			    		result_msg    = "save fail";
//		 	    	}
//			 	    
//				 }else {
//					
//					result =  ticketsService.updateTickets(bean);
//	 	    			
//				 	if(result.isSuccess()){
//				 	   	log.info( "get long : "+result.getResult());
//				 	   	result_status = "success";
//				 	   	result_msg    = "save successful";
//				 	    				
//				 	}else{
//				    	result_status = "fail";
//				    	result_msg    = "save fail";
//			 	    }
//				 }
//	
//		
//				}catch(Exception e){
//					log.info("Error !!"+e);
//				}
//			 
//			JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult());
////			}
//			return res;
//		   
//
//		 }
	 
	
    
}