package com.locus.jlo.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.beans.task.TaskBean;
import com.locus.jlo.web.services.TaskService;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
@RequestMapping("task")
public class TaskController extends CoreController {
	
	@Autowired
	private TaskService taskService;
	
	@SuppressWarnings("unchecked")
	@PostMapping("/getTaskTree")
    public @ResponseBody  JsonResultBean getTreeData(HttpServletRequest request, Locale locale) throws Exception {
    	
    	JsonResultBean res = null;
    	Map<String, Object> m = new HashMap<String, Object>();
    	
    	String result_status = "success";
		String result_msg    = "success";
		String result_data   = ""; 
    	
    	try{
    		String projectId = request.getParameter("projectId");
    		int seq = 1;
    		
    		ServiceResult<List<DataBean>> listResult = taskService.searchTaskTreeByProject(projectId);

    		List<DataTree>  task = new ArrayList<DataTree>();
            if (listResult.isSuccess()) {
            	seq = listResult.getResult().size();
            	
            	List<DataBean> listObj = listResult.getResult();
            	
            	
				List<DataBean> listTask = (List<DataBean>) CollectionUtils.select(listObj, new Predicate() {
					
					@Override
					public boolean evaluate(Object object) {
						DataBean b = (DataBean)object;
						return StringUtils.isEmpty(b.getJ());
					}
				});
            	
            	
            	for (DataBean en: listTask) {
            		List<DataTree> lch1 = new ArrayList<DataTree>();
	            	
	            	
            		DataTree parent = new DataTree();
            		parent.setTitle(en.getB());
            		parent.setKey(en.getA());
            		parent.setFolder(true);
            		parent.setLevel("1");
            		parent.setSeq(en.getI());
            		parent.setParentId(en.getJ());
            		parent.setStartDate(en.getE());
            		parent.setEndDate(en.getF());
            		String parent_id = en.getA();
            		
            		
            		List<DataBean> listTaskChild = (List<DataBean>) CollectionUtils.select(listObj, new Predicate() {
						
						@Override
						public boolean evaluate(Object object) {
							DataBean b = (DataBean)object;
							return !StringUtils.isEmpty(b.getJ()) && b.getJ().equals(parent_id) ; 
						}
					});
            		
            		for (DataBean ch: listTaskChild) {
            			DataTree child1 = new DataTree();
            			child1.setTitle(ch.getB());
            			child1.setKey(ch.getA());
            			child1.setLevel("2");
            			child1.setSeq(ch.getI());
            			child1.setParentId(ch.getJ());
            			child1.setStartDate(ch.getE());
            			child1.setEndDate(ch.getF());
            			lch1.add(child1);
            		}	
	            		
	            	parent.setChildren(lch1);
            		task.add(parent);
            	}
            }


  			m.put("tree", task);
  			m.put("seq", seq );
  			
  		
    		
    	}catch( Exception e){
    		
    		 result_status = "fail";
			 result_msg    = "fail";
			
			res = new JsonResultBean(result_status, result_msg , result_data );
			//log.info("Error !!"+e);
			e.printStackTrace();
    		
    	}
    	
    	res = new JsonResultBean(result_status, result_msg , m );
		return res;
      
       
    }

	@GetMapping("search/{projectId}")
	public @ResponseBody JsonResultBean seachTaskByProject(@PathVariable String projectId,Locale locale) throws Exception {
		JsonResultBean res = new JsonResultBean();
		String result_status = "OK";
		String result_msg    = "success";
		try {
			ServiceResult<List<Map<String, Object>>> result = taskService.searchTaskByProject(projectId);
			res = new JsonResultBean(result_status, result_msg , result.getResult() );
		}catch (Exception e){
			e.printStackTrace();
		}
		return res;
	}

	@PostMapping(value = "/save")
	public @ResponseBody JsonResultBean saveTask(@RequestBody List<TaskBean> tasks,  HttpServletRequest request,Locale locale) throws Exception {
		JsonResultBean res = null;
		String result_status = "";
		String result_msg = "";
		String uid =  getUid(request).toString();
		tasks.forEach(taskBean -> {taskBean.setCreate_user_id(uid);});
		try{
			result_status = "success";
			result_msg    = "save successful";
			res = new JsonResultBean(result_status, result_msg ,taskService.saveTask(tasks).isSuccess());
		}catch(Exception e){
			log.info("Error !!"+e);
			res = new JsonResultBean("", "" , false );
		}
		return res;
	}

	@RequestMapping(value = "/removeTask", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean removeTask(HttpServletRequest request,Locale locale) throws Exception {
		
		 ServiceResult<Integer> result = new ServiceResult<>();
	     String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
			 
	
		 String UID  = request.getSession().getAttribute("UID").toString();
		 String rm = request.getParameter("rm_data");


		 
		try {
				JSONParser jParser = new JSONParser();
				JSONObject rmObj = (JSONObject)jParser.parse(rm);
				boolean isParent = rmObj.get("level").toString().equals("1") ? true : false;
				result =  taskService.removeTask(rmObj.get("key").toString(), rmObj.get("projectId").toString(), isParent);
				log.info("remove task " + rmObj.get("key").toString()); 

				if (result.isSuccess()) {
					log.info( "get Int : "+result.getResult());
					result_data   = Integer.toString(result.getResult());
					result_status = "success";
					result_msg    = "save successful";
				
				} else {
					result_status = "fail";
					if (result.getResponseCode().equals("Data Already Used")) {
						result_msg    =  result.getResponseDescription();
					} else {
						result_msg    = "save fail";
					}
					
				}

				 
		 } catch(Exception e) {
			log.info("Error !!"+e);
			e.printStackTrace();
		 }
		
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
		 
	}
	 
	 @Setter
	 @Getter
	 public class DataTree{
		 String title;
		 String key;
		 boolean folder;
		 String level;
		 String seq;
		 String parentId;
		 String startDate;
		 String endDate;
		 List<DataTree>children;	 
		 
	 }
   
    
}