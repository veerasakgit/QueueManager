package com.locus.jlo.web.controller;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.account.AccountDetailBean;
import com.locus.jlo.web.services.AccountDetailService;
@Controller
public class AccountDetailController {

	@Autowired
	private AccountDetailService accountService;
	
	@RequestMapping(value = "/accountDetail", method = RequestMethod.POST)
	public @ResponseBody String calInsurancePremium(HttpServletRequest request, HttpServletResponse response) throws Exception {
		AccountDetailBean accountDetailBean = new AccountDetailBean();
		accountDetailBean.setAccountId((new Random().nextInt(1000)+1)+"");
		accountDetailBean.setAccountName("Test");
		try {
			ServiceResult<Boolean> serviceResult = accountService.saveAccountDetail(accountDetailBean);
			if (serviceResult.isSuccess()) {
			} else {
			}
			return null;
		} catch (Exception e) {
			return null;
		}
	}
}
