package com.locus.jlo.web.controller;


import java.util.Locale;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

    @Autowired
    private MessageSource messageSource;

    @RequestMapping("/login")
    String login(Model model, HttpServletRequest request, Locale local) {
        model.addAttribute("pageTitle", messageSource.getMessage("login.title", null, local));
        //return "home";
        return "login";
    }
    
    @RequestMapping("/expired")
    public String expire() {
        return "session.expired";
    }
    
    
}
