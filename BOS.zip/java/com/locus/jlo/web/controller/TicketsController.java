package com.locus.jlo.web.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.project.TicketsBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.TicketsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class TicketsController extends CoreController {
	
	 @Autowired
	 private TicketsService ticketsService;
	 private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/mm/yyyy"); 
	 
	 
	 
		@RequestMapping(value = {"/serviceRequest"})
		  public String index() {
		        return "serviceRequest";
		}
	 
	 
		@RequestMapping(value = "/searchTickets", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean searchTickets(HttpServletRequest request,Locale locale) throws Exception{
			
			HashMap<String, Object> criteria = new HashMap<>();
			
			String id = request.getParameter("id");
			
			//String pid = request.getParameter("projectId");
			
			String reqType = request.getParameter("reqType");
			
			if (StringUtils.isEmpty(reqType)) {
				
			}else {
				criteria.put(reqType,getUid(request));
			}

			criteria.put("uid",getUid(request));
			//criteria.put("projectId",StringUtils.isEmpty(pid)?BOSConstant.BosSupport.PROJECT_ID:pid);

			if (!StringUtils.isEmpty(id)) {
				criteria.put("id", Integer.parseInt(id));
			}

			ServiceResult<List<Map<String, Object>>> listResult =  ticketsService.searchTickets(criteria);
			JsonResultBean result = null;
			if(listResult.isSuccess()){
				result = new JsonResultBean("success", "" , listResult.getResult());
			}
			return result;
		 }
		
		@RequestMapping(value = "/searchTicketsByProject", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean searchTicketsByProject(HttpServletRequest request,Locale locale) throws Exception{
			
			HashMap<String, Object> criteria = new HashMap<>();
			
			String id = request.getParameter("id");
			
			String pid = request.getParameter("projectId");
			
			String reqType = request.getParameter("reqType");
			
			if (StringUtils.isEmpty(reqType)) {
				
			}else {
				criteria.put(reqType,getUid(request));
			}

			criteria.put("uid",getUid(request));
			criteria.put("projectId",StringUtils.isEmpty(pid)?BOSConstant.BosSupport.PROJECT_ID:pid);

			if (!StringUtils.isEmpty(id)) {
				criteria.put("id", Integer.parseInt(id));
			}

			ServiceResult<List<Map<String, Object>>> listResult =  ticketsService.searchTickets(criteria);
			JsonResultBean result = null;
			if(listResult.isSuccess()){
				result = new JsonResultBean("success", "" , listResult.getResult());
			}
			return result;
		 }
		
		 @RequestMapping(value = "/saveTickets", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.POST)
		 public @ResponseBody JsonResultBean saveTickets(HttpServletRequest request,Locale locale) throws Exception{
				
				//https://www.tutorialspoint.com/json/json_java_example.htm
				 final int USER_ID = getUid(request);
				 String data = request.getParameter("data");
				 
				 Boolean isBos = Boolean.valueOf(request.getParameter("isBos"));
				 
				 log.info("Setting User control");
				 log.info("data: "+data);
				 
//				 List<TicketsBean> beans = new ArrayList<>();
				 
//				 if (!StringUtils.isEmpty(data)&&!(data.equals("{}"))) {
					 JSONParser jParser = new JSONParser();
					 JSONObject json = (JSONObject) jParser.parse(data);
					 
					 JsonBeanUtils<TicketsBean> utils = new JsonBeanUtils<>(TicketsBean.class);	 		 
					 TicketsBean bean = utils.convertFormAndBeanWithUser(json,USER_ID);
					 
					 log.info("data");
					 //if from Bos 
					 {
						 if (isBos) {
							
							Date now = new Date();
							//req
							bean.setStatus(2);
							bean.setProject_id(BOSConstant.BosSupport.PROJECT_ID);
							bean.setRequest_by(getUserFullName(request));
							bean.setOwner_uid(getUid(request));
							bean.setAssign_uid(BOSConstant.BosSupport.ASSIGN_UID);
							
							bean.setDue_date(now);
							bean.setInform_dt(now);
							bean.setInform_person(getUserFullName(request));
						}
					 }
					 
					 utils.print(bean);

				 String result_status = "";
				 String result_msg    = "";
				 ServiceResult<Long> result = new ServiceResult<>();
				 
				 Calendar cal = Calendar.getInstance();
				 
				 switch (bean.getStatus()) {
					 case 4:
						bean.setClosed_uid(USER_ID);
						bean.setClosed_dt(cal.getTime());
						break;
					 case 5:
						bean.setCancel_uid(USER_ID);
						bean.setCancel_dt(cal.getTime());
						break;
						
					default:
						break;
				}
				 
				 try{
					 if (bean.getId() == null) {
						 
						 result =  ticketsService.insertTickets(bean);
		 	    			
				 	    if(result.isSuccess()){
				 	   		log.info( "get long : "+result.getResult());
				 	   		result_status = "success";
				 	   		result_msg    = "save successful";
				 	    				
				 	   	}else{
				     		result_status = "fail";
				    		result_msg    = "save fail";
			 	    	}
				 	    
					 }else {

						result =  ticketsService.updateTickets(bean);
		 	    			
					 	if(result.isSuccess()){
					 	   	log.info( "get long : "+result.getResult());
					 	   	result_status = "success";
					 	   	result_msg    = "save successful";
					 	    				
					 	}else{
					    	result_status = "fail";
					    	result_msg    = "save fail";
				 	    }
					 }
		
			
					}catch(Exception e){
						log.info("Error !!"+e);
					}
				 
				JsonResultBean res = new JsonResultBean(result_status, result_msg , result.getResult());
//				}
				return res;
			   

			 }
		 
//		 public static void main(String[] args) {
//			 Boolean b = Boolean.valueOf("");
//			 System.out.print(b);
//		}

}
