package com.locus.jlo.web.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.FileUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.module.DocumentsBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.DocumentsService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
@RequestMapping("doc")
public class DocumentsController extends CoreController {

    @Autowired
    private DocumentsService documentsService;

    @Value("${jlo.doc.path}")
    private String docPath;

    @PostMapping("/searchProjectDocuments")
    public @ResponseBody  JsonResultBean searchProjectDocuments(@RequestBody DocumentsBean bean, HttpServletRequest request, Locale locale) throws Exception {
    	
    	JsonResultBean res = null;
    	Map<String, Object> m = new HashMap<String, Object>();
    	
    	String result_status = "success";
		String result_msg    = "success";
		String result_data   = ""; 
    	
    	try{
    		
    		ServiceResult<List<DataBean>> document = documentsService.searchDocuments(bean);
  			if( document.isSuccess()){
  				m.put("doc",document.getResult());
  			}
  		
  			ServiceResult<List<DataBean>> projDealDocument = documentsService.searchDealInProjectDocuments(bean);
  			if( projDealDocument.isSuccess()){
  				m.put("dealDoc",projDealDocument.getResult());
  			}
    		
    	}catch( Exception e){
    		
    		 result_status = "fail";
			 result_msg    = "fail";
			
			res = new JsonResultBean(result_status, result_msg , result_data );
			log.info("Error !!"+e);
			e.printStackTrace();
    		
    	}
    	
    	res = new JsonResultBean(result_status, result_msg , m );
		return res;
      
       
    }

    
    @PostMapping(value = "saveDocument",consumes = "multipart/form-data")
    @Transactional(rollbackFor=Exception.class, propagation = Propagation.REQUIRED)
    public @ResponseBody
    JsonResultBean saveDocument(@ModelAttribute(value = "documentBean") DocumentsBean documentsBean,
                                @RequestParam(value = "fileName", required = false) MultipartFile fileUpload,
                                HttpServletRequest request, Locale locale) throws Exception {

        final Integer USER_ID = getUid(request);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

        String result_status = "";
        String result_msg = "";
        String result_data = "";

        documentsBean.setCreate_uid(USER_ID);
        
        Calendar currDate = Calendar.getInstance();
    
        //set disk path
        //Calendar Month start from 0 !!
        int currMonth = currDate.get(Calendar.MONTH) + 1; 
        String currMonthFormat = ""; 
        if(currMonth < 10){
        	currMonthFormat = "0"+currMonth;
        }else{
        	currMonthFormat = ""+currMonth;
        }
        documentsBean.setDisk_directory(currDate.get(Calendar.YEAR)+"/"+currMonthFormat);
        String diskPath = dateFormat.format(currDate.getTime()).concat("_").concat(fileUpload.getOriginalFilename());
        documentsBean.setDisk_path(diskPath);

        log.info("File size : "+fileUpload.getSize());
        if( fileUpload.getSize() > 30000000 ){
            result_status = "fail";
            result_msg = "Over limit file size!";
            JsonResultBean res = new JsonResultBean(result_status, result_msg, result_data);
            return res;
        }

        String fileType = FilenameUtils.getExtension(fileUpload.getOriginalFilename());
        documentsBean.setFile_type(fileType);
        log.info("File type : "+fileType);
        if(!fileType.matches("^(?!.*(exe|cvs|nvs|mvc|sql)).*$")){
            result_status = "fail";
            result_msg = "Not accept this file type!";
            JsonResultBean res = new JsonResultBean(result_status, result_msg, result_data);
            return res;
        }

        //documentsBean.setFile_size(""+FileUtils.convertBytesToMB(fileUpload.getSize()));
        documentsBean.setFile_size(""+fileUpload.getSize());
        documentsBean.setFile_name(fileUpload.getOriginalFilename());      

        ServiceResult<Integer> result = new ServiceResult<>();
        if (BOSConstant.DBAction.INSERT.equals(documentsBean.getAction())) {
            result = documentsService.insertDocuments(documentsBean);
        }else{
        	String file_path = "";
            List<DataBean> obj = documentsService.searchDocuments(documentsBean).getResult();
            for(DataBean o : obj ){
            	file_path = docPath+"/"+o.getN()+"/"+o.getG();
            }
            FileUtils.deleteFile(file_path,true);
            //FileUtils.deleteFile(docPath + "/" +obj.get(0).get("project_id")+ "/" + obj.get(0).get("file_name"),true);
            result = documentsService.updateDocuments(documentsBean);
        }
        if(result.isSuccess()){
            if(null != fileUpload && !fileUpload.isEmpty()){
                String filePath = this.saveDocument(documentsBean, fileUpload, false);
            }
        }

        if (result.isSuccess()) {
            log.info("get long : " + result.getResult());
            result_data = Long.toString(result.getResult());
            result_status = "success";
            result_msg = "save successful";
        } else {
            result_status = "fail";
            result_msg = "save fail";
        }

        JsonResultBean res = new JsonResultBean(result_status, result_msg, result_data);
        return res;
    }

    public String saveDocument(DocumentsBean documentsBean,MultipartFile fileUpload, boolean clearOld) throws Exception {
        //String filePath = docPath + "/" + documentsBean.getDisk_directory()+ "/" + fileUpload.getOriginalFilename();
    	String filePath = docPath + "/" + documentsBean.getDisk_directory()+ "/" + documentsBean.getDisk_path();
    	FileUtils.saveFile(fileUpload, filePath, filePath, clearOld);
    	return filePath;
    }

    @GetMapping("/delDoc/{id}")
    public @ResponseBody
    JsonResultBean delDocumentById(@PathVariable Integer id,
                                                  HttpServletRequest request, Locale locale) throws Exception {

        DocumentsBean doc = new DocumentsBean();
        doc.setId(id);
        List<DataBean> obj = documentsService.searchDocuments(doc).getResult();
        
        String file_path = "";
        for(DataBean o : obj ){
        	file_path = docPath+"/"+o.getN()+"/"+o.getO();
        }
        

        ServiceResult<Integer> res = documentsService.removeDocuments(id);
        FileUtils.deleteFile(file_path,true);
       // FileUtils.deleteFile(docPath + "/" +obj.get(0).get("project_id")+ "/" + obj.get(0).get("file_name"),true);
        
        JsonResultBean result = null;
        if (res.isSuccess()) {
            result = new JsonResultBean("success", "", res.getResult());
        }
        return result;
    }

    @GetMapping("/download/{id}")
    public @ResponseBody void downloadDocumentById(@PathVariable Integer id,
                                        HttpServletRequest request, HttpServletResponse response, Locale locale) throws Exception {

        DocumentsBean doc = new DocumentsBean();
        doc.setId(id);
        
        String file_path = "";
        String orgFilename = "";
        List<DataBean> obj = documentsService.searchDocuments(doc).getResult();
        for(DataBean o : obj ){
        	file_path = docPath+"/"+o.getN()+"/"+o.getO();
        	orgFilename = o.getG();
        }
        
        if(!StringUtils.isEmpty(file_path)){
        	FileUtils.downloadFile(request, response,file_path, orgFilename);
        }
        
        /*
         List<Map<String, Object>> obj = documentsService.searchDocuments(doc).getResult();
        if(!StringUtils.isEmpty(obj.get(0).get("file_name"))){
            String fileName = obj.get(0).get("file_name").toString();
            String projectId = obj.get(0).get("project_id").toString();

            FileUtils.downloadFile(request, response, docPath + "/" + projectId + "/" + fileName);
        }
        */
    }
}