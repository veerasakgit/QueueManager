package com.locus.jlo.web.controller;

import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.UUID;
import java.util.Date;
import java.util.HashMap;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.account.search.AccountSearchBean;
import com.locus.jlo.web.beans.leaveForm.LeaveFormDetailBean;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modeljson.DatatableModelBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.beans.tokenBean.TokenBean;
import com.locus.jlo.web.services.LeaveFormService;
import com.locus.jlo.web.services.LeaveRecordService;
import com.locus.jlo.web.services.ReportService;
import com.locus.jlo.web.services.TokenService;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

@Slf4j
@Controller
public class LeaveFormController {
	
	@Value("#{servletContext.contextPath}")
	private String servletContextPath;
	 
	//@Value("${jlo.email.reply.link}")
	//private String emailReplayLink;
	 
	final static private SimpleDateFormat yyyyMMddHHmm = new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US);
	final static private SimpleDateFormat yyyyMMddHHmmss = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US);
	
	//final static private SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US); 
	
	
	@Autowired
	ServletContext context;
	
	@Autowired
	private LeaveRecordService leaveRecordService;
	
	@Autowired
	private LeaveFormService leaveFormService;
	
	@Autowired
	private TokenService tokenService;
	
	@Autowired
	private ReportService reportService;
	
	
	 @RequestMapping(value = {"/leaveRequest"})
	  public String index() {
	        return "leaveForm";
	  }
	 
	 @RequestMapping(value = "/emailLeaveReply", method = RequestMethod.GET)
	 public @ResponseBody ModelAndView emailLeaveReply(HttpServletRequest request,Locale locale) throws Exception{
		 
		 String id = request.getParameter("id");
		 String verify_token = request.getParameter("verify");
		 String token = request.getParameter("token");
		 
		 log.info("get link: "+id+"|"+token+"|"+verify_token);
		 
		 //verify token
		 String showReturnResult = "notifyInvalid"; //default redirect //[notifyInvalid,notifyLinkExpired,notifyApproved,notifyRejected]
		 
		try{
			 
		 ServiceResult<List<DataBean>> listResult = tokenService.verifyToken(token,verify_token);  //return action , id , notify_id
		 if(listResult.isSuccess()){
			 DataBean d = new DataBean();
			 if(listResult.getResult().get(0) != null){
				      d = listResult.getResult().get(0);
			 }else{
				 //return result if data is null 
				 return  new ModelAndView(showReturnResult);
			 }
			
			 log.info("result success");
			 
				//token is in valid (N)
				if(!StringUtils.isEmpty(d.getC()) && d.getC().equals("N")) {
					 log.info("token is in valid (N)");
					showReturnResult = "notifyLinkExpired";
				}else
				//token is valid (Y)
				if(!StringUtils.isEmpty(d.getC()) && d.getC().equals("Y") ){
					 log.info("token is valid (Y)");
					//get notify == leave_id
					LeaveFormDetailBean leaveForm = new LeaveFormDetailBean();
					log.info("get leave id : "+d.getA());
					leaveForm.setLeave_id(d.getA());
					
					log.info("get C:"+d.getC()+"| get B:"+d.getB());
					//get action
					if(!StringUtils.isEmpty(d.getC()) && d.getB().equals("approved")){
						 log.info("notifyApproved");
						showReturnResult = "notifyApproved";
						//approved is status == 3
						leaveForm.setLeave_status("3");
						leaveForm.setApprove_user_id(d.getD());
						leaveForm.setUpdate_user_id(d.getD());
					
						//update to leaveForm
						leaveFormService.updateLeaveApprove(leaveForm);
						log.info("update leave form success");
						
					}else
					if(!StringUtils.isEmpty(d.getC()) && d.getB().equals("rejected")){
						showReturnResult = "notifyRejected";
						 log.info("notifyRejected");
						//rejected is status == 4
						leaveForm.setLeave_status("4");
						leaveForm.setReject_user_id(d.getD());
						leaveForm.setUpdate_user_id(d.getD());
						 
						//update to leaveForm
						leaveFormService.updateLeaveReject(leaveForm);
						log.info("update leave form success");
					}
					 
					 //add requirement 
					 //uncheck flag allow leave on probation
					 leaveFormService.recheckAllowLeaveOnProbation(leaveForm);
					 log.info("set staff leave on probation to null");
					
					 Date cur_date = yyyyMMddHHmmss.parse(yyyyMMddHHmmss.format(new Date()));
					 TokenBean t = new TokenBean();
					 t.setId(id);
					 t.setToken_valid_YN("N");
					 t.setExpire_date(cur_date);
					 t.setNotify_id(d.getA());
					 t.setUpdate_uid(d.getD());
					 
					 log.info("id: "+t.getId());
					 log.info("update user: "+d.getD());
				  
					 
					 tokenService.updateToken(t);
					 log.info("update token success");
					 
					 //send mail notify
					 sendMailNotify(request,leaveForm.getLeave_status(), leaveForm.getLeave_id() , "" );
					
					
				}
				
		 }else{
			 //query fail
			 showReturnResult = "notifyInvalid";
			 
			 log.info("result fail");
		 }
		
		}catch(Exception e){
			log.info("Error : "+e);
			e.printStackTrace();
			//if something gone wrong;
			showReturnResult = "notifyInvalid";
			 log.info("result Error");
		}
		 
		 return  new ModelAndView(showReturnResult);
	 }
	 
	  
	 //if from email channel error will be response to notify
	 /*
	 @RequestMapping(value = "/sendMail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody String sendMail(HttpServletRequest request,Locale locale) throws Exception{
		 
		 	getPath();
		  
		 	String result_status = "";
			String result_msg = "";
			String result_data = "";
			
			try{
					String template = mailTemplate("");
					
					template = template.replaceAll("#leaveStatus","cancelled");
					template = template.replaceAll("#createdon","yyyy-mm-dd");
					template = template.replaceAll("#staffName","HelloWorld");
					template = template.replaceAll("#staffDept","HelloWorld");
					template = template.replaceAll("#leaveType","Annual Leave");
					template = template.replaceAll("#leaveStartDate","Wed 12 January");
					template = template.replaceAll("#leaveStartTime","08:30");
					template = template.replaceAll("#leaveEndDate","Wed 12 January");
					template = template.replaceAll("#leaveEndTime","17:30");
					template = template.replaceAll("#leaveTotal","1 Day");
					template = template.replaceAll("#leaveJustification","Go up country");
					template = template.replaceAll("#rejectLink","helloworldLink");
					template = template.replaceAll("#approveLink","helloworldLink");
					 
					log.info("generate token");
					log.info("token :"+ generateToken());
					log.info("verify_token:"+generateVerifyToken());
					
					 		 //http://jlo.locus.co.th/bos/emailLeaveReply?id=12&act=App&verify=c5c3b569c414902e3d095&token=wDxQbGMkErLQeJXsQ7fp
					 		//http://jlo.locus.co.th/bos/emailLeaveReply?id=12&act=Rej&verify=c5c3b569c414902e3d095&token=wDxQbGMkErLQeJXsQ7fp
					
					
					//link expired
					//token is not valid
					//leave approved
					//leave rejected
					
					//log.info(template);
			
				  	Properties props = new Properties();
			        props.put("mail.smtp.host", "smtp.office365.com");
			        props.put("mail.smtp.socketFactory.port", "587");
			        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			        props.put("mail.smtp.auth", "true");
			        props.put("mail.smtp.port", "587");
			        props.put("mail.smtp.starttls.enable", "true");
			        
			        Session session = Session.getDefaultInstance(props,
			        	new javax.mail.Authenticator() {
	                    protected PasswordAuthentication getPasswordAuthentication() {
	                        return new PasswordAuthentication("arnon@locus.co.th","locus123");
	                    }
	                });

			        
			   //     InternetAddress[] myCcList = InternetAddress.parse("arnon@locus.co.th");
			        
	                Message message = new MimeMessage(session);
	                message.setFrom(new InternetAddress("arnon@locus.co.th"));
	                message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("arnon@locus.co.th"));
	            //   message.setRecipients(Message.RecipientType.CC,myCcList);
	                
	            
	                
	                message.setSubject("This is testing message");
	               // message.setText("Hi this is testing email....not spam");
	               // message.setContent("<h1><img src='http://www.locus.co.th/assets/main/img/logo@2x.png'> Hello</h1>", "text/html");
	                message.setContent(template, "text/html; charset=utf-8");
	                //message.setContent(someHtmlMessage, "text/html; charset=utf-8");
	              //  Transport.send(message);
	               
	                System.out.println("email successfully sent..");
			
				
			}catch(Exception e){
				throw new RuntimeException(e);
			}
			
	
			JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
			return "notifyRejected";
			
	}
	 */
	  
	 @RequestMapping(value = "/initailLeaveForm", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean findApproval(HttpServletRequest request,Locale locale) throws Exception{
		 
		 Map<String, Object> m = new HashMap<String, Object>();
	
		 JsonResultBean result = null;
		 try{
				
			 	//find approval & is pass probation
				UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
			 	String userId  = uinfo.getUid();
			 	
			 	//refresh every time when click button
			 	ServiceResult<List<DataBean>> approvePerson =  leaveFormService.findApproval(userId);
				if(approvePerson.isSuccess()){
					 m.put("approval", approvePerson.getResult());
				}
				
				 //get probation
				 m.put("probationPass",uinfo.getProbation_YN());
				
				 //get employee type
				 m.put("employeeType",uinfo.getEmployeeType());
				
				 //get is allow on probation
				/* 
				ServiceResult<List<DataBean>> allowLeaveOnProbation =  leaveFormService.findAllowLeaveOnProbation(userId);
				if(allowLeaveOnProbation.isSuccess()){
					 m.put("allowLeaveOnProbation", allowLeaveOnProbation.getResult());
				}
				*/
				//end refresh
				
						
				 //find annual leave balance for check annual leave is over the limit
			 	 String year = uinfo.getCurYear();
			 	 log.info("year: "+year);
			 	 
			 	 ServiceResult<List<DataBean>> sumAllLeaveUsed = new ServiceResult<>();
			 	 sumAllLeaveUsed = leaveRecordService.sumAllLeaveUsed(year,userId);
				 if(sumAllLeaveUsed.isSuccess()){
					 m.put("sumAllLeaveUsed",  sumAllLeaveUsed.getResult());
				 }
			 	 
			 	//get holiday show in calendar
				 ServiceResult<List<DataBean>> holidayCalendar = new ServiceResult<>();
				 holidayCalendar = leaveRecordService.getHolidayCalendar(year);
				 if(holidayCalendar.isSuccess()){
					 m.put("holiday",  holidayCalendar.getResult());
				 }
			 	 
				 
				 ServiceResult<List<DataBean>> annualLeaveLastYear = new ServiceResult<>();
				 annualLeaveLastYear = leaveRecordService.leaveRecordAnnualLeaveLastYearInfoService(userId);
				 if(annualLeaveLastYear.isSuccess()){
					 m.put("annualLastYearInfo",  annualLeaveLastYear.getResult());
				 }
				 
				 ServiceResult<List<DataBean>> annualLeaveThisYear = new ServiceResult<>();
				 annualLeaveThisYear = leaveRecordService.leaveRecordAnnualLeaveThisYearInfoService(userId);
				 if(annualLeaveThisYear.isSuccess()){
					 m.put("annualThisYearInfo",  annualLeaveThisYear.getResult());
				 }
				 
				 //qry this year leave record
					ServiceResult<List<DataBean>> leaveRecord  = leaveRecordService.searchLeaveRecord(year,userId);
					if(leaveRecord.isSuccess()){
						//keep to json
						m.put("leaveRecord",  leaveRecord.getResult());
					}
					
				 
				 /*
				 
				 ServiceResult<List<DataBean>> sumAnnualLeave = new ServiceResult<>();
				 log.info("summary annual leave");
				 sumAnnualLeave = leaveRecordService.summaryAnnualLeave(year,userId);
				 if(sumAnnualLeave.isSuccess()){
					 m.put("sumAnnualLeave",  sumAnnualLeave.getResult());
				 }
			
				 ServiceResult<List<DataBean>> getAnnualLeaveAccumulate = new ServiceResult<>();
				 log.info("summary annual leave");
				 getAnnualLeaveAccumulate = leaveRecordService.calAnnualLeaveAccumulate(year,userId);
				 if(getAnnualLeaveAccumulate.isSuccess()){
					 
					   
					    int size = getAnnualLeaveAccumulate.getResult().size();
					    double balance = 0.0;
					    double entitle = 0.0;
					    
					    double used = 0.0;
					    double total = 0.0;
					      
						for(int i=0;i<size;i++){
							DataBean tmp  = getAnnualLeaveAccumulate.getResult().get(i);
							log.info("current balance = "+balance);
							log.info("WORKING YEAR:"+tmp.getA()+"|ENTITLE:"+tmp.getB()+"|USED:"+tmp.getC());
							balance = Double.parseDouble(tmp.getB()) - Double.parseDouble(tmp.getC());
							log.info("balance = "+balance);
							
							total = total + balance;
							log.info("total is ["+i+"]: "+total); 
							
							
						}
						 
						if(total>15){
							total = 15;
						}
					
						log.info("Total Balance  is "+total);
					 
					 m.put("getAnnualLeaveAccumulate", total );
						
				 }
				   */
				
				//find justification detail
			
		 
		 }catch(Exception e){
			 result = new JsonResultBean("fail", "" , "");
			 log.info("Error !!"+e);
			 e.printStackTrace();
		 }

		   result = new JsonResultBean("success", "" , m);
		   return result;
	
}
	 
	  
	 @RequestMapping(value = "/checkAllowAnnualLeaveRequest", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	  public @ResponseBody JsonResultBean checkAllowLeaveRequest(HttpServletRequest request,Locale locale) throws Exception{
			 
			 Map<String, Object> m = new HashMap<String, Object>();
			 JsonResultBean result = null;
			 try{
				//find approval & is pass probation
				UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
			 	String userId  = uinfo.getUid();
			 	
			 	//refresh every time when click button
			 	ServiceResult<List<DataBean>> isAllowAnnualLeave =  leaveFormService.findApproval(userId);
				if(isAllowAnnualLeave.isSuccess()){
					 m.put("isAllowAnnualLeave", isAllowAnnualLeave.getResult());
				}
			
			 }catch(Exception e){
				 result = new JsonResultBean("fail", "" , "");
				 log.info("Error !!"+e);
				 e.printStackTrace();
			 }

			  result = new JsonResultBean("success", "" , m);
			 return result;
	 }
			 
	 
	 
	 @RequestMapping(value = "/searchLeaveRequest", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchLeaveRequest(HttpServletRequest request,Locale locale) throws Exception{
		
		 ServiceResult<List<DataBean>> serviceResult =  new ServiceResult<>();
		 JsonResultBean result = null;
		 try{
			 
			 	UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
			 	String userId  = uinfo.getUid();
			 	log.info("getUSEr from session : "+userId);
				String year    = request.getParameter("year");
				String filter_request_by = request.getParameter("filter_request_by");
				String filter_status = request.getParameter("filter_status");
				String filter_category = request.getParameter("filter_category");
				
				if(year.equals("all")){
					year = null;
				}
				
				String request_to_me = "";
				String request_from_me = "";
				if(filter_request_by.equals("request-to-me")){
					request_to_me = userId;
					request_from_me = null;
				}else if(filter_request_by.equals("request-from-me")){
					request_to_me = null;
					request_from_me = userId;;
				}
				String leaveStatus = filter_status;
				if(filter_status.equals("all")){
					leaveStatus = null;
				}
				String leaveType = filter_category;
				if(filter_category.equals("all")){
					leaveType = null;
				}
				
				serviceResult =  leaveFormService.searchLeaveReq( year , request_from_me , request_to_me , leaveStatus , leaveType ); 
				if(serviceResult.isSuccess()){
					result = new JsonResultBean("success", "" , serviceResult.getResult());
				}
				
					 
		 }catch(Exception e){
			 log.info("Error !!"+e);
			 e.printStackTrace();
		 }
	
		return result;
		
	 }
	 
	 //ajax calculate leave hour
	 @RequestMapping(value = "/calLeaveHour", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean calLeaveHour(HttpServletRequest request,Locale locale) throws Exception{
		 
		 Map<String, Object> m = new HashMap<String, Object>();
		 
		 try{
			 
		 String userId = request.getSession().getAttribute("UID").toString();
		 String data  = request.getParameter("data");
		
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
		 
		 log.info("start date: "+json.get("start_date").toString()+" "+json.get("start_time_hh").toString()+":"+json.get("start_time_mm").toString());
		 log.info("end date: "+json.get("end_date").toString()+" "+json.get("end_time_hh").toString()+":"+json.get("end_time_mm").toString());
		 
		 Date startdt = yyyyMMddHHmm.parse(json.get("start_date").toString()+" "+json.get("start_time_hh").toString()+":"+json.get("start_time_mm").toString());
		 Date enddt = yyyyMMddHHmm.parse(json.get("end_date").toString()+" "+json.get("end_time_hh").toString()+":"+json.get("end_time_mm").toString());
		 
		 
		 String leaveHour = findLeaveHour(startdt , enddt);
		 m.put("leaveHour",leaveHour);
		 
		 
		 SimpleDateFormat mysqlFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US); 
		 String ss = mysqlFormat.format(startdt);
		 String ee = mysqlFormat.format(enddt);
		 
		 log.info("start ss: "+ss);
		 log.info("end dt :"+ee);
		   
		// SimpleDateFormat mysqlDate = new SimpleDateFormat("dd/mm/yyyy",Locale.US);
			
		 //Date ss = mysqlDate.parse(json.get("start_date").toString());
		 //Date ee = mysqlDate.parse(json.get("end_date").toString());
		 
	//	 String s = xxx.format(ss).toString()+" "+json.get("start_time_hh").toString()+":"+json.get("start_time_mm").toString()+":00";
	//	 String e = xxx.format(ee)+" "+json.get("end_time_hh").toString()+":"+json.get("end_time_mm").toString()+":00";
		 
		 //cannot leave on the same day same time
		 ServiceResult<DataBean> checkLeaveSameDay = leaveFormService.findLeaveOnSameDay(userId ,ss,ee); 
		 if(checkLeaveSameDay.isSuccess()){
			  m.put("checkLeaveSameDay", checkLeaveSameDay.getResult());
		 }
		   
	 			
		// log.info("leave hour :"+leaveHour);
		
		 
	 }catch(Exception e){
		 log.info("Error !!"+e);
		 e.printStackTrace();
	 }
		JsonResultBean result = new JsonResultBean("success", "" , m );
		return result;
	 }
	 
	 
	 @RequestMapping(value = "/searchLeaveRequestDetail", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean searchLeaveRequestDetail(HttpServletRequest request,Locale locale) throws Exception{
		 
		 String id  = request.getParameter("id");
		 log.info("id: "+id);
		 ServiceResult<List<DataBean>> listResult =  leaveFormService.searchLeaveReqDetail(id); 
		 JsonResultBean result = null;
		 if(listResult.isSuccess()){
			result = new JsonResultBean("success", "" , listResult.getResult());
		 }
		 
		return result;
	 }
	 
	 @RequestMapping(value = "/saveLeaveRequest", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean saveLeaveRequestDetail(HttpServletRequest request,Locale locale) throws Exception{
		
		 
		 //send mail
		 //create task
		 //insert into notification
		 
		// UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
		 //String userId  = uinfo.getUid();
		 
		 String userId = request.getSession().getAttribute("UID").toString();
		 	
		 String data = request.getParameter("data");
		 String act  = request.getParameter("action");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		
		 String result_status = "";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 log.info("Leave form control");
		 log.info("data: "+data);
		 log.info("action : "+act);
		 
		 JSONParser jParser = new JSONParser();
		 JSONObject json = (JSONObject)jParser.parse(data);
		 
		 log.info( ""+json );
		 log.info(""+json.get("leave_type_id"));
		 
		 //convert between form and bean
		 LeaveFormDetailBean leaveForm = new LeaveFormDetailBean();
		 leaveForm.setLeave_id(json.get("leave_id").toString());
		 leaveForm.setUser_id(userId);
		 leaveForm.setLeave_type_id(json.get("leave_type_id").toString());
		 leaveForm.setJustification(json.get("justification").toString());
		 leaveForm.setProject_support(json.get("project_support").toString());
		 log.info("start date: "+json.get("start_date").toString()+" "+json.get("start_time_hh").toString()+":"+json.get("start_time_mm").toString());
		 log.info("end date: "+json.get("end_date").toString()+" "+json.get("end_time_hh").toString()+":"+json.get("end_time_mm").toString());
		 
		 Date startdt = yyyyMMddHHmm.parse(json.get("start_date").toString()+" "+json.get("start_time_hh").toString()+":"+json.get("start_time_mm").toString());
		 Date enddt = yyyyMMddHHmm.parse(json.get("end_date").toString()+" "+json.get("end_time_hh").toString()+":"+json.get("end_time_mm").toString());
		 Date cur_date = yyyyMMddHHmmss.parse(yyyyMMddHHmmss.format(new Date()));
		 
		 leaveForm.setLeave_hour(findLeaveHour(startdt , enddt));
		 leaveForm.setStart_dt(startdt);
		 leaveForm.setEnd_dt(enddt);
		 leaveForm.setUpdate_user_id(userId);
		 leaveForm.setCreate_user_id(userId);
		 
		 String approval_id = json.get("approval_id").toString();
		 
		  	
		 //get status
		 switch(json.get("leave_status").toString()){
		 	 case "draft" : leaveForm.setLeave_status("1");
		 		 			break;
		 	 case "request" : leaveForm.setLeave_status("2");
		 	 				leaveForm.setRequest_dt(cur_date);
		 	 				leaveForm.setRequest_user_id(userId);
		 	 				break;
		 	 /*			
		 	 case "cancel": leaveForm.setLeave_status("0"); 
							leaveForm.setCancel_dt(cur_date);
							leaveForm.setCancel_user_id(userId);
							break;
		 	 				
			 case "approve" : leaveForm.setLeave_status("3"); 
			 				leaveForm.setApprove_dt(cur_date);
			 				leaveForm.setApprove_user_id(userId);
			 				break;
			 case "reject" : leaveForm.setLeave_status("4"); 
			 				leaveForm.setReject_dt(cur_date);
			 				leaveForm.setReject_user_id(userId);
			 				leaveForm.setReject_reason("");
			 				break;
			*/
		 }
		 
		 try{
			 
				switch (act){
			 	    case "I" : log.info("insert data");
			 	    			result =  leaveFormService.insertLeaveForm( leaveForm );
			 	    			
			 	    			if( result.isSuccess()){
			 	    			   log.info( "get long id : "+result.getResult());
			 	    			   result_data   = Long.toString(result.getResult());
			 	    			   result_status = "success";
								   result_msg    = "save successful"; 
								   
								    log.info("get last insert id "+result_data);
									//don't send notify mail if status = draft = 1 
								    log.info("leave status : "+leaveForm.getLeave_status());
									if(!leaveForm.getLeave_status().equals("1")){
										 //send email notify approval_id act as a owner
										log.info("do send mail");
										 sendMailNotify(request,leaveForm.getLeave_status(),result_data, approval_id);
									}
									
			 	    				 
			 	    			}else{
			 	    				result_status = "fail";
									result_msg    = "save fail";
			 	    			}
			 	    		
							break;
						
			 	    case "U" : log.info("update data");
			 	    
		 						result =  leaveFormService.updateLeaveForm( leaveForm );
								if( result.isSuccess()){
								log.info( "get total update record(s) : "+result.getResult() );
									result_data   = Long.toString(result.getResult());
									result_status = "success";
									result_msg    = "save successful";
									 
									//don't send notify mail if status = draft = 1 
									 log.info("leave status: "+leaveForm.getLeave_status());
									 log.info("get update id: "+leaveForm.getLeave_id());
									if(!leaveForm.getLeave_status().equals("1")){
										 //send email notify approval_id act as a owner
										 log.info("do send mail");
										 sendMailNotify(request,leaveForm.getLeave_status(), leaveForm.getLeave_id() , approval_id );
									}
									
								}else{
									result_status = "fail";
									result_msg    = "save fail";
								}

			 	   			break;
	 	   			case "R" : log.info("remove data"); 
	 	   							result =  leaveFormService.removeLeaveForm( json.get("leave_id").toString() );
	 	   									
   								if( result.isSuccess()){
   								log.info( "get total delete rcord(s) : "+result.getResult().longValue() );
	   								result_data   = Long.toString(result.getResult().longValue());
	   								result_status = "success";
	   								result_msg    = "save successful";
   								
   								}else{
	   								result_status = "fail";
	   								result_msg    = "save fail";
   								}
			 	   		    break;
			 	   		 
			 	   default : log.error("something wrong");
					
				}
					
			}catch(Exception e){
				log.info("Error !!"+e);
			}
		
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;

	 }
	 	 
	 
	 @RequestMapping(value = "/updateLeaveApproval", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	 public @ResponseBody JsonResultBean removeLeaveRequest(HttpServletRequest request,Locale locale) throws Exception{
		
		 String userId = request.getSession().getAttribute("UID").toString();
		 	
		 String data = request.getParameter("data");
		 String status = request.getParameter("sys_status");
		 
		 ServiceResult<Long> result = new ServiceResult<>();
		
		 String result_status = "success";
		 String result_msg    = "";
		 String result_data   = "";
		 
		 try{
			 
			 JSONParser jParser = new JSONParser();
			 JSONObject json = (JSONObject)jParser.parse(data);
			 Date cur_date = yyyyMMddHHmmss.parse(yyyyMMddHHmmss.format(new Date()));
			 
			 LeaveFormDetailBean leaveForm = new LeaveFormDetailBean();
			 leaveForm.setLeave_id(json.get("leave_id").toString());
			 
			
			 switch(status){
			 
				 case "approve" : leaveForm.setLeave_status("3"); 
				 				  leaveForm.setUpdate_user_id(userId);
					 			  leaveForm.setApprove_dt(cur_date);
					 			  leaveForm.setApprove_user_id(userId);
					 			  result =  leaveFormService.updateLeaveApprove( leaveForm );
				 				break;
				 case "reject" : leaveForm.setLeave_status("4"); 
				 				 leaveForm.setUpdate_user_id(userId);
				 				 leaveForm.setReject_dt(cur_date);
				 				 leaveForm.setReject_user_id(userId);
				 				 leaveForm.setReject_reason("");
				 				 result =  leaveFormService.updateLeaveReject( leaveForm );
				 				break;
				 				
				 case "cancel": leaveForm.setLeave_status("0");
				 				leaveForm.setUpdate_user_id(userId);
								leaveForm.setCancel_dt(cur_date);
								leaveForm.setCancel_user_id(userId);
								 result =  leaveFormService.updateLeaveCancel( leaveForm );
								break;
				 				
			 }
			 
			 if( result.isSuccess()){
				 	
				 //remove token if already approved or rejected
				 tokenService.removeTokenByNofifyId( leaveForm.getLeave_id());
				 log.info("remove token success");
				 
				 //add requirement 
				 //uncheck flag allow leave on probation
				 leaveFormService.recheckAllowLeaveOnProbation(leaveForm);
				 log.info("set staff leave on probation to null");
				 
			 	 log.info( "get total update record(s) : "+result.getResult() );
				 result_data   = leaveForm.getLeave_id();
				 result_status = "success";
				 result_msg    = "save successful";
			
				 //send email notify no need to send approval id
				 log.info("do send mail");
				 sendMailNotify(request,leaveForm.getLeave_status(), result_data , "" );
					
				}else{
					result_status = "fail";
					result_msg    = "save fail";
				}
			 
			 
		 }catch(Exception e){
				log.info("Error !!"+e);
		 }
		 
		 log.info("UPdate status");
		 
		JsonResultBean res = new JsonResultBean(result_status, result_msg , result_data );
		return res;
	 }
	 
    
	 private void sendMailNotify(HttpServletRequest request, String action,String leaveid,String approval_id){
		//action for select mail template layout
		   //if leave status request will use /view/emailTemplate/leaveRequest.html
		   //else leave status will use /view/emailTemplate/leaveNotifiy.html
		//leaveid for query leave detail to email
		 try{
			 
			   //prepare link reply email
			   //when deploy link may be change by context name it mean we need to dynamic link by get host name + servlet context path ( configure from application.property )
			   URL url = new URL(request.getRequestURL().toString());
			   String host  = url.getHost()+servletContextPath;
			  
			    String contextPath = request.getContextPath();
		        String servletPath = request.getServletPath();
		        String pathInfo = request.getPathInfo();
		        String sendMailTo = "";
		        String sendMailSubject = "";
		        
		       // String userId = request.getSession().getAttribute("UID").toString();
		        
		     
		        
		        log.info("contextPath: "+contextPath);
		        log.info("servletPath: "+servletPath);
		        log.info("pathInfo: "+pathInfo);
		        
			   // String path = request.getAttribute("javax.servlet.forward.request_uri");
			  //  String query = request.getAttribute("javax.servlet.forward.query_string");
			    
				log.info("mail notify Link : "+host+servletContextPath);
				log.info("get leaveid : "+leaveid);
				log.info("get action :"+action);
				 
			 	//get leave detail
				 ServiceResult<List<DataBean>> listResult =  leaveFormService.searchLeaveReqDetail(leaveid); 
				 String template = "";
				 if(listResult.isSuccess()){
					 log.info("query result return success");
					 
					 String template_type = "";
					 String approve_link = "";
					 String reject_link = "";
					  
					//action == 2 is status request
					//set template type to request template
					DataBean d = listResult.getResult().get(0);
					
					//cannot get session
					UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
					
					if(action.equals("2")){
						
						String userId  = uinfo.getUid();
						sendMailTo = d.getQ(); //send mail to approval
						sendMailSubject = uinfo.getFirstName()+" "+uinfo.getLastName()+" send you a leave request";
						template_type = "request";
						//token will contain 2 hash code[token,verify_token]
						String token = "";
						String verify_token = "";
						
						//create template
						log.info("-----get template");
						template = mailTemplate(template_type); 
						log.info("tempte size"+template.length());
						log.info("-----end template");
						//get approved token
						log.info("-----start gen token");
						token =  generateToken();
						verify_token = generateVerifyToken();
						approve_link = "https://"+host+"/emailLeaveReply?id="+leaveid+"&token="+token+"&verify="+verify_token;
						log.info("gen approve link: "+approve_link);
						log.info("-----end gen token");
						TokenBean apt = new TokenBean();
						apt.setAction("approved");
						apt.setNotify_id(leaveid);
						apt.setVerify_token(verify_token);
						apt.setToken(token);
						apt.setToken_valid_YN("Y");
						apt.setOwner_uid(approval_id);
						apt.setNotify_email(d.getQ()); //get approved email
						apt.setCreate_uid(userId);
						log.info("-----insert token db");
						tokenService.insertToken(apt);
						
						//get reject token
						log.info("-----start gen token");
						token =  generateToken();
						verify_token = generateVerifyToken();
						log.info("-----end gen token");
						reject_link = "https://"+host+"/emailLeaveReply?id="+leaveid+"&token="+token+"&verify="+verify_token;
						log.info("gen reject link: "+reject_link);
						TokenBean rjt = new TokenBean();
						rjt.setAction("rejected");
						rjt.setNotify_id(leaveid);
						rjt.setVerify_token(verify_token);
						rjt.setToken(token);
						rjt.setToken_valid_YN("Y");
						rjt.setOwner_uid(approval_id);
						rjt.setNotify_email(d.getQ());
						rjt.setCreate_uid(userId);
						log.info("-----insert token db");
						tokenService.insertToken(rjt);
						
					}else{
						
						//0 is cancel
						if(action.equals("0")){
							
							//check who take cancel action
							String userId  = uinfo.getUid();
							
							//check action by user or approval
							//d.getP() is createUser | userId is login user
							log.info("into action : cancel");
							log.info("get userId "+userId);
							log.info("get create user : "+d.getP());
							if(userId.equalsIgnoreCase(d.getP())){
								
								log.info("into action :staff cancel");
								//staff cancel
								if(d.getC().equalsIgnoreCase(d.getF())){
									sendMailSubject = "Khun "+uinfo.getFirstName()+" "+uinfo.getLastName()+" cancelled "+d.getT()+" on "+d.getC()+".";
								}else{
									sendMailSubject = "Khun "+uinfo.getFirstName()+" "+uinfo.getLastName()+" cancelled "+d.getT()+" between "+d.getC()+" - "+d.getF()+".";
								}
								
								//staff cancel send mail to approval
								//d.getQ() is  approver email
								sendMailTo = d.getQ();
							}else{
								
								log.info("into action :approval cancel");
								//approval cancel
								sendMailSubject = "Khun "+uinfo.getFirstName()+" "+uinfo.getLastName()+" cancelled this leave request. ";
								
								//approval cancel send mail to staff
								//d.getR() is staff email
								sendMailTo = d.getR();
							}
						   
						}else{
							 
							log.info("get action:"+d.getB());
							
							if(d.getB().equalsIgnoreCase("3")){
								sendMailSubject = d.getO()+" is approved your leave request.";
							}else if(d.getB().equalsIgnoreCase("4")){
								sendMailSubject = d.getO()+" is rejected your leave request.";
							} 
							log.info("sendMailSubject: "+sendMailSubject);
							
							sendMailTo = d.getR(); //send mail to create_user_id
							
							
						}
						
					
						template_type = "notify";
						//create template
						template = mailTemplate(template_type);
						log.info("tempte size: "+template.length());
					
					}
					
				
					//leaveStatus will shown as image ( mapped to image name );
					String leaveStatus = d.getB();
					switch(leaveStatus){
						case "2" : leaveStatus = "requested"; break; 
						case "3" : leaveStatus = "approved"; break;
						case "0" : leaveStatus = "cancelled"; break;
						case "4" : leaveStatus = "rejected"; break;
						case "5" : leaveStatus = "approved"; break;
					}
				 
					log.info("-----start replace text in email body");
					log.info("leaveStatus: " +leaveStatus);
					log.info("send mail to: "+sendMailTo);
					log.info("mail subject: "+sendMailSubject);
					template = template.replaceAll("#leaveStatus",leaveStatus); //shown as image
					template = template.replaceAll("#createdon",d.getN());
					template = template.replaceAll("#staffName",d.getL());
					template = template.replaceAll("#staffDept",d.getM());
					template = template.replaceAll("#leaveType",d.getT());
					template = template.replaceAll("#leaveStartDate", d.getC() );
					template = template.replaceAll("#leaveStartTime", d.getD()+":"+d.getE());
					template = template.replaceAll("#leaveEndDate",d.getF());
					template = template.replaceAll("#leaveEndTime", d.getG()+":"+d.getH());
					template = template.replaceAll("#leaveTotal", txt_dayhour(d.getI()));
					template = template.replaceAll("#leaveJustification",d.getK());
					template = template.replaceAll("#leaveProjectSupport",d.getS());
					template = template.replaceAll("#rejectLink",reject_link);
					template = template.replaceAll("#approveLink",approve_link);
					log.info("-----end replace text in email body");
				 }//end if listResult.isSuccess();
				 else{
					 log.info("************ Error result from query ");
				 }
				//get email address notify user
				//log.info(template);
				//send mail
				 log.info("-----start send email");
			  	Properties props = new Properties();
		        props.put("mail.smtp.host", "smtp.office365.com");
		        props.put("mail.smtp.socketFactory.port", "587");
		        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		        props.put("mail.smtp.auth", "true");
		        props.put("mail.smtp.port", "587");
		        props.put("mail.smtp.starttls.enable", "true");
		        
		        Session session = Session.getDefaultInstance(props,
		        	new javax.mail.Authenticator() {
                 protected PasswordAuthentication getPasswordAuthentication() {
                     return new PasswordAuthentication("locus_smtp@locus.co.th","locus@123+");
                 }
             });
		     
		     //wording for testing REMOVE when on production date;
		     sendMailSubject = ""+sendMailSubject;  
		        
		   //     InternetAddress[] myCcList = InternetAddress.parse("arnon@locus.co.th");
		     
             Message message = new MimeMessage(session);
             message.setFrom(new InternetAddress("no-reply@locus.co.th","no-reply@locus.co.th"));
            // message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("arnon@locus.co.th"));
             message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(sendMailTo));
             
         //   message.setRecipients(Message.RecipientType.CC,myCcList);
             
             message.setSubject(sendMailSubject);
            // message.setText("Hi this is testing email....not spam");
            // message.setContent("<h1><img src='http://www.locus.co.th/assets/main/img/logo@2x.png'> Hello</h1>", "text/html");
             message.setContent(template, "text/html; charset=utf-8");
             //message.setContent(someHtmlMessage, "text/html; charset=utf-8");
             Transport.send(message);
				
             log.info("-----email successfully sent..");
             
		}catch(Exception e){
			e.printStackTrace();
			throw new RuntimeException(e);
			
		}
		
		 
		 
	 }
	 
	 //util
	 //get template path
	 //template type request will have approve and reject link
	 //tempate notify will have only information
	 private String mailTemplate( String template_type ){
		 
		 String relativeWebPath = "/WEB-INF";
		 String filePath = context.getRealPath(relativeWebPath);
		 
		 log.info("relativeWebPath: "+relativeWebPath);

		 if( template_type.equals("request")){
			 //request template
			 //dev
			 //filePath +=  "D:\\JLO_WORKSPACE\\BOS2\\BOS\\src\\main\\webapp\\WEB-INF\\view\\emailTemplate\\leaveRequest.html";
			 //prod
			 filePath +=  "/view/emailTemplate/leaveRequest.html";
		 }else{
			 //notify template
			 //dev
			 //filePath += "D:\\JLO_WORKSPACE\\BOS2\\BOS\\src\\main\\webapp\\WEB-INF\\view\\emailTemplate\\leaveNotify.html";
			 //prod
			 filePath += "/view/emailTemplate/leaveNotify.html";
		 }
		
		 File file = new File(filePath);
		 String msg = "";
		 if (file.exists() && !file.isDirectory()) {
			log.info("filePath: file exist");
			 msg = readContentFromFile(filePath);
		 } else {
			log.info("[filePath] file doesn't exist");
		 }
		 
		 file = new File(file.getAbsolutePath());
		 
		 log.info("getAbsolutePath: "+file);
		 msg = "";
		 if (file.exists() && !file.isDirectory()) {
			log.info("file absolute path: file exist");
			 msg = readContentFromFile(filePath);
		 } else {
			log.info("[file absolute path] file doesn't exist");
		 }
		 
		 return msg;
	 }
	 
	 private String txt_dayhour(String hour_used){
		 
		  double hour = Double.parseDouble(hour_used);
		  String txt = "";
		  String tmp = "";
		  int hour_per_day = 8;
		  double used_day =  (hour / hour_per_day);
		  double used_hour = (hour % hour_per_day);
		  
		  /*
		  if(used_hour % 1 != 0){
			  DecimalFormat value = new DecimalFormat("#.#");
			  tmp = value.format(used_hour);
		  }
         */
          log.info("get use day :"+(int)used_day);
           if((int)used_day > 0 ){
              txt += (int)used_day+" day ";
           }else{
        	  txt += (int)used_day+" day ";
           }
           if( used_hour != 0){
         	  tmp = used_hour +""; //+ tmp;
              txt += tmp+" hr.";
           }
          
		 return txt;
	 }
	 
	 //util
	 //read file template 
	 private String readContentFromFile(String fileName){
	     StringBuffer contents = new StringBuffer();
	     
	     try {
	       //use buffering, reading one line at a time
	       BufferedReader reader =  new BufferedReader(new FileReader(fileName));
	       try {
	         String line = null; 
	         while (( line = reader.readLine()) != null){
	           contents.append(line);
	           contents.append(System.getProperty("line.separator"));
	         }
	       }
	       finally {
	           reader.close();
	       }
	     }
	     catch(IOException ex){
	       ex.printStackTrace();
	     }
	     return contents.toString();
	 }

	 
	 private String findLeaveHour(Date startdt, Date enddt) throws Exception{
		 
		 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
		 
		 double leave_hour = 0;
		 
		 Calendar st = Calendar.getInstance();
		 Calendar et   = Calendar.getInstance();
		 
		 //use tmp_start , tmp_end to calculate each leave hour
		 Calendar tmp_start = Calendar.getInstance();
		 Calendar tmp_end = Calendar.getInstance();
		 
		 st.setTime(startdt);
		 et.setTime(enddt);
		 
		 
		 //find holiday
		 String[] dayOfWeek = {"wk","wd","wd","wd","wd","wd","wk"};
		 ServiceResult<List<DataBean>> hConf = reportService.getHolidayConfigBetweenDate(df.format(startdt),df.format(enddt)); 
		 List<DataBean> holidays = new ArrayList<DataBean>();
		 //from query we will know holiday on leave date
		  
		 //keep dd-mm-yyyy to arraylist for check holiday again
		 ArrayList holiday = new ArrayList<String>();
		 if(hConf.isSuccess()){
			 holidays = hConf.getResult();
			 log.info("holiday : "+holidays.size()); //total leave day
			 for(DataBean h : holidays ){
				 log.info(h.getA());
				 holiday.add(h.getB()+"-"+h.getC()+"-"+h.getD());
			 } 
		 }
		 
		 //find each day from start to end
		 //eg. if leave on 31-03-2018 13:00 -> 01-04-2018 12:00
		 //this will find 
		 // 31-03-2018 as 1 day
		 // 01-04-2018 as 1 day
		
		 Calendar start_date = Calendar.getInstance();
		 start_date.set(Calendar.DATE, st.get(Calendar.DATE));
		 start_date.set(Calendar.MONTH, st.get(Calendar.MONTH));
		 start_date.set(Calendar.YEAR, st.get(Calendar.YEAR));
		 
		 Calendar end_date = Calendar.getInstance();
		 end_date.set(Calendar.DATE, et.get(Calendar.DATE));
		 end_date.set(Calendar.MONTH, et.get(Calendar.MONTH));
		 end_date.set(Calendar.YEAR, et.get(Calendar.YEAR));
		 
		 int total_loop_day = 0;
		 while( !start_date.after(end_date)){
			
			    log.info("today is "+start_date.get(Calendar.DATE)+start_date.get(Calendar.MONTH)+start_date.get(Calendar.YEAR));
			    total_loop_day++;
			    
			    start_date.add(Calendar.DATE, 1);
		 }
		
		 
		 /* Main algorithm
		  
		 8.30           12.00                13.00          17.30
		 |  Morning (A)   |                   | After noon (B) |
		                  12.30 ->(ceil)-> 13.00
		           
		    | Start |  End  |
		       A    |   B     -> -1  #this is pass noon total leave -1 hour
		       A    |   A     ->  0
		       B    |   B     ->  0
		       B    |   A     ->  0
		 */
		 
		 //find date diff
		 // Get the represented date in milliseconds
		 double millis1 = st.getTimeInMillis();
		 double millis2 = et.getTimeInMillis();
	     // Calculate difference in milliseconds
		 double diff = millis2 - millis1;
	     // Calculate difference in days
		 double diffDays = Math.ceil(diff / (24 * 60 * 60 * 1000));
		// log.info("from " +st.get(Calendar.DATE)+" to "+et.get(Calendar.DATE)+"  is : "+ Math.ceil(diffDays) + " days.");
		 log.info("from " +st.get(Calendar.DATE)+" to "+et.get(Calendar.DATE)+"  is : "+ total_loop_day + " days.");
		
		 //loop date
		 //for(int i=1;i<=(int)diffDays;i++){
		  for(int i=1;i<=total_loop_day;i++){
			 
			 //log.info("start time : "+ st.getTime());
			// log.info("end   time : "+ et.getTime());
			
			// if(i == diffDays){
			if(i == total_loop_day){
				 //last day 
				 log.info("last day");
				
				 //if loop day is only 1 day it mean this start date will set by custom
				 //not start from 8.30 
				 if( total_loop_day == 1){
					 
					 tmp_start.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_start.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_start.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_start.set(Calendar.HOUR_OF_DAY, st.get(Calendar.HOUR_OF_DAY));
					 tmp_start.set(Calendar.MINUTE,st.get(Calendar.MINUTE));
					 
				 }else{
					 
					 st.set(Calendar.HOUR_OF_DAY, 8);  st.set(Calendar.MINUTE,30);
					 tmp_start.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_start.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_start.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_start.set(Calendar.HOUR_OF_DAY, 8 );
					 tmp_start.set(Calendar.MINUTE,30);
				 }
				
				 if( et.get(Calendar.HOUR_OF_DAY) == 8 &&  et.get(Calendar.MINUTE) == 0 ){
					 et.set(Calendar.MINUTE, 30 );
				 }
				 
				 tmp_end.set(Calendar.DATE,et.get(Calendar.DATE));
				 tmp_end.set(Calendar.MONTH,et.get(Calendar.MONTH));
				 tmp_end.set(Calendar.YEAR,et.get(Calendar.YEAR));
				 tmp_end.set(Calendar.HOUR_OF_DAY, et.get(Calendar.HOUR_OF_DAY));
				 tmp_end.set(Calendar.MINUTE,et.get(Calendar.MINUTE));
				
				 
			 }else{
				 
				 if(i==1){
					 log.info("start i=1");
					 tmp_start.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_start.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_start.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_start.set(Calendar.HOUR_OF_DAY, st.get(Calendar.HOUR_OF_DAY));
					 tmp_start.set(Calendar.MINUTE,st.get(Calendar.MINUTE));
					 
					 tmp_end.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_end.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_end.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_end.set(Calendar.HOUR_OF_DAY, 17 );
					 tmp_end.set(Calendar.MINUTE,30);
					   
				 }else{
					 log.info("start i!=1");
					 tmp_start.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_start.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_start.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_start.set(Calendar.HOUR_OF_DAY, 8 );
					 tmp_start.set(Calendar.MINUTE,30);
					 
					 tmp_end.set(Calendar.DATE,st.get(Calendar.DATE));
					 tmp_end.set(Calendar.MONTH,st.get(Calendar.MONTH));
					 tmp_end.set(Calendar.YEAR,st.get(Calendar.YEAR));
					 tmp_end.set(Calendar.HOUR_OF_DAY, 17 );
					 tmp_end.set(Calendar.MINUTE,30);
					 
				 }
				 
				// log.info(i+"> day start "+st.get(Calendar.DATE)+"-"+st.get(Calendar.MONTH)+"-"+st.get(Calendar.YEAR)+" | "+st.get(Calendar.HOUR_OF_DAY)+":"+st.get(Calendar.MINUTE));
				 
				// st.set(Calendar.HOUR_OF_DAY, 17);  st.set(Calendar.MINUTE,30);
				// log.info(i+"> day end "+st.get(Calendar.DATE)+"-"+st.get(Calendar.MONTH)+"-"+st.get(Calendar.YEAR)+" | "+st.get(Calendar.HOUR_OF_DAY)+":"+st.get(Calendar.MINUTE));
				 
				//add one day
				st.add(Calendar.DATE, 1);
				 
			 }//end if diffDay
			 
			 //prepare calculation
			 
			
			 
		 
			 int mm = tmp_start.get(Calendar.MONTH) + 1; // java Calendar.MONTH  start JANUARY from 0
			 String check_holiday = tmp_start.get(Calendar.DATE)+"-"+mm+"-"+tmp_start.get(Calendar.YEAR);
			 boolean is_holiday = false;
			  
			 //log.info("holiday : "+holiday.size());
			 //log.info("check holiday "+check_holiday);
			 if( holiday.contains(check_holiday)){
				 log.info(i+"> today is (holiday ) : result is -> ["+tmp_start.get(Calendar.DATE)+"-"+tmp_start.get(Calendar.MONTH)+"-"+st.get(Calendar.YEAR)+"]");
				 is_holiday = true;
			 }else{
				 //check is today is weekend
				 if( dayOfWeek[tmp_start.get(Calendar.DAY_OF_WEEK)-1].equals("wk")){
					 is_holiday = true; // today is weekend
					 log.info(i+"> today is (weekend) : result is -> "+dayOfWeek[tmp_start.get(Calendar.DAY_OF_WEEK)-1]);
				 }else{
					 log.info(i+"> today is (weekday) : result is -> "+dayOfWeek[tmp_start.get(Calendar.DAY_OF_WEEK)-1]);
				 }
			 }
			 
			 double h = (double)tmp_start.get(Calendar.HOUR_OF_DAY); //0 - 24
			 double m = (double)(tmp_start.get(Calendar.MINUTE)) * 0.01; // convert minute to hour 
			 double starth = h+m;
			 
			 String start_flag = "";
			 String end_flag   = ""; 
			 boolean isLaunchTime = false;
			 if( starth <= 12.01 ){
				// log.info("start is A");
				 start_flag = "A";
			 }else if(starth >= 12.01 && starth <= 13 ){
				 //ceil starth to 13.00
				// starth = 13;
				 tmp_start.set(Calendar.HOUR_OF_DAY,13);
				 tmp_start.set(Calendar.MINUTE,0);
				 start_flag = "B";
				// log.info("start is B");
			 }else if(starth >= 13 ){
				// log.info("start is B");
				 start_flag = "B";
			 }
			
			 h = tmp_end.get(Calendar.HOUR_OF_DAY); //0 - 24
			 m = tmp_end.get(Calendar.MINUTE) * 0.01; // convert minute to hour  
			 double endh = h+m;
			 
			 if( endh <= 12.01 ){
				// log.info("end is A");
				 end_flag = "A";
			 }else if(endh >= 12.01 && endh <= 13 ){
				 //ceil starth to 13.00
				// endh = 13;
				 tmp_end.set(Calendar.HOUR_OF_DAY,13);
				 tmp_end.set(Calendar.MINUTE,0);
				//log.info("end is B");
				 end_flag = "B";
			 }else if(endh >= 13 ){
				// log.info("end is B");
				 end_flag = "B";
			 }
			  
			 log.info(i+"> day start "+tmp_start.get(Calendar.DATE)+"-"+tmp_start.get(Calendar.MONTH)+"-"+tmp_start.get(Calendar.YEAR)+" | "+tmp_start.get(Calendar.HOUR_OF_DAY)+":"+tmp_start.get(Calendar.MINUTE));
			 log.info(i+"> day end "+tmp_end.get(Calendar.DATE)+"-"+tmp_end.get(Calendar.MONTH)+"-"+tmp_end.get(Calendar.YEAR)+" | "+tmp_end.get(Calendar.HOUR_OF_DAY)+":"+tmp_end.get(Calendar.MINUTE));
			
			 
			 //cal leave hour
			 double leave_start = tmp_start.getTimeInMillis();
			 double leave_end   = tmp_end.getTimeInMillis();
		     // Calculate difference in milliseconds
		     double tmp_hour = leave_end - leave_start;
		    // log.info("diff :"+tmp_hour);
		     // Calculate difference in days
		     Double diffHours = tmp_hour / 3600000; //(60 * 60 * 1000);
		     log.info(diffHours.toString());
			 log.info("total leave hours: " + diffHours + " hours.");
			 //----------------------------------
			 
			 if(!is_holiday ){
			    // log.info("START is ["+start_flag+"] | END is ["+end_flag+"]");
				 if( start_flag.equals("A") && end_flag.equals("B")){
					 isLaunchTime = Boolean.TRUE; 
					 log.info(i+"> pass launch time -1 ");
					 leave_hour =  leave_hour + ( diffHours - 1);
				 }else{
					 log.info(i+"> not pass launch time do nothing ");
					 leave_hour =  leave_hour + diffHours;
				 }
			 }
			 
		 }
		 
		 
		 
		 /*
		 if( df.format(startdt).equals(df.format(enddt)) ){
			 log.info("same day");
			 log.info("start date "+st.get(Calendar.HOUR_OF_DAY));
			 
			 double h = (double)st.get(Calendar.HOUR_OF_DAY); //0 - 24
			 double m = (double)(st.get(Calendar.MINUTE)) * 0.01; // convert minute to hour 
			 double starth = h+m;
			 
			 String start_flag = "";
			 String end_flag   = ""; 
			 boolean isLaunchTime = false;
			 if( starth <= 12.01 ){
				 log.info("start is A");
				 start_flag = "A";
			 }else if(starth >= 12.01 && starth <= 13 ){
				 //ceil starth to 13.00
				 starth = 13;
				 start_flag = "B";
				 log.info("start is B");
			 }else if(starth >= 13 ){
				 log.info("start is B");
				 start_flag = "B";
			 }
			
			 h = et.get(Calendar.HOUR_OF_DAY); //0 - 24
			 m = et.get(Calendar.MINUTE) * 0.01; // convert minute to hour  
			 double endh = h+m;
			 
			 if( endh <= 12.01 ){
				 log.info("end is A");
				 end_flag = "A";
			 }else if(endh >= 12.01 && starth <= 13 ){
				 //ceil starth to 13.00
				 endh = 13;
				 log.info("start is B");
				 end_flag = "B";
			 }else if(endh >= 13 ){
				 log.info("start is B");
				 end_flag = "B";
			 }
			 
		     log.info("START is ["+start_flag+"] | END is ["+end_flag+"]");
			 if( start_flag.equals("A") && end_flag.equals("B")){
				 isLaunchTime = Boolean.TRUE;
				 log.info("pass launch time -1 ");
			 }else{
				 log.info("not pass launch time do nothing");
			 }
			 
	
			 
			 
		 }else{
			 log.info("more than one day");
			 
			
			 
		 }
		 */
		// Calendar startDate =  Calendar.getInstance();
		// startDate.setTime(df.parse(df.format(startdt)));
		 
		 log.info("total leave hour : "+leave_hour);
		 
		 log.info("human readable "+txt_dayhour(leave_hour+""));
		 
		 return String.valueOf(leave_hour);
	 }
	 
	 
	 //Find total leave in hour
	 //input startdt , enddt ( dd/mm/yyyy hh:mm:ss  )
	 //output hours
	 private String findLeaveHourV1(Date startdt, Date enddt) throws Exception{
		
		 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd",Locale.US);
		 
		 Calendar startDate 	= Calendar.getInstance();
		 Calendar startDateTime = Calendar.getInstance();
		 Calendar endDate 		= Calendar.getInstance();
		 Calendar endDateTime   = Calendar.getInstance();
		 
		 //set only date
		 startDate.setTime( dateFormat.parse(dateFormat.format(startdt)));
		 endDate.setTime( dateFormat.parse(dateFormat.format(enddt)));
		 
		 //set date and time
		 startDateTime.setTime(startdt);
		 endDateTime.setTime(enddt);
		 
		 log.info("findLeaveHour startDate : "+startDate);
		 log.info("findleaveHour endDate : "+endDate);
		 
		 log.info("findLeaveHour startDateTime : "+startDateTime);
		 log.info("findleaveHour endDateTime : "+endDateTime);
		
		 
		 //find date diff
		 // Get the represented date in milliseconds
		 double millis1 = startDate.getTimeInMillis();
		 double millis2 = endDate.getTimeInMillis();
	     // Calculate difference in milliseconds
		 double diff = millis2 - millis1;
	     // Calculate difference in days
		 double diffDays = diff / 3600000;
		 log.info("In days: " + diffDays + " days.");
		 
		 String[] dayOfWeek = {"wk","wd","wd","wd","wd","wd","wk"};
		 
		 //holiday
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
		 ServiceResult<List<DataBean>> hConf = reportService.getHolidayConfigBetweenDate(sdf.format(startdt),sdf.format(enddt)); 
		 List<DataBean> holidays = new ArrayList<DataBean>();
		 if(hConf.isSuccess()){
			 holidays = hConf.getResult();
			 log.info("holiday : "+holidays.size());
			 
			 for(DataBean holiday : holidays ){
				 log.info(holiday.getA());
				
			 } 
			
		 }
		 
		 int leave_day = 0;
		 double leave_hour = 0;
		 /*
		 Calendar startDate = Calendar.getInstance();
		 Calendar endDate   = Calendar.getInstance();
		 startDate.set
		 */
		 for(int i=0;i<=(int)diffDays;i++){
			 /*
			 calendar.set(Calendar.MONTH, start_cal_month);
			 calendar.set(Calendar.YEAR, start_cal_month);
			 start_cal_date += 1;
			 */
			 log.info("today date : "+startDate.getTime()+" ");
			 log.info("today is   : "+dayOfWeek[startDate.get(Calendar.DAY_OF_WEEK)-1]);
			 
			 
			 //find holiday
			 
			 if( dayOfWeek[startDate.get(Calendar.DAY_OF_WEEK)-1].equals("wd")){
				 //check this day is holiday
				 if(holidays.size() > 0){
					 //
				 }
				 leave_day += 1;
				 //leave day +1
			 }
			 
			 
			 log.info(startDate.getTime()+"|"+endDate.getTime());
			 if(startDate.equals(endDate)){
				 log.info("ENDDDDD");
				 int hour = 0;
			
				 //set hour,minute to startDate , endDate
				 startDate.set(Calendar.HOUR_OF_DAY, startDateTime.get(Calendar.HOUR_OF_DAY));
				 startDate.set(Calendar.MINUTE, startDateTime.get(Calendar.MINUTE));
				 
				 endDate.set(Calendar.HOUR_OF_DAY, endDateTime.get(Calendar.HOUR_OF_DAY));
				 endDate.set(Calendar.MINUTE, endDateTime.get(Calendar.MINUTE));
				 
				 
				 int startTime = startDateTime.get(Calendar.HOUR_OF_DAY);
				 int endTime   = endDateTime.get(Calendar.HOUR_OF_DAY);
				 
				 log.info("startTime: "+startTime);
				 log.info("endTime "+endTime);
				 int endMinute = endDateTime.get(Calendar.MINUTE);
				 log.info("endMinute "+endMinute);
				 //initial start , end time (hour only ) if set on 12.00 or 13.00
				 if(startTime >=  12 && startTime <= 13 ){
					 startTime = 13;
					 startDate.set(Calendar.HOUR_OF_DAY, startTime);
					 startDate.set(Calendar.MINUTE, 0);
				 }
				 double isLaunchTime = endTime + ( endMinute * 0.01 );
				 log.info("isLanuchTime "+isLaunchTime);
				 if(isLaunchTime >= 12 && isLaunchTime <= 13 ){
				
					 endTime = 12;
					 endDate.set(Calendar.HOUR_OF_DAY,endTime);
					 endDate.set(Calendar.MINUTE,0);
				 }
				 //end initial
				 
				 //check if pass at noon
				 if( startTime <= 12 && endTime >= 13 ){
					 hour = 1;
				 }
				 
				 log.info("startTime: "+startDate.getTime());
				 log.info("endTime :  "+endDate.getTime());
				 
				 millis1 = startDate.getTimeInMillis();
				 millis2 = endDate.getTimeInMillis();
	
			     // Calculate difference in milliseconds
			     diff = millis2 - millis1;
			     log.info("diff :"+diff);
			     // Calculate difference in days
			     Double diffHours = diff / 3600000; //(60 * 60 * 1000);
			     log.info(diffHours.toString());
				 log.info("In hours: " + diffHours + " hours.");
				 
				 //leave_hour = (endTime - startTime) - hour;
				 leave_hour = diffHours - hour;
				
				 
			 }else{
				//current date +1 day
			    startDate.add(Calendar.DATE, 1);
			 }
			 
			
		 }
		 
		 //if found holiday in leave then subtract
		 leave_day = leave_day - holidays.size();
		 log.info("total leave day: "+leave_day);
		 
		 //format leave hour in to XX.XX decimal
		 DecimalFormat df = new DecimalFormat(".##");
		 log.info("total leave hour: "+ df.format(leave_hour));
	
		 if( leave_hour == 8){
			leave_hour = leave_day * 8;
		 }else{
			leave_day = (leave_day - 1) * 8;
			leave_hour = leave_day + leave_hour;
		 }
		 
		 log.info("return leave_hour:"+leave_hour);
		 
		 log.info("human readable "+txt_dayhour(leave_hour+""));
		 
		//cast double to string
		 return String.valueOf(leave_hour);  
		 
	 }
	 
	 
	  //random string UUID with salt
      private String generateVerifyToken(){	 
		 String digest = "";	
		 try{
			 MessageDigest salt = MessageDigest.getInstance("SHA-256");
			 salt.update(UUID.randomUUID().toString().getBytes("UTF-8"));
			 digest = bytesToHex(salt.digest());
			 
		 }catch(Exception e){
			 log.info("generateVerifyToken Error : "+e);
			 e.printStackTrace();
		 }
	
		return digest; 
	 }
	
	
	//random string with salt
     private String generateToken() {

        String SALTCHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 18) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String token = salt.toString();
		return token;
	 }
	 


	  public  String bytesToHex(byte[] bytes) {
	    StringBuilder builder = new StringBuilder();
	    for (byte b: bytes) {
	      builder.append(String.format("%02x", b));
	    }
	    return builder.toString();
	  }
	  
	  
	  public void getPath(){

		  try{
			 
			  String relativeWebPath = "/emailTemplate";
			  String view = context.getRealPath(relativeWebPath);
			  
			  log.info("view: "+view);
			 
			  
			  String path = this.getClass().getClassLoader().getResource("").getPath();
			  String fullPath = URLDecoder.decode(path, "UTF-8");
			  String pathArr[] = fullPath.split("WEB-INF/view/emailTemplate/");
			  
			  
			  
			  log.info("get full path:"+fullPath);
			  log.info("gatPath :"+pathArr[0]);
			  
			  String reponsePath = "";
			  reponsePath = new File(fullPath).getPath() + File.separatorChar + "leaveRequest.html";
			  
			  log.info(reponsePath);
			  
			  //check file exist
			  File f = new File(reponsePath);
			  if(f.exists() && !f.isDirectory()) { 
			      // do something
				  log.info("file exist");
			  }else{
				  log.info("file doesn't exist");
			  }
			  
			  
		  }catch(Exception e){
			  log.info("error getPath"+e);
			  e.printStackTrace();
		  }
		
	 }

	

}