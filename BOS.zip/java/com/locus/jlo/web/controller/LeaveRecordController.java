package com.locus.jlo.web.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.LeaveRecordService;
import com.locus.jlo.web.services.UserManagementService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class LeaveRecordController {
	
	@Autowired
	private LeaveRecordService leaveRecordService;
	
	@Autowired
	private UserManagementService userService;
	
	
	@RequestMapping(value = {"/leaveRecords"})
	  public String index() {
	        return "leaveRecords";
	}
	 
	
	@RequestMapping(value = "/searchAnnualLeaveInfomation", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchAnnualLeaveInfomation(HttpServletRequest request, Locale locale)throws Exception {
		
		JsonResultBean result = null;
		Map<String, Object> m = new HashMap<String, Object>();
		
		String result_status = "";
		String result_msg = "";
		
		String staffId = request.getParameter("staffId");
		String year = request.getParameter("year");
		
		String userId = "";
		if( StringUtils.isEmpty(staffId)){
			 userId = request.getSession().getAttribute("UID").toString();
		}else{
			userId = staffId;
		}
		
		try{
			
			 ServiceResult<List<DataBean>> staffInfo = new ServiceResult<>();
			 staffInfo = leaveRecordService.leaveRecordStaffInfoService(userId);
			 if(staffInfo.isSuccess()){
				 m.put("staffInfo",  staffInfo.getResult());
				 result_status = "success";
			 }
			 
//			 ServiceResult<List<DataBean>> annualLeaveLastYear = new ServiceResult<>();
//			 annualLeaveLastYear = leaveRecordService.leaveRecordAnnualLeaveLastYearInfoService(userId);
//			 if(annualLeaveLastYear.isSuccess()){
//				 m.put("annualLastYearInfo",  annualLeaveLastYear.getResult());
//				 result_status = "success";
//			 }
//			 
//			 ServiceResult<List<DataBean>> annualLeaveThisYear = new ServiceResult<>();
//			 annualLeaveThisYear = leaveRecordService.leaveRecordAnnualLeaveThisYearInfoService(userId);
//			 if(annualLeaveThisYear.isSuccess()){
//				 m.put("annualThisYearInfo",  annualLeaveThisYear.getResult());
//				 result_status = "success";
//			 }
			 
			 UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
			 int currYear = Integer.parseInt(uinfo.getCurYear());
			 
			 ServiceResult<List<DataBean>> annualLeaveLastYear = new ServiceResult<>();
			 ServiceResult<List<DataBean>> annualLeaveThisYear = new ServiceResult<>();
			 if (Integer.parseInt(year) == currYear) {
				 annualLeaveLastYear = leaveRecordService.leaveRecordAnnualLeaveLastYearInfoService(userId);
				 annualLeaveThisYear = leaveRecordService.leaveRecordAnnualLeaveThisYearInfoService(userId);
			 } else {
				 annualLeaveLastYear = leaveRecordService.leaveRecordAnnualLeaveLast2YearInfoService(userId);
				 annualLeaveThisYear = leaveRecordService.leaveRecordAnnualLeaveLastYearInfoService(userId);
			 }
			 
			 if(annualLeaveLastYear.isSuccess()){
				 m.put("annualLastYearInfo",  annualLeaveLastYear.getResult());
				 result_status = "success";
			 }
			 
			 if(annualLeaveThisYear.isSuccess()){
				 m.put("annualThisYearInfo",  annualLeaveThisYear.getResult());
				 result_status = "success";
			 }
			 
			 
			
		}catch(Exception e){
			log.info("Error !!"+e);
		}
		
		result = new JsonResultBean(result_status, result_msg , m);
		
		return result;	
	}
	
	
	
	@RequestMapping(value = "/searchUser", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchUser(HttpServletRequest request, Locale locale)throws Exception {
		
		JsonResultBean result = null;
		Map<String, Object> m = new HashMap<String, Object>();
		
		String result_status = "";
		String result_msg = "";
		
		try{
			
			 result_status = "success";
			
			 //test leave summary
			 ServiceResult<List<KeyValueBean>> searchUser = new ServiceResult<>();
			 log.info("summary annual leave");
			 searchUser = leaveRecordService.searchUser();
			 if(searchUser.isSuccess()){
				 m.put("searchUser",  searchUser.getResult());
				 result_status = "success";
			 }
			 
			
		}catch(Exception e){
			log.info("Error !!"+e);
		}
		
		result = new JsonResultBean(result_status, result_msg , m);
		
		return result;	
	}
	

	@RequestMapping(value = "/searchLeaveRecord", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchLeaveRecord(HttpServletRequest request, Locale locale)throws Exception {
		
		JsonResultBean result = null;
		Map<String, Object> m = new HashMap<String, Object>();
		
		String result_status = "";
		String result_msg = "";
	   
		//result = new JsonResultBean("success","", m );
		
		String year = request.getParameter("year");
		String userId = request.getParameter("staffId"); // getParameter("uid");
		
		if( StringUtils.isEmpty( userId )){
			 userId = request.getSession().getAttribute("UID").toString(); 
		}
		
		
		/*
		if(userId != null && !userId.equals("")){
			UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
		 	userId  = uinfo.getUid();
		}
		*/
		log.info("search user id "+userId);
		log.info("search Leave Record with year : "+year);
		try{
			
			/*
			ServiceResult<List<DataBean>> leaveSummary  = new ServiceResult<>(); 
			leaveSummary = leaveRecordService.calWorkingDay(userId);
			log.info("result : "+leaveSummary.isSuccess());
			 
			if(leaveSummary.isSuccess()){
				log.info("search Leave Record success");
				int size = leaveSummary.getResult().size();
				for(int i=0;i<size;i++){
					DataBean tmp  = leaveSummary.getResult().get(i);
					log.info("Year:"+tmp.getA()+"|Month:"+tmp.getB()+"|Day:"+tmp.getC()+"|Total Day:"+tmp.getD());
				}
			}
			//keep to json
			 m.put("leaveTotal",  leaveSummary.getResult() );
			 */
			 
			 
			 /*
			 //test leave summary
			 ServiceResult<List<DataBean>> sumAnnualLeave = new ServiceResult<>();
			 log.info("summary annual leave");
			 sumAnnualLeave = leaveRecordService.summaryAnnualLeave(year,userId);
			 if(sumAnnualLeave.isSuccess()){
				 m.put("sumAnnualLeave",  sumAnnualLeave.getResult());
			 }
			 
		
			 ServiceResult<List<DataBean>> getAnnualLeaveAccumulate = new ServiceResult<>();
			 log.info("summary annual leave");
			 getAnnualLeaveAccumulate = leaveRecordService.calAnnualLeaveAccumulate(year,userId);
			 if(getAnnualLeaveAccumulate.isSuccess()){
				 
				 	
				   
				    int size = getAnnualLeaveAccumulate.getResult().size();
				    double balance = 0.0;
				    double entitle = 0.0;
				    
				    double used = 0.0;
				    double total = 0.0;
				      
					for(int i=0;i<size;i++){
						DataBean tmp  = getAnnualLeaveAccumulate.getResult().get(i);
						log.info("current balance = "+balance);
						log.info("WORKING YEAR:"+tmp.getA()+"|ENTITLE:"+tmp.getB()+"|USED:"+tmp.getC());
						balance = Double.parseDouble(tmp.getB()) - Double.parseDouble(tmp.getC());
						log.info("balance = "+balance);
						
						total = total + balance;
						log.info("total is ["+i+"]: "+total); 
						
						log.info("WORKING YEAR:"+tmp.getA()+"|ENTITLE:"+tmp.getB()+"|USED:"+tmp.getC()+"|BALANCED:"+tmp.getD());
						
						if(i==0){
							entitle = Double.parseDouble(tmp.getD());
							log.info("Set[0] entitle to: "+entitle);
						}else{
							entitle += Double.parseDouble(tmp.getB());
							log.info("Set["+i+"] entitle to: "+entitle);
						}
							
							if(entitle>15){
								entitle = 15;
							}
							
							log.info("entitle "+entitle+" - "+tmp.getC());
							balance += entitle - Double.parseDouble(tmp.getC());
						
						
						log.info("Total Balance "+tmp.getA()+" is "+balance);
						
						
					}
					 
					if(total>15){
						total = 15;
					}
				
					log.info("Total Balance  is "+total);
				 
				 m.put("getAnnualLeaveAccumulate", total );
			 }
			 
			 */
			 
			 //test cal previous year annual leave and entitle
			 /*
			 ServiceResult<List<DataBean>> previousEntitle = new ServiceResult<>();
			 log.info("summary annual leave");
			 previousEntitle = leaveRecordService.previousYearLeaveEntitle(userId);
			 if(previousEntitle.isSuccess()){
				 m.put("previousEntitle",  previousEntitle.getResult());
			 }
			 */
			
//			 ServiceResult<List<DataBean>> annualLeaveLastYear = new ServiceResult<>();
//			 annualLeaveLastYear = leaveRecordService.leaveRecordAnnualLeaveLastYearInfoService(userId);
//			 if(annualLeaveLastYear.isSuccess()){
//				 m.put("annualLastYearInfo",  annualLeaveLastYear.getResult());
//				 result_status = "success";
//			 }
//			 
//			 ServiceResult<List<DataBean>> annualLeaveThisYear = new ServiceResult<>();
//			 annualLeaveThisYear = leaveRecordService.leaveRecordAnnualLeaveThisYearInfoService(userId);
//			 if(annualLeaveThisYear.isSuccess()){
//				 m.put("annualThisYearInfo",  annualLeaveThisYear.getResult());
//				 result_status = "success";
//			 }
			 
			 UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
			 int currYear = Integer.parseInt(uinfo.getCurYear());
			 ServiceResult<List<DataBean>> annualLeaveLastYear = new ServiceResult<>();
			 ServiceResult<List<DataBean>> annualLeaveThisYear = new ServiceResult<>();
			 if (Integer.parseInt(year) == currYear) {
				 annualLeaveLastYear = leaveRecordService.leaveRecordAnnualLeaveLastYearInfoService(userId);
				 annualLeaveThisYear = leaveRecordService.leaveRecordAnnualLeaveThisYearInfoService(userId);
			 } else {
				 annualLeaveLastYear = leaveRecordService.leaveRecordAnnualLeaveLast2YearInfoService(userId);
				 annualLeaveThisYear = leaveRecordService.leaveRecordAnnualLeaveLastYearInfoService(userId);
			 }
			 
			 if(annualLeaveLastYear.isSuccess()){
				 m.put("annualLastYearInfo",  annualLeaveLastYear.getResult());
				 result_status = "success";
			 }
			 
			 if(annualLeaveThisYear.isSuccess()){
				 m.put("annualThisYearInfo",  annualLeaveThisYear.getResult());
				 result_status = "success";
			 }
			 
			 
			 //qry this year leave record
			ServiceResult<List<DataBean>> leaveRecord  = leaveRecordService.searchLeaveRecord(year,userId);
			if(leaveRecord.isSuccess()){
				//keep to json
				m.put("leaveRecord",  leaveRecord.getResult() );
				result_status = "success";
				//JsonResultBean result = new JsonResultBean("success", "", listResult.getResult());
			}
		
		
		}catch(Exception e){
			log.info("Error !!"+e);
		}
		
		result = new JsonResultBean(result_status, result_msg , m);
		
		return result;
	}
}
