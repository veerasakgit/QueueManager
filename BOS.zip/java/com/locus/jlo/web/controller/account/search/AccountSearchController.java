package com.locus.jlo.web.controller.account.search;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.account.search.AccountSearchBean;
import com.locus.jlo.web.beans.system.modeljson.DatatableModelBean;
import com.locus.jlo.web.services.AccountSearchService;


@Controller
public class AccountSearchController{
	
	@Autowired
	private AccountSearchService accountSearchService;
	
	@RequestMapping(value = "/accountSearch", headers = { "Accept=application/json" }, method = RequestMethod.POST)
	public @ResponseBody List<AccountSearchBean> accountSearch(HttpServletRequest request, HttpServletResponse response, Model model, Locale locale,
			@ModelAttribute("accountSearchBean") AccountSearchBean accountSearchBean) throws Exception {
		
		ServiceResult<List<AccountSearchBean>> listResult = accountSearchService.searchAccount(accountSearchBean);
		DatatableModelBean datatableModelBean = new DatatableModelBean();
		
		List<AccountSearchBean> accountList = new ArrayList<>();
		
		if(listResult.isSuccess()){
			accountList = listResult.getResult();
			
//			Integer totalRecords = (int) (long)accountList.getTotalElements();
			datatableModelBean.setiTotalDisplayRecords(accountList.size());
			datatableModelBean.setiTotalRecords(accountList.size());
			datatableModelBean.setAaData(accountList);
		}else{
			
		}
		
		return accountList;
	}

}
