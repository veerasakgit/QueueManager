package com.locus.jlo.web.controller.report;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.report.staff.StaffOvertimeReportRes;
import com.locus.jlo.web.beans.report.staff.StaffReportCriteria;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
public class StaffOvertimeReportController {
	
	@Autowired
	private ExcelReportService excelReportService;
		
	@RequestMapping(value = "/searchStaffOvertimeReport", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchStaffOvertimeReport(HttpServletRequest request,Locale locale) throws Exception{

		String cri = request.getParameter("cri");	
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(cri);
		
		JsonResultBean validResult = validateCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		 //get session user
		 UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
		 
		 StaffReportCriteria timeSheetCr = getCriteria(json, uinfo);
		 
		 JsonResultBean result = null;
		 
		 ServiceResult<List<StaffOvertimeReportRes>> listResult = excelReportService.searchStaffOvertimeReport(timeSheetCr);
		 
		 if (listResult.isSuccess()) {
			 result = new JsonResultBean("success", "" , listResult.getResult());
			 log.info("successRespones : "+result.toString());
			 log.info(" total : " + listResult.getResult().size());
		 }  else {
			 log.info("fail_Respones : ");
		 }
			 

		 
		 return result;
	
	}
	 
    @RequestMapping(value = "/validateOTStaffCriteria", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateCriteria(HttpServletRequest request,Locale locale) throws Exception{
    	String cri = request.getParameter("cri");
    	JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(cri);
		return validateCriteria(json);
    	
    }
    
    
    @SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportStaffOvertimeReport", method = RequestMethod.POST)
	public @ResponseBody void exportStaffOvertimeReport(HttpServletRequest request, HttpServletResponse response, StaffReportCriteria cr) throws Exception {

		OutputStream outputStream = null;
		ByteArrayOutputStream outByteStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();
      
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("startDate", cr.getStartDate());
			jsonObj.put("endDate", cr.getEndDate());
			jsonObj.put("employeeName", cr.getEmployeeName());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());
			jsonObj.put("project", cr.getProject());
			jsonObj.put("searchMode", cr.getSearchMode());
			
			//get session user
			UserInfoDTO uinfo  = (UserInfoDTO)request.getSession().getAttribute("USER");
			
			StaffReportCriteria timeSheetCr  = getCriteria(jsonObj, uinfo);

			ServiceResult<List<StaffOvertimeReportRes>> listResult = null;
			listResult = excelReportService.searchStaffOvertimeReport(timeSheetCr);

		
			// end search
			
			int rowCount = 0;
			int columnCount = 0;
          	List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
          	
          	//create Header styles
          	XSSFCellStyle cellStyleHeader = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
			
			//create Cells styles
			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
            
			//create header
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Spent On", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employee Id", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employee Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Position", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Division Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dept Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Section Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Code", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Task Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Note Comment", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Start Time", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "End Time", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Hours", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Requested", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Mobile Service", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Car Allowance", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Taxi Fee", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Approved Status", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Approved User", cellStyleHeader));
			
			//create row data
			
			for (StaffOvertimeReportRes rec : listResult.getResult()) {
				rowCount++;
				columnCount = 0;
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSpentOn(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeId(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getPosition(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDivisionName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDeptName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSectionName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProjectName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProjectCode(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTaskName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNoteComment(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getStartTime(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEndTime(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getOtHours()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getOtRequested()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getMobileService()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getCarAllowance()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getTaxiFee()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOtApprovedStatus(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getApprovalUser(), cellStyleLeft));
				
				
			}
            
			PoiUtils.createSheet(wb, "MyOvertime1", lstExObj, null, false);
			/*
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.addHeader("Content-Disposition", "attachment; filename=\"MyOvertime.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream);
			*/
			log.info("start export...");
			outByteStream = new ByteArrayOutputStream();
            wb.write(outByteStream);
            byte[] outArray = outByteStream.toByteArray();
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setContentLength(outArray.length);
            response.setHeader("Content-Disposition", "attachment; filename=\"MyOvertime.xlsx\"");
            outputStream = response.getOutputStream();
            outputStream.write(outArray);
            log.info("end export");
            
          
      } catch (Exception e) {
          e.printStackTrace();
      } finally {
      	outputStream.flush();
      	outputStream.close();
      	outByteStream.close();
      	wb.close();
      }
      
	}
    
    private JsonResultBean validateCriteria(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg    = "";
		String result_data   = "";

		if (StringUtils.isEmpty(json.get("startDate"))) {
			result_data   = "";
			result_status = "error";
			result_msg    = "Please Fill StartDate";
			return new JsonResultBean(result_status, result_msg , result_data );
		}
		 
		if (StringUtils.isEmpty(json.get("endDate"))) {
			result_data   = "";
			result_status = "error";
			result_msg    = "Please Fill EndDate";
			return new JsonResultBean(result_status, result_msg , result_data );
		}
		
		
		String startDate = json.get("startDate").toString();
		String endDate = json.get("endDate").toString();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date stDate = sdf.parse(startDate); 
		Date edDate = sdf.parse(endDate);

		long difference = edDate.getTime() - stDate.getTime();
		float daysBetween =  TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);
		
		if (daysBetween < 0) {
			 result_data   = "";
			 result_status = "error";
			 result_msg    = "EndDate more than equal StartDate";
			 return new JsonResultBean(result_status, result_msg , result_data );
		}
		
		return new JsonResultBean("success", "" , "" );
    }
    
    
    private StaffReportCriteria getCriteria(JSONObject json, UserInfoDTO uinfo) throws Exception {

		String startDate = json.get("startDate").toString();
		String endDate = json.get("endDate").toString();
		
		String division = null;
		String department = null;
		String project = null;
		String section = null;
		String employeeName = null;
		if (json.get("division") != null) {
			division = json.get("division").toString();
		}
		if (json.get("department") != null) {
			department = json.get("department").toString();
		}
		if (json.get("section") != null) {
			section = json.get("section").toString();
		}
		if (json.get("project") != null) {
			project = json.get("project").toString();
		}
		if (json.get("employeeName") != null) {
			employeeName = json.get("employeeName").toString();
		}
		String searchMode = json.get("searchMode").toString();
		 
		 
		 
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd");
		Date stDate = sdf.parse(startDate);
		String startDateFmt = output.format(stDate);
		Date edDate = sdf.parse(endDate);
		String endDateFmt = output.format(edDate);
		
		 
		 StaffReportCriteria timeSheetCriteria = new StaffReportCriteria();
		

		 if (!StringUtils.isEmpty(startDateFmt)) {
			 timeSheetCriteria.setStartDate(startDateFmt);
		 }
			 
		 if (!StringUtils.isEmpty(endDateFmt))
			 timeSheetCriteria.setEndDate(endDateFmt);
		 if (!StringUtils.isEmpty(division))
			 timeSheetCriteria.setDivision(division);
		 if (!StringUtils.isEmpty(department))
			 timeSheetCriteria.setDepartment(department);
		 if (!StringUtils.isEmpty(section))
			 timeSheetCriteria.setSection(section);
		 if (!StringUtils.isEmpty(project)) {
			 String ids = project.replaceAll("\\[|\\]", ""); 
			 List<String> listId = Arrays.asList(ids.split(","));
			 if (listId.size() > 1) {
				 listId = JsonBeanUtils.jsonToList(project); 
			 }
			 timeSheetCriteria.setProject(listId);
		 }
		 if (searchMode.equals("1")) {
			 List<String> id = new ArrayList<String>();
			 id.add(uinfo.getUid());
			 timeSheetCriteria.setEmployeeName(id);
		 } else if (searchMode.equals("2")) {
			 
		 } else if (searchMode.equals("3")) {
			 if (!StringUtils.isEmpty(employeeName)) {
				 String ids = employeeName.replaceAll("\\[|\\]", ""); 
				 List<String> listId = Arrays.asList(ids.split(","));
				 if (listId.size() > 1) {
					 listId = JsonBeanUtils.jsonToList(employeeName); 
				 }
				 timeSheetCriteria.setEmployeeName(listId);
			 }

		 }
		 
		 return timeSheetCriteria;
    }
		

}
