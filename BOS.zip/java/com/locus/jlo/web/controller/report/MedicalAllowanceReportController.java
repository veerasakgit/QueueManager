package com.locus.jlo.web.controller.report;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriod;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriodRes;
import com.locus.jlo.web.beans.medical.report.MedicalReportSUM;
import com.locus.jlo.web.beans.medical.report.MedicalReportSUMRes;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class MedicalAllowanceReportController {

	@Autowired
	private ExcelReportService excelReportService;

	@RequestMapping(value = "/searchMedicalAllowanceReportByPeriod", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchMedicalAllowanceReportByPeriod(HttpServletRequest request, Locale locale) throws Exception {

		String cri = request.getParameter("cri");

		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);
		MedicalReportByPeriod medicalReportSum = getCriteriaMedicalReportByPeriod(json);

		ServiceResult<List<MedicalReportByPeriodRes>> listResult = excelReportService.searchMedicalAllowanceReportByPeriod(medicalReportSum);

		JsonResultBean result = null;
		if (listResult.isSuccess()) {
			result = new JsonResultBean("success", "", listResult.getResult());
			log.info("successRespones : " + result.toString());
		} else {
			log.info("fail_Respones : ");
		}
		return result;
	}

	@RequestMapping(value = "/searchMedicalAllowanceReportSum", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchMedicalAllowanceReportSum(HttpServletRequest request, Locale locale) throws Exception {

		String cri = request.getParameter("cri");

		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);
		MedicalReportSUM medicalReportSum = getCriteriaMedicalReportSUM(json);

		ServiceResult<List<MedicalReportSUMRes>> listResult = excelReportService.searchMedicalAllowanceReportSum(medicalReportSum);

		JsonResultBean result = null;
		if (listResult.isSuccess()) {
			result = new JsonResultBean("success", "", listResult.getResult());
			log.info("successRespones : " + result.toString());
		} else {
			log.info("fail_Respones : ");
		}
		return result;
	}

	@RequestMapping(value = "/validateCriteriaMedicalReportSum", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateCriteriaMedicalReportSum(HttpServletRequest request, Locale locale)
			throws Exception {
		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);
		return validateCriteriaMedicalReportSum(json);
	}


	@RequestMapping(value = "/validateCriteriaMedicalReportByPeriod", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateCriteriaMedicalReportByPeriod(HttpServletRequest request, Locale locale)
			throws Exception {
		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);
		return validateCriteriaMedicalReportByPeriod(json);
	}

    @SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportMedicalReportSum", method = RequestMethod.POST)
	public @ResponseBody void exportMedicalReportSum(HttpServletRequest request, HttpServletResponse response, MedicalReportSUM cr) throws Exception {
		OutputStream outputStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("year", cr.getYear());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());
			jsonObj.put("employeeName", cr.getEmployeeName());
			
			MedicalReportSUM medicalReportSumCriteria  = getCriteriaMedicalReportSUM(jsonObj);
			String year = medicalReportSumCriteria.getYear();
//			int yearBefore = Integer.parseInt(medicalReportSumCriteria.getYear()) - 1;

			ServiceResult<List<MedicalReportSUMRes>> listResult = excelReportService.searchMedicalAllowanceReportSum(medicalReportSumCriteria); 
		
			int rowCount = 0;
			int columnCount = 0;
          	List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
          	List<Integer[]> mergeList = new ArrayList<Integer[]>();
          	
			XSSFCellStyle cellStyleR1 = PoiUtils.creatCellStyle(wb, "Angsana New", true, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleG1 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
	        XSSFCellStyle cellStyleG2 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.PINK.index);
			XSSFCellStyle cellStyleG3 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.RED.index);
//			XSSFCellStyle cellStyleG4 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.DARK_YELLOW.index);
//			XSSFCellStyle cellStyleG5 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.SEA_GREEN.index);
            
			String [] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sep", "Oct", "Nov", "Dec"};
			
			//row1
            columnCount = 0;
            
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "รายการเบิกค่า Medical allowance 15,000", cellStyleR1));
            mergeList.add(new Integer[]{ 0, 0, 0, 5});
            
            lstExObj.add(new ExcelObject(rowCount, 6, "31-ธ.ค." + year, cellStyleG3));
             
        	//row2
            rowCount++;
            columnCount = 0;
            
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dept Code", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp Code", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp. Name", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Start Working Date", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Completed Probation Period", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Resigned Date", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Service of year", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "15,000", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, year+" Summary claim", cellStyleG1));
            columnCount +=3;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "15,000", cellStyleG1));
            
            for (String month : months) {
                lstExObj.add(new ExcelObject(rowCount, columnCount++, month, cellStyleG2));
        		columnCount +=6;
            }
            
            //row3
            rowCount++;
            columnCount = 7;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Medical Allowance "+year, cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Medical", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dental", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "ตัดแว่น/คอนเทคเลนส์ ", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total Balance "+year, cellStyleG1));

            for (String month : months) {
	            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employee", cellStyleG2));
	    		columnCount +=2;
	            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Family", cellStyleG2));
	    		columnCount +=2;
	            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total Claim", cellStyleG1));
            }
            // set merge cell
            mergeList.add(new Integer[]{ 1, 3, 0, 0});//Dept Code
            mergeList.add(new Integer[]{ 1, 3, 1, 1});//Emp Code
            mergeList.add(new Integer[]{ 1, 3, 2, 2});//Emp. Name
            mergeList.add(new Integer[]{ 1, 3, 3, 3});//Start working date
            mergeList.add(new Integer[]{ 1, 3, 4, 4});//Completed probation period
            mergeList.add(new Integer[]{ 1, 3, 5, 5});//Resigned date
            mergeList.add(new Integer[]{ 1, 3, 6, 6});//Service of year 
            mergeList.add(new Integer[]{ 1, 1, 8, 11});//YearBefore Summary claim 
            int columnMergeStart = 13;
            int columnMergeEnd = 19;
            for (String month : months) {
            	mergeList.add(new Integer[]{ 1, 1, columnMergeStart, columnMergeEnd});
            	columnMergeStart += 7;
            	columnMergeEnd +=7;
            }

            //row4
            rowCount++;
            columnCount = 13;
            for (String month : months) {
	            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Medical", cellStyleG2));
	            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dental", cellStyleG2));
	            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Eye", cellStyleG2));
	            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Medical", cellStyleG2));
	            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dental", cellStyleG2));
	            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Eye", cellStyleG2));
	            columnCount++;
            }

            mergeList.add(new Integer[]{ 2, 3, 7, 7});//Medical Allowance yearBefore
            mergeList.add(new Integer[]{ 2, 3, 8, 8});//Medical
            mergeList.add(new Integer[]{ 2, 3, 9, 9});//Dental
            mergeList.add(new Integer[]{ 2, 3, 10, 10});//ตัดแว่น/คอนเทคเลนส์
            mergeList.add(new Integer[]{ 2, 3, 11, 11});//Total
            mergeList.add(new Integer[]{ 2, 3, 12, 12});//Total Balance yearBefore
            int columnMergeRow2Start = 13;
            int columnMergeRow2End = columnMergeRow2Start+2;
            for (String month : months) {
            	mergeList.add(new Integer[]{ 2, 2, columnMergeRow2Start, columnMergeRow2End});
            	columnMergeRow2Start = columnMergeRow2End+1;
            	columnMergeRow2End = columnMergeRow2Start+2;
            	mergeList.add(new Integer[]{ 2, 2, columnMergeRow2Start, columnMergeRow2End});
            	columnMergeRow2Start = columnMergeRow2End+1;
            	columnMergeRow2End = columnMergeRow2Start;
            	mergeList.add(new Integer[]{ 2, 3, columnMergeRow2Start, columnMergeRow2End});
            	columnMergeRow2Start = columnMergeRow2End+1;
            	columnMergeRow2End = columnMergeRow2Start+2;
            }

            //create row data
			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
			for (MedicalReportSUMRes rec: listResult.getResult()) {
                rowCount++;
                columnCount = 0;
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDeptCode(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpCode(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpName(), cellStyleLeft));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAppearanceDate(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProbationDate(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getResignDate(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getServiceYear(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEntitleMedicalAl(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMedical(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDental(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTotal(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTotalBal(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJanTotalClaim(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFebTotalClaim(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMarTotalClaim(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAprTotalClaim(), cellStyleCenter));         
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getMayTotalClaim(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJunTotalClaim(), cellStyleCenter)); 
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getJulTotalClaim(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getAugTotalClaim(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSepTotalClaim(), cellStyleCenter)); 
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOctTotalClaim(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNovTotalClaim(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecStaffMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecStaffDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecFamilyMed(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecFamilyDen(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDecTotalClaim(), cellStyleCenter)); 
			}
			
			PoiUtils.createSheet(wb, "MedicalReportSum", lstExObj, mergeList, true);
			wb.getSheet("MedicalReportSum").autoSizeColumn((short) 0);
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.addHeader("Content-Disposition", "attachment; filename=\"Medical Report Sum.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream); 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			outputStream.flush();
			outputStream.close();
			wb.close();
		}
	}

    @SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportMedicalReportByPeriod", method = RequestMethod.POST)
	public @ResponseBody void exportMedicalReportByPeriod(HttpServletRequest request, HttpServletResponse response, MedicalReportByPeriod cr) throws Exception {

    	OutputStream outputStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("startDate", cr.getStartDate());
			jsonObj.put("endDate", cr.getEndDate());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());
			jsonObj.put("employeeName", cr.getEmployeeName());
			
			MedicalReportByPeriod medicalReportByPeriodCriteria  = getCriteriaMedicalReportByPeriod(jsonObj);
			ServiceResult<List<MedicalReportByPeriodRes>> listResult = excelReportService.searchMedicalAllowanceReportByPeriod(medicalReportByPeriodCriteria); 
		
			int rowCount = 0;
			int columnCount = 0;
          	List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
          	List<Integer[]> mergeList = new ArrayList<Integer[]>();
          	
			XSSFCellStyle cellStyleR1 = PoiUtils.creatCellStyle(wb, "Angsana New", true, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleG1 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
			XSSFCellStyle cellStyleG3 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true,HorizontalAlignment.CENTER, IndexedColors.RED.index);
			XSSFCellStyle cellStyleG4 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.BLACK.getIndex(), true,HorizontalAlignment.LEFT, IndexedColors.YELLOW.index);

			//row1
            columnCount = 0;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "รายงานการเบิกค่ารักษาพยาบาล", cellStyleR1));
            mergeList.add(new Integer[]{ 0, 0, 0, 3});
        	//row2
            rowCount++;
            columnCount = 0;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "ตั้งแต่ " + cr.getStartDate() + " ถึง "+ cr.getEndDate(), cellStyleG4));
            columnCount +=3;
            mergeList.add(new Integer[]{ 1, 1, 0, 3});
            
            columnCount = 6;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "รักษาตามใบเสร็จ", cellStyleG3));
            mergeList.add(new Integer[]{ 1, 1, 6, 12});
            //row3
            rowCount++;
            columnCount = 0;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Date", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dept Code", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp Code", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp. Name", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "ชื่อสถานพยาบาล", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "โรคที่รักษา", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Staff", cellStyleG1));
            columnCount +=2;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Family", cellStyleG1));
            columnCount +=2;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "รวม", cellStyleG1));

            mergeList.add(new Integer[]{ 2, 3, 0, 0});//Date
            mergeList.add(new Integer[]{ 2, 3, 1, 1});//Dept Code
            mergeList.add(new Integer[]{ 2, 3, 2, 2});//Emp Code
            mergeList.add(new Integer[]{ 2, 3, 3, 3});//Emp. Name
            mergeList.add(new Integer[]{ 2, 3, 4, 4});//ชื่อสถานพยาบาล
            mergeList.add(new Integer[]{ 2, 3, 5, 5});//โรคที่รักษา
            mergeList.add(new Integer[]{ 2, 2, 6, 8});//Staff 
            mergeList.add(new Integer[]{ 2, 2, 9, 11});//Family
            mergeList.add(new Integer[]{ 2, 3, 12, 12});//รวม
            //row4
            rowCount++;
            columnCount = 6;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Medical", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dental", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Eye", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Medical", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dental", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Eye", cellStyleG1));
            
            //create row data
			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
			for (MedicalReportByPeriodRes rec: listResult.getResult()) {
                rowCount++;
                columnCount = 0;
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getReceiptDate(), cellStyleCenter));
            	lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDeptCode(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmpCode(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFullname(), cellStyleLeft));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getHospital(), cellStyleLeft));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDisease(), cellStyleLeft));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getStaffMedical(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getStaffDental(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getStaffEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFamilyMedical(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFamilyDental(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getFamilyEye(), cellStyleCenter));
                lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTotal(), cellStyleCenter));
			}
            
			PoiUtils.createSheet(wb, "MedicalReportByPeriod", lstExObj, mergeList, true);
			wb.getSheet("MedicalReportByPeriod").autoSizeColumn((short) 0);
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.addHeader("Content-Disposition", "attachment; filename=\"Medical Report By Period.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream); 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			outputStream.flush();
			outputStream.close();
			wb.close();
		}
	}

	private JsonResultBean validateCriteriaMedicalReportSum(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg = "";
		String result_data = "";

		if (StringUtils.isEmpty(json.get("year"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill Year";
			return new JsonResultBean(result_status, result_msg, result_data);
		}
		return new JsonResultBean("success", "", "");
	}

	private JsonResultBean validateCriteriaMedicalReportByPeriod(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg = "";
		String result_data = "";

		if (StringUtils.isEmpty(json.get("startDate"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill Start Date";
			return new JsonResultBean(result_status, result_msg, result_data);
		}

		if (StringUtils.isEmpty(json.get("endDate"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill End Date";
			return new JsonResultBean(result_status, result_msg, result_data);
		}
		return new JsonResultBean("success", "", "");
	}

	private MedicalReportSUM getCriteriaMedicalReportSUM(JSONObject json) throws Exception {
		String year = json.get("year").toString();
		String division = json.get("division").toString();
		String department = json.get("department").toString();
		String section = json.get("section").toString();
		String employeeName = null;
		if (json.get("employeeName") != null) {
			employeeName = json.get("employeeName").toString();
		}

		MedicalReportSUM medicalReportSum = new MedicalReportSUM();
		medicalReportSum.setYear(year);

		if (!StringUtils.isEmpty(division)) {
			medicalReportSum.setDivision(division);
		}
		if (!StringUtils.isEmpty(department)) {
			medicalReportSum.setDepartment(department);
		}
		if (!StringUtils.isEmpty(section)) {
			medicalReportSum.setSection(section);
		}
		if (!StringUtils.isEmpty(employeeName)) {
			String ids = employeeName.replaceAll("\\[|\\]", "");
			List<String> listId = Arrays.asList(ids.split(","));
			if (listId.size() > 1) {
				listId = JsonBeanUtils.jsonToList(employeeName);
			}
			medicalReportSum.setEmployeeName(listId);
		}
		return medicalReportSum;
	}

	private MedicalReportByPeriod getCriteriaMedicalReportByPeriod(JSONObject json) throws Exception {

		String startDate = json.get("startDate").toString();
		String endDate = json.get("endDate").toString();
		String division = json.get("division").toString();
		String department = json.get("department").toString();
		String section = json.get("section").toString();
		String employeeName = null;
		if (json.get("employeeName") != null) {
			employeeName = json.get("employeeName").toString();
		}

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd");
		Date stDate = sdf.parse(startDate);
		String startDateFmt = output.format(stDate);
		Date edDate = sdf.parse(endDate);
		String endDateFmt = output.format(edDate);

		MedicalReportByPeriod medicalReportByPeriod = new MedicalReportByPeriod();

		if (!StringUtils.isEmpty(startDateFmt)) {
			medicalReportByPeriod.setStartDate(startDateFmt);
		}
		if (!StringUtils.isEmpty(endDateFmt)) {
			medicalReportByPeriod.setEndDate(endDateFmt);
		}
		if (!StringUtils.isEmpty(division)) {
			medicalReportByPeriod.setDivision(division);
		}
		if (!StringUtils.isEmpty(department)) {
			medicalReportByPeriod.setDepartment(department);
		}
		if (!StringUtils.isEmpty(section)) {
			medicalReportByPeriod.setSection(section);
		}
		if (!StringUtils.isEmpty(employeeName)) {
			String ids = employeeName.replaceAll("\\[|\\]", "");
			List<String> listId = Arrays.asList(ids.split(","));
			if (listId.size() > 1) {
				listId = JsonBeanUtils.jsonToList(employeeName);
			}
			medicalReportByPeriod.setEmployeeName(listId);
		}
		return medicalReportByPeriod;
	}
	
	
}
