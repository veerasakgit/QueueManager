package com.locus.jlo.web.controller.report;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.report.hr.HrReportCriteria;
import com.locus.jlo.web.beans.report.hr.HrTimeSheetReportRes;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
public class HrTimeSheetReportController {
	
	@Autowired
	private ExcelReportService excelReportService;
	
		
	@RequestMapping(value = "/searchHrTimeSheetReport", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchHrTimeSheetReport(HttpServletRequest request,Locale locale) throws Exception{

		String cri = request.getParameter("cri");	
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(cri);
		
		JsonResultBean validResult = validateCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		HrReportCriteria timeSheetCr = getCriteria(json);
		JsonResultBean result = null;
		ServiceResult<List<HrTimeSheetReportRes>> listResult = excelReportService.searchHrTimeSheetReport(timeSheetCr);
		 
		if (listResult.isSuccess()) {
			result = new JsonResultBean("success", "" , listResult.getResult());
			log.info("successRespones : "+result.toString());
			log.info(" total : " + listResult.getResult().size());
		}  else {
			log.info("fail_Respones : ");
		}
		return result;
	}
	 
    @RequestMapping(value = "/validateHrTSCriteria", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateCriteria(HttpServletRequest request,Locale locale) throws Exception{
    	String cri = request.getParameter("cri");
    	JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject)jParser.parse(cri);
		return validateCriteria(json);
    	
    }
    
    
    @SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportHrTimeSheetReport", method = RequestMethod.POST)
	public @ResponseBody void exportHrTimeSheetReport(HttpServletRequest request, HttpServletResponse response, HrReportCriteria cr) throws Exception {

		OutputStream outputStream = null;
		ByteArrayOutputStream outByteStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();
      
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("spentFrom", cr.getSpentFrom());
			jsonObj.put("spentTo", cr.getSpentTo());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());
			jsonObj.put("employeeId", cr.getEmployeeId());
			jsonObj.put("employeeType", cr.getEmployeeType());
			jsonObj.put("projectId", cr.getProjectId());

			HrReportCriteria timeSheetCr  = getCriteria(jsonObj);

			ServiceResult<List<HrTimeSheetReportRes>> listResult = null;
			listResult = excelReportService.searchHrTimeSheetReport(timeSheetCr);

		
			// end search
			
			int rowCount = 0;
			int columnCount = 0;
          	List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
          	
          	//create Header styles
          	XSSFCellStyle cellStyleHeader = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
			
			//create Cells styles
			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
            
			//create header
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Year", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Month", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Spent On", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employee Id", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employee Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Position", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Division Id", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Division Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dept Code", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dept Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Section Code", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Section Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Rank Id", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Role Id", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Code", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Task Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Internal Project", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Implement Project", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "MA Project", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Deal Project", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Type", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "ORC Status Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Deal Status Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Sales Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Customer Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Logtime Status", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Logtime Approve By", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Note Comment", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Office Hour", cellStyleHeader));
			
			//create row data
			
			for (HrTimeSheetReportRes rec : listResult.getResult()) {
				rowCount++;
				columnCount = 0;
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTyear()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTmonth()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSpentOn(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeId(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getPosition(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDivisionId()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDivisionName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDeptCode()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDeptName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getSectionCode()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSectionName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRankId()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRoleId()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProjectName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProjectCode(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTaskName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getInternalProject()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getImplementProject()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getMaProject()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getDealProject()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProjectType(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOrcStatusName(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDealStatusName(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSalesName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getCustomerName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeStatus(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getLogtimeApproveBy(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNoteComment(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getOfficeHour()), cellStyleCenter));
				
			}
            
			PoiUtils.createSheet(wb, "TimeSheet1", lstExObj, null, false);
			/*
			log.info("start...");
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.addHeader("Content-Disposition", "attachment; filename=\"HrTimeSheet.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream); 
			log.info("end...");
			*/
			
			log.info("start export...");
			outByteStream = new ByteArrayOutputStream();
            wb.write(outByteStream);
            byte[] outArray = outByteStream.toByteArray();
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setContentLength(outArray.length); 
            response.setHeader("Content-Disposition", "attachment; filename=\"HrTimeSheet.xlsx\"");
            outputStream = response.getOutputStream();
            outputStream.write(outArray);
            log.info("end export");
            
            
			
          
      } catch (Exception e) {
          e.printStackTrace();
      } finally {
      	outputStream.flush();
      	outputStream.close();
      	outByteStream.close();
      	wb.close();
      }
      
	}
    
    private JsonResultBean validateCriteria(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg    = "";
		String result_data   = "";

		if (StringUtils.isEmpty(json.get("spentFrom"))) {
			result_data   = "";
			result_status = "error";
			result_msg    = "Please Fill StartDate";
			return new JsonResultBean(result_status, result_msg , result_data );
		}
		 
		if (StringUtils.isEmpty(json.get("spentTo"))) {
			result_data   = "";
			result_status = "error";
			result_msg    = "Please Fill EndDate";
			return new JsonResultBean(result_status, result_msg , result_data );
		}
		
		
		String spentFrom = json.get("spentFrom").toString();
		String spentTo = json.get("spentTo").toString();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date stDate = sdf.parse(spentFrom); 
		Date edDate = sdf.parse(spentTo);

		long difference = edDate.getTime() - stDate.getTime();
		float daysBetween =  TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);
		
		if (daysBetween < 0) {
			 result_data   = "";
			 result_status = "error";
			 result_msg    = "EndDate more than equal StartDate";
			 return new JsonResultBean(result_status, result_msg , result_data );
		}
		
		/*if ( daysBetween > 31 ) {
			
			 result_data   = "";
			 result_status = "error";
			 result_msg    = "StartDate-EndDate not over 31 Days";
			 return new JsonResultBean(result_status, result_msg , result_data );
			 
		}*/

		return new JsonResultBean("success", "" , "" );
    }
    
    
    private HrReportCriteria getCriteria(JSONObject json) throws Exception {
		String spentFrom = json.get("spentFrom").toString();
		String spentTo = json.get("spentTo").toString();
		String division = json.get("division").toString();
		String department = json.get("department").toString();
		String section = json.get("section").toString();
		String employeeId = null;
		if (json.get("employeeId") != null) {
			employeeId = json.get("employeeId").toString();
		}
		String employeeType = json.get("employeeType").toString();
		String projectId = json.get("projectId").toString();
		 
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd");
		Date stDate = sdf.parse(spentFrom);
		String spentFromFmt = output.format(stDate);
		Date edDate = sdf.parse(spentTo);
		String spentToFmt = output.format(edDate);
		 
		HrReportCriteria timeSheetCriteria = new HrReportCriteria();

		if (!StringUtils.isEmpty(spentFromFmt)) {
			timeSheetCriteria.setSpentFrom(spentFromFmt);
		}

		if (!StringUtils.isEmpty(spentToFmt))
			timeSheetCriteria.setSpentTo(spentToFmt);
		if (!StringUtils.isEmpty(division))
			timeSheetCriteria.setDivision(division);
		if (!StringUtils.isEmpty(department))
			timeSheetCriteria.setDepartment(department);
		if (!StringUtils.isEmpty(section))
			timeSheetCriteria.setSection(section);
		if (!StringUtils.isEmpty(employeeId)) {
			String ids = employeeId.replaceAll("\\[|\\]", "");
			List<String> listId = Arrays.asList(ids.split(","));
			if (listId.size() > 1) {
				listId = JsonBeanUtils.jsonToList(employeeId);
			}
			timeSheetCriteria.setEmployeeId(listId);
		}
		if (!StringUtils.isEmpty(employeeType))
			timeSheetCriteria.setEmployeeType(employeeType);
		if (!StringUtils.isEmpty(projectId))
			timeSheetCriteria.setProjectId(projectId);
		return timeSheetCriteria;
    }

}
