package com.locus.jlo.web.controller.report;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.report.hr.HrOvertimeReportRes;
import com.locus.jlo.web.beans.report.hr.HrReportCriteria;
import com.locus.jlo.web.beans.report.hr.OTReportCriteria;
import com.locus.jlo.web.beans.report.hr.OTReportRes;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class HrOvertimeReportController {

	@Autowired
	private ExcelReportService excelReportService;

	@RequestMapping(value = "/searchHrOvertimeReport", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchHrOvertimeReport(HttpServletRequest request, Locale locale) throws Exception {
		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);

		JsonResultBean validResult = validateCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		HrReportCriteria timeSheetCr = getCriteria(json);
		JsonResultBean result = null;
		ServiceResult<List<HrOvertimeReportRes>> listResult = excelReportService.searchHrOvertimeReport(timeSheetCr);

		if (listResult.isSuccess()) {
			result = new JsonResultBean("success", "", listResult.getResult());
			log.info("successRespones : " + result.toString());
			log.info(" total : " + listResult.getResult().size());
		} else {
			log.info("fail_Respones : ");
		}
		return result;
	}

	@RequestMapping(value = "/searchOTReport", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean searchOTReport(HttpServletRequest request, Locale locale) throws Exception {
		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);

		JsonResultBean validResult = validateOTReportCriteria(json);
		if (validResult.getStatus().equals("error")) {
			return validResult;
		}

		OTReportCriteria criteria = getOTReportCriteria(json);
		JsonResultBean result = null;
		ServiceResult<List<OTReportRes>> listResult = excelReportService.searchOTReport(criteria);

		if (listResult.isSuccess()) {
			result = new JsonResultBean("success", "", listResult.getResult());
			log.info("successRespones : " + result.toString());
			log.info(" total : " + listResult.getResult().size());
		} else {
			log.info("fail_Respones : ");
		}
		return result;
	}

	@RequestMapping(value = "/validateOTCriteria", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateCriteria(HttpServletRequest request, Locale locale) throws Exception {
		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);
		return validateCriteria(json);
	}

	@RequestMapping(value = "/validateOTReport", headers = {"Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean validateOTReport(HttpServletRequest request, Locale locale) throws Exception {
		String cri = request.getParameter("cri");
		JSONParser jParser = new JSONParser();
		JSONObject json = (JSONObject) jParser.parse(cri);
		return validateOTReportCriteria(json);
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportHrOvertimeReport", method = RequestMethod.POST)
	public @ResponseBody void exportHrOvertimeReport(HttpServletRequest request, HttpServletResponse response,
			HrReportCriteria cr) throws Exception {
		OutputStream outputStream = null;
		ByteArrayOutputStream outByteStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("spentFrom", cr.getSpentFrom());
			jsonObj.put("spentTo", cr.getSpentTo());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());
			jsonObj.put("employeeId", cr.getEmployeeId());
			jsonObj.put("employeeType", cr.getEmployeeType());
			jsonObj.put("projectId", cr.getProjectId());

			HrReportCriteria timeSheetCr = getCriteria(jsonObj);

			ServiceResult<List<HrOvertimeReportRes>> listResult = null;
			listResult = excelReportService.searchHrOvertimeReport(timeSheetCr);

			// end search

			int rowCount = 0;
			int columnCount = 0;
			List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();

			// create Header styles
			XSSFCellStyle cellStyleHeader = PoiUtils.creatCellStyle(wb, "Angsana New",
					HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);

			// create Cells styles
			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false,
					HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);

			// create header
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Year", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Month", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Spent On", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employee Id", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employee Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Position", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Division Id", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Division Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dept Code", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Dept Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Section Code", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Section Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Rank Id", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Role Id", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Code", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Task Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Internal Project", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Implement Project", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "MA Project", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Deal Project", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Project Type", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "ORC Status Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Deal Status Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Sales Name", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Customer Name", cellStyleHeader));

			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Log Time Status", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Logtime Approve By", cellStyleHeader));

			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Note Comment", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Start Time", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "End Time", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Hours", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Date Type", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Rate1", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Rate1.5", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Rate3.0", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Requested", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Mobile Service", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Car Allowance", cellStyleHeader));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Taxi Fee", cellStyleHeader));

			// create row data

			for (HrOvertimeReportRes rec : listResult.getResult()) {
				rowCount++;
				columnCount = 0;

				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTyear()),
						cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getTmonth()),
						cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSpentOn(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeId(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getPosition(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getDivisionId()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDivisionName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getDeptCode()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDeptName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getSectionCode()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSectionName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRankId()),
						cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToInteger(rec.getRoleId()),
						cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProjectName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProjectCode(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getTaskName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getInternalProject()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getImplementProject()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getMaProject()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getDealProject()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getProjectType(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOrcStatusName(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDealStatusName(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getSalesName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getCustomerName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOtApprovedStatus(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getApprovalUser(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getNoteComment(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getStartTime(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEndTime(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getOtHours()),
						cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getDateType(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getOtRate1()),
						cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToDouble(rec.getOtRate15()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getOtRate3()),
						cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getOtRequested()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getMobileService()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++,
						ObjectBeanUtils.convertToInteger(rec.getCarAllowance()), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, ObjectBeanUtils.convertToDouble(rec.getTaxiFee()),
						cellStyleCenter));

			}

			PoiUtils.createSheet(wb, "Overtime1", lstExObj, null, false);
			XSSFSheet sheet = wb.getSheet("Overtime1");
			sheet.autoSizeColumn((short) 0);
			/*
			 * response.setContentType(
			 * "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			 * response.addHeader("Content-Disposition",
			 * "attachment; filename=\"HrOvertime.xlsx\""); outputStream =
			 * response.getOutputStream(); wb.write(outputStream);
			 */
			log.info("start export...");
			outByteStream = new ByteArrayOutputStream();
			wb.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			response.setContentLength(outArray.length);
			response.setHeader("Content-Disposition", "attachment; filename=\"HrOvertime.xlsx\"");
			outputStream = response.getOutputStream();
			outputStream.write(outArray);
			log.info("end export");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			outputStream.flush();
			outputStream.close();
			outByteStream.close();
			wb.close();
		}
	}
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/exportOTReport", method = RequestMethod.POST)
	public @ResponseBody void exportOTReport(HttpServletRequest request, HttpServletResponse response, OTReportCriteria cr) throws Exception {

		OutputStream outputStream = null;
		XSSFWorkbook wb = new XSSFWorkbook();

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("employeeId", cr.getEmployeeId());
			jsonObj.put("yearOt", cr.getYearOt());
			jsonObj.put("monthOt", cr.getMonthOt());
			jsonObj.put("employeeType", cr.getEmployeeType());
			jsonObj.put("division", cr.getDivision());
			jsonObj.put("department", cr.getDepartment());
			jsonObj.put("section", cr.getSection());

			OTReportCriteria criteria = getOTReportCriteria(jsonObj);

			ServiceResult<List<OTReportRes>> listResult = excelReportService.searchOTReport(criteria);

			int rowCount = 0;
			int columnCount = 0;
			List<ExcelObject> lstExObj = new ArrayList<ExcelObject>();
			List<Integer[]> mergeList = new ArrayList<Integer[]>();

			XSSFCellStyle cellStyleR1 = PoiUtils.creatCellStyle(wb, "Angsana New", true, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleG1 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.BLUE.index);
			XSSFCellStyle cellStyleG2 = PoiUtils.creatCellStyle(wb, "Angsana New", HSSFColorPredefined.WHITE.getIndex(), true, HorizontalAlignment.CENTER, IndexedColors.DARK_GREEN.index);

			XSSFCellStyle cellStyleCenter = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.CENTER);
			XSSFCellStyle cellStyleLeft = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.LEFT);
			XSSFCellStyle cellStyleRight = PoiUtils.creatCellStyle(wb, "Angsana New", false, HorizontalAlignment.RIGHT);

			// row1
			columnCount = 0;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Report", cellStyleR1));
			mergeList.add(new Integer[] { 0, 0, 0, 11 });
			// row2
			rowCount++;
			columnCount = 0;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Emp ID", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Employee Name", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "OT Hour", cellStyleG1));
			columnCount +=3;
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total Allowance", cellStyleG2));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Transportation", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Upcountry", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Mobile Service", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Car Allowance", cellStyleG1));
			lstExObj.add(new ExcelObject(rowCount, columnCount++, "Taxi Fee", cellStyleG1));

            mergeList.add(new Integer[]{ rowCount, rowCount+1, 0, 0});//Emp ID
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 1, 1});//Employee Name
            mergeList.add(new Integer[]{ rowCount, rowCount, 2, 5});//OT Hour
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 6, 6});//Total Allowance
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 7, 7});//Transportation
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 8, 8});//Upcountry
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 9, 9});//Mobile Service
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 10, 10});//Car Allowance
            mergeList.add(new Integer[]{ rowCount, rowCount+1, 11, 11});//Taxi Fee
            //row3
            rowCount++;
            columnCount = 2;
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "1", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "1.5", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "3", cellStyleG1));
            lstExObj.add(new ExcelObject(rowCount, columnCount++, "Total", cellStyleG1));
			
			for (OTReportRes rec : listResult.getResult()) {
				rowCount++;
				columnCount = 0;
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeId(), cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getEmployeeName(), cellStyleLeft));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOt1Value()!=null?Double.parseDouble(rec.getOt1Value()):null, cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOt15Value()!=null?Double.parseDouble(rec.getOt15Value()):null, cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOt3Value()!=null?Double.parseDouble(rec.getOt3Value()):null, cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, rec.getOtTotal()!=null?Double.parseDouble(rec.getOtTotal()):null, cellStyleCenter));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, Double.parseDouble(rec.getTotalAllowance()), cellStyleRight));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, "", cellStyleRight));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, "", cellStyleRight));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, Double.parseDouble(rec.getMobileService()), cellStyleRight));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, Double.parseDouble(rec.getCarAllowance()), cellStyleRight));
				lstExObj.add(new ExcelObject(rowCount, columnCount++, Double.parseDouble(rec.getTaxiFee()), cellStyleRight));
			}

			wb = PoiUtils.createSheet(wb, "OTReport", lstExObj, mergeList, true);
			XSSFSheet sheet = wb.getSheet("OTReport");
			sheet.autoSizeColumn((short) 0);
			sheet.autoSizeColumn((short) 1);
	        
			response.addHeader("Content-Disposition", "attachment; filename=\"OTReport.xlsx\"");
			outputStream = response.getOutputStream();
			wb.write(outputStream);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			outputStream.flush();
			outputStream.close();
			wb.close();
		}
	}

	private JsonResultBean validateCriteria(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg = "";
		String result_data = "";

		if (StringUtils.isEmpty(json.get("spentFrom"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill StartDate";
			return new JsonResultBean(result_status, result_msg, result_data);
		}

		if (StringUtils.isEmpty(json.get("spentTo"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill EndDate";
			return new JsonResultBean(result_status, result_msg, result_data);
		}

		String spentFrom = json.get("spentFrom").toString();
		String spentTo = json.get("spentTo").toString();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date stDate = sdf.parse(spentFrom);
		Date edDate = sdf.parse(spentTo);

		long difference = edDate.getTime() - stDate.getTime();
		float daysBetween = TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);

		if (daysBetween < 0) {
			result_data = "";
			result_status = "error";
			result_msg = "EndDate more than equal StartDate";
			return new JsonResultBean(result_status, result_msg, result_data);
		}

		/*
		 * if ( daysBetween > 31 ) {
		 * 
		 * result_data = ""; result_status = "error"; result_msg =
		 * "StartDate-EndDate not over 31 Days"; return new
		 * JsonResultBean(result_status, result_msg , result_data );
		 * 
		 * }
		 */

		return new JsonResultBean("success", "", "");
	}
	
	private JsonResultBean validateOTReportCriteria(JSONObject json) throws Exception {
		String result_status = "";
		String result_msg = "";
		String result_data = "";

		if (StringUtils.isEmpty(json.get("yearOt"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill Year";
			return new JsonResultBean(result_status, result_msg, result_data);
		}
		if (StringUtils.isEmpty(json.get("monthOt"))) {
			result_data = "";
			result_status = "error";
			result_msg = "Please Fill Accum. to Month";
			return new JsonResultBean(result_status, result_msg, result_data);
		}
		return new JsonResultBean("success", "", "");
	}

	private HrReportCriteria getCriteria(JSONObject json) throws Exception {
		String spentFrom = json.get("spentFrom").toString();
		String spentTo = json.get("spentTo").toString();
		String division = json.get("division").toString();
		String department = json.get("department").toString();
		String section = json.get("section").toString();
		String employeeId = null;
		if (json.get("employeeId") != null) {
			employeeId = json.get("employeeId").toString();
		}
		String employeeType = json.get("employeeType").toString();
		String projectId = json.get("projectId").toString();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat output = new SimpleDateFormat("yyyy-MM-dd");
		Date stDate = sdf.parse(spentFrom);
		String spentFromFmt = output.format(stDate);
		Date edDate = sdf.parse(spentTo);
		String spentToFmt = output.format(edDate);

		HrReportCriteria timeSheetCriteria = new HrReportCriteria();

		if (!StringUtils.isEmpty(spentFromFmt)) {
			timeSheetCriteria.setSpentFrom(spentFromFmt);
		}

		if (!StringUtils.isEmpty(spentToFmt))
			timeSheetCriteria.setSpentTo(spentToFmt);
		if (!StringUtils.isEmpty(division))
			timeSheetCriteria.setDivision(division);
		if (!StringUtils.isEmpty(department))
			timeSheetCriteria.setDepartment(department);
		if (!StringUtils.isEmpty(section))
			timeSheetCriteria.setSection(section);
		if (!StringUtils.isEmpty(employeeId)) {
			String ids = employeeId.replaceAll("\\[|\\]", "");
			List<String> listId = Arrays.asList(ids.split(","));
			if (listId.size() > 1) {
				listId = JsonBeanUtils.jsonToList(employeeId);
			}
			timeSheetCriteria.setEmployeeId(listId);
		}
		if (!StringUtils.isEmpty(employeeType))
			timeSheetCriteria.setEmployeeType(employeeType);
		if (!StringUtils.isEmpty(projectId))
			timeSheetCriteria.setProjectId(projectId);
		return timeSheetCriteria;
	}
	
	private OTReportCriteria getOTReportCriteria(JSONObject json) throws Exception {

		String yearOt = json.get("yearOt").toString();
		String monthOt = json.get("monthOt").toString();
		String division = json.get("division").toString();
		String department = json.get("department").toString();
		String section = json.get("section").toString();
		String employeeId = null;
		if (json.get("employeeId") != null) {
			employeeId = json.get("employeeId").toString();
		}
		String employeeType = json.get("employeeType").toString();

		OTReportCriteria criteria = new OTReportCriteria();

		if (!StringUtils.isEmpty(yearOt)) {
			criteria.setYearOt(yearOt);
		}
		if (!StringUtils.isEmpty(monthOt)) {
			criteria.setMonthOt(monthOt);
		}
		if (!StringUtils.isEmpty(division)) {
			criteria.setDivision(division);
		}
		if (!StringUtils.isEmpty(department)) {
			criteria.setDepartment(department);
		}
		if (!StringUtils.isEmpty(section)) {
			criteria.setSection(section);
		}
		if (!StringUtils.isEmpty(employeeId)) {
			String ids = employeeId.replaceAll("\\[|\\]", "");
			List<String> listId = Arrays.asList(ids.split(","));
			if (listId.size() > 1) {
				listId = JsonBeanUtils.jsonToList(employeeId);
			}
			criteria.setEmployeeId(listId);
		}
		if (!StringUtils.isEmpty(employeeType))
			criteria.setEmployeeType(employeeType);
		return criteria;
	}

}
