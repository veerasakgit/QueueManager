package com.locus.jlo.web.controller;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.module.DocumentTypeSettingBean;
import com.locus.jlo.web.beans.module.DocumentsBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.DocumentTypeSettingService;
import com.locus.jlo.web.services.DocumentsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Locale;
import java.util.Map;


@Slf4j
@Controller
@RequestMapping("docType")
public class DocumentsTypeSettingController extends CoreController {

    @Autowired
    private DocumentTypeSettingService documentTypeSettingService;

    @PostMapping("/searchDocType")
    public @ResponseBody
    JsonResultBean searchDocumentType(@RequestBody DocumentTypeSettingBean bean, HttpServletRequest request, Locale locale) throws Exception {
        ServiceResult<List<Map<String, Object>>> obj = documentTypeSettingService.searchDocumentType(bean);
        JsonResultBean result = null;
        if (obj.isSuccess()) {
            result = new JsonResultBean("success", "", obj.getResult());
        }
        return result;
    }
}