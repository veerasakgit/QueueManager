package com.locus.jlo.web.controller;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.utils.JsonBeanUtils;
import com.locus.jlo.utils.PoiUtils;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriod;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriodRes;
import com.locus.jlo.web.beans.medical.report.MedicalReportSUM;
import com.locus.jlo.web.beans.medical.report.MedicalReportSUMRes;
import com.locus.jlo.web.beans.report.ExcelObject;
import com.locus.jlo.web.beans.report.leave.LeaveReportCriteria;
import com.locus.jlo.web.beans.report.leave.LeaveReportRes;
import com.locus.jlo.web.beans.report.leave.LeaveReportWithFillterRes;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
public class ExcelReportController {
	
	@Autowired
	private ExcelReportService excelReportService;
	
	
	
	
	@RequestMapping(value = {"/attendance_report"})
	public String attendance() {
		return "attendance_report";
	}
	
	@RequestMapping(value = {"/medical_allowance_report_sum"})
	public String medicalSum() {
		return "medical_allowance_report_sum";
	}
	
	@RequestMapping(value = {"/medical_allowance_report_by_period"})
	public String medicalPeriod() {
		return "medical_allowance_report_by_period";
	}
	
	@RequestMapping(value = {"/utilization_accum"})
	public String utillizationAccum() {
		return "utilization_accum";
	}
	
	@RequestMapping(value = {"/utilization_monthly"})
	public String utillizationMonthly() {
		return "utilization_monthly";
	}
	
	@RequestMapping(value = {"/utilization_graph"})
	public String utillizationGraph() {
		return "utilization_graph";
	}
	
	  
	  
	  
		
		
		
		

}
