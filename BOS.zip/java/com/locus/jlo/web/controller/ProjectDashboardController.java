package com.locus.jlo.web.controller;

import lombok.extern.slf4j.Slf4j;

import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.services.ApprovalService;
import com.locus.jlo.web.services.ProjectDashboardService;
import com.locus.jlo.web.services.ReportService;


@Slf4j
@Controller
public class ProjectDashboardController {
	
	
	@Autowired
	private ProjectDashboardService projectDashboardService;
	  

	@RequestMapping(value = "/projectDashboard", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
		public @ResponseBody JsonResultBean projectDashboard(HttpServletRequest request,Locale locale,Principal principal) throws Exception{
	 
		Map<String, Object> m = new HashMap<String, Object>();
		JsonResultBean res = null;
		
		String result_status = "success";
		String result_msg    = "success";
		String result_data   = "";
		
		
		String projectId = request.getParameter("projectId");
		//String monthId = request.getParameter("searchMonth");
		
		String approverId = request.getSession().getAttribute("UID").toString();
		/*
		String projectId = "";
		String deptId = "";
		String staffId = ""; 
		*/
		
		try{
		
			//search project detail summary
			ServiceResult<List<DataBean>> project =  projectDashboardService.searchProjectDashboardDetail(projectId); 
			if( project.isSuccess()){
				m.put("projSummary",project.getResult());
			}
			
			//search project member
			ServiceResult<List<DataBean>> department =  projectDashboardService.searchProjectDashboardMember(projectId); 
			if( department.isSuccess()){
				m.put("projMember",department.getResult());
			}
			
			
			//search project workhour logtime
			ServiceResult<List<DataBean>> staff =  projectDashboardService.searchProjectWorkhourLogtime(projectId); 
			if( staff.isSuccess()){
				m.put("projWh",staff.getResult());
			}
			
			//search project overtime
			ServiceResult<List<DataBean>> approveList =  projectDashboardService.searchProjectOvertimeLogtime(projectId); 
			if( approveList.isSuccess()){
				m.put("projOt",approveList.getResult());
			}
	    
			//search bar graph
			ServiceResult<List<DataBean>> projDash =  projectDashboardService.searchProjectBarGraphLogtime(projectId); 
			if( projDash.isSuccess()){
				m.put("projDash",projDash.getResult());
			}
			
		
		}catch(Exception e){
			 result_status = "fail";
			 result_msg    = "fail";
			
			res = new JsonResultBean(result_status, result_msg , result_data );
			log.info("Error !!"+e);
			e.printStackTrace();
			
		}
		
		res = new JsonResultBean(result_status, result_msg , m );
		return res;
		
	}

		
		
	
}