package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.trainingRecord.TrainingRecordBean;

public interface TrainingRecordService {
	
	ServiceResult<List<Map<String, Object>>> searchTrainingRecord(String year,String userId,String id) throws Exception;
	ServiceResult<Long> insertTrainingRecord(TrainingRecordBean bean) throws Exception;
	ServiceResult<Long> updateTrainingRecord(TrainingRecordBean bean) throws Exception;
	ServiceResult<Long> deleteTrainingRecord(String id) throws Exception;
}
