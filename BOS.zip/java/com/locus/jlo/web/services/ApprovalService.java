package com.locus.jlo.web.services;

import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.account.search.AccountSearchBean;

public interface ApprovalService {
	
	/*inital approval*/
	ServiceResult<List<DataBean>> searchTimesheetApprovalProgress(String year,  String staffId) throws Exception;
	
	ServiceResult<List<DataBean>> initFilterTimesheetProject(String year, String monthId, String approverId) throws Exception;
	ServiceResult<List<KeyValueBean>> initFilterTimesheetApproveAuthorizePerson(String year, String monthId, String approverId) throws Exception;
	ServiceResult<List<KeyValueBean>> initFilterTimesheetProjectForAdminRole(String year, String monthId) throws Exception;
	ServiceResult<List<KeyValueBean>> initFilterTimesheetDepartment(String year, String monthId ,List<String> projectId, String isAdmin ) throws Exception;
	ServiceResult<List<DataBean>> initFilterTimesheetStaff(String year, String monthId, List<String> projectId, String isAdmin, String approverId ) throws Exception;
	
	/*timesheet approval*/
	ServiceResult<List<DataBean>> searchTimesheetApproval(String year, String monthId , String projectId, List<String> staffId ) throws Exception;
	
	ServiceResult<List<DataBean>> searchTimesheetApprovalStaffDetail(String year, String monthId , String staffId, String projectId) throws Exception;
	ServiceResult<List<DataBean>> summaryApprovalTimesheet(String year, String monthId ,String projectId, List<String> staffId) throws Exception;
	
	ServiceResult<Long> staffApprovalAll(List<DataBean> db) throws Exception;
	
	/*ot approval*/
	ServiceResult<List<DataBean>> searchOTApproval(String year, String monthId , String projectId, List<String> staffId  ) throws Exception;
	ServiceResult<List<DataBean>> searchOvertimeStaffDtl(String otId) throws Exception;
	
	/* approval for each staff */
	ServiceResult<Long> approveWorkhour(List<DataBean> db) throws Exception;
	ServiceResult<Long> approveOvertime(List<DataBean> db) throws Exception;
	
	
	/* approval ot detail for staff (only 1 person per time )*/
	ServiceResult<Long> approvedOvertimeStaffDetail( String otId , String approverId )throws Exception;
	ServiceResult<Long> rejectedOvertimeStaffDetail( String otId , String approverId , String data ) throws Exception;
	
	ServiceResult<DataBean> getTimesheetRejectDataByTimeEntries(String eid)throws Exception;

	
	//String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception;
	/*
	ServiceResult<Long> insertLogtime(String pid, String tid, String date, String hour, String status, String uid) throws Exception;
	ServiceResult<Long> updateLogtime(String pid, String tid, String date, String hour, String status, String uid, String eid ) throws Exception;
	ServiceResult<Long> removeLogtime(String eid) throws Exception;
	
	ServiceResult<List<DataBean>> searchTimesheet_beforeSubmit() throws Exception;
	ServiceResult<Long> submitTimesheet(String data_eid) throws Exception;
 
	ServiceResult<Integer> insertLogtime(String id) throws Exception;
	ServiceResult<Integer> updateLogtime(String id) throws Exception;
	ServiceResult<Integer> deleteLogtime(String id) throws Exception;
	*/
	
	ServiceResult<DataBean> searchOTApprovalByAllowanceId(String allwanceId) throws Exception;
}
