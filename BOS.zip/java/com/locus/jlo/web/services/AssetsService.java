package com.locus.jlo.web.services;



import java.util.HashMap;
import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.assets.AssetCriteria;
import com.locus.jlo.web.beans.assets.AssetsBean;
import com.locus.jlo.web.beans.assets.AssetsCustomBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;

public interface AssetsService {
	
	public ServiceResult<AssetsCustomBean> searchAssets(HashMap<String,String> criteria);
	
	public ServiceResult<List<Long>> saveAssets(List<AssetsBean> beans,Integer userId);
	
	public ServiceResult<Long> deleteAssets(Long id);
	
	public ServiceResult<List<AssetsBean>> searchAssetAll(AssetCriteria criteria) throws Exception;
	
	public ServiceResult<List<AssetsBean>> searchAssetUser(AssetCriteria criteria) throws Exception;
	
	
}
