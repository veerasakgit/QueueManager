package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.contacts.ContactBean;
import com.locus.jlo.web.services.ContactService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ContactServiceImpl extends BaseService implements ContactService {

	// Query
	private final String SQL_SEARCH = "CONTACT.SQL_SEARCH";
	private final String SQL_SEARCH_DETAIL = "CONTACT.SQL_SEARCH_DETAIL";
	
	private final String SQL_SEARCH_INDUSTRIES = "INDUSTRIES.SQL_SEARCH";

	// Excute
	private final String SQL_INSERT = "CONTACT.SQL_INSERT";
	private final String SQL_UPDATE = "CONTACT.SQL_UPDATE";
	private final String SQL_DELETE = "CONTACT.SQL_DELETE";
	
	
	@Override
	public ServiceResult<List<Map<String, Object>>> searchContact() throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();

		try {
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH,new SimpleKeyValue("id",""));
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());

		} catch (Exception e) {
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<Map<String, Object>>> searchContactDetail(String id,String is_company,String company_id) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();

		try {
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH_DETAIL
					, new SimpleKeyValue("id",ObjectBeanUtils.isNullStr(id))
					, new SimpleKeyValue("is_company",ObjectBeanUtils.isNullStr(is_company))
					, new SimpleKeyValue("company_id",ObjectBeanUtils.isNullStr(company_id)));
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());

		} catch (Exception e) {
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<Long> insertContact(ContactBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT,Boolean.TRUE,bean);
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
		
	
	}
	@Override
	public ServiceResult<Long> updateContact(ContactBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer id = dynamicJdbcDao.executeUpdate(SQL_UPDATE,bean);
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
		
	
	}
	@Override
	public ServiceResult<Long> deleteContact(String id) throws Exception {
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer delId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(delId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
		
	}

	@Override
	public ServiceResult<List<Map<String, Object>>> searchIndustries() throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();

		try {
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH_INDUSTRIES,new SimpleKeyValue("id",""));
			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: " + serviceResult.getResult().size());

		} catch (Exception e) {
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}




}
