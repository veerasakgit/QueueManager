package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.scheduler.bean.SchedulerBean;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.services.TimesheetSummaryService;


import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class TimesheetSummaryServiceImpl extends BaseService implements TimesheetSummaryService{
	
	String SQL_SUMMARY_TIMESHEET = "TIMESHEET.SUMMARY"; 
	String SQL_SUMMARY_TIMESHEET_DETAIL = "TIMESHEET.SUMMARY_DETAIL"; 
	String SQL_SUMMARY_TIMESHEET_NOTE = "TIMESHEET.SUMMARY_TIMESHEET_NOTE";
	String SQL_SUMMARY_TIMESHEET_OVERTIME = "TIMESHEET.SUMMARY_OVERTIME";
	
	String SQL_SUMMARY_STAFF_PROFILE_DASHBOARD = "TIMESHEET.SUMMARY_STAFF_PROFILE_DASHBOARD";
	String SQL_SUMMARY_REPORT_START_END_DTL = "TIMESHEET.SUMMARY_REPORT_START_END_DTL";
	
	String SQL_SUMMARY_TIMESHEET_OVERALL_PIE_A = "TIMESHEET.OVERALL_TIMSHEET_PIE_GRAPH_A";
	String SQL_SUMMARY_TIMESHEET_OVERALL_PIE_B = "TIMESHEET.OVERALL_TIMSHEET_PIE_GRAPH_B";
	
	String SQL_SUMMARY_UTILIZE = "TIMESHEET.UTILIZE_YEAR";	
	
	String SQL_SEARCH_STAFF_IN_DEPARTMENT = "TIMESHEET.SEARCH_STAFF_IN_DEPARTMENT";
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimesheet(String year,String monthId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{

			result = dynamicJdbcDao.findForList(SQL_SUMMARY_TIMESHEET,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId",monthId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	

	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimesheetDetail(String year, String monthId, String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_SUMMARY_TIMESHEET_DETAIL,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));

			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimesheetNote(String year,String monthId, String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_SUMMARY_TIMESHEET_NOTE,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));
				serviceResult = new ServiceResult<List<DataBean>>(result);
			   System.out.println("searchReportTimesheetNote total records : "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchReportTimeshhetOvertime(String year,String monthId, String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			result = dynamicJdbcDao.findForList(SQL_SUMMARY_TIMESHEET_OVERTIME,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));
				serviceResult = new ServiceResult<List<DataBean>>(result);
			   System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	

	
	@Override
	public ServiceResult<DataBean> searchReportStaffDetail(String staffId) throws Exception{
		ServiceResult<DataBean> serviceResult = new ServiceResult<DataBean>();
	
		try{
		
			DataBean db = dynamicJdbcDao.findForObject(SQL_SUMMARY_STAFF_PROFILE_DASHBOARD,
					BeanPropertyRowMapper.newInstance(DataBean.class),new SimpleKeyValue("staffId",staffId)); 
			
			serviceResult.setResult(db);
			serviceResult.setSuccess(Boolean.TRUE);
		
		//	System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<DataBean>(e);
			serviceResult.setSuccess(Boolean.FALSE);
		}
		return serviceResult;
	}
	
	
	public ServiceResult<List<DataBean>> searchMemberInDept(String staffId) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_STAFF_IN_DEPARTMENT,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("staffId", staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("searchReportTimesheetNote total records : "+serviceResult.getResult().size());
			
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
			serviceResult.setSuccess(Boolean.FALSE);
		}
		return serviceResult;
		
	}
	
	
	
	@Override
	public ServiceResult<DataBean> searchReportStartEndDetail(String year, String monthId) throws Exception{
		ServiceResult<DataBean> serviceResult = new ServiceResult<DataBean>();
		DataBean result = new DataBean();
		try{
			String month = "";
			if( monthId.length() == 1){
				month += "0"+monthId;
			}else{
				month = monthId;
			}
			String date = year+"-"+month+"-01";
			
			result = dynamicJdbcDao.findForObject(SQL_SUMMARY_REPORT_START_END_DTL,
					BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("date",date),
					new SimpleKeyValue("year",year),
					new SimpleKeyValue("monthId",monthId));
			serviceResult = new ServiceResult<DataBean>(result);
		
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<DataBean>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> searchOverallLogitmePieA(String year,String monthId, String staffId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
		
			result = dynamicJdbcDao.findForList(SQL_SUMMARY_TIMESHEET_OVERALL_PIE_A,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("searchReportTimesheetNote total records : "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
			serviceResult.setSuccess(Boolean.FALSE);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> searchOverallLogitmePieB(String year,String monthId, String staffId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
		
			result = dynamicJdbcDao.findForList(SQL_SUMMARY_TIMESHEET_OVERALL_PIE_B,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("monthId", monthId), new SimpleKeyValue("staffId", staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("searchReportTimesheetNote total records : "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
			serviceResult.setSuccess(Boolean.FALSE);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> searchUtilizeSummary(String year, String staffId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
		
			result = dynamicJdbcDao.findForList(SQL_SUMMARY_UTILIZE,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("year", year), new SimpleKeyValue("staffId", staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("searchReportTimesheetNote total records : "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
			serviceResult.setSuccess(Boolean.FALSE);
		}
		return serviceResult;
	}
	

	
	
	/*
	@Override
	public ServiceResult<List<DataBean>> getHolidayConfig(String year, String monthId) throws Exception{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			
			result = dynamicJdbcDao.findForList(SQL_REPORT_GET_HOLIDAY,BeanPropertyRowMapper.newInstance(DataBean.class),new SimpleKeyValue("year",year),new SimpleKeyValue("monthId",monthId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> getHolidayConfigBetweenDate(String startDate, String endDate) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;
		try{
			
			result = dynamicJdbcDao.findForList(SQL_REPORT_GET_HOLIDAY_BETWEEN_DAY,
					BeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("startDate", startDate),new SimpleKeyValue("endDate",endDate));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheet_beforeSubmit() throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_TEIMSHEET_BEFORE_SUBMIT,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("accountName",""));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<Long> submitTimesheet(String data_eid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control data_eid :"+data_eid);
	
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			data_eid = data_eid.replaceAll("\"", "");
			String[] arr = data_eid.split(",");
//			List<String> lst = new ArrayList<>();
			Integer success = 0;
			for(int i=0;i<arr.length;i++){
				log.info("Timesheet control data_eid :"+arr[i]);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_SUBMIT_TIMESHEET, new SimpleKeyValue("data_eid",arr[i]));
				if(cnt==1){
					success++;
				}
			}
			
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	
	
	
	
	@Override
	public ServiceResult<Long> insertLogtime(String pid,String tid,String date,String hour,String status , String uid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_LOGTIME, Boolean.TRUE, new SimpleKeyValue("pid",pid),
																							   new SimpleKeyValue("tid",tid),
																							   new SimpleKeyValue("date",date), 
																							   new SimpleKeyValue("hour",hour),
																							   new SimpleKeyValue("status",status),
																							   new SimpleKeyValue("uid",uid));
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateLogtime(String pid, String tid, String date, String hour, String status, String uid, String eid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		log.info("Timesheet control eid :"+eid);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_LOGTIME, new SimpleKeyValue("pid",pid),
																			   new SimpleKeyValue("tid",tid),
																			   new SimpleKeyValue("date",date), 
																			   new SimpleKeyValue("hour",hour),
																			   new SimpleKeyValue("status",status),
																			   new SimpleKeyValue("uid",uid),
																			   new SimpleKeyValue("eid",eid));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> removeLogtime(String eid) throws Exception {
		 
		//trace parameter
		log.info("Timesheet control eid :"+eid);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_LOGTIME, new SimpleKeyValue("eid",eid));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	/*
	@Override
	public String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception {
		//ServiceResult<String> result = null;
		
		log.info("Timesheet control"+pid);
		 
		String result = "";
		try {
			List<String> lst = dynamicJdbcDao.findForList(SQL_CHECK_LOGTIME, String.class , 
					new SimpleKeyValue("pid",pid));
			  log.info("size : "+lst.size());
			  if(lst.size()>0){
				  result = lst.get(0);
			log.info("Timesheet control"+lst.get(0));
			  }
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
		return result;
	}
  */
}
