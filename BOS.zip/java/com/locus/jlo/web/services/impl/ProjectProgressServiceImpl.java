package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.common.mapper.PrimitiveSafeBeanPropertyRowMapper;
import com.locus.jlo.web.beans.project.MemberTimeEntriesBean;
import com.locus.jlo.web.beans.project.ProjectProgressBean;
import com.locus.jlo.web.beans.project.ProjectProgressResultBean;
import com.locus.jlo.web.services.ProjectProgressService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProjectProgressServiceImpl extends BaseService implements ProjectProgressService{
	
	String SQL_SEARCH = "PROJECT_PROGRESS.SQL_SEARCH";
	
	String SQL_INSERT = "PROJECT_PROGRESS.SQL_INSERT";
	String SQL_UPDATE = "PROJECT_PROGRESS.SQL_UPDATE";
	String SQL_DELETE = "PROJECT_PROGRESS.SQL_DELETE";

	String SQL_DELETE_BY_PROJECT = "PROJECT_PROGRESS.SQL_DELETE_BY_PROJECT";
	
	String SQL_SEARCH_PROGRESS_RESULT = "PROJECT_PROGRESS.SQL_SEARCH_PROGRESS_RESULT";
	String SQL_SEARCH_PROJECT_MEMBER_TIME_ENTRIES = "PROJECT_PROGRESS.SQL_SEARCH_PROJECT_MEMBER_TIME_ENTRIES";
	String SQL_GET_LAST_UPDATE_PROGRESS = "PROJECT_PROGRESS.SQL_QUERY_LAST_UPD";

	@Override
	public ServiceResult<List<Map<String, Object>>> searchProjectProgress(ProjectProgressBean progressBean) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
		try {
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH
					, new SimpleKeyValue("project_id", progressBean.getProject_id())
					, new SimpleKeyValue("id", progressBean.getId()));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<ProjectProgressResultBean>> searchProjectProgressResult(String projectId) throws Exception {
		ServiceResult<List<ProjectProgressResultBean>> serviceResult = new ServiceResult<>();
		try {
			List<ProjectProgressResultBean> result = 
					dynamicJdbcDao.findForList(SQL_SEARCH_PROGRESS_RESULT, BeanPropertyRowMapper.newInstance(ProjectProgressResultBean.class)
					, new SimpleKeyValue("project_id", projectId));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<MemberTimeEntriesBean>> searchProjectMemberTimeEntries(String projectId)
			throws Exception {
		ServiceResult<List<MemberTimeEntriesBean>> serviceResult = new ServiceResult<>();
		try {
			List<MemberTimeEntriesBean> result = 
					dynamicJdbcDao.findForList(SQL_SEARCH_PROJECT_MEMBER_TIME_ENTRIES, BeanPropertyRowMapper.newInstance(MemberTimeEntriesBean.class)
					, new SimpleKeyValue("project_id", projectId));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Integer> insertProjectProgress(ProjectProgressBean progressBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, progressBean ).intValue();
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> updateProjectProgress(ProjectProgressBean progressBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, progressBean);
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> removeProjectProgress(Integer progress_id) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",progress_id));
			result.setResult(res);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> removeProjectProgressByProject(Integer project_id) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE_BY_PROJECT
					,new SimpleKeyValue("project_id",project_id));
			result.setResult(res);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}
	
	@Override
	public ServiceResult<ProjectProgressResultBean> getLastUpdProgress(String projectId) throws Exception {
		ServiceResult<ProjectProgressResultBean> serviceResult = new ServiceResult<>();
		try{
			ProjectProgressResultBean result = dynamicJdbcDao.findForObject(SQL_GET_LAST_UPDATE_PROGRESS
					,PrimitiveSafeBeanPropertyRowMapper.newInstance(ProjectProgressResultBean.class)
					,new SimpleKeyValue("project_id",projectId));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}


}
