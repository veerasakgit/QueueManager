package com.locus.jlo.web.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.assets.AssetCriteria;
import com.locus.jlo.web.beans.assets.AssetsBean;
import com.locus.jlo.web.beans.assets.AssetsCustomBean;
import com.locus.jlo.web.beans.setting.SettingDeptBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.constant.BOSConstant;
import com.locus.jlo.web.services.AssetsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AssetsServiceImpl extends BaseService implements AssetsService {

	final String SQL_SEARCH = "ASSETS.SQL_SEARCH";
	final String SQL_SEARCH_USER = "ASSETS.SQL_SEARCH_USER";
	final String SQL_INSERT = "ASSETS.SQL_INSERT";
	final String SQL_UPDATE = "ASSETS.SQL_UPDATE";
	final String SQL_DELETE = "ASSETS.SQL_DELETE";
	final String SQL_SEARCH_ASSET_ALL = "ASSETS.SQL_SEARCH_ASSET_ALL";
	
	@Override
	public ServiceResult<AssetsCustomBean> searchAssets(HashMap<String, String> criteria) {
		ServiceResult<AssetsCustomBean> serviceResult = null;
		
		try{

			
			List<Map<String, Object>> users = dynamicJdbcDao.findForList(SQL_SEARCH_USER,criteria);
			if (!users.isEmpty()) {
				
				Map<String,Object> user = users.get(0);
				
				
				ObjectBeanUtils<SettingUserBean> settingUserUtils = new ObjectBeanUtils<>(SettingUserBean.class);
				SettingUserBean settingUserBean = settingUserUtils.convertMapToObject(user);
				
				SettingDeptBean settingDeptBean = new SettingDeptBean();
				Integer deptId = settingUserBean.getMain_dept_id()==null?null:settingUserBean.getMain_dept_id();
				settingDeptBean.setId(deptId);
				String deptName = user.get("dept_name")==null? null: user.get("dept_name").toString();
				settingDeptBean.setDept_name(deptName);
				
				AssetsCustomBean bean = new AssetsCustomBean(settingUserBean,settingDeptBean);
				
				List<Map<String, Object>> assetsList = dynamicJdbcDao.findForList(SQL_SEARCH,new SimpleKeyValue("user_id", settingUserBean.getId()));
				if (!CollectionUtils.isEmpty(assetsList)) {
					ObjectBeanUtils<AssetsBean> assetsUtils = new ObjectBeanUtils<>(AssetsBean.class);
					List<AssetsBean> assetsBeans = assetsUtils.convertListMapToObject(assetsList);
					bean.setAssetsBeans(assetsBeans);
				}

				serviceResult = new ServiceResult<AssetsCustomBean>(bean);
			} else {
				serviceResult = new ServiceResult<>(null);
			}

//			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<AssetsCustomBean>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<Long>> saveAssets(List<AssetsBean> beans ,Integer userId) {
		ServiceResult<List<Long>> serviceResult = null;
		try{
						
			List<Long> ids = new ArrayList<>();
			
			if (!CollectionUtils.isEmpty(beans)) {
				
				int seq = 1;
				
				for (AssetsBean bean : beans) {

					try {
						bean.setSeq(seq);
						
						Long id = 0L;
						
						switch (bean.getAction()) {
						case BOSConstant.DBAction.INSERT :
							id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean);
							seq++;
							break;
						case BOSConstant.DBAction.UPDATE :
							id = Long.valueOf(dynamicJdbcDao.executeUpdate(SQL_UPDATE,bean));
							seq++;
							break;
						case BOSConstant.DBAction.DELETE :
//							id = Long.valueOf(dynamicJdbcDao.executeUpdate(SQL_DELETE,bean));
							break;
						default:
							log.error("Not an action");
							break;
						}

						if (id != null && id != 0L) {
							ids .add(id);
						}
						
						
						
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}
			
			serviceResult = new ServiceResult<>(ids);
		
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Long>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> deleteAssets(Long id) {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer delId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(delId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
		
	
	}
	
	@Override
	public ServiceResult<List<AssetsBean>> searchAssetAll(AssetCriteria criteria) throws Exception {
		ServiceResult<List<AssetsBean>> serviceResult = null;
		try {
			
			List<AssetsBean> result = null;

			result = dynamicJdbcDao.findForList(SQL_SEARCH_ASSET_ALL, BeanPropertyRowMapper.newInstance(AssetsBean.class), criteria);

			serviceResult = new ServiceResult<List<AssetsBean>>(result);
			
		} catch (Exception ex) {
			serviceResult = new ServiceResult<List<AssetsBean>>(ex);
		}
		
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<AssetsBean>> searchAssetUser(AssetCriteria criteria) throws Exception {
		ServiceResult<List<AssetsBean>> serviceResult = null;
		try {
			
			List<AssetsBean> result = null;

			result = dynamicJdbcDao.findForList(SQL_SEARCH_USER, BeanPropertyRowMapper.newInstance(AssetsBean.class), criteria);

			serviceResult = new ServiceResult<List<AssetsBean>>(result);
			
		} catch (Exception ex) {
			serviceResult = new ServiceResult<List<AssetsBean>>(ex);
		}
		
		return serviceResult;
	}
	


	

}
