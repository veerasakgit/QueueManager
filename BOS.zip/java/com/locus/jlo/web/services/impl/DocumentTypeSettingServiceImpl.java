package com.locus.jlo.web.services.impl;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.module.DocumentTypeSettingBean;
import com.locus.jlo.web.services.DocumentTypeSettingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class DocumentTypeSettingServiceImpl extends BaseService implements DocumentTypeSettingService {
	
	String SQL_SEARCH = "DOCUMENT_TYPE.SQL_SEARCH";
	
	String SQL_INSERT = "DOCUMENT_TYPE.SQL_INSERT";
	String SQL_UPDATE = "DOCUMENT_TYPE.SQL_UPDATE";
	String SQL_DELETE = "DOCUMENT_TYPE.SQL_DELETE";

	@Override
	public ServiceResult<List<Map<String, Object>>> searchDocumentType(DocumentTypeSettingBean typeSettingBean) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
		try {
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH
					, new SimpleKeyValue("id", typeSettingBean.getId())
					, new SimpleKeyValue("active", typeSettingBean.getActive()));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Integer> insertDocumentType(DocumentTypeSettingBean typeSettingBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, typeSettingBean ).intValue();
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> updateDocumentType(DocumentTypeSettingBean typeSettingBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, typeSettingBean);
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> removeDocumentType(Integer type_id) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",type_id));
			result.setResult(res);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}
}
