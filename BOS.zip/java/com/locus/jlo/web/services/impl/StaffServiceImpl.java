package com.locus.jlo.web.services.impl;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.services.StaffService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class StaffServiceImpl extends BaseService implements StaffService{
	
	String SQL_SEARCH_ORGANIZE = "STAFF.SQL_SEARCH_ORGANIZE";
	String SQL_SEARCH_STAFF_ORGANIZE = "STAFF.SQL_SEARCH_STAFF_ORGANIZE";
	
	

	@Override
	public ServiceResult<List<DataBean>> searchOrganize() throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_ORGANIZE,BeanPropertyRowMapper.newInstance(DataBean.class));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}

	
	
	
	
 
}
