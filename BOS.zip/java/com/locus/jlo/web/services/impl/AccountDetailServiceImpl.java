package com.locus.jlo.web.services.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.account.AccountDetailBean;
import com.locus.jlo.web.services.AccountDetailService;

@Service
public class AccountDetailServiceImpl extends BaseService implements AccountDetailService {
	private Logger logger = Logger.getLogger(getClass());

	final static String SQL_INSERT_ACCOUNT_DETAIL = "ACCOUNT_DETAIL.SQL_INSERT_ACCOUNT_DETAIL";
	final static String SQL_COUNT_ACCOUNT_DETAIL_BY_ID = "ACCOUNT_DETAIL.SQL_COUNT_ACCOUNT_DETAIL_BY_ID";

	@Override
	public ServiceResult<Boolean> saveAccountDetail(AccountDetailBean accountDetailModelBean) {
		ServiceResult<Boolean> result = new ServiceResult<>();
		try {
			// Check Duplicate before insert
			Integer count = dynamicJdbcDao.findForObject(SQL_COUNT_ACCOUNT_DETAIL_BY_ID, new IntegerResultMapper(),accountDetailModelBean);
			if (count > 0) {
				result.setResponseCode("DATA IS DUPPLICATE");
				result.setResponseDescription("Cannot insert account detail with duplicate Data");
				result.setSuccess(Boolean.FALSE);
				return result;
			}
			int row = 0;
			row = dynamicJdbcDao.executeUpdate(SQL_INSERT_ACCOUNT_DETAIL, accountDetailModelBean);
			result = new ServiceResult<>(row > 0 ? Boolean.TRUE : Boolean.FALSE);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			setErrorResult(result, e);
		}
		return result;
	}
	
	@Override
	public ServiceResult<Boolean> updateAccountDetail(AccountDetailBean accountDetailModelBean) {
		// TODO Auto-generated method stub
		return null;
	}
}
