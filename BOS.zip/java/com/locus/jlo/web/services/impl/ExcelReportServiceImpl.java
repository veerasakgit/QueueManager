package com.locus.jlo.web.services.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriod;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriodRes;
import com.locus.jlo.web.beans.medical.report.MedicalReportSUM;
import com.locus.jlo.web.beans.medical.report.MedicalReportSUMRes;
import com.locus.jlo.web.beans.report.attendance.AttendanceReportCriteria;
import com.locus.jlo.web.beans.report.attendance.AttendanceReportRes;
import com.locus.jlo.web.beans.report.hr.HrOvertimeReportRes;
import com.locus.jlo.web.beans.report.hr.HrReportCriteria;
import com.locus.jlo.web.beans.report.hr.HrTimeSheetReportRes;
import com.locus.jlo.web.beans.report.hr.ManHourReportCriteria;
import com.locus.jlo.web.beans.report.hr.ManHourReportRes;
import com.locus.jlo.web.beans.report.hr.OTReportCriteria;
import com.locus.jlo.web.beans.report.hr.OTReportRes;
import com.locus.jlo.web.beans.report.leave.LeaveReportCriteria;
import com.locus.jlo.web.beans.report.leave.LeaveReportRes;
import com.locus.jlo.web.beans.report.leave.LeaveReportWithFillterRes;
import com.locus.jlo.web.beans.report.staff.PmTimesheetReportBean;
import com.locus.jlo.web.beans.report.staff.StaffOvertimeReportRes;
import com.locus.jlo.web.beans.report.staff.StaffReportCriteria;
import com.locus.jlo.web.beans.report.staff.StaffTimeSheetReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationAccumGroupReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationAccumReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationGraphReportCriteria;
import com.locus.jlo.web.beans.report.utilization.UtilizationGraphReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationMonthlyGroupReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationMonthlyReportRes;
import com.locus.jlo.web.services.ExcelReportService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExcelReportServiceImpl extends BaseService implements ExcelReportService{
	
	/* initial */
	String INITIAL_PROJECT = "SQL_REPORT_INITIAL.FILTER_APPROVAL_PROJECT";
	String INITIAL_PROJECT_FOR_ADMIN_ROLE = "SQL_REPORT_INITIAL.FILTER_APPROVAL_PROJECT_FOR_ADMIN_ROLE";
	String INITIAL_STAFF = "SQL_REPORT_INITIAL.FILTER_APPROVAL_STAFF";
	String INITIAL_STAFF_FOR_ADMIN_ROLE = "SQL_REPORT_INITIAL.FILTER_APPROVAL_STAFF_FOR_ADMIN_ROLE";
	
	String MEDICAL_ALLOWANCEREPORT_BY_PERIOD = "SQL_SEARCH.MEDICAL_ALLOWANCEREPORT_BY_PERIOD";
	String MEDICAL_ALLOWANCEREPORT_BY_PERIOD_LIST = "SQL_SEARCH.MEDICAL_ALLOWANCEREPORT_BY_PERIOD_LIST";
	String MEDICAL_ALLOWANCEREPORT_SUM_LIST = "SQL_SEARCH.MEDICAL_ALLOWANCEREPORT_SUM_LIST";
	String MEDICAL_ALLOWANCEREPORT_SUM = "SQL_SEARCH.MEDICAL_ALLOWANCEREPORT_SUM";
	
	String LEAVE_REPORT_ALL = "SQL_SEARCH.LEAVE_REPORT_ALL"; 
	String LEAVE_REPORT_ANNUAL_LEAVE = "SQL_SEARCH.LEAVE_REPORT_ANNUAL_LEAVE";
	String LEAVE_REPORT_OTHER_LEAVE = "SQL_SEARCH.LEAVE_REPORT_OTHER_LEAVE";
	String ATTENDANCE_DIVISION_REPORT = "SQL_SEARCH.ATTENDANCE_DIVISION_REPORT";
	String ATTENDANCE_DEPARTMENT_REPORT = "SQL_SEARCH.ATTENDANCE_DEPARTMENT_REPORT";
	String HR_TIMESHEET = "SQL_SEARCH.HR_TIMESHEET";
	String HR_OVERTIME = "SQL_SEARCH.HR_OVERTIME";
	String STAFF_TIMESHEET = "SQL_SEARCH.STAFF_TIMESHEET";
	String STAFF_OVERTIME = "SQL_SEARCH.STAFF_OVERTIME";
	
	String PM_TIMESHEET_REPORT = "SQL_SEARCH.PM_TIMESHEET_REPORT";
	
	String INITIAL_PROJECT_FOR_PM = "SQL_REPORT_INITIAL.INITIAL_PROJECT_FOR_PM";
	String INITIAL_STAFF_FOR_PM = "SQL_REPORT_INITIAL.INITIAL_STAFF_FOR_PM";
	
	String UTILIZATION_GRAPH_REPORT = "SQL_SEARCH.UTILIZATION_GRAPH_REPORT";
	String UTILIZATION_MONTHLY_REPORT = "SQL_SEARCH.UTILIZATION_MONTHLY_REPORT";
	String UTILIZATION_MONTHLY_GROUP_REPORT = "SQL_SEARCH.UTILIZATION_MONTHLY_GROUP_REPORT";
	String UTILIZATION_ACCUM_REPORT = "SQL_SEARCH.UTILIZATION_ACCUM_REPORT";
	String UTILIZATION_ACCUM_GROUP_REPORT = "SQL_SEARCH.UTILIZATION_ACCUM_GROUP_REPORT";
	
	String OT_REPORT = "SQL_SEARCH.OT_REPORT";
	String MAN_HOUR_TIMESHEET_REPORT = "SQL_SEARCH.MAN_HOUR_TIMESHEET_REPORT";
	String MAN_HOUR_OVERTIME_REPORT = "SQL_SEARCH.MAN_HOUR_OVERTIME_REPORT";
	String UTILIZATION_MAN_DAY = "SQL_SEARCH.UTILIZATION_MAN_DAY";
	
	@Override
	public  ServiceResult<List<MedicalReportByPeriodRes>> searchMedicalAllowanceReportByPeriod(MedicalReportByPeriod medicalReport) throws Exception {
		ServiceResult<List<MedicalReportByPeriodRes>> serviceResult = null;
		try{	
			List<MedicalReportByPeriodRes> result = null;
			//List<Map<String, Object>> result = dynamicJdbcDao.findForList(MEDICAL_ALLOWANCEREPORT_BY_PERIOD,medicalReport);
//			if(null == medicalReport.getEmployeeNameOne()) {
//				log.info("SQL_SEARCH.MEDICAL_ALLOWANCEREPORT_BY_PERIOD_LIST");
//				result = dynamicJdbcDao.findForList(MEDICAL_ALLOWANCEREPORT_BY_PERIOD_LIST,BeanPropertyRowMapper.newInstance(MedicalReportByPeriodRes.class),medicalReport);
//			}else if(null != medicalReport.getEmployeeNameOne()) {
				log.info("SQL_SEARCH.MEDICAL_ALLOWANCEREPORT_BY_PERIOD");
				result = dynamicJdbcDao.findForList(MEDICAL_ALLOWANCEREPORT_BY_PERIOD,BeanPropertyRowMapper.newInstance(MedicalReportByPeriodRes.class),medicalReport);
//			}
			//serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			serviceResult = new ServiceResult<List<MedicalReportByPeriodRes>>(result);
			/*if(serviceResult.getResult()==null) {
			}*/
		} catch(Exception e) {
			//serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
			serviceResult = new ServiceResult<List<MedicalReportByPeriodRes>>(e);
		}
		return serviceResult;
	
	}
	
	@Override
	public  ServiceResult<List<MedicalReportSUMRes>> searchMedicalAllowanceReportSum(MedicalReportSUM medicalReportSum) throws Exception {
		ServiceResult<List<MedicalReportSUMRes>> serviceResult = null;
		try{	
			List<MedicalReportSUMRes> result = null;
			//List<Map<String, Object>> result = dynamicJdbcDao.findForList(MEDICAL_ALLOWANCEREPORT_BY_PERIOD,medicalReport);
//			log.info("EmployeeName : "+medicalReportSum.getEmployeeNameOne());
//			if(null == medicalReportSum.getEmployeeNameOne()) {
//				log.info("SQL_SEARCH.MEDICAL_ALLOWANCEREPORT_SUM_LIST");
				//log.info("year : "+medicalReportSum.getYear());
//				result = dynamicJdbcDao.findForList(MEDICAL_ALLOWANCEREPORT_SUM_LIST,BeanPropertyRowMapper.newInstance(MedicalReportSUMRes.class),medicalReportSum);
//			}else if(null != medicalReportSum.getEmployeeNameOne()) {
			log.info("SQL_SEARCH.MEDICAL_ALLOWANCEREPORT_SUM");
			result = dynamicJdbcDao.findForList(MEDICAL_ALLOWANCEREPORT_SUM,BeanPropertyRowMapper.newInstance(MedicalReportSUMRes.class),medicalReportSum);
//			}
			//serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			/*for(MedicalReportSUMRes test : result) {
				System.out.println("DataRes : "+test.toString() );
			}*/
			serviceResult = new ServiceResult<List<MedicalReportSUMRes>>(result);
			/*if(serviceResult.getResult()==null) {
				c
			}*/
		} catch(Exception e) {
			//serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
			serviceResult = new ServiceResult<List<MedicalReportSUMRes>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<LeaveReportRes>> searchLeaveReport(LeaveReportCriteria leaveReportCriteria)
			throws Exception {
		ServiceResult<List<LeaveReportRes>> serviceResult = null;
		try {
			
			List<LeaveReportRes> result = null;

			result = dynamicJdbcDao.findForList(LEAVE_REPORT_ALL, BeanPropertyRowMapper.newInstance(LeaveReportRes.class), leaveReportCriteria);

			serviceResult = new ServiceResult<List<LeaveReportRes>>(result);
			
		} catch (Exception ex) {
			serviceResult = new ServiceResult<List<LeaveReportRes>>(ex);
		}
		
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<LeaveReportWithFillterRes>> searchLeaveReportFillter(LeaveReportCriteria leaveReportCriteria)
			throws Exception {
		ServiceResult<List<LeaveReportWithFillterRes>> serviceResult = null;
		try {
			
			List<LeaveReportWithFillterRes> result = null;
			String SQL_SEARCH_LEAVE = "";
			
			
			if (!StringUtils.isEmpty(leaveReportCriteria.getLeaveType())) {
				 if (leaveReportCriteria.getLeaveType() .equals("1")) { // Annaul leave
					 SQL_SEARCH_LEAVE = LEAVE_REPORT_ANNUAL_LEAVE;
				 } else {
					 SQL_SEARCH_LEAVE = LEAVE_REPORT_OTHER_LEAVE;
				 }
				 result = dynamicJdbcDao.findForList(SQL_SEARCH_LEAVE, BeanPropertyRowMapper.newInstance(LeaveReportWithFillterRes.class), leaveReportCriteria);

			 }
			
			serviceResult = new ServiceResult<List<LeaveReportWithFillterRes>>(result);
			
		} catch (Exception ex) {
			serviceResult = new ServiceResult<List<LeaveReportWithFillterRes>>(ex);
		}
		
		return serviceResult;
	}

	@Override
	public ServiceResult<List<AttendanceReportRes>> searchAttendanceReport (AttendanceReportCriteria attendanceReportCriteria) throws Exception {
		ServiceResult<List<AttendanceReportRes>> serviceResult = null;
		try {
			List<AttendanceReportRes> result = null;
			String SQL_SEARCH_ATTENDANCE = "";
			if (!StringUtils.isEmpty(attendanceReportCriteria.getReportType())) {
				 if (attendanceReportCriteria.getReportType() .equals("1")) { // Division
					 SQL_SEARCH_ATTENDANCE = ATTENDANCE_DIVISION_REPORT;
				 } else { // Department
					 SQL_SEARCH_ATTENDANCE = ATTENDANCE_DEPARTMENT_REPORT;
				 }
				 result = dynamicJdbcDao.findForList(SQL_SEARCH_ATTENDANCE, BeanPropertyRowMapper.newInstance(AttendanceReportRes.class), attendanceReportCriteria);
			}
			if(result != null && result.size() <= 2) {
				result = null;
				serviceResult = new ServiceResult<List<AttendanceReportRes>>();
			} else {
				serviceResult = new ServiceResult<List<AttendanceReportRes>>(result);
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<AttendanceReportRes>>(ex);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<HrTimeSheetReportRes>> searchHrTimeSheetReport(HrReportCriteria timeSheetCriteria)
			throws Exception {
		ServiceResult<List<HrTimeSheetReportRes>> serviceResult = null;
		try {
			
			List<HrTimeSheetReportRes> result = null;

			result = dynamicJdbcDao.findForList(HR_TIMESHEET, BeanPropertyRowMapper.newInstance(HrTimeSheetReportRes.class), timeSheetCriteria);

			serviceResult = new ServiceResult<List<HrTimeSheetReportRes>>(result);
			
		} catch (Exception ex) {
			serviceResult = new ServiceResult<List<HrTimeSheetReportRes>>(ex);
		}
		
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<HrOvertimeReportRes>> searchHrOvertimeReport(HrReportCriteria overtimeCriteria)
			throws Exception {
		ServiceResult<List<HrOvertimeReportRes>> serviceResult = null;
		try {
			
			List<HrOvertimeReportRes> result = null;

			result = dynamicJdbcDao.findForList(HR_OVERTIME, BeanPropertyRowMapper.newInstance(HrOvertimeReportRes.class), overtimeCriteria);

			serviceResult = new ServiceResult<List<HrOvertimeReportRes>>(result);
			
		} catch (Exception ex) {
			serviceResult = new ServiceResult<List<HrOvertimeReportRes>>(ex);
		}
		
		return serviceResult;
	}

	@Override
	public ServiceResult<List<StaffTimeSheetReportRes>> searchStaffTimeSheetReport(StaffReportCriteria timeSheetCriteria)
			throws Exception {
		ServiceResult<List<StaffTimeSheetReportRes>> serviceResult = null;
		try {
			
			List<StaffTimeSheetReportRes> result = null;

			result = dynamicJdbcDao.findForList(STAFF_TIMESHEET, BeanPropertyRowMapper.newInstance(StaffTimeSheetReportRes.class), timeSheetCriteria);

			serviceResult = new ServiceResult<List<StaffTimeSheetReportRes>>(result);
			
		} catch (Exception ex) {
			serviceResult = new ServiceResult<List<StaffTimeSheetReportRes>>(ex);
		}
		
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<StaffOvertimeReportRes>> searchStaffOvertimeReport(StaffReportCriteria overtimeCriteria)
			throws Exception {
		ServiceResult<List<StaffOvertimeReportRes>> serviceResult = null;
		try {
			
			List<StaffOvertimeReportRes> result = null;

			result = dynamicJdbcDao.findForList(STAFF_OVERTIME, BeanPropertyRowMapper.newInstance(StaffOvertimeReportRes.class), overtimeCriteria);

			serviceResult = new ServiceResult<List<StaffOvertimeReportRes>>(result);
			
		} catch (Exception ex) {
			serviceResult = new ServiceResult<List<StaffOvertimeReportRes>>(ex);
		}
		
		return serviceResult;
	}

	@Override
	public ServiceResult<List<KeyValueBean>> initFilterProject(String isAdmin, String approverId) throws Exception {
		ServiceResult<List<KeyValueBean>> serviceResult = null;
		List<KeyValueBean> result = null;
		try{
			
			if (isAdmin.equals("Y")) {
				result = dynamicJdbcDao.findForList(INITIAL_PROJECT_FOR_ADMIN_ROLE, BeanPropertyRowMapper.newInstance(KeyValueBean.class));
			} else {
				result = dynamicJdbcDao.findForList(INITIAL_PROJECT, BeanPropertyRowMapper.newInstance(KeyValueBean.class),
						 new SimpleKeyValue("approverId",approverId));
			}
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<DataBean>> initFilterStaff(List<String> projectId, String isAdmin, String approverId) throws Exception
	{
		ServiceResult<List<DataBean>> serviceResult = null;
		try
		{
			Calendar cal = Calendar.getInstance();
			Date endDate = cal.getTime();
			
			cal.set(Calendar.DATE, 1);
			Date startDate = cal.getTime();
			
			serviceResult = initFilterStaff(projectId, isAdmin, approverId, startDate/*, endDate*/);
			
		}catch(Exception e)
		{
			log.info("error "+e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	@Override
	public ServiceResult<List<DataBean>> initFilterStaff(List<String> projectId, String isAdmin, String approverId, Date startDate/*, Date endDate*/ ) throws Exception
	{
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
			
			if (isAdmin.equals("Y")) {
				log.debug("=== Query for Admin =====> ");
				result = dynamicJdbcDao.findForList(INITIAL_STAFF_FOR_ADMIN_ROLE
													, BeanPropertyRowMapper.newInstance(DataBean.class)
													
													, new SimpleKeyValue("projectId",projectId)
													, new SimpleKeyValue("startDate", startDate)
													/*, new SimpleKeyValue("endDate", endDate)*/ );
			} else {
				log.debug("=== Query for Approver =====> ");
				result = dynamicJdbcDao.findForList(INITIAL_STAFF
												, BeanPropertyRowMapper.newInstance(DataBean.class)
												
												, new SimpleKeyValue("approverId", approverId )
												, new SimpleKeyValue("projectId",projectId)
												, new SimpleKeyValue("startDate", startDate)
												/*, new SimpleKeyValue("endDate", endDate)*/ );
			}
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<DataBean>> searchPmTimeSheetReport(PmTimesheetReportBean pmCriteria)throws Exception {
		ServiceResult<List<DataBean>> serviceResult = null;
		try {
			
			List<DataBean> result = null;

			result = dynamicJdbcDao.findForList(PM_TIMESHEET_REPORT, BeanPropertyRowMapper.newInstance(DataBean.class), pmCriteria);

			serviceResult = new ServiceResult<List<DataBean>>(result);
			
		} catch (Exception ex) {
			serviceResult = new ServiceResult<List<DataBean>>(ex);
		}
		
		return serviceResult;
	}

	@Override
	public ServiceResult<List<KeyValueBean>> initFilterProjectForPm(String isAdmin, String userId)
			throws Exception {
		ServiceResult<List<KeyValueBean>> serviceResult = null;
		List<KeyValueBean> result = null;
		try{
			
			result = dynamicJdbcDao.findForList(INITIAL_PROJECT_FOR_PM, BeanPropertyRowMapper.newInstance(KeyValueBean.class),
					new SimpleKeyValue("userId",userId) );
			serviceResult = new ServiceResult<List<KeyValueBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<KeyValueBean>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<DataBean>> initFilterStaffForPm(List<String> projectId, String isAdmin, String userId)
			throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
			
			result = dynamicJdbcDao.findForList(INITIAL_STAFF_FOR_PM,BeanPropertyRowMapper.newInstance(DataBean.class),
				new SimpleKeyValue("projectId",projectId) );
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.info("error "+e);
			e.printStackTrace();
			
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<UtilizationGraphReportRes>> searchUtilizationGraphReport (UtilizationGraphReportCriteria criteria) throws Exception {
		ServiceResult<List<UtilizationGraphReportRes>> serviceResult = null;
		try {
			List<UtilizationGraphReportRes> result = dynamicJdbcDao.findForList(UTILIZATION_GRAPH_REPORT, BeanPropertyRowMapper.newInstance(UtilizationGraphReportRes.class), criteria);
			serviceResult = new ServiceResult<List<UtilizationGraphReportRes>>(result);
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<UtilizationGraphReportRes>>(ex);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<UtilizationMonthlyReportRes>> searchUtilizationMonthlyReport (UtilizationGraphReportCriteria criteria) throws Exception {
		ServiceResult<List<UtilizationMonthlyReportRes>> serviceResult = null;
		try {
			List<UtilizationMonthlyReportRes> result = dynamicJdbcDao.findForList(UTILIZATION_MONTHLY_REPORT, BeanPropertyRowMapper.newInstance(UtilizationMonthlyReportRes.class), criteria);
			serviceResult = new ServiceResult<List<UtilizationMonthlyReportRes>>(result);
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<UtilizationMonthlyReportRes>>(ex);
		}
		return serviceResult;
	}
	

	@Override
	public ServiceResult<List<UtilizationMonthlyGroupReportRes>> searchUtilizationMonthlyGroupReport (UtilizationGraphReportCriteria criteria) throws Exception {
		ServiceResult<List<UtilizationMonthlyGroupReportRes>> serviceResult = null;
		try {
			List<UtilizationMonthlyGroupReportRes> result = dynamicJdbcDao.findForList(UTILIZATION_MONTHLY_GROUP_REPORT, BeanPropertyRowMapper.newInstance(UtilizationMonthlyGroupReportRes.class), criteria);
			serviceResult = new ServiceResult<List<UtilizationMonthlyGroupReportRes>>(result);
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<UtilizationMonthlyGroupReportRes>>(ex);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<UtilizationAccumReportRes>> searchUtilizationAccumReport (UtilizationGraphReportCriteria criteria) throws Exception {
		ServiceResult<List<UtilizationAccumReportRes>> serviceResult = null;
		try {
			List<UtilizationAccumReportRes> result = dynamicJdbcDao.findForList(UTILIZATION_ACCUM_REPORT, BeanPropertyRowMapper.newInstance(UtilizationAccumReportRes.class), criteria);
			serviceResult = new ServiceResult<List<UtilizationAccumReportRes>>(result);
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<UtilizationAccumReportRes>>(ex);
		}
		return serviceResult;
	}
	

	@Override
	public ServiceResult<List<UtilizationAccumGroupReportRes>> searchUtilizationAccumGroupReport (UtilizationGraphReportCriteria criteria) throws Exception {
		ServiceResult<List<UtilizationAccumGroupReportRes>> serviceResult = null;
		try {
			List<UtilizationAccumGroupReportRes> result = dynamicJdbcDao.findForList(UTILIZATION_ACCUM_GROUP_REPORT, BeanPropertyRowMapper.newInstance(UtilizationAccumGroupReportRes.class), criteria);
			serviceResult = new ServiceResult<List<UtilizationAccumGroupReportRes>>(result);
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<UtilizationAccumGroupReportRes>>(ex);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<OTReportRes>> searchOTReport (OTReportCriteria criteria) throws Exception {
		ServiceResult<List<OTReportRes>> serviceResult = null;
		try {
			List<OTReportRes> result = dynamicJdbcDao.findForList(OT_REPORT, BeanPropertyRowMapper.newInstance(OTReportRes.class), criteria);
			serviceResult = new ServiceResult<List<OTReportRes>>(result);
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<OTReportRes>>(ex);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<ManHourReportRes>> searchManHourTimeSheetReport (ManHourReportCriteria criteria) throws Exception {
		ServiceResult<List<ManHourReportRes>> serviceResult = null;
		try {
			List<ManHourReportRes> result = dynamicJdbcDao.findForList(MAN_HOUR_TIMESHEET_REPORT, BeanPropertyRowMapper.newInstance(ManHourReportRes.class), criteria);
			serviceResult = new ServiceResult<List<ManHourReportRes>>(result);
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<ManHourReportRes>>(ex);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<ManHourReportRes>> searchManHourOverTimeReport (ManHourReportCriteria criteria) throws Exception {
		ServiceResult<List<ManHourReportRes>> serviceResult = null;
		try {
			List<ManHourReportRes> result = dynamicJdbcDao.findForList(MAN_HOUR_OVERTIME_REPORT, BeanPropertyRowMapper.newInstance(ManHourReportRes.class), criteria);
			serviceResult = new ServiceResult<List<ManHourReportRes>>(result);
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<ManHourReportRes>>(ex);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<UtilizationAccumReportRes>> searchManDayFromUtilization (UtilizationGraphReportCriteria criteria) throws Exception {
		ServiceResult<List<UtilizationAccumReportRes>> serviceResult = null;
		try {
			List<UtilizationAccumReportRes> result = dynamicJdbcDao.findForList(UTILIZATION_MAN_DAY, BeanPropertyRowMapper.newInstance(UtilizationAccumReportRes.class), criteria);
			serviceResult = new ServiceResult<List<UtilizationAccumReportRes>>(result);
		} catch (Exception ex) {
			ex.printStackTrace();
			serviceResult = new ServiceResult<List<UtilizationAccumReportRes>>(ex);
		}
		return serviceResult;
	}
	
}
