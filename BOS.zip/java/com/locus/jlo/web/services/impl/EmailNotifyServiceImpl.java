package com.locus.jlo.web.services.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.account.AccountDetailBean;
import com.locus.jlo.web.beans.leaveForm.LeaveFormDetailBean;
import com.locus.jlo.web.services.AccountDetailService;
import com.locus.jlo.web.services.EmailNotifyService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EmailNotifyServiceImpl extends BaseService implements EmailNotifyService {


	final static String SQL_FIND_APPROVAL_EMAIL_BY_PROJECT_ID = "EMAIL_NOTIFY.SQL_FIND_APPROVAL_EMAIL_BY_PROJECT_ID";
	final static String SQL_FIND_APPROVAL_EMAIL_BY_INTERNAL_PROJECT = "EMAIL_NOTIFY.SQL_FIND_APPROVAL_EMAIL_BY_INTERNAL_PROJECT";
	final static String SQL_FIND_SUBMIT_WORKHOUR_DATA = "EMAIL_NOTIFY.SQL_FIND_SUBMIT_TIMESHEET_WORKHOUR_DATA";
	final static String SQL_FIND_SUBMIT_OT_DATA = "EMAIL_NOTIFY.SQL_FIND_SUBMIT_TIMESHEET_OT_DATA";
	final static String SQL_QRY_UTILIZE_HOUR_SUMMARY = "EMAIL_NOTIFY.QRY_UTILIZE_HOUR_SUMMARY"; 
	final static String SQL_QRY_TIMESHEET_UTILIZE_HOUR = "EMAIL_NOTIFY.QRY_TIMESHEET_UTILIZE_HOUR";
	final static String SQL_QRY_TIMESHEET_REJECT_DATA = "EMAIL_NOTIFY.SQL_QRY_TIMESHEET_REJECT_DATA";
		
	@Override
	public ServiceResult<List<DataBean>> findApprovalEmailByProjectId( String project_id , String user_id) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			//find in project type != 0 ( not internal project )
			result = dynamicJdbcDao.findForList(SQL_FIND_APPROVAL_EMAIL_BY_PROJECT_ID,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("project_id",project_id));
			
			//log.info("Implement project size ---------------> :"+result.size());
			//check internal project type = 0 
			if( result.size() == 0){
				result = dynamicJdbcDao.findForList(SQL_FIND_APPROVAL_EMAIL_BY_INTERNAL_PROJECT,BeanPropertyRowMapper.newInstance(DataBean.class)
						,new SimpleKeyValue("user_id",user_id));
				
				//log.info("Internal project size ---------------> :"+result.size());
				
			} 
			
			
		
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
	
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> qryTimesheetWorkhourData( String project_id , String user_id , String month_id , String year) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try {
			
			result = dynamicJdbcDao.findForList(SQL_FIND_SUBMIT_WORKHOUR_DATA,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("project_id",project_id),new SimpleKeyValue("user_id",user_id)
					,new SimpleKeyValue("month_id",month_id),new SimpleKeyValue("year",year));
			 
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
				
		} catch (Exception e) {
			log.info("submitWorkhour Error: "+e);
		}
	
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> qryTimesheetOTData( String project_id , String user_id , String month_id , String year) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try {
			
			result = dynamicJdbcDao.findForList(SQL_FIND_SUBMIT_OT_DATA,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("project_id",project_id),new SimpleKeyValue("user_id",user_id)
					,new SimpleKeyValue("month_id",month_id),new SimpleKeyValue("year",year));
			 
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
				
		} catch (Exception e) {
			log.info("submitWorkhour Error: "+e);
		}
	
		return serviceResult;
	}
	
	
	
	
	
	@Override
	public ServiceResult<List<DataBean>> qryUtilizeHourSummary(String month_id , String year) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try {
			
			
			result = dynamicJdbcDao.findForList(SQL_QRY_UTILIZE_HOUR_SUMMARY,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("month_id",month_id),new SimpleKeyValue("year",year));
			 
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
				
		} catch (Exception e) {
			log.info("submitWorkhour Error: "+e);
		}
	
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> getTimesheetRejectData(String month_id, String year , String project_id, String user_id) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try {
			
			result = dynamicJdbcDao.findForList(SQL_QRY_TIMESHEET_REJECT_DATA,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("month_id",month_id)
					,new SimpleKeyValue("year",year)
					,new SimpleKeyValue("project_id",project_id)
					,new SimpleKeyValue("user_id",user_id));
			 
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
				
		} catch (Exception e) {
			log.info("get timesheet reject data error: "+e);
		}
	
		return serviceResult;
	}
	

	 

}
