package com.locus.jlo.web.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.common.mapper.PrimitiveSafeBeanPropertyRowMapper;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.system.dto.LoginDTO;
import com.locus.jlo.web.beans.system.dto.UserAuthenDTO;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.modelbean.MenuDetailModelBean;
import com.locus.jlo.web.services.UserManagementService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("userManagementService")
public class UserManagementServiceImpl extends BaseService implements UserManagementService {

    public static final String SQL_LOGIN_BY_USER_LOGIN_ID = "USER.SQL_LOGIN_BY_USER_ID"; 
    public static final String SQL_USER_MENU_PRIVILEGES = "USER.SQL_USER_MENU_PRIVILEGES";
    public static final String SQL_USER_LOGIN_PROFILE = "USER.SQL_USER_LOGIN_PROFILE";
    
    public static final String SQL_USER_LOGIN_LOG_TIMESTAMP = "USER.SQL_USER_LOGIN_LOG_TIMESTAMP";

    @Override
    public ServiceResult<UserAuthenDTO> getAuthentication(String userName) {
    	
        ServiceResult<UserAuthenDTO> serviceResult = new ServiceResult<>();
        UserAuthenDTO uAuthen;
        
        try {
        	log.info("userName: "+userName);
        	 uAuthen = dynamicJdbcDao.findForObject(SQL_LOGIN_BY_USER_LOGIN_ID,
                    PrimitiveSafeBeanPropertyRowMapper.newInstance(UserAuthenDTO.class), new SimpleKeyValue("USER_ID", userName));
        
    	     if(uAuthen != null) {
	    	   serviceResult.setResult(uAuthen);
               serviceResult.setSuccess(true);
               
             }else{
            	 
        	   serviceResult.setSuccess(false);
               serviceResult.setResponseCode("USR00001");
               serviceResult.setResponseDescription("Record is not found");
             }
    	     
        	
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            e.printStackTrace();
            setErrorResult(serviceResult, e);
        }
        return serviceResult;
    }
    
    @Override
    public ServiceResult<LoginDTO> getLoginInfo(String userName) {
        ServiceResult<LoginDTO> loginServiceResult = new ServiceResult<>();
        ServiceResult<UserInfoDTO> userServiceResult = new ServiceResult<>();
        LoginDTO loginInfo;
        try {
        	log.info("userName: "+userName);
        	
        	UserAuthenDTO uAuthen = dynamicJdbcDao.findForObject(SQL_LOGIN_BY_USER_LOGIN_ID,
                     PrimitiveSafeBeanPropertyRowMapper.newInstance(UserAuthenDTO.class), new SimpleKeyValue("USER_ID", userName));
         
     	     if(uAuthen != null){
             
     	        List<GrantedAuthority> result = new ArrayList<>();
                result.add((GrantedAuthority) new SimpleGrantedAuthority("LOGIN_READ"));
                  
                log.info("userLogin : "+uAuthen.getLogin());
                log.info("userAuthenMode : "+uAuthen.getAuthenMode());
                if(uAuthen.getAuthenMode() != null){
 	               	if(uAuthen.getAuthenMode().equals("1")){
 	               		  log.info("userPass  : ****** ");
 	               	}else if(uAuthen.getAuthenMode().equals("2")){
 	               		  log.info("userPass  : ****** ");
 	               		uAuthen.setPassword("*****");
 	               	}
                } 
                //set login
                loginInfo = new LoginDTO(uAuthen.getLogin(), uAuthen.getPassword(), result , uAuthen.getAuthenMode());
                
                //set user info DTO
                UserInfoDTO userInfo = dynamicJdbcDao.findForObject(SQL_USER_LOGIN_PROFILE,
                        PrimitiveSafeBeanPropertyRowMapper.newInstance(UserInfoDTO.class), new SimpleKeyValue("USER_ID", userName));
                
                userServiceResult.setResult(userInfo);
                loginInfo.setUserInfo(userServiceResult.getResult());
                loginServiceResult.setResult(loginInfo);
                loginServiceResult.setSuccess(true);
                
            	//log user login timestamp
            	dynamicJdbcDao.executeUpdate(SQL_USER_LOGIN_LOG_TIMESTAMP,  
            		   PrimitiveSafeBeanPropertyRowMapper.newInstance(UserInfoDTO.class), new SimpleKeyValue("UID", userInfo.getUid()));
         
            } else {
            	loginServiceResult.setSuccess(false);
            	loginServiceResult.setResponseCode("USR00002");
            	loginServiceResult.setResponseDescription("UserId is not found or invalid.");
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(loginServiceResult, e);
        }
        return loginServiceResult;
    }
    
    
    @Override
    public ServiceResult<UserInfoDTO> getUserInfo(String userId) {
        ServiceResult<UserInfoDTO> serviceResult = new ServiceResult<>();
        
        log.info("get user info: "+userId);
        try{
        
        	UserInfoDTO result = dynamicJdbcDao.findForObject(SQL_USER_LOGIN_PROFILE,
                   PrimitiveSafeBeanPropertyRowMapper.newInstance(UserInfoDTO.class), new SimpleKeyValue("USER_ID", userId));
        	
        
           
            if(result != null) {
             	log.info("result user is not null ");
             	
                serviceResult.setResult(result);
                serviceResult.setSuccess(true);
            }else{
            	log.info("result user is  null");
                serviceResult.setSuccess(false);
                serviceResult.setResponseCode("USR00001");
                serviceResult.setResponseDescription("Record is not found");
            }
        } catch (Exception e) {
        	e.printStackTrace();
            log.error(e.getMessage(), e);
            setErrorResult(serviceResult, e);
        }
        return serviceResult;
    }
    
    
    /*
    @Override
    public ServiceResult<UserInfoDTO> getMenuInfo(String userId) {
        ServiceResult<UserInfoDTO> serviceResult = new ServiceResult<>();
        try {
        	UserInfoDTO result = dynamicJdbcDao.findForObject(SQL_USER_LOGIN_PROFILE,
                   PrimitiveSafeBeanPropertyRowMapper.newInstance(UserInfoDTO.class), new SimpleKeyValue("USER_ID", userId));
            
           // UserInfoDTO result = dynamicJdbcDao.findForObject(SQL_STAFF_LOGIN_PROFILE,
            		 //         PrimitiveSafeBeanPropertyRowMapper.newInstance(UserInfoDTO.class), new SimpleKeyValue("USER_ID", userId));
            

            if (result == null) {
                serviceResult.setSuccess(false);
                serviceResult.setResponseCode("USR00001");
                serviceResult.setResponseDescription("Record is not found");
            } else {
                serviceResult.setResult(result);
                serviceResult.setSuccess(true);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(serviceResult, e);
        }
        return serviceResult;
    }
    */
    
    
    
    /* success login handler qry staff profile into session 
    @Override
    public ServiceResult<DataBean> getUserSessionProfile(String userId) {
    	log.info("get user session profile : "+userId);
        ServiceResult<DataBean> serviceResult = new ServiceResult<>();
        try {
        	DataBean result = dynamicJdbcDao.findForObject(SQL_STAFF_LOGIN_PROFILE, PrimitiveSafeBeanPropertyRowMapper.newInstance(DataBean.class), new SimpleKeyValue("staffId", userId));
        	log.info("result return");
            if (result == null) {
            	log.info("return null");
                serviceResult.setSuccess(false);
                serviceResult.setResponseCode("USR00001");
                serviceResult.setResponseDescription("Record is not found");
            } else {
            	log.info("return resulted");
            	//serviceResult = new ServiceResult(result);
                serviceResult.setResult(result);
                serviceResult.setSuccess(true);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(serviceResult, e);
        }
        
        return serviceResult;
    }
    */
    
}
