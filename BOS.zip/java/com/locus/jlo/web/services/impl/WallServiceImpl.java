package com.locus.jlo.web.services.impl;

import java.util.List;
import java.util.Set;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.services.WallService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class WallServiceImpl extends BaseService implements WallService{
	
	String SQL_SEARCH_WALL = "WALL.SQL_SEARCH_WALL";
	String SQL_INSERT_WALL_POST = "WALL.INSERT_WALL_POST";
	String SQL_UPDATE_WALL_POST = "WALL.UPDATE_WALL_POST";
	String SQL_DELETE_WALL_POST = "WALL.DELETE_WALL_POST";
	

	@Override
	public ServiceResult<List<DataBean>> searchWall() throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_WALL,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("user_id","43"));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<Long> insertWallPost( String uid, String msg ) throws Exception {
		
		//trace parameter
		log.info("Timesheet control msg :"+msg);
		log.info("Timesheet control uid :"+uid);
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_WALL_POST, Boolean.TRUE, new SimpleKeyValue("uid",uid) , new SimpleKeyValue("msg",msg) );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateWallPost( String uid,String msgid, String msg) throws Exception {
		
		//trace parameter
		log.info("Timesheet control msg :"+msg);
		log.info("Timesheet control uid :"+uid);
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer id = dynamicJdbcDao.executeUpdate(SQL_UPDATE_WALL_POST,  new SimpleKeyValue("uid",uid) , new SimpleKeyValue("msgid",msgid), new SimpleKeyValue("msg",msg));
				result.setResult(id.longValue());
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> removeWallPost( String uid,String msgid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control msg :"+msgid);
		log.info("Timesheet control uid :"+uid);
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Integer id = dynamicJdbcDao.executeUpdate(SQL_DELETE_WALL_POST, new SimpleKeyValue("uid",uid) ,  new SimpleKeyValue("msgid",msgid) );
				result.setResult(id.longValue());
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	
 
}
