package com.locus.jlo.web.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.utils.ObjectBeanUtils;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.trainingRecord.TrainingRecordBean;
import com.locus.jlo.web.services.TrainingRecordService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class TrainingRecordServiceImpl extends BaseService implements TrainingRecordService{

	//Query
	final String SQL_SEARCH = "TRAINING_RECORD.SQL_SEARCH";
//	final String SQL_SEARCH_DETAIL = "SETTING_CALENDAR.SQL_SEARCH_SETTING_CALENDAR_DETAIL";
	//Excute
	final String SQL_INSERT = "TRAINING_RECORD.SQL_INSERT";
	final String SQL_UPDATE = "TRAINING_RECORD.SQL_UPDATE";
	final String SQL_DELETE = "TRAINING_RECORD.SQL_DELETE";
	
	@Override
	public ServiceResult<List<Map<String, Object>>> searchTrainingRecord(String year,String userId,String id) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<List<Map<String, Object>>>();
			
		
		try{

			Map<String, Object> param = new HashMap<>(3);
			param.put("year", ObjectBeanUtils.isNullStr(year));
			param.put("userId", ObjectBeanUtils.isNullStr(userId));
			param.put("id", ObjectBeanUtils.isNullStr(id));
			
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH, param);

			serviceResult = new ServiceResult<List<Map<String, Object>>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<Map<String, Object>>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Long> insertTrainingRecord(TrainingRecordBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, bean );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}

	@Override
	public ServiceResult<Long> updateTrainingRecord(TrainingRecordBean bean) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE,bean);
				result.setResult(Long.valueOf(id));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}

	@Override
	public ServiceResult<Long> deleteTrainingRecord(String id) throws Exception {

		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
			
				final int returnId = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",id));
				result.setResult(Long.valueOf(returnId));
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
	           setErrorResult(result, e);
		}
		return result;
	 
	}
	
}
