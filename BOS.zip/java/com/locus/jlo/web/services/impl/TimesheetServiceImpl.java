package com.locus.jlo.web.services.impl;

import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.timesheet.OvertimeBean;
import com.locus.jlo.web.beans.timesheet.TimesheetNoteBean;
import com.locus.jlo.web.services.TimesheetService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class TimesheetServiceImpl extends BaseService implements TimesheetService{
	
	String SQL_SEARCH_TIMESHEET = "TIMESHEET.SQL_SEARCH_TIMESHEET";
	String SQL_SEARCH_TIMESHEET_BY_ID = "TIMESHEET.SQL_SEARCH_TIMESHEET_BY_ID";
	
	// is this used ? 
	String SQL_SEARCH_TIMSHEET_SUMMARY = "TIMESHEET.SQL_SEARCH_TIMESHEET_SUMMARY";
	String SQL_SEARCH_OVERTIME_SUMMARY = "TIMESHEET.SQL_SEARCH_OVERTIME_SUMMARY";
	String SQL_SEARCH_MONTH_UTILIZE = "TIMESHEET.SQL_SEARCH_MONTH_UTILIZE";
	
	String SQL_SEARCH_MONTHLY_APPROVE_PROGRESS = "TIMESHEET.SQL_SEARCH_MONTHLY_APPROVE_PROGRESS";
	
	//update stauts to submit
	String SQL_SUBMIT_WORKHOUR = "TIMESHEET.SQL_SUBMIT_WORKHOUR";
	String SQL_SUBMIT_OVERTIME = "TIMESHEET.SQL_SUBMIT_OVERTIME";
	
	//deprecate
	String SQL_CHECK_LOGTIME = "TIMESHEET.CHECK_LOGTIME";
	
	String SQL_INSERT_LOGTIME = "TIMESHEET.INSERT_LOGTIME";
	String SQL_UPDATE_LOGTIME = "TIMESHEET.UPDATE_LOGTIME";
	String SQL_REMOVE_LOGTIME = "TIMESHEET.DELETE_LOGTIME";
	
	String SQL_SEARCH_OT = "TIMESHEET.SEARCH_OVERTIME";
	String SQL_SEARCH_OT_DETAIL = "TIMESHEET.SEARCH_OVERTIME_DETAIL";
	String SQL_AVAILABLE_PROJECT_TASK = "TIMESHEET.SEARCH_AVAILABLE_PROJECT_TASK";
	String SQL_INSERT_OT = "TIMESHEET.SQL_INSERT_OVERTIME";
	String SQL_UPDATE_OT = "TIMESHEET.SQL_UPDATE_OVERTIME";
	String SQL_REMOVE_OT = "TIMESHEET.SQL_REMOVE_OVERTIME";
	
	String SQL_SEARCH_TIMESHEET_NOTE = "TIMESHEET.SEARCH_TIMESHEET_NOTE";
	String SQL_SEARCH_TIMESHEET_NOTE_DETAIL = "TIMESHEET.SEARCH_TIMESHEET_NOTE_DETAIL";
	String SQL_INSERT_NOTE = "TIMESHEET.SQL_INSERT_NOTE";
	String SQL_UPDATE_NOTE = "TIMESHEET.SQL_UPDATE_NOTE";
	String SQL_REMOVE_NOTE = "TIMESHEET.SQL_REMOVE_NOTE";
	
	//LOG FOR MONITOR TRANSACTION
	String SQL_TIME_ENTRIES_MOINTOR = "TIMESHEET.TIME_ENTRIES_MONITOR";
	String SQL_TIME_SHEET_NOTE_MONITOR = "TIMESHEET.TIME_SHEET_NOTE_MONITOR";
	String SQL_TIME_SHEET_OT_MONITOR = "TIMESHEET.TIME_SHEET_OT_MONITOR";
	
	String SQL_SEARCH_TIMESHEET_SUMMARY_FOR_PM = "TIMESHEET.SQL_SEARCH_TIMESHEET_SUMMARY_FOR_PM";
	String SQL_SEARCH_OVERTIME_SUMMARY_FOR_PM = "TIMESHEET.SQL_SEARCH_OVERTIME_SUMMARY_FOR_PM";
		
	@Override
	public ServiceResult<List<DataBean>> searchTimesheet(int monthid , int year , String staffId ) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			String month = Integer.toString(monthid);
			if(monthid < 10){
				month = "0"+monthid;
			}
			String yearmonth = year+""+month;
			log.info("yearmonth:"+yearmonth);
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_TIMESHEET,BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("monthid",monthid),new SimpleKeyValue("year",year),new SimpleKeyValue("uid",staffId), new SimpleKeyValue("yearmonth",yearmonth) );
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetById( String time_entry_id ) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_TIMESHEET_BY_ID,BeanPropertyRowMapper.newInstance(DataBean.class),new SimpleKeyValue("time_entry_id",time_entry_id));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Database return result : "+serviceResult.getResult().size());
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	
	
//------------------------------Timesheet note
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetNote(int monthId , int year , String staffId ) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		log.info("monthid: "+monthId);
		log.info("year "+year);
		log.info("uid: "+staffId);
		
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_TIMESHEET_NOTE,BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("monthId",monthId),new SimpleKeyValue("year",year),new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetNoteDetail(String noteDate , String staffId ) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		log.info("noteDate: "+noteDate);
		log.info("staffId : "+staffId);
		
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_TIMESHEET_NOTE_DETAIL,BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("noteDate",noteDate),new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	
	
	public ServiceResult<Long> insertTimesheetNote(TimesheetNoteBean tnb) throws Exception {

		final ServiceResult<Long> result = new ServiceResult<>();
		
		log.info("id: "+tnb.getId());
		log.info("seq "+tnb.getSeq());
		
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_NOTE, Boolean.TRUE, tnb );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	public ServiceResult<Long> updateTimesheetNote(TimesheetNoteBean tnb) throws Exception {

		log.info("id: "+tnb.getId());
		log.info("seq "+tnb.getSeq());
		
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_NOTE, Boolean.TRUE, tnb );
				result.setResult(cnt.longValue());
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	public ServiceResult<Long> removeTimesheetNote(String noteid) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
				final Integer cnt  = dynamicJdbcDao.executeUpdate(SQL_REMOVE_NOTE, Boolean.TRUE, new SimpleKeyValue("id",noteid) );
				result.setResult(cnt.longValue());
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           setErrorResult(result, e);
		}
		return result;
	
	}
//---------------------------End timesheet note --------------	

	
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetSummary(String year, String monthId, String staffId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_TIMSHEET_SUMMARY,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("year",year),new SimpleKeyValue("monthId",monthId),new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchOvertimeSummary(String year, String monthId, String staffId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_OVERTIME_SUMMARY,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("year",year),new SimpleKeyValue("monthId",monthId),new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element searchOvertimeSummary :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	
	
	@Override
	public ServiceResult<List<DataBean>> searchMonthUtilize(String year, String monthId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_MONTH_UTILIZE,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("year",year),new SimpleKeyValue("monthId",monthId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	@Override
	public ServiceResult<List<DataBean>> searchMonthlyPercentApprove(int year, String staffId) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_MONTHLY_APPROVE_PROGRESS,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("year",year),new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}
	
	
	
	
	@Override
	public ServiceResult<Long> submitWorkhour(List<DataBean> db) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			List<DataBean> arr = db;
			int dataLength = arr.size();
			Integer success = 0;
			for(int a=0;a<dataLength;a++){ 
				
				DataBean d = arr.get(a);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_SUBMIT_WORKHOUR, new SimpleKeyValue("entry_id",d.getA()) 
						, new SimpleKeyValue("status",d.getB()) 
						, new SimpleKeyValue("hours",d.getE()) 
						, new SimpleKeyValue("staffId",d.getC()));
				if(cnt==1){
					success++;
				}
			}  
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			log.info("submitWorkhour Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> submitOvertime(List<DataBean> db) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			List<DataBean> arr = db;
			int dataLength = arr.size();
			Integer success = 0;
			for(int i=0;i<dataLength;i++){
				DataBean d = arr.get(i);
				final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_SUBMIT_OVERTIME, new SimpleKeyValue("entry_id",d.getA()) , new SimpleKeyValue("status",d.getB()) , new SimpleKeyValue("staffId",d.getC()));
				if(cnt==1){
					success++;
				}
			}
			result.setResult(success.longValue());
            result.setSuccess(Boolean.TRUE);
			
		} catch (Exception e) {
			log.info("submitOvertime Error: "+e);
		}
	
		return result;
	}
	
	
	
	
	//---------------------------Start timesheet overtime
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetOvertime(int monthId , int year , String staffId ) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_OT,BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("monthId",monthId),new SimpleKeyValue("year",year),new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchTimesheetOvertimeDetail(String otDate, String staffId ) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_OT_DETAIL,BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("otDate",otDate) ,new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	@Override
	public ServiceResult<List<DataBean>> searchAvailableProjectTask(int monthId , int year , String staffId ) throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			String month = Integer.toString(monthId);
			if(monthId < 10){
				month = "0"+monthId;
			}
			String yearmonth = year+""+month;
			
			result = dynamicJdbcDao.findForList(SQL_AVAILABLE_PROJECT_TASK,BeanPropertyRowMapper.newInstance(DataBean.class),
					new SimpleKeyValue("yearmonth",yearmonth),new SimpleKeyValue("staffId",staffId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	
	
	@Override
	public ServiceResult<Long> insertLogtime(String pid,String tid,Date date,String hour,String status , String uid) throws Exception {
		
		//trace parameter
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_LOGTIME, Boolean.TRUE, new SimpleKeyValue("pid",pid),
																							   new SimpleKeyValue("tid",tid),
																							   new SimpleKeyValue("date",date), 
																							   new SimpleKeyValue("hour",hour),
																							   new SimpleKeyValue("status",status),
																							   new SimpleKeyValue("uid",uid));
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateLogtime(String pid, String tid, Date date, String hour, String status, String uid, String id) throws Exception {
		
		//trace parameter
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		log.info("Timesheet control eid :"+id);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_LOGTIME, new SimpleKeyValue("pid",pid),
																			   new SimpleKeyValue("tid",tid),
																			   new SimpleKeyValue("date",date), 
																			   new SimpleKeyValue("hour",hour),
																			   new SimpleKeyValue("status",status),
																			   new SimpleKeyValue("uid",uid),
																			   new SimpleKeyValue("id",id));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> removeLogtime(String id) throws Exception {
		 
		//trace parameter
		log.info("Timesheet control id :"+id);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_LOGTIME, new SimpleKeyValue("id",id));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	//--------------------------- timesheet Overtime
	@Override
	public ServiceResult<Long> insertOvertime(OvertimeBean ot)throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_OT, Boolean.TRUE, ot );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			   log.error(e.getMessage(), e);
			   e.printStackTrace();
	           setErrorResult(result, e);
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateOvertime(OvertimeBean ot) throws Exception {
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_OT,ot);
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> removeOvertime(String id) throws Exception {
		 
		//trace parameter
		log.info("Timesheet control id :"+id);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_OT, new SimpleKeyValue("id",id));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
	
		return result;
	}

	@Override
	public ServiceResult<List<DataBean>> searchTimesheetSummaryForPm(String year, String monthId, String staffId,String projectId)
			throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_SEARCH_TIMESHEET_SUMMARY_FOR_PM,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("year",year),new SimpleKeyValue("monthId",monthId),new SimpleKeyValue("staffId",staffId),new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<List<DataBean>> searchOvertimeSummaryForPm(String year, String monthId, String staffId,String projectId)
			throws Exception {
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		try{
			result = dynamicJdbcDao.findForList(SQL_SEARCH_OVERTIME_SUMMARY_FOR_PM,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("year",year),new SimpleKeyValue("monthId",monthId),new SimpleKeyValue("staffId",staffId),new SimpleKeyValue("projectId",projectId));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element searchOvertimeSummary :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
			e.printStackTrace();
		}
		return serviceResult;
	}
	
	/*
	@Override
	public String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception {
		//ServiceResult<String> result = null;
		
		log.info("Timesheet control"+pid);
		 
		String result = "";
		try {
			List<String> lst = dynamicJdbcDao.findForList(SQL_CHECK_LOGTIME, String.class , 
					new SimpleKeyValue("pid",pid));
			  log.info("size : "+lst.size());
			  if(lst.size()>0){
				  result = lst.get(0);
			log.info("Timesheet control"+lst.get(0));
			  }
			
		} catch (Exception e) {
			log.info("Timesheet control Error: "+e);
		}
		return result;
	}
  */
}
