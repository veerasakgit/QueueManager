package com.locus.jlo.web.services.impl;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.IdentifyKeyBean;
import com.locus.jlo.web.services.IdentifyKeyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class IdentifyKeyServiceImpl extends BaseService implements IdentifyKeyService {
    private static final String SQL_SEARCH = "IDENTIFY.SQL_SEARCH";

    private static final String  SQL_INSERT = "IDENTIFY.SQL_INSERT";
    private static final String  SQL_UPDATE = "IDENTIFY.SQL_UPDATE";
    private static final String  SQL_DELETE = "IDENTIFY.SQL_DELETE";

    @Override
    public ServiceResult<List<Map<String, Object>>> searchIdentifyKey(IdentifyKeyBean identifyKeyBean) throws Exception {
        ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
        try{
            List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH
                    , new SimpleKeyValue("id", identifyKeyBean.getId()));
            serviceResult.setResult(result);
            serviceResult.setSuccess(Boolean.TRUE);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            setErrorResult(serviceResult, e);
        }
        return serviceResult;
    }

    @Override
    public ServiceResult<Integer> insertIdentifyKey(String typePD, String uniqueName, String projectName, Integer createUid) throws Exception {
        IdentifyKeyBean identifyKeyBean = new IdentifyKeyBean();
        identifyKeyBean.setType_PD(typePD);
        identifyKeyBean.setUnique_name(uniqueName);
        identifyKeyBean.setCreate_uid(createUid);
        identifyKeyBean.setName(projectName);
        final ServiceResult<Integer> result = new ServiceResult<>();
        try{
            final Integer id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE, identifyKeyBean ).intValue();
            result.setResult(id);
            result.setSuccess(Boolean.TRUE);
        }catch(Exception e){
            log.error(e.getMessage(), e);
            setErrorResult(result, e);
            throw e;
        }
        return result;
    }

    @Override
    public ServiceResult<Integer> updateIdentifyKeyBean(IdentifyKeyBean identifyKeyBean) throws Exception {
        final ServiceResult<Integer> result = new ServiceResult<>();
        try{
            final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, identifyKeyBean);
            result.setResult(id);
            result.setSuccess(Boolean.TRUE);
        }catch(Exception e){
            log.error(e.getMessage(), e);
            setErrorResult(result, e);
            throw e;
        }
        return result;
    }

    @Override
    public ServiceResult<Integer> removeIdentifyKeyBean(Integer iden_id) throws Exception {
        final ServiceResult<Integer> result = new ServiceResult<>();
        try{
            final Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("id",iden_id));
            result.setResult(res);
            result.setSuccess(Boolean.TRUE);
        }catch(Exception e){
            log.error(e.getMessage(), e);
            setErrorResult(result, e);
            throw e;
        }
        return result;
    }

}
