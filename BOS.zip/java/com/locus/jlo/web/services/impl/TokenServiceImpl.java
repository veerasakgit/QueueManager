package com.locus.jlo.web.services.impl;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Service;
import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.leaveForm.LeaveFormDetailBean;
import com.locus.jlo.web.beans.tokenBean.TokenBean;
import com.locus.jlo.web.services.LeaveFormService;
import com.locus.jlo.web.services.TokenService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class TokenServiceImpl extends BaseService implements TokenService{
	
	//String SQL_SEARCH_LEAVE_REQ = "LEAVE_FORM.SQL_SEARCH_LEAVE_REQ";
	//String SQL_SEARCH_LEAVE_FORM = "LEAVE_FORM.SQL_SEARCH_LEAVE_FORM";
	String SQL_INSERT_TOKEN = "BOS_TOKEN.INSERT_TOKEN"; 
	String SQL_UPDATE_TOKEN = "BOS_TOKEN.UPDATE_TOKEN"; 
	String SQL_REMOVE_BY_TOKEN_ID = "BOS_TOKEN.REMOVE_TOKEN_BY_TOKEN_ID"; 
	String SQL_REMOVE_BY_NOTIFY_ID = "BOS_TOKEN.REMOVE_TOKEN_BY_NOTIFY_ID";
	

	
	String SQL_VERIFY_TOKEN = "BOS_TOKEN.VERIFY";
	
	
	@Override
	public ServiceResult<List<DataBean>> verifyToken(String token,String verify_token) throws Exception{
		
		ServiceResult<List<DataBean>> serviceResult = new ServiceResult<List<DataBean>>();
		List<DataBean> result = null;	
		
		try{
			
			result = dynamicJdbcDao.findForList(SQL_VERIFY_TOKEN,BeanPropertyRowMapper.newInstance(DataBean.class)
					,new SimpleKeyValue("token",token) ,new SimpleKeyValue("verify_token",verify_token));
			
			serviceResult = new ServiceResult<List<DataBean>>(result);
			System.out.println("Element result :: "+serviceResult.getResult().size());
			
		}catch(Exception e){
			serviceResult = new ServiceResult<List<DataBean>>(e);
			log.error("Token verify sql error: "+e.getMessage(), e);
	        e.printStackTrace();
		}
		return serviceResult;
		
	}
	
	@Override
	public ServiceResult<Long> insertToken(TokenBean tkb) throws Exception {
		
		//trace parameter
		final ServiceResult<Long> result = new ServiceResult<>();
	
		try{
				final Long id = dynamicJdbcDao.executeInsert(SQL_INSERT_TOKEN, Boolean.TRUE, tkb );
				result.setResult(id);
	            result.setSuccess(Boolean.TRUE);
		}catch(Exception e){ 
			
			   log.error("Token inseret sql error: "+e.getMessage(), e);
	           e.printStackTrace();
		}
		return result;
	
	}
	
	@Override
	public ServiceResult<Long> updateToken(TokenBean tkb) throws Exception {
		
		//trace parameter
		/*
		log.info("Timesheet control pid :"+pid);
		log.info("Timesheet control tid :"+tid);
		log.info("Timesheet control date :"+date);
		log.info("Timesheet control hour :"+hour);
		log.info("Timesheet control uid :"+uid);
		log.info("Timesheet control eid :"+eid);
		*/
		
		final ServiceResult<Long> result = new ServiceResult<>();
		try{
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_UPDATE_TOKEN, tkb );
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Token update sql error: "+e);
			e.printStackTrace();
		}
	
		return result;
	}
	
	
	@Override
	public ServiceResult<Long> removeTokenById(String id) throws Exception {
		 
		//trace parameter
		log.info("Remove token id :"+id);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_BY_TOKEN_ID, new SimpleKeyValue("token_id",id));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Token delete sql error: "+e);
		}
	
		return result;
	}
	
	@Override
	public ServiceResult<Long> removeTokenByNofifyId(String id) throws Exception {
		 
		//trace parameter
		log.info("Remove token id :"+id);
				
		final ServiceResult<Long> result = new ServiceResult<>();
		try {
			
			final Integer cnt = dynamicJdbcDao.executeUpdate(SQL_REMOVE_BY_NOTIFY_ID, new SimpleKeyValue("notify_id",id));
			
			result.setResult(cnt.longValue());
            result.setSuccess(Boolean.TRUE);
		
			
		} catch (Exception e) {
			log.info("Token delete sql error: "+e);
		}
	
		return result;
	}
	
	
	
	
 
}
