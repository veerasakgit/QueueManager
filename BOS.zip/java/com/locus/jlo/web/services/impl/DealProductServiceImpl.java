package com.locus.jlo.web.services.impl;

import com.locus.common.domain.ServiceResult;
import com.locus.common.domain.SimpleKeyValue;
import com.locus.jlo.web.beans.deals.DealProductBean;
import com.locus.jlo.web.services.DealProductService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class DealProductServiceImpl extends BaseService implements DealProductService {
	
	String SQL_SEARCH = "DEAL_PRODUCT.SQL_SEARCH";
	
	String SQL_INSERT = "DEAL_PRODUCT.SQL_INSERT";
	String SQL_UPDATE = "DEAL_PRODUCT.SQL_UPDATE";
	String SQL_DELETE = "DEAL_PRODUCT.SQL_DELETE";

	@Override
	public ServiceResult<List<Map<String, Object>>> searchDealProduct(DealProductBean dealProductBean) throws Exception {
		ServiceResult<List<Map<String, Object>>> serviceResult = new ServiceResult<>();
		try{
			List<Map<String, Object>> result = dynamicJdbcDao.findForList(SQL_SEARCH
					, new SimpleKeyValue("deal_id", dealProductBean.getDeal_id()));
			serviceResult.setResult(result);
			serviceResult.setSuccess(Boolean.TRUE);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			setErrorResult(serviceResult, e);
		}
		return serviceResult;
	}

	@Override
	public ServiceResult<Integer> insertDealProduct(DealProductBean dealProductBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer id = dynamicJdbcDao.executeInsert(SQL_INSERT, Boolean.TRUE,
					dealProductBean ).intValue();
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> updateDealProduct(DealProductBean dealProductBean) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final int id = dynamicJdbcDao.executeUpdate(SQL_UPDATE, dealProductBean);
			result.setResult(id);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

	@Override
	public ServiceResult<Integer> removeDealProjectByDeal(Integer deal_id) throws Exception {
		final ServiceResult<Integer> result = new ServiceResult<>();
		try{
			final Integer res = dynamicJdbcDao.executeUpdate(SQL_DELETE,new SimpleKeyValue("deal_id",deal_id));
			result.setResult(res);
			result.setSuccess(Boolean.TRUE);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			setErrorResult(result, e);
			throw e;
		}
		return result;
	}

}
