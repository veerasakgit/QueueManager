package com.locus.jlo.web.services;

import com.locus.jlo.web.beans.RoleBean;
import java.util.List;

public interface DemoService {

    List<RoleBean> getUserRoles() throws Exception;
}
