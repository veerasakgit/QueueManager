package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.TreeParentBean;
import com.locus.jlo.web.beans.system.modelbean.MenuDetailModelBean;

import java.util.List;

public interface SettingPrivilegesService {

    ServiceResult<List<MenuDetailModelBean>> searchMenuByUserPermission(Integer uid)throws Exception;
 
    
    ServiceResult<List<MenuDetailModelBean>> searchMenuByAdminRole()throws Exception;
    

    ServiceResult<List<MenuDetailModelBean>> initialMenuByDepartment(MenuDetailModelBean menuBean)throws Exception;

    ServiceResult<Integer> updatePrivileges(List<MenuDetailModelBean> menuDetailModelBeanList, Integer uid);
    
    ServiceResult<List<TreeParentBean>> getTreeDepartmentPrivileges() throws Exception;
    ServiceResult<Long> insertPrivileges(MenuDetailModelBean bean);
    
    

}
