package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;

public interface BashService {
	
	//public ServiceResult<Long> autoUpdateProbationDate();
	public ServiceResult<Long> autoUpdatePassProbation() throws Exception;
	
	public ServiceResult<Long> reCalLeaveHour(String userId);
	
	
}
