package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.deals.DealProductBean;

import java.util.List;
import java.util.Map;


public interface DealProductService {

	ServiceResult<List<Map<String, Object>>> searchDealProduct(DealProductBean dealProductBean) throws Exception;

	ServiceResult<Integer> insertDealProduct(DealProductBean dealProductBean) throws Exception;
	ServiceResult<Integer> updateDealProduct(DealProductBean dealProductBean) throws Exception;
	ServiceResult<Integer> removeDealProjectByDeal(Integer deal_id) throws Exception;
}
