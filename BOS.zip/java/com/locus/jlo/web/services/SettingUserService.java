package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;
import com.locus.jlo.web.beans.setting.SettingUserProfileBean;
import com.locus.jlo.web.beans.task.TaskAssigneeBean;
import com.locus.jlo.web.beans.task.TaskBean;

public interface SettingUserService {
	
	ServiceResult<List<Map<String, Object>>> searchSettingUserList(String userStatus) throws Exception;
	
	ServiceResult<List<Map<String, Object>>> searchSettingUser(String id,String userStatus,String deptId) throws Exception;
	ServiceResult<List<Map<String, Object>>> searchSettingUserDetail(String id) throws Exception;
	
	//String checkSettingUser(String field,String action) throws Exception;
	
	ServiceResult<Long> insertSettingUser(SettingUserBean settingUserBean) throws Exception;
	ServiceResult<Long> updateSettingUser(SettingUserBean settingUserBean) throws Exception;
	ServiceResult<Long> removeSettingUser(String user_id) throws Exception;
	
	ServiceResult<Long> userStatusUpdate(String id,int userStatus) throws Exception;
	ServiceResult<Integer> saveImportSettingUser(SettingUserBean bean) throws Exception;
	ServiceResult<Integer> saveImportSettingUserProfile(SettingUserProfileBean bean) throws Exception;
	
	/*
	
	//
	
	
	ServiceResult<List<DataBean>> searchTimesheet_beforeSubmit() throws Exception;
	ServiceResult<Long> submitTimesheet(String data_eid) throws Exception;


	ServiceResult<Integer> insertLogtime(String id) throws Exception;
	ServiceResult<Integer> updateLogtime(String id) throws Exception;
	ServiceResult<Integer> deleteLogtime(String id) throws Exception;
	*/
	
	ServiceResult<SettingUserBean> searchUserDetailById(String id) throws Exception;
	ServiceResult<List<TaskBean>> searchTaskListByProjectId(String projectId, String userId) throws Exception;
	ServiceResult<int[]> insertInsertTaskAssignee(List<TaskAssigneeBean> taskAssigneeList);
	ServiceResult<TaskAssigneeBean> searchTimesheetTaskAssigneeByUserId(String userId,String projectId) throws Exception;
	ServiceResult<Long> deleteTimesheetTaskAssigneeByUserId(String userId,String projectId) throws Exception;
	
	ServiceResult<List<DataBean>> findCurrentDeptProjectId(List<String> deptId) throws Exception;
	ServiceResult<Long> deleteOldTaskAssignee(String userId,List<String> projectId) throws Exception;
}
