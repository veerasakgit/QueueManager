package com.locus.jlo.web.services;

import java.util.Date;
import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.account.search.AccountSearchBean;
import com.locus.jlo.web.beans.leaveForm.LeaveFormDetailBean;

public interface LeaveFormService {
	 
	ServiceResult<List<DataBean>> searchLeaveReq(String year,String request_from_me, String request_to_me, String leaveStatus, String leaveType) throws Exception;
	ServiceResult<List<DataBean>> searchLeaveReqDetail(String leave_id) throws Exception;
	ServiceResult<List<DataBean>> findApproval(String user_id) throws Exception;
	ServiceResult<DataBean> findLeaveOnSameDay(String user_id, String start_date , String end_date) throws Exception;
	ServiceResult<List<DataBean>> findAllowLeaveOnProbation(String user_id) throws Exception;
	
	
	ServiceResult<Long> recheckAllowLeaveOnProbation(LeaveFormDetailBean leaveForm) throws Exception;
	
	ServiceResult<Long> insertLeaveForm(LeaveFormDetailBean leaveForm) throws Exception;
	ServiceResult<Long> updateLeaveForm(LeaveFormDetailBean leaveForm) throws Exception;
	
	ServiceResult<Long> updateLeaveApprove(LeaveFormDetailBean leaveForm) throws Exception;
	ServiceResult<Long> updateLeaveReject(LeaveFormDetailBean leaveForm) throws Exception;
	ServiceResult<Long> updateLeaveCancel(LeaveFormDetailBean leaveForm) throws Exception;
	
	//currently not used
	ServiceResult<Long> removeLeaveForm(String leave_id) throws Exception;
	
	
	//String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception;
	/*
	
	
	ServiceResult<List<DataBean>> searchTimesheet_beforeSubmit() throws Exception;
	ServiceResult<Long> submitTimesheet(String data_eid) throws Exception;

	
	ServiceResult<Integer> insertLogtime(String id) throws Exception;
	ServiceResult<Integer> updateLogtime(String id) throws Exception;
	ServiceResult<Integer> deleteLogtime(String id) throws Exception;
	*/
}
