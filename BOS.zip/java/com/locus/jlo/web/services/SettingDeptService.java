package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.department.DepartmentBean;
import com.locus.jlo.web.beans.setting.SettingDeptBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;

public interface SettingDeptService {
	
	ServiceResult<List<Map<String, Object>>> searchSettingDept(String id) throws Exception;
	
	ServiceResult<Long> insertSettingDept(SettingDeptBean settingDeptBean) throws Exception;
	ServiceResult<Long> updateSettingDept(SettingDeptBean bean) throws Exception;
	ServiceResult<Long> removeSettingDept(String id) throws Exception;
	
	ServiceResult<List<Map<String, Object>>> searchSettingDeptMember(String id) throws Exception;
	ServiceResult<Long> saveSettingDeptMember(List<SettingUserBean> beans) throws Exception;
	
	ServiceResult<List<KeyValueBean>> searchSettingDevision() throws Exception;
	ServiceResult<List<KeyValueBean>> searchSettingDepartment(String division) throws Exception;
	ServiceResult<List<KeyValueBean>> searchSettingSection(String department) throws Exception;
	ServiceResult<List<KeyValueBean>> searchSettingDepartment() throws Exception;
	ServiceResult<List<KeyValueBean>> searchSettingSection() throws Exception;
	
	ServiceResult<DepartmentBean> searchSettingDeptDetailById(String id) throws Exception;
	ServiceResult<DepartmentBean> searchSettingDeptProjectDetailById(String id) throws Exception;
	ServiceResult<Long> insertSettingDeptProject(DepartmentBean departmentBean) throws Exception;
	ServiceResult<Long> updateSettingDeptProject(DepartmentBean departmentBean) throws Exception;
	ServiceResult<Long> insertSettingDeptProjectIndentifyKey(DepartmentBean departmentBean) throws Exception;
	ServiceResult<Long> updateProjectSettingDept(SettingDeptBean bean) throws Exception;
	ServiceResult<Long> insertTaskTemplateDepartmentProject(DepartmentBean departmentBean) throws Exception;
	
	ServiceResult<List<KeyValueBean>> searchDivisionByDepartmentId(String division) throws Exception;
	ServiceResult<List<KeyValueBean>> searchDepartmentBySectionId(String division) throws Exception;
}
