package com.locus.jlo.web.services;

import java.util.List;
import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.timesheet.TimeSheetApproveBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetIncompleteBean;
import com.locus.jlo.web.beans.timesheet.TimeSheetIncompleteDetailBean;

public interface TimeSheetIncompleteService {
	ServiceResult<List<TimeSheetIncompleteBean>> findTimeSheetIncomplete(TimeSheetIncompleteBean timeSheetIncompleteBean) throws Exception;
	ServiceResult<List<TimeSheetIncompleteDetailBean>> findTimeSheetIncompleteDetailByUserId(TimeSheetIncompleteBean timeSheetIncompleteBean) throws Exception;
	ServiceResult<TimeSheetIncompleteBean> findTimeSheetIncompleteByUserId(TimeSheetIncompleteBean timeSheetIncompleteBean) throws Exception;
	
	ServiceResult<List<TimeSheetApproveBean>> findTimeSheetApproveSendEmailAlert(TimeSheetApproveBean timeSheetApproveBean) throws Exception;
}
