package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.project.MemberTimeEntriesBean;
import com.locus.jlo.web.beans.project.ProjectProgressBean;
import com.locus.jlo.web.beans.project.ProjectProgressResultBean;

import java.util.List;
import java.util.Map;

public interface ProjectProgressService {

	ServiceResult<List<Map<String, Object>>> searchProjectProgress(ProjectProgressBean projectProgressBean) throws Exception;
	ServiceResult<List<ProjectProgressResultBean>> searchProjectProgressResult(String projectId ) throws Exception;
	ServiceResult<List<MemberTimeEntriesBean>> searchProjectMemberTimeEntries(String projectId ) throws Exception;
	ServiceResult<ProjectProgressResultBean> getLastUpdProgress(String projectId ) throws Exception;
	
	

	ServiceResult<Integer> insertProjectProgress(ProjectProgressBean projectBean) throws Exception;
	ServiceResult<Integer> updateProjectProgress(ProjectProgressBean projectBean) throws Exception;
	ServiceResult<Integer> removeProjectProgress(Integer id) throws Exception;

	ServiceResult<Integer> removeProjectProgressByProject(Integer project_id) throws Exception;

}
