package com.locus.jlo.web.services;

import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;

public interface LeaveRecordService {
	 
	 ServiceResult<List<DataBean>> searchLeaveRecord(String year,String userId) throws Exception;
	
	//ServiceResult<List<DataBean>> calWorkingDay(String userId) throws Exception;
	//ServiceResult<List<DataBean>> searchTeamLeaveRecord(String userId) throws Exception;
	
	ServiceResult<List<DataBean>> summaryAnnualLeave(String year,String userId) throws Exception;
	
	
	ServiceResult<List<DataBean>> previousYearLeaveEntitle(String userId) throws Exception;
	
	ServiceResult<List<DataBean>> calAnnualLeaveAccumulate(String year,String userId) throws Exception;
	
	ServiceResult<List<KeyValueBean>> searchUser() throws Exception;
	
	ServiceResult<List<DataBean>> getHolidayCalendar(String year) throws Exception;
	
	

	//show info on modal info
	 ServiceResult<List<DataBean>> leaveRecordStaffInfoService(String userId) throws Exception;	 
	 ServiceResult<List<DataBean>> leaveRecordAnnualLeaveLastYearInfoService(String userId) throws Exception;	
	 ServiceResult<List<DataBean>> leaveRecordAnnualLeaveLast2YearInfoService(String userId) throws Exception;
	 ServiceResult<List<DataBean>> leaveRecordAnnualLeaveThisYearInfoService(String userId) throws Exception;	
	 ServiceResult<List<DataBean>> sumAllLeaveUsed(String year,String userId) throws Exception;	
	
	
}
