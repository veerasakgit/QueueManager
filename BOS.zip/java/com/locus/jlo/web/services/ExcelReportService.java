package com.locus.jlo.web.services;

import java.util.Date;
import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriod;
import com.locus.jlo.web.beans.medical.report.MedicalReportByPeriodRes;
import com.locus.jlo.web.beans.medical.report.MedicalReportSUM;
import com.locus.jlo.web.beans.medical.report.MedicalReportSUMRes;
import com.locus.jlo.web.beans.report.attendance.AttendanceReportCriteria;
import com.locus.jlo.web.beans.report.attendance.AttendanceReportRes;
import com.locus.jlo.web.beans.report.hr.HrOvertimeReportRes;
import com.locus.jlo.web.beans.report.hr.HrReportCriteria;
import com.locus.jlo.web.beans.report.hr.HrTimeSheetReportRes;
import com.locus.jlo.web.beans.report.hr.ManHourReportCriteria;
import com.locus.jlo.web.beans.report.hr.ManHourReportRes;
import com.locus.jlo.web.beans.report.hr.OTReportCriteria;
import com.locus.jlo.web.beans.report.hr.OTReportRes;
import com.locus.jlo.web.beans.report.leave.LeaveReportCriteria;
import com.locus.jlo.web.beans.report.leave.LeaveReportRes;
import com.locus.jlo.web.beans.report.leave.LeaveReportWithFillterRes;
import com.locus.jlo.web.beans.report.staff.PmTimesheetReportBean;
import com.locus.jlo.web.beans.report.staff.StaffOvertimeReportRes;
import com.locus.jlo.web.beans.report.staff.StaffReportCriteria;
import com.locus.jlo.web.beans.report.staff.StaffTimeSheetReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationAccumGroupReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationAccumReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationGraphReportCriteria;
import com.locus.jlo.web.beans.report.utilization.UtilizationGraphReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationMonthlyGroupReportRes;
import com.locus.jlo.web.beans.report.utilization.UtilizationMonthlyReportRes;

public interface ExcelReportService {
	
	/* INITAIL REPORT */
	
	public ServiceResult<List<KeyValueBean>> initFilterProject(String isAdmin, String approverId) throws Exception;
	public ServiceResult<List<DataBean>> initFilterStaff(List<String> projectId, String isAdmin, String approverId ) throws Exception;
	public ServiceResult<List<DataBean>> initFilterStaff(List<String> projectId, String isAdmin, String approverId, Date startDate/*, Date endDate*/ ) throws Exception;
	
	//public ServiceResult<List<Map<String, Object>> > searchMedicalAllowanceReportByPeriod (Map<String, Object> criteria) throws Exception;
	public ServiceResult<List<MedicalReportByPeriodRes>> searchMedicalAllowanceReportByPeriod (MedicalReportByPeriod medicalReport) throws Exception;
	public ServiceResult<List<MedicalReportSUMRes>> searchMedicalAllowanceReportSum (MedicalReportSUM medicalReportsum) throws Exception;
	public ServiceResult<List<LeaveReportRes>> searchLeaveReport (LeaveReportCriteria leaveReportCriteria) throws Exception;
	public ServiceResult<List<LeaveReportWithFillterRes>> searchLeaveReportFillter (LeaveReportCriteria leaveReportCriteria) throws Exception;
	public ServiceResult<List<AttendanceReportRes>> searchAttendanceReport (AttendanceReportCriteria criteria) throws Exception;
	public ServiceResult<List<HrTimeSheetReportRes>> searchHrTimeSheetReport (HrReportCriteria hrCriteria) throws Exception;
	public ServiceResult<List<HrOvertimeReportRes>> searchHrOvertimeReport (HrReportCriteria hrCriteria) throws Exception;
	public ServiceResult<List<StaffTimeSheetReportRes>> searchStaffTimeSheetReport (StaffReportCriteria hrCriteria) throws Exception;
	public ServiceResult<List<StaffOvertimeReportRes>> searchStaffOvertimeReport (StaffReportCriteria hrCriteria) throws Exception;
	
	public ServiceResult<List<DataBean>> searchPmTimeSheetReport(PmTimesheetReportBean pmCriteria) throws Exception;
	
	public ServiceResult<List<KeyValueBean>> initFilterProjectForPm(String isAdmin, String userId) throws Exception;
	public ServiceResult<List<DataBean>> initFilterStaffForPm(List<String> projectId, String isAdmin, String userId ) throws Exception;

	public ServiceResult<List<UtilizationGraphReportRes>> searchUtilizationGraphReport (UtilizationGraphReportCriteria criteria) throws Exception;
	public ServiceResult<List<UtilizationMonthlyReportRes>> searchUtilizationMonthlyReport (UtilizationGraphReportCriteria criteria) throws Exception;
	public ServiceResult<List<UtilizationMonthlyGroupReportRes>> searchUtilizationMonthlyGroupReport (UtilizationGraphReportCriteria criteria) throws Exception;
	public ServiceResult<List<UtilizationAccumReportRes>> searchUtilizationAccumReport (UtilizationGraphReportCriteria criteria) throws Exception;
	public ServiceResult<List<UtilizationAccumGroupReportRes>> searchUtilizationAccumGroupReport (UtilizationGraphReportCriteria criteria) throws Exception;
	public ServiceResult<List<UtilizationAccumReportRes>> searchManDayFromUtilization (UtilizationGraphReportCriteria criteria) throws Exception;
	
	public ServiceResult<List<OTReportRes>> searchOTReport (OTReportCriteria criteria) throws Exception;
	public ServiceResult<List<ManHourReportRes>> searchManHourTimeSheetReport (ManHourReportCriteria criteria) throws Exception;
	public ServiceResult<List<ManHourReportRes>> searchManHourOverTimeReport (ManHourReportCriteria criteria) throws Exception;
	
}
