package com.locus.jlo.web.services;

import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.account.search.AccountSearchBean;
import com.locus.jlo.web.beans.leaveForm.LeaveFormDetailBean;
import com.locus.jlo.web.beans.tokenBean.TokenBean;

public interface TokenService {
	 
	ServiceResult<Long> insertToken(TokenBean tkb) throws Exception;
	ServiceResult<Long> updateToken(TokenBean tkb) throws Exception;
	ServiceResult<Long> removeTokenById(String id) throws Exception;
	ServiceResult<Long> removeTokenByNofifyId(String id) throws Exception;
	
	ServiceResult<List<DataBean>> verifyToken(String token, String verifyToken)throws Exception;
	
}
