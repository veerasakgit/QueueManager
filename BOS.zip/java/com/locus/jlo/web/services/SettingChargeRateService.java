package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.KeyValueBean;
import com.locus.jlo.web.beans.department.DepartmentBean;
import com.locus.jlo.web.beans.setting.SettingChargeRateBean;
import com.locus.jlo.web.beans.setting.SettingDeptBean;
import com.locus.jlo.web.beans.setting.SettingUserBean;

public interface SettingChargeRateService {
	
	ServiceResult<List<SettingChargeRateBean>> searchSettingChargeRate(SettingChargeRateBean criteria) throws Exception;
	
	ServiceResult<int[]> insertSettingChargeRate(List<SettingChargeRateBean> bean) throws Exception;
	
	ServiceResult<Integer> deleteSettingChargeRate(SettingChargeRateBean criteria) throws Exception;
	
}
