package com.locus.jlo.web.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.product.ProductBean;

public interface ProductService {
	
	ServiceResult<List<Map<String, Object>>> searchProduct(HashMap<String,Object> criteria) throws Exception;
	ServiceResult<Long> insertProduct(ProductBean bean) throws Exception;
	ServiceResult<Long> updateProduct(ProductBean bean) throws Exception;
	ServiceResult<Long> deleteProduct(String id) throws Exception;
}
