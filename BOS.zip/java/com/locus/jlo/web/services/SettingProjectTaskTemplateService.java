package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.setting.SettingProjectTaskTemplateBean;


public interface SettingProjectTaskTemplateService {
		
	ServiceResult<List<Map<String, Object>>> searchProjectTaskTemplate(String id) throws Exception;

	ServiceResult<Long> insertProjectTaskTemplate(SettingProjectTaskTemplateBean bean) throws Exception;
	ServiceResult<Long> updateProjectTaskTemplate(SettingProjectTaskTemplateBean bean) throws Exception;
	ServiceResult<Long> deleteProjectTaskTemplate(String id) throws Exception;
}
