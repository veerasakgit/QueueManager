package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.setting.SettingCalendarBean;
import com.locus.jlo.web.beans.setting.SettingProjectRoleBean;


public interface SettingProjectRoleService {
		
	ServiceResult<List<Map<String, Object>>> searchProjectRole(String id,String status) throws Exception;
	ServiceResult<List<Map<String, Object>>> searchMenu() throws Exception;

	ServiceResult<Long> insertProjectRole(SettingProjectRoleBean bean) throws Exception;
	ServiceResult<Long> updateProjectRole(SettingProjectRoleBean bean) throws Exception;
	ServiceResult<Long> deleteProjectRole(String id) throws Exception;
}
