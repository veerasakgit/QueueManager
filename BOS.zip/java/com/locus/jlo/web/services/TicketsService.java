package com.locus.jlo.web.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.project.TicketsBean;

public interface TicketsService {
	
	ServiceResult<List<Map<String, Object>>> searchTickets(HashMap<String,Object> criteria) throws Exception;
	ServiceResult<Long> insertTickets(TicketsBean bean) throws Exception;
	ServiceResult<Long> updateTickets(TicketsBean bean) throws Exception;
}
