package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.project.ProjectMembersBean;
import com.locus.jlo.web.beans.task.TaskAssigneeBean;
import com.locus.jlo.web.beans.task.TaskBean;


public interface TaskService {


	ServiceResult<List<Map<String, Object>>> searchTaskByProject(String projectId) throws Exception;
	ServiceResult<List<DataBean>> searchTaskTreeByProject(String projectId) throws Exception;

	ServiceResult<Integer> insertTask(TaskBean taskBean) throws Exception;
	ServiceResult<Integer> updateTask(TaskBean taskBean) throws Exception;
	ServiceResult<Integer> removeTask(String task_id) throws Exception;
	ServiceResult<Integer> removeTask(String taskId,String projectId, boolean isParent) throws Exception;

	ServiceResult<Integer> saveTask(List<TaskBean> tasks) throws Exception;



	ServiceResult<Integer> insertTaskAssignee(TaskAssigneeBean taskAssigneeBean) throws Exception;
	ServiceResult<Integer> removeTaskAssigneeByTask(String task_id) throws Exception;
	ServiceResult<Integer> assigneeByTask(TaskBean taskBean,boolean clearOld) throws Exception;
	ServiceResult<Integer> assigneeByMembers(ProjectMembersBean bean)throws Exception;
	ServiceResult<Integer> removeTaskAssigneeByMember(ProjectMembersBean bean) throws Exception;

	ServiceResult<List<DataBean>> searchProjectMember(String  projectId) throws Exception;
	ServiceResult<List<DataBean>> searchMemberTaskAssigned(String projectId, String taskId) throws Exception;
	ServiceResult<List<DataBean>> searchMemberTaskNotAssigned(String projectId, String taskId) throws Exception;

	ServiceResult<Long> inserTaskAssign(String projectId, String taskId , String userId, String status, String StartDt, String endDt, String createUid ) throws Exception;
	ServiceResult<Long> removeTaskTaskAssign(String taskAssigneeId) throws Exception;
	ServiceResult<Long> updateTaskAssign(String taskAssigneeId , String StartDt, String endDt ) throws Exception;
	
	
}
