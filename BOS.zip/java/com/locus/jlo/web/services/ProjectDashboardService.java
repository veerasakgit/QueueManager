package com.locus.jlo.web.services;

import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;


public interface ProjectDashboardService {
	 
	
	ServiceResult<List<DataBean>> searchProjectDashboardDetail(String projectId) throws Exception; 
	ServiceResult<List<DataBean>> searchProjectDashboardMember(String projectId) throws Exception;
	ServiceResult<List<DataBean>> searchProjectWorkhourLogtime(String projectId) throws Exception;
	ServiceResult<List<DataBean>> searchProjectOvertimeLogtime(String projectId) throws Exception;
	ServiceResult<List<DataBean>> searchProjectBarGraphLogtime(String projectId) throws Exception;
	
	
	 
}
