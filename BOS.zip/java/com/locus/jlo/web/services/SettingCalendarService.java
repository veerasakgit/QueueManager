package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.setting.SettingCalendarBean;


public interface SettingCalendarService {
		
	ServiceResult<List<Map<String, Object>>> searchSettingCalendar(String id,String dateType) throws Exception;
	
	ServiceResult<Long> insertSettingCalendar(SettingCalendarBean bean) throws Exception;
	ServiceResult<Long> updateSettingCalendar(SettingCalendarBean settingUserBean) throws Exception;
	ServiceResult<Long> removeSettingCalendar(String id) throws Exception;


}
