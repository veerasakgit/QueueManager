package com.locus.jlo.web.services;

import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;


public interface WallService {
	 
	ServiceResult<List<DataBean>> searchWall() throws Exception;
	ServiceResult<Long> insertWallPost(String uid, String msg) throws Exception;
	ServiceResult<Long> updateWallPost(String uid, String msgid , String msg) throws Exception;
	ServiceResult<Long> removeWallPost(String uid, String msgid ) throws Exception;
	
	//String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception;
	/*
	ServiceResult<Long> insertLogtime(String pid, String tid, String date, String hour, String status, String uid) throws Exception;
	ServiceResult<Long> updateLogtime(String pid, String tid, String date, String hour, String status, String uid, String eid ) throws Exception;
	ServiceResult<Long> removeLogtime(String eid) throws Exception;
	
	ServiceResult<List<DataBean>> searchTimesheet_beforeSubmit() throws Exception;
	ServiceResult<Long> submitTimesheet(String data_eid) throws Exception;

	
	ServiceResult<Integer> insertLogtime(String id) throws Exception;
	ServiceResult<Integer> updateLogtime(String id) throws Exception;
	ServiceResult<Integer> deleteLogtime(String id) throws Exception;
	*/
}
