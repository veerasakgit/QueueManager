package com.locus.jlo.web.services;

import java.util.Date;
import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.timesheet.OvertimeBean;
import com.locus.jlo.web.beans.timesheet.TimesheetNoteBean;

public interface TimesheetService {
	
	ServiceResult<List<DataBean>> searchTimesheet(int monthid , int year , String staffId ) throws Exception;
	
	//String checkLogtime(String pid,String tid,String date,String hour,String uid) throws Exception;
	
	ServiceResult<Long> insertLogtime(String pid, String tid, Date date, String hour, String status, String uid) throws Exception;
	ServiceResult<Long> updateLogtime(String pid, String tid, Date date, String hour, String status, String uid, String id ) throws Exception;
	ServiceResult<Long> removeLogtime(String id) throws Exception;
	
	ServiceResult<List<DataBean>> searchTimesheetById(String time_entry_id )throws Exception; 
	
	ServiceResult<List<DataBean>> searchTimesheetSummary(String year, String monthId, String staffId) throws Exception;
	ServiceResult<List<DataBean>> searchOvertimeSummary(String year, String monthId, String staffId) throws Exception;
	
	ServiceResult<List<DataBean>> searchTimesheetSummaryForPm(String year, String monthId, String staffId,String projectId) throws Exception;
	ServiceResult<List<DataBean>> searchOvertimeSummaryForPm(String year, String monthId, String staffId,String projectId) throws Exception;
	
	ServiceResult<List<DataBean>> searchMonthUtilize(String year, String monthId) throws Exception;
	
	
	ServiceResult<Long> submitWorkhour(List<DataBean> db) throws Exception;
	ServiceResult<Long> submitOvertime(List<DataBean> db) throws Exception;
	
	//lookup overtime project-task
	ServiceResult<List<DataBean>> searchMonthlyPercentApprove(int year, String staffId) throws Exception;
	ServiceResult<List<DataBean>> searchAvailableProjectTask(int year, int monthId, String staffId) throws Exception;
	ServiceResult<List<DataBean>> searchTimesheetOvertime(int year, int monthId, String staffId) throws Exception;
	ServiceResult<List<DataBean>> searchTimesheetOvertimeDetail(String otDate, String staffId) throws Exception;
	ServiceResult<Long> insertOvertime(OvertimeBean ob) throws Exception;
	ServiceResult<Long> updateOvertime(OvertimeBean ob) throws Exception;
	ServiceResult<Long> removeOvertime(String id) throws Exception;
	
	ServiceResult<List<DataBean>> searchTimesheetNote(int year, int monthId, String staffId) throws Exception;
	ServiceResult<List<DataBean>> searchTimesheetNoteDetail(String noteDate, String staffId) throws Exception;
	ServiceResult<Long> insertTimesheetNote(TimesheetNoteBean tnb) throws Exception;
	ServiceResult<Long> updateTimesheetNote(TimesheetNoteBean tnb) throws Exception;
	ServiceResult<Long> removeTimesheetNote(String id) throws Exception;
	
}
