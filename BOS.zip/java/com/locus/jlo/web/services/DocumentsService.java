package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.module.DocumentsBean;

import java.util.List;
import java.util.Map;

public interface DocumentsService {

	
	ServiceResult<List<DataBean>> searchDocuments(DocumentsBean documentsBean) throws Exception;
	ServiceResult<List<DataBean>> searchDealInProjectDocuments(DocumentsBean documentsBean) throws Exception;

	ServiceResult<Integer> insertDocuments(DocumentsBean documentsBean) throws Exception;
	ServiceResult<Integer> updateDocuments(DocumentsBean documentsBean) throws Exception;
	ServiceResult<Integer> removeDocuments(Integer id) throws Exception;
}
