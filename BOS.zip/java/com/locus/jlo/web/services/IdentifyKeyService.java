package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.IdentifyKeyBean;

import java.util.List;
import java.util.Map;

public interface IdentifyKeyService {

    ServiceResult<List<Map<String, Object>>> searchIdentifyKey(IdentifyKeyBean identifyKeyBean) throws Exception;

    ServiceResult<Integer> insertIdentifyKey(String typePD, String uniqueName, String projectName, Integer createUid) throws Exception;

    ServiceResult<Integer> updateIdentifyKeyBean(IdentifyKeyBean identifyKeyBean) throws Exception;

    ServiceResult<Integer> removeIdentifyKeyBean(Integer iden_id) throws Exception;
}
