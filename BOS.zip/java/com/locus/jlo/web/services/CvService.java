package com.locus.jlo.web.services;

import java.util.List;
import java.util.Map;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.cv.CvBean;
import com.locus.jlo.web.beans.trainingRecord.TrainingRecordBean;

public interface CvService {
	
	ServiceResult<List<Map<String, Object>>> searchCv(String userId) throws Exception;
	ServiceResult<Long> insertCv(CvBean bean) throws Exception;
	ServiceResult<Long> deleteCv(String id) throws Exception;
}
