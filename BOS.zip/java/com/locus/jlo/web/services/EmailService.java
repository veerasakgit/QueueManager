package com.locus.jlo.web.services;

public interface EmailService {
	public void sendMailNotify(String mailSubject, String mailTo, String template);
	public String mailTemplate(String template_type);
	public String readContentFromFile(String fileName);
	public String removeLastChar(String s);
}
