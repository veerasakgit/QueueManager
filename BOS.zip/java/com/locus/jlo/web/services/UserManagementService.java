package com.locus.jlo.web.services;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.system.dto.LoginDTO;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.beans.system.dto.UserAuthenDTO;;
public interface UserManagementService {

    ServiceResult<UserAuthenDTO> getAuthentication(String userId);
    ServiceResult<UserInfoDTO> getUserInfo(String userId);
    
   // ServiceResult<UserInfoDTO> getUserMenuPrivileges(String userId);
    
    ServiceResult<LoginDTO> getLoginInfo(String userId);
    
}
