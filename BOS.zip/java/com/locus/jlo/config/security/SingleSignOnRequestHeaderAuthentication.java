package com.locus.jlo.config.security;

import org.springframework.security.web.authentication.preauth.RequestHeaderAuthenticationFilter;

import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SingleSignOnRequestHeaderAuthentication extends RequestHeaderAuthenticationFilter {

    public SingleSignOnRequestHeaderAuthentication() {
        super();
        this.setPrincipalRequestHeader("SM_USER");
    }

    @Override
    protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
        String username = (String) (super.getPreAuthenticatedPrincipal(request));
        log.info("SSO username : " + username);
        return username;
    }
}
