package com.locus.jlo.config.security;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.locus.jlo.web.services.SettingPrivilegesService;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonEncoding;
import com.locus.common.domain.ServiceResult;
import com.locus.jlo.web.beans.DataBean;
import com.locus.jlo.web.beans.SearchBean;
import com.locus.jlo.web.beans.system.dto.LoginDTO;
import com.locus.jlo.web.beans.system.dto.UserInfoDTO;
import com.locus.jlo.web.services.MedicalAllowanceService;
import com.locus.jlo.web.services.UserManagementService;


import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

@Slf4j
public class SuccessLoginHandler implements AuthenticationSuccessHandler {

    private final RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
    	
    	LoginDTO login = (LoginDTO)authentication.getPrincipal();
    	UserInfoDTO uInfo = login.getUserInfo();
    
    	//avatar image can't access from public we need to locate default path on server
    	//add server location initial path
    	//log.info( "default profile path: "+defaultServerProfilePath); 
    	 //uInfo.setAvatar(defaultServerProfilePath+"/"+uInfo.getAvatar());
    	//log.info("get avatar : "+uInfo.getAvatar());
    	
        if(StringUtils.isEmpty(uInfo.getAvatar())){uInfo.setAvatar("assets/img/default-user.png");}
        try {
    	//staffProfile
    	request.getSession().setAttribute("USER",uInfo);
    	request.getSession().setAttribute("UID",uInfo.getUid());
        //staffMenu
        request.getSession().setAttribute("staffMenu",login.getMenuInfo());
        } catch (Exception e) {
            e.printStackTrace();
        }

        redirectStrategy.sendRedirect(request, response, "/home");
    }

}
