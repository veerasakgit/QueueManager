package com.locus.jlo.config;

import com.locus.common.jdbc.DynamicJdbcDao;
import com.locus.common.jdbc.DynamicJdbcDaoImpl;
import com.locus.common.oxm.OxmMarshaller;
import com.locus.common.sql.SqlStatementBuilder;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;


@Configuration
public class DataSourceConfiguration {
    /*
	@Value("${datasource.driver}")
    private String driver;
	
    @Value("${datasource.url}")
    private String url;
    
    @Value("${datasource.username}")
    private String username;
    
    @Value("${datasource.password}")
    private String password;
   */
	
    @Bean
    @ConfigurationProperties(prefix="jlo.datasource")
    public DataSource getDataSource() {
    	
    	return DataSourceBuilder
                .create()
                .build();
    	
    	 
    	   
    	/*
        return DataSourceBuilder
                .create()
                    .driverClassName(driver)
                    .url(url)
                    .username(username)
                    .password(password)
                .build();
      */
    }

    @Bean
    public DynamicJdbcDao dynamicJdbcDao() {
        return new DynamicJdbcDaoImpl(getDataSource());
    }

    @Bean
    public Jaxb2Marshaller jaxb2Marshaller() {
        final Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
        jaxb2Marshaller.setClassesToBeBound(
                com.locus.common.oxm.OxmParameter.class,
                com.locus.common.oxm.OxmQueryCollection.class,
                com.locus.common.oxm.OxmSqlService.class
        );
        return jaxb2Marshaller;
    }

    @Bean
    public OxmMarshaller oxmMarshaller() {
        final OxmMarshaller oxmMarshaller = new OxmMarshaller();
        oxmMarshaller.setMarshaller(jaxb2Marshaller());
        oxmMarshaller.setUnmarshaller(jaxb2Marshaller());
        return oxmMarshaller;
    }

    @Bean
    public SqlStatementBuilder sqlStatementBuilder() {
        final SqlStatementBuilder sqlStatementBuilder = new SqlStatementBuilder();
        sqlStatementBuilder.setResource("classpath:/sql/*.xml");
        sqlStatementBuilder.setMarshaller(oxmMarshaller());
        return sqlStatementBuilder;
    }
}
