package com.locus.jlo.scheduler.service;

import java.util.Date;
import java.util.List;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.scheduler.bean.SchedulerHistoryBean;
import com.locus.jlo.scheduler.bean.SchedulerBean;
import org.quartz.SchedulerException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface SchedulerService {
    
    ServiceResult<List<SchedulerBean>> findAllScheduler();

    ServiceResult<Page<SchedulerBean>> findAllScheduler(Pageable pageable);

    ServiceResult<SchedulerBean> findSchedulerById(Long id);

    ServiceResult<Page<SchedulerHistoryBean>> findSchedulerHistoryBySchedulerId(Long schedulerId, Pageable pageable);

    ServiceResult<Long> insertScheduler(SchedulerBean schedulerModelBean);

    void updateScheduler(SchedulerBean schedulerModelBean);

    ServiceResult<Long> insertSchedulerHistory(SchedulerHistoryBean schedulerHistoryModelBean);

    void scheduleJob(SchedulerBean schedulerModelBean) throws ClassNotFoundException, SchedulerException;

    void cancelJob(SchedulerBean schedulerModelBean) throws SchedulerException;

    void shutdownScheduler() throws SchedulerException;

    void interruptJob(SchedulerBean schedulerModelBean) throws SchedulerException;

    List<SchedulerBean> listAllJobs() throws SchedulerException;

    List<SchedulerBean> listRunningJobs() throws SchedulerException;
    
    void executeJob(SchedulerBean schedulerModelBean) throws Exception;
    public void executeJob(SchedulerBean schedulerModelBean, Date startDate, Date endDate) throws Exception;
    
    ServiceResult<Boolean> deleteScheduler(Long schedulerId);
    
    boolean runOnThisContext();
    
//========================================================================================================
	public List<SchedulerBean> select(SchedulerBean schedulerBean) throws Exception;
	public SchedulerBean save(final SchedulerBean schedulerBean, String userId, Date time) throws Exception;
	public Long insert(SchedulerBean schedulerBean) throws Exception;
	public int update(SchedulerBean schedulerBean) throws Exception;
	public int deleteById(Long schedulerId) throws Exception;
	
	public List<SchedulerHistoryBean> selectSchedulerHistory(SchedulerHistoryBean bean) throws Exception;
}
