/**
 * created-date: 2019-06-12
 * original-from: MakroAdmin project
 */

package com.locus.jlo.scheduler.controller;

import com.locus.common.domain.ServiceResult;
import com.locus.jlo.scheduler.bean.SchedulerBean;
import com.locus.jlo.scheduler.bean.SchedulerHistoryBean;
import com.locus.jlo.scheduler.service.SchedulerService;
import com.locus.jlo.web.beans.system.modeljson.DatatableModelBean;
import com.locus.jlo.web.beans.system.modeljson.JsonResultBean;
import com.locus.jlo.web.constant.JLOWebConstant;
import com.locus.jlo.web.controller.BaseController;

import lombok.extern.slf4j.Slf4j;
import org.quartz.CronExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Slf4j
@Controller
public class SchedulerManagementController extends BaseController
{
	@Autowired private SchedulerService schedulerService;
	
//=============================================================================================================================================
	@RequestMapping(value = {"/schedulerList"})
	public String schedulerList()
	{
		log.info("==>>> schedulerList ========================== " + Calendar.getInstance().getTime());
		try
		{
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
		} finally
		{
			log.info("======================== schedulerList ==>>> " + Calendar.getInstance().getTime());
		}
		return "scheduler_list";
	}
	
	@RequestMapping(value = "/scheduler/getSchedulerList", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean getSchedulerList(HttpServletRequest request, HttpServletResponse response, Locale locale, Model model) throws Exception
	{
		JsonResultBean result = new JsonResultBean();
		
		log.info("==>>> getSchedulerList ========================== " + Calendar.getInstance().getTime());
		log.info("************************************************");
		
		try
		{
			SchedulerBean beanParam = new SchedulerBean();
			//beanParam.setInstance(InetAddress.getLocalHost().getHostName());
			List<SchedulerBean> beanList = schedulerService.select(beanParam);
			
			List<SchedulerBean> runJobList = schedulerService.listRunningJobs();
			List<SchedulerBean> queJobList = schedulerService.listAllJobs();
			
			if (beanList != null && beanList.size() > 0)
			{
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
				
				for (int schIndex = 0, schSize = beanList.size(); schIndex < schSize; schIndex++)
				{
					SchedulerBean schBean = beanList.get(schIndex);
					
					for (SchedulerBean queJobBean : queJobList)
					{
						if (schBean.getSchedulerId().equals(queJobBean.getSchedulerId()))
						{
							if (queJobBean.getNextFireTime() != null)
							{
								schBean.setStatus("Next run " + sdf.format(queJobBean.getNextFireTime()));
							}
						}
	                }
					
					for (SchedulerBean runJobBean : runJobList)
					{
						if (schBean.getSchedulerId().equals(runJobBean.getSchedulerId()))
						{
							schBean.setStatus("Running");
						}
	                }
				}
			}
			
			result.setData(beanList);
			result.setMsg(JLOWebConstant.SUCCESS_DESC);
			result.setStatus(JLOWebConstant.SUCCESS_CODE);
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			
			result.setMsg(ex.getMessage());
			result.setStatus(JLOWebConstant.FAIL_CODE);
		} finally
		{
			log.info("result: [{}]", result);
			log.info("======================== getSchedulerList ==>>> " + Calendar.getInstance().getTime());
		}
		return result;
	}
	
	@RequestMapping(value = "/scheduler/saveScheduler", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean saveScheduler(HttpServletRequest request, HttpServletResponse response, Locale locale, Model model
													, @ModelAttribute("SchedulerBean") SchedulerBean schedulerBean) throws Exception
	{
		JsonResultBean result = new JsonResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		result.setData(map);
		
		log.info("==>>> saveScheduler ========================== " + Calendar.getInstance().getTime());
		log.info("************************************************");
		log.info("SchedulerBean: [{}]", schedulerBean);
		
		map.put("schedulerBean", schedulerBean);
		
		try
		{
			if (CronExpression.isValidExpression(schedulerBean.getExpressions()))
		    {
				schedulerBean = schedulerService.save(schedulerBean
													, request.getSession().getAttribute("UID").toString()
													, Calendar.getInstance().getTime());
				schedulerService.scheduleJob(schedulerBean);
				
				result.setData(schedulerBean);
				result.setMsg(JLOWebConstant.SUCCESS_DESC);
	    		result.setStatus(JLOWebConstant.SUCCESS_CODE);
		    } else
		    {
		    	result.setMsg("Error: INVALID EXPRESSION");
	    		result.setStatus(JLOWebConstant.FAIL_CODE);
		    }
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
    		
    		result.setMsg(ex.getMessage());
    		result.setStatus(JLOWebConstant.FAIL_CODE);
		} finally
		{
			log.info("result: [{}]", result);
    		log.info("======================== saveScheduler ==>>> " + Calendar.getInstance().getTime());
		}
		return result;
	}
	
	@RequestMapping(value = "/scheduler/getSchedulerDetail", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.GET)
    public @ResponseBody ModelAndView getSchedulerDetail(HttpServletRequest request, HttpServletResponse response, Locale locale, Model model
    													, @ModelAttribute("SchedulerBean") SchedulerBean schedulerBean) throws Exception
	{
		log.info("==>>> getSchedulerDetail ========================== " + Calendar.getInstance().getTime());
		log.info("************************************************");
		log.info("SchedulerBean: [{}]", schedulerBean);
		
		ModelAndView output = new ModelAndView("scheduler_detail");
		try
		{
			if (schedulerBean != null && schedulerBean.getSchedulerId() != null)
			{
				List<SchedulerBean> beanList = schedulerService.select(schedulerBean);
	    		log.info("beanList: [{}]", beanList);
	    		if (beanList != null && beanList.size() > 0)
	    		{
	    			schedulerBean = beanList.get(0);
	    		}
			}
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
		} finally
		{
			log.info("SchedulerBean: [{}]", schedulerBean);
			log.info("======================== getSchedulerDetail ==>>> " + Calendar.getInstance().getTime());
		}
		
		output.addObject("SchedulerBean", schedulerBean);
		return output;
    }
	
	@RequestMapping(value = "/scheduler/deleteScheduler", headers = { "Accept=application/json;charset=utf-8" }, method = RequestMethod.POST)
	public @ResponseBody JsonResultBean deleteScheduler(HttpServletRequest request, HttpServletResponse response, Locale locale, Model model
													, @ModelAttribute("SchedulerBean") SchedulerBean schedulerBean) throws Exception
	{
		JsonResultBean result = new JsonResultBean();
		Map<String, Object> map = new HashMap<String, Object>();
		result.setData(map);
		
		log.info("==>>> deleteScheduler ========================== " + Calendar.getInstance().getTime());
		log.info("************************************************");
		log.info("SchedulerBean: [{}]", schedulerBean);
		
		map.put("schedulerBean", schedulerBean);
		
		try
		{
			/*SchedulerBean bean = new SchedulerBean();
			bean.setEnabled(Boolean.FALSE);
			bean.setUpdateBy(request.getSession().getAttribute("UID").toString());
			bean.setUpdateDate(Calendar.getInstance().getTime());
			
			schedulerService.update(bean);*/
			
			schedulerService.deleteById(schedulerBean.getSchedulerId());
			
			result.setMsg(JLOWebConstant.SUCCESS_DESC);
    		result.setStatus(JLOWebConstant.SUCCESS_CODE);
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
    		
    		result.setMsg(ex.getMessage());
    		result.setStatus(JLOWebConstant.FAIL_CODE);
		} finally
		{
			log.info("result: [{}]", result);
    		log.info("======================== deleteScheduler ==>>> " + Calendar.getInstance().getTime());
		}
		return result;
	}
	
//=============================================================================================================================================
	@RequestMapping(value = "/scheduler/schedulerHistory", headers = {"Accept=application/json;charset=utf-8"}, method = RequestMethod.GET)
    public @ResponseBody ModelAndView schedulerHistory(HttpServletRequest request, HttpServletResponse response, Locale locale, Model model
    													, @ModelAttribute("SchedulerBean") SchedulerBean schedulerBean) throws Exception
	{
		log.info("==>>> schedulerHistory ========================== " + Calendar.getInstance().getTime());
		log.info("************************************************");
		log.info("SchedulerBean: [{}]", schedulerBean);
		
		ModelAndView output = new ModelAndView("scheduler_history");
		try
		{
			if (schedulerBean != null && schedulerBean.getSchedulerId() != null)
			{
				List<SchedulerBean> beanList = schedulerService.select(schedulerBean);
	    		log.info("beanList: [{}]", beanList);
	    		if (beanList != null && beanList.size() > 0)
	    		{
	    			schedulerBean = beanList.get(0);
	    		}
			}
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
		} finally
		{
			log.info("SchedulerBean: [{}]", schedulerBean);
			log.info("======================== schedulerHistory ==>>> " + Calendar.getInstance().getTime());
		}
		
		output.addObject("SchedulerBean", schedulerBean);
		return output;
    }
	
	@RequestMapping(value = "/scheduler/getPageHistory", headers = {"Accept=application/json"})
    public @ResponseBody DatatableModelBean getPageHistory(HttpServletRequest request, HttpServletResponse response, Model model, Locale local
    													, @RequestParam(value = "schedulerId", required = true) Long schedulerId) throws Exception
	{
		log.info("==>>> getPageHistory ========================== " + Calendar.getInstance().getTime());
		log.info("************************************************");
		log.info("schedulerId: [{}]", schedulerId);
		
		DatatableModelBean result = new DatatableModelBean();
		try
		{
			Pageable pageable = getPagableFromRequest(request);
			ServiceResult<Page<SchedulerHistoryBean>> serviceResult = schedulerService.findSchedulerHistoryBySchedulerId(schedulerId, pageable);
			
			if (serviceResult.isSuccess())
			{
				Page<SchedulerHistoryBean> pages = serviceResult.getResult();
				Long totalEle = pages.getTotalElements();
				
				result.setsEcho(getSecho(request));
				result.setiTotalDisplayRecords(totalEle.intValue());
				result.setiTotalRecords(totalEle.intValue());
				result.setAaData(pages.getContent());
			} else
			{
				result.setsEcho(1);
				result.setiTotalDisplayRecords(0);
				result.setiTotalRecords(0);
				result.setAaData(null);
			}
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			
			result.setsEcho(1);
            result.setiTotalDisplayRecords(0);
            result.setiTotalRecords(0);
            result.setAaData(null);
		} finally
		{
			log.info("======================== getPageHistory ==>>> " + Calendar.getInstance().getTime());
		}
        return result;
    }
	
	@RequestMapping(value = "/scheduler/getSchedulerHistoryList", headers = {"Accept=application/json"})
    public @ResponseBody JsonResultBean getSchedulerHistoryList(HttpServletRequest request, HttpServletResponse response, Model model, Locale local
    													, @RequestParam(value = "schedulerId", required = true) Long schedulerId) throws Exception
	{
		log.info("==>>> getSchedulerHistoryList ========================== " + Calendar.getInstance().getTime());
		log.info("************************************************");
		log.info("schedulerId: [{}]", schedulerId);
		
		JsonResultBean jsonBean = new JsonResultBean();
		String msg = "";
		try
		{
			SchedulerHistoryBean bean = new SchedulerHistoryBean();
			bean.setSchedulerId(schedulerId);
			
			List<SchedulerHistoryBean> beanList = schedulerService.selectSchedulerHistory(bean);
			
			msg = "Select done.";
			jsonBean.setData(beanList);
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			msg = ex.getMessage();
		} finally
		{
			log.info("======================== getSchedulerHistoryList ==>>> " + Calendar.getInstance().getTime());
		}
		
		jsonBean.setMsg(msg);
		jsonBean.setStatus(JLOWebConstant.SUCCESS_CODE);
		
        return jsonBean;
    }
	
	@RequestMapping(value = "/scheduler/executeNow")
	public @ResponseBody JsonResultBean executeNow(Locale local, HttpServletRequest request
											, @RequestParam(value = "schedulerId", required = true) Long schedulerId
											, @RequestParam(value = "startDate", required = false) String startDateStr
											, @RequestParam(value = "endDate", required = false) String endDateStr)
	{
		log.info("==>>> executeNow ========================== " + Calendar.getInstance().getTime());
		log.info("************************************************");
		log.info("schedulerId: [{}]", schedulerId);
		log.info("startDateStr: [{}]", startDateStr);
		log.info("endDateStr: [{}]", endDateStr);
		
		JsonResultBean jsonBean = new JsonResultBean();
		String msg = "";
		try
		{
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			
			Date startDate = null;
			if (startDateStr != null && startDateStr.trim().length() > 0)
			{
				startDate = dateFormat.parse(startDateStr);
			}
			
			Date endDate = null;
			if (endDateStr != null && endDateStr.trim().length() > 0)
			{
				endDate = dateFormat.parse(endDateStr);
			}
			
			if (startDateStr != null && startDateStr.trim().length() > 0
				&& endDateStr != null && endDateStr.trim().length() > 0)
			{
				Long startLong = startDate.getTime();
				Long endLong = endDate.getTime();
				
				if (startLong > endLong)
					msg = "Start date is more than End date.";
			}
			
			if (msg == null || msg.trim().length() == 0)
			{
				SchedulerBean schedulerBean = new SchedulerBean();
				schedulerBean.setSchedulerId(schedulerId);
				
				List<SchedulerBean> schBeanList = schedulerService.select(schedulerBean);
				if (schBeanList != null && schBeanList.size() > 0)
				{
					schedulerBean = schBeanList.get(0);
					jsonBean.setData(schedulerBean);
					
					schedulerService.executeJob(schBeanList.get(0), startDate, endDate);
					msg = schBeanList.get(0).getSchedulerName() + " Started";
				}
				
				jsonBean.setMsg(msg);
				jsonBean.setStatus(JLOWebConstant.SUCCESS_CODE);
			} else
			{
				jsonBean.setMsg(msg);
				jsonBean.setStatus(JLOWebConstant.FAIL_CODE);
			}
			
		} catch (Exception ex)
		{
			log.error(ex.getMessage(), ex);
			msg = ex.getMessage();
			
			jsonBean.setMsg(msg);
			jsonBean.setStatus(JLOWebConstant.FAIL_CODE);
		} finally
		{
			log.info("======================== executeNow ==>>> " + Calendar.getInstance().getTime());
		}
		
		return jsonBean;
	}
}
