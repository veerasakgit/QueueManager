package com.locus.jlo.scheduler.bean;

import com.locus.jlo.web.beans.system.modelbean.BaseModelBean;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class SchedulerBean extends BaseModelBean implements Serializable
{
	private static final long serialVersionUID = -9104162369845940072L;
	
	private Long schedulerId;
	private String schedulerName;
	private String schedulerType;
	private String expressions; //50
	private Boolean enabled;
	private String classpath; //300
	private String instance;
	private Integer priority;
	private Boolean retry;
	private Integer retryDelay;
	private Integer retryMax;
	
	private Long regId;
	private String regName;
	private Date regDt;
	private String regDtStr;
	
	private Long chgId;
	private String chgName;
	private Date chgDt;
	private String chgDtStr;
	
	private String group;
	private Date fireTime;
	private Date nextFireTime;
	private String status;
}
