package th.co.msat.motor.database;
/**
 * Home interface for Enterprise Bean: FacingSheetSB
 */
public interface FacingSheetSBHome extends javax.ejb.EJBHome {
	/**
	 * Creates a default instance of Session Bean: FacingSheetSB
	 */
	public th.co.msat.motor.database.FacingSheetSB create()
		throws javax.ejb.CreateException,
		java.rmi.RemoteException;
}
