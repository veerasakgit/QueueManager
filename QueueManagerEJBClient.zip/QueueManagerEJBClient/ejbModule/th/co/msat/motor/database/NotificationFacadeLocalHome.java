package th.co.msat.motor.database;
/**
 * Local Home interface for Enterprise Bean: NotificationFacade
 */
public interface NotificationFacadeLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates a default instance of Session Bean: NotificationFacade
	 */
	public th.co.msat.motor.database.NotificationFacadeLocal create()
		throws javax.ejb.CreateException;
}
