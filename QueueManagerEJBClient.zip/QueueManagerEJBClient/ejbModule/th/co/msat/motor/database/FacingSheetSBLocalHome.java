package th.co.msat.motor.database;
/**
 * Local Home interface for Enterprise Bean: FacingSheetSB
 */
public interface FacingSheetSBLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates a default instance of Session Bean: FacingSheetSB
	 */
	public th.co.msat.motor.database.FacingSheetSBLocal create()
		throws javax.ejb.CreateException;
}
