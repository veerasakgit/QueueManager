package th.co.msat.schedulejobmanager.database;

public class MSATServiceLocatorException extends Exception {

	/**
	 * Constructor for ServiceLocatorException
	 */
	public MSATServiceLocatorException() {
		super();
	}

	/**
	 * Constructor for ServiceLocatorException
	 */
	public MSATServiceLocatorException(String arg0) {
		super(arg0);
	}


}

