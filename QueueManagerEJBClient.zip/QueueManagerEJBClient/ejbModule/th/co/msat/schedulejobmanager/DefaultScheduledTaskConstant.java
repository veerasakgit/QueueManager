/*
 * Created on 1 �.�. 2551
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package th.co.msat.schedulejobmanager;

/**
 * @author ituser3
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface DefaultScheduledTaskConstant {

	public static final int SYNCHRONIZE_SCHEDULED_JOB_ID = 1;
	public static final String TASK_STATUS_READY = "R";
	public static final String TASK_STATUS_DISABLE = "D";
	public static final String RECORD_STATUS_AVAILABLE = "Y";
	public static final String RECORD_STATUS_UNAVAILABLE = "N";
	


}
