package th.co.msat.motor.queuemanager.database.websphere_deploy;

/**
 * Internal Home interface for Enterprise Bean: Queuetb
 */
public interface QueuetbBeanInternalHome_6b8e8e23 extends javax.ejb.EJBHome {
}
