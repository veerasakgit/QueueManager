package th.co.msat.motor.queuemanager.database.websphere_deploy;

/**
 * Internal Local Home interface for Enterprise Bean: Jobtb
 */
public interface JobtbBeanInternalLocalHome_db815d18 {
	/**
	 * findJobtbByQ_msatlib_jobtb_queueid_00001Key_Local
	 */
	public java.util.Collection findJobtbByQ_msatlib_jobtb_queueid_00001Key_Local(th.co.msat.motor.queuemanager.database.QueuetbKey key) throws javax.ejb.FinderException;
}
