package th.co.msat.motor.queuemanager.database.websphere_deploy;

/**
 * Cache Entry interface for Enterprise Bean: Queuetb
 */
public interface QueuetbBeanCacheEntry_6b8e8e23 extends java.io.Serializable {
	/**
	 * getQueueid
	 */
	public java.math.BigDecimal getQueueid();
	/**
	 * setQueueid
	 */
	public void setQueueid(java.math.BigDecimal newQueueid);
	/**
	 * getQueuename
	 */
	public java.lang.String getQueuename();
	/**
	 * setQueuename
	 */
	public void setQueuename(java.lang.String newQueuename);
	/**
	 * getSize
	 */
	public java.math.BigDecimal getSize();
	/**
	 * setSize
	 */
	public void setSize(java.math.BigDecimal newSize);
	/**
	 * getAvailable
	 */
	public java.math.BigDecimal getAvailable();
	/**
	 * setAvailable
	 */
	public void setAvailable(java.math.BigDecimal newAvailable);
	/**
	 * getIsterminate
	 */
	public java.lang.String getIsterminate();
	/**
	 * setIsterminate
	 */
	public void setIsterminate(java.lang.String newIsterminate);
	/**
	 * getWorkingtime
	 */
	public java.math.BigDecimal getWorkingtime();
	/**
	 * setWorkingtime
	 */
	public void setWorkingtime(java.math.BigDecimal newWorkingtime);
	/**
	 * getMessageclass
	 */
	public java.lang.String getMessageclass();
	/**
	 * setMessageclass
	 */
	public void setMessageclass(java.lang.String newMessageclass);
	/**
	 * getActivateclass
	 */
	public java.lang.String getActivateclass();
	/**
	 * setActivateclass
	 */
	public void setActivateclass(java.lang.String newActivateclass);
	/**
	 * getCreatedate
	 */
	public java.math.BigDecimal getCreatedate();
	/**
	 * setCreatedate
	 */
	public void setCreatedate(java.math.BigDecimal newCreatedate);
	/**
	 * getCreatetime
	 */
	public java.math.BigDecimal getCreatetime();
	/**
	 * setCreatetime
	 */
	public void setCreatetime(java.math.BigDecimal newCreatetime);
	/**
	 * getCreateuser
	 */
	public java.lang.String getCreateuser();
	/**
	 * setCreateuser
	 */
	public void setCreateuser(java.lang.String newCreateuser);
	/**
	 * getUpdatedate
	 */
	public java.math.BigDecimal getUpdatedate();
	/**
	 * setUpdatedate
	 */
	public void setUpdatedate(java.math.BigDecimal newUpdatedate);
	/**
	 * getUpdatetime
	 */
	public java.math.BigDecimal getUpdatetime();
	/**
	 * setUpdatetime
	 */
	public void setUpdatetime(java.math.BigDecimal newUpdatetime);
	/**
	 * getUpdateuser
	 */
	public java.lang.String getUpdateuser();
	/**
	 * setUpdateuser
	 */
	public void setUpdateuser(java.lang.String newUpdateuser);
	/**
	 * getUpdateprogram
	 */
	public java.lang.String getUpdateprogram();
	/**
	 * setUpdateprogram
	 */
	public void setUpdateprogram(java.lang.String newUpdateprogram);
	/**
	 * getRecordstatus
	 */
	public java.lang.String getRecordstatus();
	/**
	 * setRecordstatus
	 */
	public void setRecordstatus(java.lang.String newRecordstatus);
	/**
	 * getOCCColumn
	 */
	public long getOCCColumn();
}
