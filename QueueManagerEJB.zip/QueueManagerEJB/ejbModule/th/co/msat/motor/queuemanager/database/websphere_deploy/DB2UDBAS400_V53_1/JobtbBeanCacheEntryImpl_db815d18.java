package th.co.msat.motor.queuemanager.database.websphere_deploy.DB2UDBAS400_V53_1;

/**
 * JobtbBeanCacheEntryImpl_db815d18
 */
public class JobtbBeanCacheEntryImpl_db815d18 extends com.ibm.ws.ejbpersistence.cache.DataCacheEntry implements th.co.msat.motor.queuemanager.database.websphere_deploy.JobtbBeanCacheEntry_db815d18 {
	/**
	 * getJobid
	 */
	public java.math.BigDecimal getJobid() {
		return JOBID_Data;
	}
	/**
	 * setJobid
	 */
	public void setJobid(java.math.BigDecimal data) {
		if (data == null)
			this.JOBID_Data= null;
		else {
			this.JOBID_Data=data; }
	}
	/**
	 * setDataForJOBID
	 */
	public void setDataForJOBID(java.math.BigDecimal data) {
		this.JOBID_Data=data;
	}
	private java.math.BigDecimal JOBID_Data;
	/**
	 * getMessage
	 */
	public byte[] getMessage() {
		return MESSAGE_Data;
	}
	/**
	 * setMessage
	 */
	public void setMessage(byte[] data) {
		this.MESSAGE_Data=data;
	}
	/**
	 * setDataForMESSAGE
	 */
	public void setDataForMESSAGE(byte[] data) {
		this.MESSAGE_Data=data;
	}
	private byte[] MESSAGE_Data;
	/**
	 * getStatus
	 */
	public java.lang.String getStatus() {
		return STATUS_Data;
	}
	/**
	 * setStatus
	 */
	public void setStatus(String data) {
		this.STATUS_Data=data;
	}
	/**
	 * setDataForSTATUS
	 */
	public void setDataForSTATUS(String data) {
		this.STATUS_Data=data;
	}
	private String STATUS_Data;
	/**
	 * getPiority
	 */
	public java.math.BigDecimal getPiority() {
		return PIORITY_Data;
	}
	/**
	 * setPiority
	 */
	public void setPiority(java.math.BigDecimal data) {
		if (data == null)
			this.PIORITY_Data= null;
		else {
			this.PIORITY_Data=data; }
	}
	/**
	 * setDataForPIORITY
	 */
	public void setDataForPIORITY(java.math.BigDecimal data) {
		this.PIORITY_Data=data;
	}
	private java.math.BigDecimal PIORITY_Data;
	/**
	 * getSubmitdate
	 */
	public java.math.BigDecimal getSubmitdate() {
		return SUBMITDATE_Data;
	}
	/**
	 * setSubmitdate
	 */
	public void setSubmitdate(java.math.BigDecimal data) {
		if (data == null)
			this.SUBMITDATE_Data= null;
		else {
			this.SUBMITDATE_Data=data; }
	}
	/**
	 * setDataForSUBMITDATE
	 */
	public void setDataForSUBMITDATE(java.math.BigDecimal data) {
		this.SUBMITDATE_Data=data;
	}
	private java.math.BigDecimal SUBMITDATE_Data;
	/**
	 * getSubmittime
	 */
	public java.math.BigDecimal getSubmittime() {
		return SUBMITTIME_Data;
	}
	/**
	 * setSubmittime
	 */
	public void setSubmittime(java.math.BigDecimal data) {
		if (data == null)
			this.SUBMITTIME_Data= null;
		else {
			this.SUBMITTIME_Data=data; }
	}
	/**
	 * setDataForSUBMITTIME
	 */
	public void setDataForSUBMITTIME(java.math.BigDecimal data) {
		this.SUBMITTIME_Data=data;
	}
	private java.math.BigDecimal SUBMITTIME_Data;
	/**
	 * getSubmituser
	 */
	public java.lang.String getSubmituser() {
		return SUBMITUSER_Data;
	}
	/**
	 * setSubmituser
	 */
	public void setSubmituser(String data) {
		this.SUBMITUSER_Data=data;
	}
	/**
	 * setDataForSUBMITUSER
	 */
	public void setDataForSUBMITUSER(String data) {
		this.SUBMITUSER_Data=data;
	}
	private String SUBMITUSER_Data;
	/**
	 * getUpdatedate
	 */
	public java.math.BigDecimal getUpdatedate() {
		return UPDATEDATE_Data;
	}
	/**
	 * setUpdatedate
	 */
	public void setUpdatedate(java.math.BigDecimal data) {
		if (data == null)
			this.UPDATEDATE_Data= null;
		else {
			this.UPDATEDATE_Data=data; }
	}
	/**
	 * setDataForUPDATEDATE
	 */
	public void setDataForUPDATEDATE(java.math.BigDecimal data) {
		this.UPDATEDATE_Data=data;
	}
	private java.math.BigDecimal UPDATEDATE_Data;
	/**
	 * getUpdatetime
	 */
	public java.math.BigDecimal getUpdatetime() {
		return UPDATETIME_Data;
	}
	/**
	 * setUpdatetime
	 */
	public void setUpdatetime(java.math.BigDecimal data) {
		if (data == null)
			this.UPDATETIME_Data= null;
		else {
			this.UPDATETIME_Data=data; }
	}
	/**
	 * setDataForUPDATETIME
	 */
	public void setDataForUPDATETIME(java.math.BigDecimal data) {
		this.UPDATETIME_Data=data;
	}
	private java.math.BigDecimal UPDATETIME_Data;
	/**
	 * getUpdateuser
	 */
	public java.lang.String getUpdateuser() {
		return UPDATEUSER_Data;
	}
	/**
	 * setUpdateuser
	 */
	public void setUpdateuser(String data) {
		this.UPDATEUSER_Data=data;
	}
	/**
	 * setDataForUPDATEUSER
	 */
	public void setDataForUPDATEUSER(String data) {
		this.UPDATEUSER_Data=data;
	}
	private String UPDATEUSER_Data;
	/**
	 * getUpdateprogram
	 */
	public java.lang.String getUpdateprogram() {
		return UPDATEPROGRAM_Data;
	}
	/**
	 * setUpdateprogram
	 */
	public void setUpdateprogram(String data) {
		this.UPDATEPROGRAM_Data=data;
	}
	/**
	 * setDataForUPDATEPROGRAM
	 */
	public void setDataForUPDATEPROGRAM(String data) {
		this.UPDATEPROGRAM_Data=data;
	}
	private String UPDATEPROGRAM_Data;
	/**
	 * getRecordstatus
	 */
	public java.lang.String getRecordstatus() {
		return RECORDSTATUS_Data;
	}
	/**
	 * setRecordstatus
	 */
	public void setRecordstatus(String data) {
		this.RECORDSTATUS_Data=data;
	}
	/**
	 * setDataForRECORDSTATUS
	 */
	public void setDataForRECORDSTATUS(String data) {
		this.RECORDSTATUS_Data=data;
	}
	private String RECORDSTATUS_Data;
	/**
	 * getReferenceno
	 */
	public java.lang.String getReferenceno() {
		return REFERENCENO_Data;
	}
	/**
	 * setReferenceno
	 */
	public void setReferenceno(String data) {
		this.REFERENCENO_Data=data;
	}
	/**
	 * setDataForREFERENCENO
	 */
	public void setDataForREFERENCENO(String data) {
		this.REFERENCENO_Data=data;
	}
	private String REFERENCENO_Data;
	/**
	 * getJobgroup
	 */
	public java.math.BigDecimal getJobgroup() {
		return JOBGROUP_Data;
	}
	/**
	 * setJobgroup
	 */
	public void setJobgroup(java.math.BigDecimal data) {
		if (data == null)
			this.JOBGROUP_Data= null;
		else {
			this.JOBGROUP_Data=data; }
	}
	/**
	 * setDataForJOBGROUP
	 */
	public void setDataForJOBGROUP(java.math.BigDecimal data) {
		this.JOBGROUP_Data=data;
	}
	private java.math.BigDecimal JOBGROUP_Data;
	/**
	 * getQ_msatlib_jobtb_queueid_00001_queueid
	 */
	public java.math.BigDecimal getQ_msatlib_jobtb_queueid_00001_queueid() {
		return QUEUEID_Data;
	}
	/**
	 * setQ_msatlib_jobtb_queueid_00001_queueid
	 */
	public void setQ_msatlib_jobtb_queueid_00001_queueid(java.math.BigDecimal data) {
		if (data == null)
			this.QUEUEID_Data= null;
		else {
			this.QUEUEID_Data=data; }
	}
	/**
	 * setDataForQUEUEID
	 */
	public void setDataForQUEUEID(java.math.BigDecimal data) {
		this.QUEUEID_Data=data;
	}
	private java.math.BigDecimal QUEUEID_Data;
	/**
	 * getOCCColumn
	 */
	public long getOCCColumn() {
		return 0;
	}
	/**
	 * getQ_msatlib_jobtb_queueid_00001Key
	 */
	public th.co.msat.motor.queuemanager.database.QueuetbKey getQ_msatlib_jobtb_queueid_00001Key() {
		if(QUEUEID_Data==null)
			return null;
		th.co.msat.motor.queuemanager.database.QueuetbKey key=new th.co.msat.motor.queuemanager.database.QueuetbKey();
		key.queueid=QUEUEID_Data;
		return key;
	}
	/**
	 * setQ_msatlib_jobtb_queueid_00001Key
	 */
	public void setQ_msatlib_jobtb_queueid_00001Key(th.co.msat.motor.queuemanager.database.QueuetbKey data) {
		if(data==null)
		{
			this.QUEUEID_Data= null;
		}
		else {
		if (data.queueid == null)
			this.QUEUEID_Data= null;
		else {
			this.QUEUEID_Data=data.queueid; }
		}
	}
	/**
	 * getForeignKey
	 */
	public Object getForeignKey(String role) {
		if(role.equals("q_msatlib_jobtb_queueid_00001"))
			return getQ_msatlib_jobtb_queueid_00001Key();
		else
			return null;
	}
}
