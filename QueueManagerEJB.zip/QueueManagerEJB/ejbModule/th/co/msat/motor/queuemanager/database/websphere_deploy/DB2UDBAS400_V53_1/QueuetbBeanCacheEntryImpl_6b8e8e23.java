package th.co.msat.motor.queuemanager.database.websphere_deploy.DB2UDBAS400_V53_1;

/**
 * QueuetbBeanCacheEntryImpl_6b8e8e23
 */
public class QueuetbBeanCacheEntryImpl_6b8e8e23 extends com.ibm.ws.ejbpersistence.cache.DataCacheEntry implements th.co.msat.motor.queuemanager.database.websphere_deploy.QueuetbBeanCacheEntry_6b8e8e23 {
	/**
	 * getQueueid
	 */
	public java.math.BigDecimal getQueueid() {
		return QUEUEID_Data;
	}
	/**
	 * setQueueid
	 */
	public void setQueueid(java.math.BigDecimal data) {
		if (data == null)
			this.QUEUEID_Data= null;
		else {
			this.QUEUEID_Data=data; }
	}
	/**
	 * setDataForQUEUEID
	 */
	public void setDataForQUEUEID(java.math.BigDecimal data) {
		this.QUEUEID_Data=data;
	}
	private java.math.BigDecimal QUEUEID_Data;
	/**
	 * getQueuename
	 */
	public java.lang.String getQueuename() {
		return QUEUENAME_Data;
	}
	/**
	 * setQueuename
	 */
	public void setQueuename(String data) {
		this.QUEUENAME_Data=data;
	}
	/**
	 * setDataForQUEUENAME
	 */
	public void setDataForQUEUENAME(String data) {
		this.QUEUENAME_Data=data;
	}
	private String QUEUENAME_Data;
	/**
	 * getSize
	 */
	public java.math.BigDecimal getSize() {
		return SIZE_Data;
	}
	/**
	 * setSize
	 */
	public void setSize(java.math.BigDecimal data) {
		if (data == null)
			this.SIZE_Data= null;
		else {
			this.SIZE_Data=data; }
	}
	/**
	 * setDataForSIZE
	 */
	public void setDataForSIZE(java.math.BigDecimal data) {
		this.SIZE_Data=data;
	}
	private java.math.BigDecimal SIZE_Data;
	/**
	 * getAvailable
	 */
	public java.math.BigDecimal getAvailable() {
		return AVAILABLE_Data;
	}
	/**
	 * setAvailable
	 */
	public void setAvailable(java.math.BigDecimal data) {
		if (data == null)
			this.AVAILABLE_Data= null;
		else {
			this.AVAILABLE_Data=data; }
	}
	/**
	 * setDataForAVAILABLE
	 */
	public void setDataForAVAILABLE(java.math.BigDecimal data) {
		this.AVAILABLE_Data=data;
	}
	private java.math.BigDecimal AVAILABLE_Data;
	/**
	 * getIsterminate
	 */
	public java.lang.String getIsterminate() {
		return ISTERMINATE_Data;
	}
	/**
	 * setIsterminate
	 */
	public void setIsterminate(String data) {
		this.ISTERMINATE_Data=data;
	}
	/**
	 * setDataForISTERMINATE
	 */
	public void setDataForISTERMINATE(String data) {
		this.ISTERMINATE_Data=data;
	}
	private String ISTERMINATE_Data;
	/**
	 * getWorkingtime
	 */
	public java.math.BigDecimal getWorkingtime() {
		return WORKINGTIME_Data;
	}
	/**
	 * setWorkingtime
	 */
	public void setWorkingtime(java.math.BigDecimal data) {
		if (data == null)
			this.WORKINGTIME_Data= null;
		else {
			this.WORKINGTIME_Data=data; }
	}
	/**
	 * setDataForWORKINGTIME
	 */
	public void setDataForWORKINGTIME(java.math.BigDecimal data) {
		this.WORKINGTIME_Data=data;
	}
	private java.math.BigDecimal WORKINGTIME_Data;
	/**
	 * getMessageclass
	 */
	public java.lang.String getMessageclass() {
		return MESSAGECLASS_Data;
	}
	/**
	 * setMessageclass
	 */
	public void setMessageclass(String data) {
		this.MESSAGECLASS_Data=data;
	}
	/**
	 * setDataForMESSAGECLASS
	 */
	public void setDataForMESSAGECLASS(String data) {
		this.MESSAGECLASS_Data=data;
	}
	private String MESSAGECLASS_Data;
	/**
	 * getActivateclass
	 */
	public java.lang.String getActivateclass() {
		return ACTIVATECLASS_Data;
	}
	/**
	 * setActivateclass
	 */
	public void setActivateclass(String data) {
		this.ACTIVATECLASS_Data=data;
	}
	/**
	 * setDataForACTIVATECLASS
	 */
	public void setDataForACTIVATECLASS(String data) {
		this.ACTIVATECLASS_Data=data;
	}
	private String ACTIVATECLASS_Data;
	/**
	 * getCreatedate
	 */
	public java.math.BigDecimal getCreatedate() {
		return CREATEDATE_Data;
	}
	/**
	 * setCreatedate
	 */
	public void setCreatedate(java.math.BigDecimal data) {
		if (data == null)
			this.CREATEDATE_Data= null;
		else {
			this.CREATEDATE_Data=data; }
	}
	/**
	 * setDataForCREATEDATE
	 */
	public void setDataForCREATEDATE(java.math.BigDecimal data) {
		this.CREATEDATE_Data=data;
	}
	private java.math.BigDecimal CREATEDATE_Data;
	/**
	 * getCreatetime
	 */
	public java.math.BigDecimal getCreatetime() {
		return CREATETIME_Data;
	}
	/**
	 * setCreatetime
	 */
	public void setCreatetime(java.math.BigDecimal data) {
		if (data == null)
			this.CREATETIME_Data= null;
		else {
			this.CREATETIME_Data=data; }
	}
	/**
	 * setDataForCREATETIME
	 */
	public void setDataForCREATETIME(java.math.BigDecimal data) {
		this.CREATETIME_Data=data;
	}
	private java.math.BigDecimal CREATETIME_Data;
	/**
	 * getCreateuser
	 */
	public java.lang.String getCreateuser() {
		return CREATEUSER_Data;
	}
	/**
	 * setCreateuser
	 */
	public void setCreateuser(String data) {
		this.CREATEUSER_Data=data;
	}
	/**
	 * setDataForCREATEUSER
	 */
	public void setDataForCREATEUSER(String data) {
		this.CREATEUSER_Data=data;
	}
	private String CREATEUSER_Data;
	/**
	 * getUpdatedate
	 */
	public java.math.BigDecimal getUpdatedate() {
		return UPDATEDATE_Data;
	}
	/**
	 * setUpdatedate
	 */
	public void setUpdatedate(java.math.BigDecimal data) {
		if (data == null)
			this.UPDATEDATE_Data= null;
		else {
			this.UPDATEDATE_Data=data; }
	}
	/**
	 * setDataForUPDATEDATE
	 */
	public void setDataForUPDATEDATE(java.math.BigDecimal data) {
		this.UPDATEDATE_Data=data;
	}
	private java.math.BigDecimal UPDATEDATE_Data;
	/**
	 * getUpdatetime
	 */
	public java.math.BigDecimal getUpdatetime() {
		return UPDATETIME_Data;
	}
	/**
	 * setUpdatetime
	 */
	public void setUpdatetime(java.math.BigDecimal data) {
		if (data == null)
			this.UPDATETIME_Data= null;
		else {
			this.UPDATETIME_Data=data; }
	}
	/**
	 * setDataForUPDATETIME
	 */
	public void setDataForUPDATETIME(java.math.BigDecimal data) {
		this.UPDATETIME_Data=data;
	}
	private java.math.BigDecimal UPDATETIME_Data;
	/**
	 * getUpdateuser
	 */
	public java.lang.String getUpdateuser() {
		return UPDATEUSER_Data;
	}
	/**
	 * setUpdateuser
	 */
	public void setUpdateuser(String data) {
		this.UPDATEUSER_Data=data;
	}
	/**
	 * setDataForUPDATEUSER
	 */
	public void setDataForUPDATEUSER(String data) {
		this.UPDATEUSER_Data=data;
	}
	private String UPDATEUSER_Data;
	/**
	 * getUpdateprogram
	 */
	public java.lang.String getUpdateprogram() {
		return UPDATEPROGRAM_Data;
	}
	/**
	 * setUpdateprogram
	 */
	public void setUpdateprogram(String data) {
		this.UPDATEPROGRAM_Data=data;
	}
	/**
	 * setDataForUPDATEPROGRAM
	 */
	public void setDataForUPDATEPROGRAM(String data) {
		this.UPDATEPROGRAM_Data=data;
	}
	private String UPDATEPROGRAM_Data;
	/**
	 * getRecordstatus
	 */
	public java.lang.String getRecordstatus() {
		return RECORDSTATUS_Data;
	}
	/**
	 * setRecordstatus
	 */
	public void setRecordstatus(String data) {
		this.RECORDSTATUS_Data=data;
	}
	/**
	 * setDataForRECORDSTATUS
	 */
	public void setDataForRECORDSTATUS(String data) {
		this.RECORDSTATUS_Data=data;
	}
	private String RECORDSTATUS_Data;
	/**
	 * getOCCColumn
	 */
	public long getOCCColumn() {
		return 0;
	}
}
