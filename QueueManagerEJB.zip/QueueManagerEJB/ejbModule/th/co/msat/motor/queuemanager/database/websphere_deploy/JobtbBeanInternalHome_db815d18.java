package th.co.msat.motor.queuemanager.database.websphere_deploy;

/**
 * Internal Home interface for Enterprise Bean: Jobtb
 */
public interface JobtbBeanInternalHome_db815d18 extends javax.ejb.EJBHome {
}
