package th.co.msat.motor.queuemanager.database.websphere_deploy;

/**
 * Internal Local Home interface for Enterprise Bean: Queuetb
 */
public interface QueuetbBeanInternalLocalHome_6b8e8e23 {
	/**
	 * findQ_msatlib_jobtb_queueid_00001ByJobtbKey_Local
	 */
	public th.co.msat.motor.queuemanager.database.QueuetbLocal findQ_msatlib_jobtb_queueid_00001ByJobtbKey_Local(th.co.msat.motor.queuemanager.database.JobtbKey key) throws javax.ejb.FinderException;
	/**
	 * findByPrimaryKeyForCMR
	 */
	public th.co.msat.motor.queuemanager.database.QueuetbLocal findByPrimaryKeyForCMR(th.co.msat.motor.queuemanager.database.QueuetbKey key) throws javax.ejb.FinderException;
}
