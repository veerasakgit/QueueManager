package th.co.msat.motor.queuemanager.database.websphere_deploy;

/**
 * Injector interface for Enterprise Bean: Jobtb
 */
public interface JobtbBeanInjector_db815d18 extends com.ibm.ws.ejbpersistence.beanextensions.EJBPartialInjector {
	/**
	 * findJobtbByQ_msatlib_jobtb_queueid_00001Key_Local
	 */
	public void findJobtbByQ_msatlib_jobtb_queueid_00001Key_Local(th.co.msat.motor.queuemanager.database.QueuetbKey key, javax.resource.cci.IndexedRecord record);
}
